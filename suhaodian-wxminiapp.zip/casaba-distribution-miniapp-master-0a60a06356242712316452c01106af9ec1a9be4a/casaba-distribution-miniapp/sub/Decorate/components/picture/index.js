import link from '../../utils/link'
Component({
  properties: {
    type: {
      type: String,
      value: 'rowOne',
    },
    picsList: {
      type: Array,
      value: [],
    },
    padding: {
      type: Boolean,
      value: true,
    },
    content: Object,
  },
  methods: {
    handleJump({ currentTarget }) {
      console.log('图片======', currentTarget.dataset.item)
      const { swiper2Url } = currentTarget.dataset.item
      link.bind(this, currentTarget.dataset.item, swiper2Url)()
    },
  },
})
