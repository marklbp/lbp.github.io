 /* 首先require 加载两个模块 */
 var http         = require('http'), 
	 fs           = require('fs'),
	 url   	      = require('url'),
	 querystring  = require('querystring'),
	 httpParam    = require('./http_param'),
	 staticModule = require('./static_module');
var BASE_DIR      = __dirname;
http.createServer(function(req, res) {
	var pathname = url.parse(req.url).pathname;
	httpParam.init(req, res);
	switch(pathname){
		case '/upload' : upload(res, req);
		break;
		case '/image'  : showImage(res, req);
		break;
		default        : defaultIndex(res);
		break;
	}
}).listen(1337);

function defaultIndex(res){
	/* 获取当前index.html的路径 */
	var readPath = __dirname + '/' +url.parse('index.html').pathname;
	var indexPage = fs.readFileSync(readPath);
	res.writeHead(200, { 'Content-Type': 'text/html' });
	res.end(indexPage);
}

function upload(res, req){
	var readPath = __dirname + '/' +url.parse('show_image.html').pathname;
	var indexPage = fs.readFileSync(readPath);
    // 设置接收数据编码格式为 UTF-8
    req.setEncoding('utf8');
	httpParam.POST('image', function(image){
		var tmp_path = image.path,
			target_path = BASE_DIR . '/uploadFile/test.png';
		fs.rename(tmp_path, target_path, function(err) {
            if (err) throw err;
            // 删除临时文件夹文件,
            Module.fs.unlink(tmp_path, function() {
                if (err) throw err;
                res.writeHead(200, { 'Content-Type': 'text/html' });
				res.end(indexPage);
            });
        });
	});
}

function showImage(res, req){
    res.writeHead(200, { 'Content-Type': 'text/html' });
	res.end({'retCode':0, 'imageUrl': '/uploadFile/test.png'});
}