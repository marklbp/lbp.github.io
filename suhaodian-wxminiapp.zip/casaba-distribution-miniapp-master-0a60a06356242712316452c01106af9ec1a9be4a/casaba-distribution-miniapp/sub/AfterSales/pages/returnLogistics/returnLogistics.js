import {
  getReturnDetail,
  saveReturnLogistics,
  getReturnLogistics,
  getExpressDetails,
} from '../../../../api/index'
import { get, set } from '../../../../utils/storage.js'

const app = getApp()
Page({
  data: {
    rejectedInfo: null,
    refundTotalCount: '',
    productlist: null,
    listLoading: false,
    isShowReloadBtn: false,
    express: null,
    expressCode: '',
    phone: '',
    logisticsSaved: false,
    logisticsInfo: null,
  },
  onLoad: function(query) {
    // 获取退货详情
    this.setData({ returnId: query.returnId })
    var postdata = {
      tenantCode: app.globalData.tenantCode,
      orderId: this.data.returnId,
    }
    this.queryReturnOrderDetail(postdata)
    this.getReturnLogistics()
  },
  saveExpressCode: function(event) {
    this.setData({
      expressCode: event.detail.value,
    })
  },
  savephone: function(event) {
    this.setData({
      phone: event.detail.value,
    })
  },
  postData: function() {
    var refundOrder = wx.getStorageSync('refundOrder')
    refundOrder = JSON.parse(refundOrder)
    if (!this.data.phone.trim()) {
      wx.showToast({
        title: '请输入手机号码',
        icon: 'none',
        duration: 2000,
      })
      return
    }
    if (!this.data.expressCode.trim()) {
      wx.showToast({
        title: '请输入物流单号',
        icon: 'none',
        duration: 2000,
      })
      return
    }
    saveReturnLogistics({
      orderId: refundOrder.orderId,
      spuCode: refundOrder.spuCode,
      expressCompany: this.data.express.companyName,
      expressNumber: this.data.expressCode,
      phone: this.data.phone,
    })
      .then(res => {
        if (res.code === '0') {
          wx.showToast({
            showToast: '保存成功',
            icon: 'none',
            duration: 2000,
          })
          set('chosedExpress', '')
          app.router.navigateBack()
        } else {
          wx.showToast({
            title: res.message,
            icon: 'none',
            duration: 2000,
          })
        }
      })
      .catch(e => {
        wx.showToast({
          title: e.message,
          icon: 'none',
          duration: 2000,
        })
        console.log(e)
      })
  },
  onShow: function() {
    let chosed = get('chosedExpress', null)
    this.setData({
      express: chosed,
    })
  },
  queryReturnOrderDetail(data) {
    this.setData({
      listLoading: true,
    })
    getReturnDetail({
      tenantCode: app.globalData.tenantCode,
      orderId: this.data.returnId,
    })
      .then(res => {
        if (res.code === '0') {
          const result = res.data[0]
          const ro = get('rejectedProduct', [])
          const orderPorductOutList = [ro]
          let refundTotalCount = 0
          const _product = result.lines.map(i => {
            const someItem = orderPorductOutList.find(j => j.skuId === i.skuId)
            if (someItem) {
              return {
                ...someItem,
                ...i,
              }
            } else {
              return i
            }
          })
          _product.forEach(i => {
            // i.isGift === undefined 防止getStorageSync出错的判断
            if (i.isGift === '0' || i.isGift === undefined) {
              refundTotalCount += i.count
            }
          })

          this.setData({
            rejectedInfo: result,
            refundTotalCount: refundTotalCount,
            productlist: _product,
            listLoading: false,
            isShowReloadBtn: false,
          })
        }
      })
      .catch(() => {
        this.setData({
          listLoading: false,
          isShowReloadBtn: true,
        })
      })
  },
  goChoseLogistics() {
    // 选择物流公司
    app.router.navigateTo('/sub/AfterSales/pages/choseLogistics/choseLogistics')
  },
  getReturnLogistics() {
    var refundOrder = wx.getStorageSync('refundOrder')
    refundOrder = JSON.parse(refundOrder)
    getReturnLogistics({
      orderId: refundOrder.orderId,
      spuCode: refundOrder.spuCode,
    })
      .then(res => {
        if (res.code === '0') {
          this.setData({
            logisticsSaved: true,
            logisticsInfo: res.data[0],
          })
          wx.setNavigationBarTitle({
            title: '查询退货物流',
          })
          this.getExpressDetails({
            expressCompany: res.data[0]['expressCompany'],
            expressNumber: res.data[0]['expressNumber'],
          })
        }
      })
      .catch(e => {
        console.log(e)
      })
  },
  // 获取物流详情
  getExpressDetails(data) {
    getExpressDetails(data)
      .then(res => {
        if (res.code === '0') {
          this.setData({
            logisticsInfo: Object.assign(this.data.logisticsInfo, {
              lists: res.data,
            }),
          })
        }
      })
      .catch(e => {
        console.log('物流详情错误', e)
      })
  },
})
