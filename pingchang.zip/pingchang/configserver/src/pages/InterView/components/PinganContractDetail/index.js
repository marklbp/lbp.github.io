import PinganContractDetail from './PinganContractDetail';

export default PinganContractDetail;
