import { prepayOrderAction } from '../honghu/index'
// import { formatTime } from '../utils/util'
let orderbak = null

var pay = function(order) {
  orderbak = order
  if (order.isHonghu !== false && order['externalOrderId']) {
    return prepayOrderAction(order.orderId)
      .then(({ data: { orderPrepay } }) => requestPayment(orderPrepay))
      .catch(() => {
        order.isHonghu = false
        this.bindPayMent()
      })
  }

  const orderId = order.orderId
  // const orderTime = formatTime(new Date()).replace(/-|:| /g, '')
  const orderTime = order.orderDate.replace(/-|:| /g, '')
  const app = getApp()
  const amount =
    order.amount.toString().indexOf(',') > 0
      ? order.amount.replace(',', '')
      : order.amount
  let data = {
    channelType: 'weixin',
    currency: 'cny',
    extendParams:
      '{"openid":"' +
      app.globalData.openid +
      '","spbill_create_ip":"127.0.0.1"}',
    memo: orderId,
    orderDesc: orderId,
    payAmount: amount,
    paymentType: 'applet',
    tenantCode: app.globalData.tenantCode,
    tenantOrderNo: orderId,
    tenantOrderTime: orderTime,
    tenantReturnUrl: 'https://casabaplus.baozun.com',
  }

  app.http({
    url: '/casaba/trade/payOrder',
    data: data,
    header: {
      xAuthToken: app.globalData.xAuthToken,
      unexUserToken: app.globalData.unexUserToken,
      'invoke-source': app.globalData['invoke-source'],
    },
    success: function(res) {
      console.log('payOrder', res)
      if (res.data.code !== '0') {
        wx.showModal({
          title: '微信支付',
          content: res.data.msg || res.data.errMsg || '服务器出错',
          showCancel: false,
          confirmText: '刷新',
          success: function() {
            const route = getCurrentPages()
            const currentPage = route[route.length - 1]
            currentPage.onShow()
          },
        })
        // $this.setData({ clickPay: false })
      } else {
        // 发起支付
        requestPayment({
          timeStamp: res.data.data.weixin_timestamp,
          nonceStr: res.data.data.weixin_nonce_str,
          package: res.data.data.weixin_wx_package,
          signType: 'MD5',
          paySign: res.data.data.weixin_sign,
        })
      }
    },
    fail: function(res) {
      // $this.setData({ clickPay: false })
      console.log('支付失败', res)
    },
  })
}

function requestPayment(payment) {
  wx.requestPayment({
    ...payment,
    fail: res => {
      console.log('支付', res)
      if (res.errMsg.split(' ')[1] === 'cancel') {
        wx.showToast({
          title: '取消支付',
          icon: 'none',
          duration: 2000,
        })
      } else {
        wx.showModal({
          title: '调用支付失败',
          content: res.err_desc || res,
        })
      }
      const route = getCurrentPages()
      const currentPage = route[route.length - 1]
      if (
        currentPage &&
        currentPage.route === 'sub/Pay/pages/againMoney/againMoney'
      ) {
        currentPage.handlequeryOrderOpenDetail(currentPage.options)
      } else {
        wx.redirectTo({
          url:
            '/sub/Pay/pages/againMoney/againMoney?orderId=' + orderbak.orderId,
        })
      }
    },
    success: () => {
      wx.showToast({
        title: '支付成功',
        icon: 'success',
        duration: 2000,
      })
      setTimeout(() => {
        wx.redirectTo({
          url:
            '/sub/Pay/pages/paysuccess/paysuccess?orderId=' +
            orderbak.orderId +
            '&receivedAmount=' +
            orderbak.amount +
            '&iphone=' +
            orderbak.orderReceiptInfoOut.mobile,
        })
        // resolve(res)
      }, 2000)
    },
    complete: () => {
      // this.setData({ clickPay: false })
    },
  })
}

export default pay
