export const loginStr = `mutation($appCode: String!, $code: String!) {
  user: memberWechatAuthenticate(appCode: $appCode, code: $code) {
    sessionKey
    token:accessToken
    nickName
    avatarUrl
    openid
  }
}
`

export const updateUserStr = `mutation ($data: UpdateMemberInput!){ 
  memberUpdate(input: $data) {
    id
    code
    nickName
    avatarUrl
  }
}`
