import { createRefundment } from '../../../../api/index'
import { get } from '../../../../utils/storage.js'
import { formatPrice } from '../../../../utils/util'

const app = getApp()

Page({
  data: {
    rejectedProduct: null,
    listLoading: false,
    currentreason: [],
    _currentReason: '',
    coutOfProduct: 1,
    reasonsMask: false,
    postLoading: false, // 提交状态
    refundDesc: '',
    returnAmount: '',
    returnMode: '11', // 11退货21换货31返修41仅退款
    // 退货原因
    reasonList: [],
    isMajorCustomer: false,
  },
  onLoad: function(query) {
    // 获取 退货的商品
    const ro = get('refundOrder', null)
    let reasonLibrary = {
      rejected: [
        '商品质量问题',
        '商品与页面描述不符',
        '大小/尺寸与商品描述不符',
        '收到商品破损',
        '商品错发',
        '商品漏发',
        '无理由退货',
      ],
      refund: [
        '不喜欢/不想要',
        '空包裹',
        '快递/物流一直未送到',
        '快递/物流无跟踪记录',
        '货物破损已拒签',
      ],
    }
    this.setData({
      rejectedProduct: ro,
      coutOfProduct: ro.returnableCount || 1,
      returnAmount: formatPrice(ro.amount),
      returnMode: query.mode === '0' ? '41' : '11',
      reasonList:
        query.mode === '0' ? reasonLibrary.refund : reasonLibrary.rejected,
      isMajorCustomer: app.globalData.isMajorCustomer,
    })
    this.changemode(query.mode)
  },
  changemode(mode) {
    if (mode === '0') {
      // 仅退款
      wx.setNavigationBarTitle({
        title: '退款详情',
      })
    } else {
      // 退货退款
      wx.setNavigationBarTitle({
        title: '退货详情',
      })
    }
  },
  handleOpenReasonSheet() {
    this.setData({
      reasonsMask: true,
    })
  },
  onReasonCancel() {
    this.setData({
      reasonsMask: false,
    })
  },
  onReasonChange({ detail }) {
    if (detail.checked) {
      this.setData({
        currentReason: [detail.value],
        _currentReason: detail.value,
      })
    } else {
      this.setData({
        currentReason: [],
        _currentReason: '',
      })
    }
  },
  onChangeCount({ detail }) {
    const totalCount = this.data.rejectedProduct.returnableCount
    const totalAmount = this.data.rejectedProduct.amount
    const perAmount = (totalAmount * 100) / (totalCount * 100)
    let amount = formatPrice(perAmount * detail.value)
    if (detail.value === totalCount) {
      amount = formatPrice(totalAmount)
    }

    this.setData({
      coutOfProduct: detail.value,
      returnAmount: amount,
    })
  },
  handleRefundDesc({ detail }) {
    this.setData({
      refundDesc: detail.value,
    })
  },
  handlePost() {
    // 创建退货单
    this.setData({
      postLoading: true,
    })
    let orderReturnLineCreateInfoIns = [
      {
        count: this.data.coutOfProduct,
        orderProdureId: this.data.rejectedProduct.id,
        description: this.data._currentReason,
      },
    ]
    if (this.data.isMajorCustomer) {
      orderReturnLineCreateInfoIns = this.data.rejectedProduct.prods.map(
        item => {
          return {
            count: item.count,
            orderProdureId: item.id,
            description: this.data._currentReason,
          }
        }
      )
    }
    let postdata = {
      orderId: this.data.rejectedProduct.orderId,
      returnMode: this.data.returnMode,
      pickupMode: '21', // 11上门取件21寄送仓库31寄送自提点
      isInvoice: '0', // 1有发票 0无发票
      description: this.data.refundDesc,
      // reason: this.data._currentReason,
      tenantCode: app.globalData.tenantCode,
      orderReturnLineCreateInfoIns: orderReturnLineCreateInfoIns,
    }
    createRefundment(postdata, {
      xAuthToken: app.globalData.xAuthToken,
    })
      .then(res => {
        if (res.code === '0') {
          const route = getCurrentPages()
          if (route[route.length - 2].pubRefresh) {
            route[route.length - 2].pubRefresh()
          }
          let url = ''
          if (this.data.returnMode === '41') {
            url = `/sub/AfterSales/pages/refundsDetails/refundsDetails?returnId=${
              res.data
            }&orderId=${this.data.rejectedProduct.orderId}`
          } else {
            url = `/sub/AfterSales/pages/rejectedGoodsDetail/rejectedGoodsDetail?returnId=${
              res.data
            }&orderId=${this.data.rejectedProduct.orderId}&mode=${
              this.data.returnMode
            }`
          }
          app.router.redirectTo(url)
        } else {
          var reg = /=(.*)}/g
          let message = res.message
          if (reg.test(res.message)) {
            message = res.message
              .match(reg)[0]
              .replace('=', '')
              .replace('}', '')
          }
          wx.showToast({
            title: message,
            icon: 'none',
            duration: 3000,
          })
          this.setData({ postLoading: false })
        }
      })
      .catch(err => {
        this.setData({ postLoading: false })
        console.log('创建退货单', err)
      })
  },
})
