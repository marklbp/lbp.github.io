/**
 * 该文件系自动生成，手动修改可能会被替换
 * 可以通过node generate-router.js自动生成
 */
//import AbcRoute from "./pages/Abc/AbcRoute.js"
import AccountRoute from "./pages/Account/AccountRoute.js"
import ContractRoute from "./pages/Contract/ContractRoute.js"
import ContractEditRoute from "./pages/ContractEdit/ContractEditRoute.js"
import ContractFileRoute from "./pages/ContractFile/ContractFileRoute.js"
import DemoRoute from "./pages/Demo/DemoRoute.js"
import EnterQueryRoute from "./pages/EntryQuery/EnterQueryRoute.js"
import ExamineApproveRoute from "./pages/ExamineApprove/ExamineApproveRoute.js"
import fontConfigRouter from "./pages/FontConfig/fontConfigRouter.js"
import LoanApplicationRoute from "./pages/LoanApplication/LoanApplicationRoute.js"
import MaterialSubmitRoute from "./pages/MaterialSubmit/MaterialSubmitRoute.js"
import ProcessRoute from "./pages/Process/ProcessRoute.js"
import ProductRoute from "./pages/Product/ProductRoute.js"
import ReviewApproveRoute from "./pages/ReviewApprove/ReviewApproveRoute.js"

export default [
    //AbcRoute,
    AccountRoute,
    ContractRoute,
    ContractEditRoute,
    ContractFileRoute,
    DemoRoute,
    EnterQueryRoute,
    ExamineApproveRoute,
    fontConfigRouter,
    LoanApplicationRoute,
    MaterialSubmitRoute,
    ProcessRoute,
    ProductRoute,
    ReviewApproveRoute
];
