import SetFontFieldsets from './SetFontFieldsets';

export default SetFontFieldsets;