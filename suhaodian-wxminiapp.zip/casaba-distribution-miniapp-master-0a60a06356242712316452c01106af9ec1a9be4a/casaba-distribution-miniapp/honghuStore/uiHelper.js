/* global wx */
export const PROMPT_DURATION_TIME = 2500

export const showLoading = function({
  title = '',
  mask,
  success,
  fail,
  complete,
} = {}) {
  wx.showLoading({ title, mask, success, fail, complete })
}

export const hideLoading = function() {
  wx.hideLoading()
}

export const showToast = function({
  title,
  image,
  mask,
  icon = 'none',
  duration = PROMPT_DURATION_TIME,
  success,
  fail,
  complete,
} = {}) {
  wx.showToast({ title, image, mask, icon, duration, success, fail, complete })
}

export const hideToast = function() {
  wx.hideToast()
}

export const navigateTo = function(url) {
  wx.navigateTo({ url })
}

export default {
  showLoading,
  hideLoading,
  showToast,
  hideToast,
}
