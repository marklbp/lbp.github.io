function omit(value, key) {
  delete value[key]
  return value
}

export const padTime = value => {
  if (value < 10) {
    return `0${value}`
  }
  return value.toString()
}

export const REAMINING_TIME_TYPE = {
  BY_DAY: 'BY_DAY',
  BY_HOUR: 'BY_HOUR',
  BY_MINUTE: 'BY_MINUTE',
}

export const getRemainingTime = function(
  timestamp,
  type = REAMINING_TIME_TYPE.BY_HOUR,
  isFill0ForDay = true
) {
  const result = {
    day: isFill0ForDay ? '00' : 0,
    hours: '00',
    minutes: '00',
    seconds: '00',
  }
  if (!timestamp) {
    return type === REAMINING_TIME_TYPE.BY_DAY ? result : omit(result, 'day')
  }
  const originTime = new Date(1970, 0, 1, 0, 0, 0, 0)
  const campaignEndTime = new Date(timestamp)
  const currentTime = new Date()
  let deviationTime = 0
  // 当前sdk window开发者工具 执行wx.getStorageSync 直接挂掉，try catch都catch不了
  // try {
  //   deviationTime = wx.getStorageSync('deviationTime')
  // } catch (e) {
  //   deviationTime = 0
  // }

  let differenceTimestamp = campaignEndTime - currentTime + deviationTime
  if (differenceTimestamp < 0) {
    differenceTimestamp = 0
  }
  const differenceTime = new Date(parseInt(differenceTimestamp))
  differenceTime.setHours(differenceTime.getHours() - 8)
  result.day =
    differenceTime.getDate() -
    originTime.getDate() +
    (differenceTime.getMonth() - originTime.getMonth()) * 30
  result.hours = differenceTime.getHours() - originTime.getHours()
  result.minutes = differenceTime.getMinutes() - originTime.getMinutes()
  result.seconds = differenceTime.getSeconds() - originTime.getSeconds()
  if (type === REAMINING_TIME_TYPE.BY_DAY) {
    return {
      day: isFill0ForDay ? padTime(result.day) : result.day,
      hours: padTime(result.hours),
      minutes: padTime(result.minutes),
      seconds: padTime(result.seconds),
    }
  }
  result.hours = result.hours + result.day * 24

  if (type === REAMINING_TIME_TYPE.BY_HOUR) {
    return {
      hours: padTime(result.hours),
      minutes: padTime(result.minutes),
      seconds: padTime(result.seconds),
    }
  }

  result.minutes = result.minutes + result.hours * 60

  if (type === REAMINING_TIME_TYPE.BY_MINUTE) {
    return {
      minutes: padTime(result.minutes),
      seconds: padTime(result.seconds),
    }
  }
}
