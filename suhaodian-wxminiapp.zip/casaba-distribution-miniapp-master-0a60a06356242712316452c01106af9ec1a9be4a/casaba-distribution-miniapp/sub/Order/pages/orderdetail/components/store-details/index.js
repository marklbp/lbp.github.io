Component({
  properties: {
    store: {
      type: Object,
      value: {},
    },
    theme: {
      type: String,
      value: 'dark', // dark light  黑色主题  亮色主题
    },
  },
  methods: {
    callPhone() {
      this.triggerEvent('phone')
    },
    openLocation() {
      const store = this.data.store
      if (store && store.latitude && store.longitude) {
        const latitude = store.latitude
        const longitude = store.longitude
        wx.openLocation({
          latitude,
          longitude,
          name: store.storeName,
          address: store.address,
        })
      }
    },
  },
})
