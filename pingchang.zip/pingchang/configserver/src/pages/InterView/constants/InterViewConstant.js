import { BaseConstant } from 'base';

class InterViewConstant extends BaseConstant{
	constructor(){
		super();

		this.key = 'InterView_'
	}
}

export default new InterViewConstant();