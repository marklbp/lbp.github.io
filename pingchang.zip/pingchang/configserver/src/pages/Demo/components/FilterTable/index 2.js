import FilterTable from './FilterTable';

export default FilterTable;
