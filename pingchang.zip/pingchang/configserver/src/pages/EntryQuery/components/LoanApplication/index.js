import LoanApplication from './LoanApplication';

export default LoanApplication;
