// sub/Distribution/pages/center/center.js
import {
  updateUserInfo,
  querySaleManage,
  invitationCode,
} from '../../../../api/index.js'
const app = getApp()
let saveCanvasImageUrl = '' // 保存二维码的图片地址
let id = null
let QRcode =
  'https://timgsa.baidu.com/timg?image&quality=80&size=b9999_10000&sec=1552384523242&di=7851058aaeb3191f4a08effdccadaae5&imgtype=0&src=http%3A%2F%2Fimg.atobo.com%2FProductImg%2FEWM%2FUWeb%2F2%2F4%2F9%2F0%2F3225%2F24903225%2F1.gif' // 二维码
Page({
  /**
   * 页面的初始数据
   */
  data: {
    withdrawAmount: 0.0, // 可提现金额
    settledCommissionIncome: 0.0, // 待结算佣金金额
    settledCommissionIncomeToday: 0.0, // 今日待结算佣金金额
    totalCommissionIncome: 0.0, // 总佣金奖励金额
    settledInviterIncome: 0.0, // 待结算邀请人奖励金额
    totalInviterIncome: 0.0, // 总邀请人奖励金额
    animationData: null, // 邀请好友购物动画数据
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    if (options.id) {
      id = options.id
    }
    this.querySaleManageCenter()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {},

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {},

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {},

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {},

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {},

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {},

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {},
  /**
   * 提现
   */
  goRollIn() {
    wx.navigateTo({
      url: '/sub/Distribution/pages/rollin/rollin',
    })
  },
  /**
   * 收入明细
   */
  goIncome() {
    wx.navigateTo({
      url: '/sub/Distribution/pages/incomeDetails/incomeDetails',
    })
  },
  /**
   * 订单明细
   */
  goOrders() {
    wx.navigateTo({
      url: '/sub/Distribution/pages/orders/orders',
    })
  },
  /**
   * 销售明细
   */
  gosaleDetails() {
    wx.navigateTo({
      url: '/sub/Distribution/pages/saleDetails/saleDetails',
    })
  },
  /**
   * 邀请人明细
   */
  goInviterAward() {
    wx.navigateTo({
      url: '/sub/Distribution/pages/inviterAward/inviterAward',
    })
  },
  /**
   * 邀请朋友
   */
  bindClient() {
    wx.navigateTo({
      url: '/sub/Distribution/pages/client/client',
    })
  },
  /**
   * 前往我的客户
   */
  goMyClient() {
    wx.navigateTo({
      url: `/sub/Distribution/pages/myClient/myClient?id=${id}`,
    })
  },
  /**
   * 我的朋友
   */
  goFriends() {
    wx.navigateTo({
      url:
        '/sub/Distribution/pages/friends/friends?recruitFlag=' +
        this.data.recruitFlag +
        '&distributFlag=' +
        this.data.distributFlag,
    })
  },
  /**
   * 分销中心显示
   */
  querySaleManageCenter() {
    // debugger
    const promise = querySaleManage({
      tenantCode: app.globalData.tenantCode,
      openId: app.globalData.openid || wx.getStorageSync('openid'),
    })
    promise.then(res => {
      const { code, data } = res
      if (Object.is(code, '0')) {
        this.setData({
          withdrawAmount: data.withdrawAmount,
          settledCommissionIncome: data.settledCommissionIncome,
          settledCommissionIncomeToday: data.settledCommissionIncomeToday,
          totalCommissionIncome: data.totalCommissionIncome,
          settledInviterIncome: data.settledInviterIncome,
          totalInviterIncome: data.totalInviterIncome,
        })
      }
    })
  },
  /**
   * 获取邀请好友购物二维码
   */
  invitationCodes(e) {
    const promise1 = updateUserInfo(
      {
        id: app.globalData.accountId,
        openId: app.globalData.openid,
        userName: e.detail.userInfo.nickName,
        userPhoto: e.detail.userInfo.avatarUrl,
      },
      {
        unexUserToken: app.globalData.unexUserToken,
      }
    )
    promise1.then(res => {
      console.log('同步用户信息')
    })
    const userInfo = e.detail.userInfo
    const promise = invitationCode({
      id: id,
      appCode: wx.getStorageSync('appCode'),
      tenantCode: app.globalData.tenantCode,
    })
    promise
      .then(res => {
        const { success, data = {}, message } = res
        if (success) {
          QRcode = data
          console.log('data', data)
          this.invitationShop({ userInfo })
        } else {
          wx.showModal({
            title: '提示',
            content: message,
          })
        }
      })
      .catch(() => {
        wx.showModal({
          title: '提示',
          content: '获取二维码失败',
        })
      })
    // this.invitationShop({ userInfo })
  },

  /**
   * 邀请好友来购物
   */
  invitationShop({ userInfo }) {
    // debugger
    const avatarUrl = this.downloadNetworkFile(userInfo.avatarUrl)
    const wxPromise = this.downloadNetworkFile(QRcode)
    Promise.all([wxPromise, avatarUrl])
      .then(res => {
        console.log('res', res)
        const data = {
          userInfo: userInfo,
          files: res.map(item => item.tempFilePath),
        }
        this.drawCanvas(data)
      })
      .catch(err => {
        console.log('err', err)
      })
  },
  /**
   * 下载网络资源
   */
  downloadNetworkFile(url) {
    const promise = new Promise((resolve, reject) => {
      wx.downloadFile({
        url: url,
        header: {},
        success: function(res) {
          resolve(res)
        },
        fail: function(res) {
          reject(res)
        },
        complete: function(res) {},
      })
    })
    return promise
  },
  /**
   * 绘制Canvas
   */
  drawCanvas({ userInfo, files }) {
    const nameHeight = 92
    const ctx = wx.createCanvasContext('invitation-shop')

    ctx.beginPath()
    ctx.setStrokeStyle('rgba(255, 255, 255, 0)')
    const info = wx.getSystemInfoSync()
    const canvasWidth = (info.screenWidth * 279) / 375

    const canvasHeight = info.screenHeight * 0.57
    console.log('info', info)
    ctx.rect(0, 0, canvasWidth, canvasHeight)
    ctx.setFillStyle('white')
    ctx.fill()
    ctx.closePath()
    ctx.stroke()

    ctx.beginPath()
    ctx.setFontSize(14)
    ctx.setTextAlign('center')
    ctx.setFillStyle('#333333')
    ctx.fillText(userInfo.nickName, canvasWidth / 2, nameHeight + 12)
    ctx.closePath()
    ctx.stroke()

    ctx.beginPath()
    ctx.setFontSize(12)
    ctx.setTextAlign('center')
    ctx.setFillStyle('#6B6B6B')
    ctx.fillText(
      '我在这里发现很多爆款好物',
      canvasWidth / 2,
      nameHeight + 20 + 4 + 10
    )
    ctx.closePath()
    ctx.stroke()

    ctx.beginPath()
    ctx.setFontSize(24)
    ctx.setTextAlign('center')
    ctx.setFillStyle('#333333')
    ctx.setLineWidth(20)
    ctx.fillText(
      '快点来逛逛',
      canvasWidth / 2,
      nameHeight + 20 + 4 + 17 + 8 + 16.5
    )
    ctx.closePath()
    ctx.stroke()

    ctx.beginPath()
    const src = files[0] || this.data.QRcode
    ctx.drawImage(
      src,
      canvasWidth / 2 - (info.screenWidth * 74) / 375,
      nameHeight + 20 + 4 + 17 + 8 + 33 + 0,
      (info.screenWidth * 148) / 375,
      (info.screenWidth * 168) / 375
    )
    ctx.closePath()
    ctx.stroke()

    ctx.save()
    ctx.beginPath()
    ctx.setStrokeStyle('rgba(255, 255, 255, 0)')
    ctx.arc(canvasWidth / 2, 24 + 31, 31, 0, 2 * Math.PI)
    ctx.clip()
    ctx.drawImage(files[1], canvasWidth / 2 - 31, 21, 67, 67)
    ctx.restore()

    ctx.draw(false, () => {
      this.saveCanvasImageUrl()
    })

    this.openInvitationShop()
  },

  /**
   * 绘制Canvas
   */
  drawCanvas1({ userInfo, files }) {
    const nameHeight = 75
    const ctx = wx.createCanvasContext('invitation-shop')
    ctx.beginPath()
    ctx.setStrokeStyle('rgba(255, 255, 255, 0)')
    ctx.rect(0, 33.5, 279, 341)
    ctx.setFillStyle('white')
    ctx.fill()
    ctx.closePath()
    ctx.stroke()

    ctx.beginPath()
    ctx.setFontSize(14)
    ctx.setTextAlign('center')
    ctx.setFillStyle('#333333')
    ctx.fillText(userInfo.nickName, 139.5, 75 + 10)
    ctx.closePath()
    ctx.stroke()

    ctx.beginPath()
    ctx.setFontSize(12)
    ctx.setTextAlign('center')
    ctx.setFillStyle('#6B6B6B')
    ctx.fillText('邀请您一起来CASABA', 139.5, nameHeight + 20 + 4 + 10)
    ctx.closePath()
    ctx.stroke()

    ctx.beginPath()
    ctx.setFontSize(24)
    ctx.setTextAlign('center')
    ctx.setFillStyle('#333333')
    ctx.setLineWidth(20)
    ctx.fillText('邀请好友购物', 139.5, nameHeight + 20 + 4 + 10 + 17 + 8 + 8.5)
    ctx.closePath()
    ctx.stroke()

    ctx.beginPath()
    const src = files[0] || QRcode
    ctx.drawImage(
      src,
      66,
      nameHeight + 20 + 4 + 10 + 17 + 8 + 33 + 10,
      147,
      147
    )
    ctx.closePath()
    ctx.stroke()

    ctx.beginPath()
    ctx.setStrokeStyle('rgba(255, 255, 255, 0)')
    ctx.lineTo(0, 33.5)
    ctx.arc(139.5, 33.5, 33.5, 0, 2 * Math.PI)
    ctx.lineTo(279, 33.5)
    ctx.stroke()

    ctx.clip()

    ctx.beginPath()
    ctx.drawImage(files[1], 106, 0, 67, 67)
    ctx.closePath()
    ctx.stroke()
    ctx.draw(false, () => {
      this.saveCanvasImageUrl()
    })

    this.openInvitationShop()
  },
  /**
   * 保存Canvas为图片URL
   */
  saveCanvasImageUrl() {
    wx.canvasToTempFilePath(
      {
        quality: 1,
        canvasId: 'invitation-shop',
        success: function(res) {
          // console.log('保存图片', res)
          saveCanvasImageUrl = res.tempFilePath
        },
        fail: function(res) {},
        complete: res => {},
      },
      this
    )
  },
  /**
   * 下载保存好的图片至本地相册
   */
  saveCanvasImage() {
    wx.saveImageToPhotosAlbum({
      filePath: saveCanvasImageUrl,
      success: function(res) {
        console.log('保存图片成功', res.savedFilePath)
      },
      fail: function(res) {},
      complete: res => {
        this.closeInvitationShop()
      },
    })
  },
  /**
   * 打开邀请好友来购物
   */
  openInvitationShop() {
    wx.setNavigationBarColor({
      frontColor: '#000000',
      backgroundColor: '#666666',
      animation: {
        duration: 400,
        timingFunc: 'linear',
      },
    })
    const animation = wx.createAnimation({
      duration: 400,
      timingFunction: 'linear',
    })
    animation.bottom('0').step()
    this.setData({
      animationData: animation.export(),
    })
  },
  /**
   * 关闭邀请好友来购物
   */
  closeInvitationShop() {
    wx.setNavigationBarColor({
      frontColor: '#000000',
      backgroundColor: '#ffffff',
      animation: {
        duration: 400,
        timingFunc: 'linear',
      },
    })
    const animation = wx.createAnimation({
      duration: 400,
      timingFunction: 'linear',
    })
    animation.bottom('-100%').step()
    this.setData({
      animationData: animation.export(),
    })
  },
})
