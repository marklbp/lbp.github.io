Component({
  externalClasses: ['u-class'],
  properties: {
    size: {
      type: Number,
      value: 25,
      observer: 'updateSize',
    },
    activeColor: {
      type: String,
      value: 'rgba(0,0,0,.25)',
    },
    defaultColor: {
      type: String,
      value: 'rgba(0,0,0,.25)',
    },
    isChecked: {
      type: Boolean,
      value: false,
    },
  },
  data: {
    isChecked: false,
    handledSize: 25,
  },
  methods: {
    handleChange() {
      let isChecked = this.data.isChecked
      this.setData(
        {
          isChecked: !isChecked,
        },
        () => {
          this.triggerEvent('change', {
            isChecked: this.data.isChecked,
          })
        }
      )
    },
    updateSize() {
      this.setData({
        handledSize: +this.data.size,
      })
    },
  },
})
