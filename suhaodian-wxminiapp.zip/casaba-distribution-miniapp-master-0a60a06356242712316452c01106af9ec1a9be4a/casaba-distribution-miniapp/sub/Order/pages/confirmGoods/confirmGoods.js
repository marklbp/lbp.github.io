const app = getApp()
Page({
  handleBackHome() {
    app.router.navigateTo('/pages/home/home')
  },
  handleViewOrder() {
    app.router.navigateBack()
  },
})
