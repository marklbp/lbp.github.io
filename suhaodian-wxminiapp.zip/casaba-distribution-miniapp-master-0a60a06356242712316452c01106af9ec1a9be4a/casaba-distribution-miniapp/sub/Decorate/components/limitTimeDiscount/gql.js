import gql from '../../../../utils/gql'
const query = `
query ($code: String!) {
  byCode(typename: "LimitTimeDiscountsCampaign", code: $code) {
    ... on LimitTimeDiscountsCampaign {
      code
      name
      timeType
      periodPoints
      limitCount
      discountQuantity
      availablePeriod {
        start
        end
      }
      status
      discountPricePrecision
      spus {
        product {
          spuCode: code
          name
          salePrice
          listPrice
          listTime
          pics:itemImageList {
            picUrl
          }
          skus {
            netqty
            salePrice
          }
        }
        discount
      }
    }
  }
}
`
export const getDiscountDetail = gql(query)
