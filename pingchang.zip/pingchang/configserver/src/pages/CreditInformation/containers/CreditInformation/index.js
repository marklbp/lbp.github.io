import CreditInformation from './CreditInformation';

export default CreditInformation;
