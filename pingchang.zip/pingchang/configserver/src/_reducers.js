/**
 * 该文件系自动生成，手动修改可能会被替换
 * 可以通过node generate-reducer.js自动生成
 */
//import AbcReducer from "./pages/Abc/reducers/AbcReducer.js"
import AccountReducer from "./pages/Account/reducers/AccountReducer.js"
import ContractReducer from "./pages/Contract/reducers/ContractReducer.js"
import ContractEditReducer from "./pages/ContractEdit/reducers/ContractEditReducer.js"
import ContractFileReducer from "./pages/ContractFile/reducers/ContractFileReducer.js"
import DashboardReducer from "./pages/Dashboard/reducers/DashboardReducer.js"
import DemoReducer from "./pages/Demo/reducers/DemoReducer.js"
import EntryQueryReducer from "./pages/EntryQuery/reducers/EntryQueryReducer.js"
import ExamineApproveReducer from "./pages/ExamineApprove/reducers/ExamineApproveReducer.js"
import FontConfigReducer from "./pages/FontConfig/reducers/FontConfigReducer.js"
import LoanApplicationReducer from "./pages/LoanApplication/reducers/LoanApplicationReducer.js"
import MaterialSubmitReducer from "./pages/MaterialSubmit/reducers/MaterialSubmitReducer.js"
import ProcessReducer from "./pages/Process/reducers/ProcessReducer.js"
import ProductReducer from "./pages/Product/reducers/ProductReducer.js"
import ReviewApproveReducer from "./pages/ReviewApprove/reducers/ReviewApproveReducer.js"

export default {
    //AbcReducer,
    AccountReducer,
    ContractReducer,
    ContractEditReducer,
    ContractFileReducer,
    DashboardReducer,
    DemoReducer,
    EntryQueryReducer,
    ExamineApproveReducer,
    FontConfigReducer,
    LoanApplicationReducer,
    MaterialSubmitReducer,
    ProcessReducer,
    ProductReducer,
    ReviewApproveReducer,
};