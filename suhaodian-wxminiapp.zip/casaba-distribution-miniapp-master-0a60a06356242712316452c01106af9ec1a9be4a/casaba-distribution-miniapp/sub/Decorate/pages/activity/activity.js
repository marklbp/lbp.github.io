import { queryDiscreteness } from '../../../../api/index'
import { getExtConfig } from '../../../../utils/util'
import * as dnt from '../../../../template/decoration'
const app = getApp()
Page({
  data: {
    homeData: [],
    pageId: '',
    errCode: '',
    isShowReloadBtn: false,
    listLoading: false,
    barTitle: '',
    background: '#FFFFFF',
    allIsEmpty: false,
    timer: null,
  },
  store: {
    allVideoComponentNode: [],
    currentVideoNode: '',
  },
  onLoad(query) {
    // 开启转发按钮，并带上shareTicket信息
    wx.showShareMenu({ withShareTicket: true })
    if (query.pageId) {
      this.setData({ pageId: query.pageId })
    }
    this.setData({
      listLoading: true,
    })
  },
  onShow() {
    this.initLoad()
  },
  onUnload() {
    this.selectAllComponents('#js-marketing').forEach(
      c => c.pubClearTimer && c.pubClearTimer()
    )
    clearInterval(this.data.timer)
  },
  onHide() {
    this.selectAllComponents('#js-marketing').forEach(
      c => c.pubClearTimer && c.pubClearTimer()
    )
    clearInterval(this.data.timer)
  },
  initLoad() {
    this.getHomeData(this.refreshMarketingComponent)
    this.refreshBaseComponents()
  },
  handleReload() {
    this.initLoad()
  },
  getMarketingCompoentsProductCount() {
    // 此函数判断微页面当只配置了营销组件的时候，营销活动结束或商品已售罄，页面内已无元素，则显示文案和首页按钮
    // 营销组件类型：M_TYPE，基础组件类型：B_TYPE
    const M_TYPE = new Set([
      'MARKETING_SPELL',
      'MARKETING_COUPONS',
      'MARKETING_SECKILL',
      'MARKETING_LIMITE',
    ])
    const B_TYPE = new Set([
      'SECEACH_BOX',
      'SWIPER',
      'TITLE',
      'COMMEND_PRODUCT',
      'VIDEO',
      'PIC',
      'TEXT',
      'NAVIGATION',
    ])
    // 获取整个微页面配置的组件数据
    const typeArr = this.data.homeData.map(hd => ({
      cid: hd.id,
      ctype: hd.type,
      isEmpty: null,
    }))
    // 过滤出基础组件数据baseCompArr，营销组件数据mCompArr
    const baseCompArr = typeArr.filter(ta => B_TYPE.has(ta.ctype))
    const mCompArr = typeArr.filter(ta => M_TYPE.has(ta.ctype))
    // 有基础组件就return
    if (baseCompArr.length > 0 || mCompArr.length === 0) {
      return
    }
    // 设置定时器，去查询营销组件内数据是否加载完毕，再判断数据是否为空
    const timer = setInterval(() => {
      const mc = this.selectAllComponents('#js-marketing')
      mc.forEach(item => {
        const index = mCompArr.findIndex(cp => cp.cid === item.data.cid)
        if (~index) {
          if (item.data.done) {
            if (
              item.data.ctype === 'MARKETING_SPELL' ||
              item.data.ctype === 'MARKETING_SECKILL' ||
              item.data.ctype === 'MARKETING_LIMITE'
            ) {
              mCompArr[index].isEmpty = item.data._commodityList.length === 0
            }
            if (item.data.ctype === 'MARKETING_COUPONS') {
              mCompArr[index].isEmpty = item.data.couponList.length === 0
            }
          }
        }
      })
      if (mCompArr.every(mca => mca.isEmpty !== null)) {
        const allIsEmpty = mCompArr.every(cp => cp.isEmpty === true)
        console.log('微页面数据是否为空===', mCompArr, allIsEmpty)
        this.setData({
          allIsEmpty,
        })
        clearInterval(timer)
      }
    }, 100)
    this.setData({ timer })
  },
  handleGoHome() {
    app.router.navigateTo('pages/home/home')
  },
  setNavigationBarTitle(obj) {
    wx.setNavigationBarTitle({
      title: obj.name || '微页面',
    })
  },
  setNavigationBarColor(obj) {
    wx.setNavigationBarColor({
      frontColor: obj.nameColor || '#000000',
      backgroundColor: obj.titleBgColor || '#FFFFFF',
      animation: {
        duration: 0,
        timingFunc: 'easeIn',
      },
    })
  },
  getHomeData(cb) {
    getExtConfig().then(c => {
      queryDiscreteness({
        tenantCode: c.extConfig.tenantCode,
        id: this.data.pageId,
      })
        .then(res => {
          dnt.getCallBack(this, res, cb)
        })
        .catch(() => this.handleCatchError())
    })
  },
  handleCatchError() {
    dnt.handleCatchError(this)
  },
  onEmitJump({ detail }) {
    app.router.navigateTo(detail.url)
  },
  onVideoPlay({ detail }) {
    if (detail.status === 'play') {
      const allVideoComponentNode = this.store.allVideoComponentNode
      allVideoComponentNode.forEach(node => {
        if (node !== detail.node) {
          node.pubStop()
        }
      })
      this.store.currentVideoNode = detail.node
    }
  },
  onShareAppMessage(res) {
    return {
      title: this.data.barTitle,
      path: '/sub/Decorate/pages/activity/activity?pageId=' + this.data.pageId,
    }
  },
  onPullDownRefresh() {
    clearInterval(this.data.timer)
    wx.showNavigationBarLoading()
    this.getHomeData(this.refreshMarketingComponent)
    this.refreshBaseComponents()
  },
  refreshBaseComponents(id) {
    this.selectAllComponents(`#js-base`).forEach(c =>
      setTimeout(() => {
        if (c.pubRefresh) {
          c.pubRefresh()
        }
      }, 16)
    )
  },
  refreshMarketingComponent() {
    this.selectAllComponents('#js-marketing').forEach(c =>
      setTimeout(() => {
        if (c.pubRefresh) {
          c.pubRefresh()
        }
      }, 16)
    )
  },
  onPageScroll(e) {
    // TODO:  当视频播放后，滚动屏幕后，视频离开可视区域，停止视频播放
  },
  catchtouchmove() {},
})
