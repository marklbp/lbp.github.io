export const STATUS = {
  CREATE: 'CREATE', // 未开始
  WARMING_UP: 'WARMING_UP', // 预热中
  STARTED: 'STARTED', // 秒杀中
  ENDED: 'ENDED', // 已结束
  STOPPED: 'STOPPED', // 已终止
}
