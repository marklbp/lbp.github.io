export const pintuanProductSkuFragment = `
  fragment pintuanProductSkuFragment on PintuanCampaign {
    productSkus{
        id
        code
        sales
        status
        netqty
        inventory
        listPrice
        salePrice
        price: pintuanPrice
        creatorPrice
        attrSaleList{
          code
          attributeFrontName
          attributeValueList{
            code
            attributeValueName
            attributeValueFrontName
            attributeValuePicURL
            itemAttributeValueImageList{
              picUrl
              saleAttributeId
              saleAttributeValue
            }
          }
        }
     }
  }
`

export const pintuanCampaignFragment = `
  fragment pintuanCampaignFragment on PintuanCampaign {
      id
      code
      name
      type
      description
      rules {
        salesVolume
        cashBack
      }
      status
      limitNumber
      availablePeriod {
        start
        end
      }
      ...pintuanProductSkuFragment
  }
  
  ${pintuanProductSkuFragment}
`

export const limitTimeDiscountsCampaignFragment = `
  fragment limitTimeDiscountsCampaignFragment on LimitTimeDiscountsCampaign {
    id
    code
    name
    discountsStatus: status
  }
`

export const seckillProductSkuFragment = `
  fragment seckillProductSkusFragment on SeckillCampaign {
    productSkus {
      id
      code
      salePrice
      price: seckillPrice
      seckillInventory
      seckillSoldNum
      plannedSalesCount
      product{
        id
        itemImageList{
          picUrl
        }
      }
      attrSaleList {
        code
        attributeFrontName
        attributeValueList {
          code
          attributeValueFrontName
          itemAttributeValueImageList {
            picUrl
          }
        }
      }
    }
  }
`
export const seckillCampaignFragment = `
  fragment seckillCampaignFragment on SeckillCampaign {
      id
      code
      name
      status
      warmUpAt
      availablePeriod {
        start
        end
      }
      ...seckillProductSkusFragment
  }
  
  ${seckillProductSkuFragment}
`
