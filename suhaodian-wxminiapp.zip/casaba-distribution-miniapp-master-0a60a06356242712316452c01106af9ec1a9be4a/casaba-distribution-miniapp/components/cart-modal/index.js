/*
 * @Author: mengxiaofei
 * @Date:   2019-01-21 10:20:18
 * @Last Modified by:   mengxiaofei
 * @Last Modified time: 2019-04-04 13:44:54
 */
import {
  updateUserInfo,
  getItemDetailV1,
  getQuotaQualification,
} from '../../api/index'
import queryString from '../../utils/query-string'
import { addToCart } from '../../utils/cart'
import apiReload from '../../utils/reload'
const app = getApp()

function formatProductSkus(skus, skuCodeList, pintuanTeamId) {
  return skus
    .map(sku => {
      if (!skuCodeList.includes(sku.code)) {
        return null
      }
      let attrCodes = []
      sku.attrSaleList.forEach(skuAttrItem => {
        attrCodes = attrCodes.concat(
          skuAttrItem.attributeValueList.map(item => item.code)
        )
      })
      return {
        id: sku.id,
        code: sku.code,
        inventory: sku.inventory,
        netqty: sku.netqty,
        listPrice: sku.listPrice,
        price: pintuanTeamId ? sku.price : sku.creatorPrice || sku.price,
        salePrice: sku.salePrice,
        attrCodes,
      }
    })
    .filter(sku => sku !== null)
}

Component({
  properties: {
    visible: {
      type: Boolean,
      value: false,
      observer: function(nVal, oVal) {
        if (!nVal && oVal) {
          this.setData({
            unavailable: [],
            cacheUnavailable: [],
          })
        }
      },
    },
  },
  data: {
    picCopy: '',
    pic: '',
    netqty: -1,
    skucode: '',
    pintuanAllNetQty: '',
    allNetQtyBackup: '',
    countData: '',
    isCreatePintuanAction: false,
    soldOut: false,
    pullOffShelves: false,
    saleStatus: '',
    fixedListTime: '',
    hasPintuanCampaign: false,
    currentType: '',
    refusedToAuth: '',
    currentPintuanCampaignSelectSku: '',
    minimalPriceSku: {},
    pintuanCampaign: {},
    currentSelectSku: null,
    salePriceCopy: '',
    skuListMap: [],
    attrSaleList: [],
    currentSelectAttrArray: [],
    currentSelectAttrMap: null,
    isNormal: true,
    shopStyle: {
      color: '#fff',
      selectedColor: '#333333',
      auxiliaryColor: '#F4766E',
    },
    skuList: [],
    storeId: '',
    storeCode: '',
    showCart: false,
    quotaInfo: null,
    pintuanCampaignProduct: null,
    unavailable: [],
    cacheUnavailable: [],
  },
  attached() {
    this.setData({
      unavailable: [],
      shopStyle: {
        color: app.globalData.shopStyle[0],
        selectedColor: app.globalData.shopStyle[1],
        auxiliaryColor: app.globalData.shopStyle[2],
      },
    })
  },
  detached() {
    this.setData({
      unavailable: [],
    })
  },
  methods: {
    // 默认选中首个 sku
    selectAttrFirst() {
      let attrSaleList = this.data.attrSaleList
      if (this.data.currentSelectSku) {
        return
      }
      if (!this.data.attrSaleList) {
        wx.showModal({
          title: '',
          content: '该商品没有设置规格',
          showCancel: false,
          confirmColor: '#333',
        })
        return
      }
      // 找到第一个有库存的商品
      const hasNetqty = this.data.skuList.find(s => s.netqty > 0)
      if (hasNetqty) {
        hasNetqty.attrSaleList.forEach((item, index) => {
          const oneIndex = attrSaleList.findIndex(a => a.code === item.code)
          const oneItem = attrSaleList.find(a => a.code === item.code)
          const twoIndex = oneItem
            ? oneItem.attributeValueList.findIndex(
              a => a.code === item.attributeValueList[0].code
            )
            : 0
          this.handleSelectAttr({
            currentTarget: {
              dataset: {
                attributefrontname: item.attributeFrontName,
                attributename:
                  item.attributeValueList[0].attributeValueFrontName,
                code: item.code,
                attrcode: item.attributeValueList[0].code,
                index: oneIndex || 0,
                idx: twoIndex || 0,
                disabled: item.attributeValueList[0].isDisabled,
              },
            },
          })
        })
      }
    },
    // sku选择
    handleSelectAttr({ currentTarget: { dataset } }) {
      const data = this.data
      const skuList = data.skuList
      let currentSelectAttrArray = data.currentSelectAttrArray
      const attrSaleList = data.attrSaleList
      const attrSaleLen = attrSaleList.length
      const pleaseSelectSku = data.pleaseSelectSku
      const attributeFrontName = dataset.attributefrontname
      const attributeName = dataset.attributename
      const code = dataset.code
      const attrCode = dataset.attrcode
      const LevelOneIndex = dataset.index // attrSaleList下一级索引
      const LevelTwoIndex = dataset.idx // attrSaleList下二级索引
      const disabled = dataset.disabled // 拼团-无效的attr，直接return，不走流程
      if (disabled) {
        return
      }
      // step1. 将当前的选择属性以Map结构存储下来，遍历attrSaleList
      let isSelectCode = true
      let currentSelectAttrMap = new Map()
      currentSelectAttrArray.push({
        code: code,
        attrCode: attrCode,
        attributeName: attributeName,
      })
      currentSelectAttrArray.forEach(sa => {
        currentSelectAttrMap.set(sa.code, {
          attrCode: sa.attrCode,
          attributeName: sa.attributeName,
        })
      })
      attrSaleList[LevelOneIndex].attributeValueList.forEach(
        (item, index, self) => {
          if (LevelTwoIndex === index) {
            // 取反active
            self[index].active = !self[index].active
            if (self[index].active) {
              // 未选择->已选择
              const i = pleaseSelectSku.findIndex(p => p === attributeFrontName)
              ~i && data.pleaseSelectSku.splice(i, 1)
            } else {
              // 已选择->未选择
              let deleteArr = []
              currentSelectAttrArray.forEach((sa, i) => {
                if (sa.code === code) {
                  deleteArr.push(i)
                }
              })
              deleteArr
                .reverse()
                .forEach(del => currentSelectAttrArray.splice(del, 1))
              currentSelectAttrMap.delete(code)
              pleaseSelectSku.push(attributeFrontName)
              isSelectCode = false
            }
          } else {
            const delIndex = currentSelectAttrArray.findIndex(d => {
              return d.attrCode === item.code
            })
            ~delIndex && currentSelectAttrArray.splice(delIndex, 1)
            self[index].active = false
          }
        }
      )
      // 设置skuListMap
      data.currentSelectAttrArray = currentSelectAttrArray
      data.currentSelectAttrMap =
        currentSelectAttrMap.size === 0 ? null : currentSelectAttrMap
      data.skuListMap = Array.from(currentSelectAttrMap.values(), item => {
        return {
          attrCode: item.attrCode,
          attributeName: item.attributeName,
        }
      })
      // 查找主规格
      let MainSkuIndex = 0
      MainSkuIndex = attrSaleList.findIndex(item => {
        return item.attributeValueList[0].itemAttributeValueImageList
      })
      // sku图片查找
      let _selectAttrImage = data.picCopy
      if (LevelOneIndex === MainSkuIndex) {
        _selectAttrImage =
          attrSaleList[MainSkuIndex].attributeValueList[LevelTwoIndex]
            .itemAttributeValueImageList[0].picUrl
      }
      // 拼团 - 当属性选择完毕，更新属性状态
      const currentSelectedCode = data.skuListMap.map(item => item.attrCode)
      if (this.data.isCreatePintuanAction) {
        this.updateOptionClickableStatus(
          code,
          LevelOneIndex,
          attrSaleList,
          isSelectCode,
          currentSelectedCode,
          data.pintuanCampaign.productSkus
        )
      } else {
        this.handleUpdateStatus(currentSelectAttrArray, attrSaleList)
      }
      // step2. 将已经选择属性的长度与skuList的长度对比
      // 相等 - 属性已经全部选择完毕，去匹配对应的sku，拿到skuItem（价格、库存、图片）
      // 不相等 - 取消选择或未完全选择，将对应的数据置为初始值
      let currentAttrList = currentSelectAttrArray.map(attr => attr.attrCode)
      const skuItem = skuList.find(item => {
        const isAllInCurrentAttr = currentAttrList.every(code => {
          return item.formatAttrCode.indexOf(code) > -1
        })
        return isAllInCurrentAttr ? item : false
      })
      if (JSON.stringify(data.pintuanCampaign) !== '{}') {
        // 更新当前拼团的sku
        this.updateCurrentSelectSku(
          data,
          attrSaleList.length === currentSelectAttrArray.length
            ? skuItem.code
            : undefined
        )
      }
      if (currentSelectAttrMap.size === attrSaleLen) {
        if (skuItem) {
          data.skucode = skuItem.code
          data.netqty = skuItem.netqty
          data.salePriceCopy = skuItem.salePrice
          data.listPriceCopy = skuItem.listPrice
          data.countData = skuItem.netqty === 0 ? 0 : 1
          data.picCopy = _selectAttrImage || data.pic
          // if (hasImageField) {
          //   data.picCopy = _selectAttrImage
          // } else {
          //   data.picCopy = data.pic
          // }
          // 普通立即购买更新当前的sku
          this.updateCurrentSku(data, skuItem.code)
        }
      } else {
        data.netqty = -1
        data.skucode = ''
        data.countData = -1
        data.salePriceCopy = data.salePrice
        data.listPriceCopy = data.listPrice
        data.picCopy = _selectAttrImage || data.pic
      }
      this.setData(data)
    },
    // count change
    onChangeCount({ detail }) {
      let quotaInfo = this.data.quotaInfo
      if (quotaInfo.isQuota === '1') {
        if (detail.value === quotaInfo.canBuy) {
          wx.showToast({
            title: `每人限购${quotaInfo.canBuy}件`,
            icon: 'none',
          })
        }
      }
      this.setData({
        countData: detail.value,
      })
    },
    // 加入购物车
    handleAddBtn(e) {
      this.setData({
        isAddCard: true,
        isBuyNow: false,
      })
      if (this.data.isNormal) {
        if (!this.data.skucode) {
          wx.showToast({
            title: '请选择' + this.data.pleaseSelectSku,
            icon: 'none',
          })
          return
        }
        this.handleAddCartNetQty()
      } else {
        this.handleShowSelectionSpec()
      }
    },
    handleShowSelectionSpec() {
      const data = this.data
      if (data.soldOut) {
        return
      }
      if (!this.data.attrSaleList) {
        wx.showModal({
          title: '',
          content: '该商品没有设置规格',
          showCancel: false,
          confirmColor: '#333',
        })
        return
      }
      // this.updateSkuView()
      this.setData({
        isShowMask: true,
      })
      setTimeout(() => {
        if (data.isCreatePintuanAction) {
          const skuListMap = JSON.parse(
            JSON.stringify(this.data.pintuanSkuListMap)
          )
          this.setData({
            skuListMap,
            netqty: data.pintuanNetqty,
            countData: data.pintuanCountData,
            skucode: data.pintuanSkucode,
            attrSaleList: this.data.pintuanAttrSaleList,
            currentSelectAttrArray: JSON.parse(
              JSON.stringify(this.data.pintuanCurrentSelectAttrMap)
            ),
          })
        }
        if (data.isBuyNow || data.isAddCard || data.isNormal) {
          const skuListMap = JSON.parse(
            JSON.stringify(this.data.skuListMapBackup)
          )
          this.setData({
            skuListMap,
            netqty: data.netqtyBackup,
            countData: data.countDataBackup,
            skucode: data.skucodeBackup,
            attrSaleList: this.data.attrSaleListBackup,
            currentSelectAttrArray: JSON.parse(
              JSON.stringify(this.data.currentSelectAttrMapBackup)
            ),
          })
        }
      }, 200)
    },
    updateCurrentSku(data, skuCode) {
      const currentSku = data.skuList.find(sku => {
        return sku.code === skuCode
      })
      data.currentSelectSku = currentSku
    },
    updateCurrentSelectSku(data, skuCode) {
      if (!this.data.hasPintuanCampaign) {
        return
      }
      const currentSku = this.data.pintuanCampaign.productSkus.find(sku => {
        return sku.code === skuCode
      })
      data.currentPintuanCampaignSelectSku = currentSku || null
      data.pintuanCampaignProduct = this.data.pintuanCampaignProduct
      this.setData(data)
    },
    onAuthorizationSuccess({ detail }) {
      app.globalData.userInfo = detail.userInfo
      app.honghuStore.isAuthorized = true
      if (!app.globalData.accountId) {
        apiReload.getAuthParam(app, app.globalData.openid).then(() => {
          this.updateUserInfo(detail)
        })
      } else {
        this.updateUserInfo(detail)
      }
      this.setData({ isShowAuthorized: false })
      if (detail.tapType === 'addcart') {
        this.addShopCart()
      }
    },
    updateUserInfo(detail) {
      updateUserInfo(
        {
          id: app.globalData.accountId,
          openId: app.globalData.openid,
          userName: detail.userInfo.nickName,
          userPhoto: detail.userInfo.avatarUrl,
        },
        {
          unexUserToken: app.globalData.unexUserToken,
        }
      )
    },
    onAuthorizationCancel({ detail }) {
      if (detail.tapType !== 'pintuan' && detail.cancel === 'fail') {
        this.setData({ refusedToAuth: false })
        if (detail.tapType === 'buynow') {
          this.handleBuyNow()
        } else if (detail.tapType === 'addcart') {
          this.handleAddBtn()
        }
      }
      this.setData({ isShowAuthorized: false, clickAuthBtnType: '' })
    },
    getRightDiscount(skucode) {
      let currentSku = this.data.skuList.find(item => {
        return item.code === skucode
      })
      return currentSku
    },
    handleBuyNow() {
      const data = this.data
      const attrValue = data.skuListMap
        .map(item => item.attributeName)
        .join(',')
      if (!this.data.skucode) {
        wx.showToast({
          title: '请选择' + this.data.pleaseSelectSku,
          icon: 'none',
        })
        return
      }

      const productList = [
        {
          title: data.title,
          pic: data.picCopy,
          saleprice: data.salePriceCopy,
          listprice: data.listPriceCopy,
          attrValue: attrValue,
          count: data.countData,
          brandcode: data.brandcode,
          categorycode: data.categorycode,
          categoryname: data.categoryname,
          brandname: data.brandname,
          image: data.picCopy,
          spuCode: data.spuCode,
          skucode: data.skucode,
          extentionCode: data.currentSelectSku.extentionCode
            ? data.currentSelectSku.extentionCode
            : data.skucode,
          skuListMap: data.skuListMap,
          campaignId: data.pintuanCampaign.code
            ? data.pintuanCampaign.code
            : '',
          pintuanCampaignSkuId: data.currentPintuanCampaignSelectSku.id,
          pintuanCampaignProduct: data.pintuanCampaignProduct,
          currentType: data.currentType,
        },
      ]
      app.globalData.productlist = productList
      const query = queryString({
        isTrueFase: true,
        fromPage: 'pdp',
        isCreatePintuanAction: data.isCreatePintuanAction,
        pintuanTeamId: data.pintuanTeamId || '',
        storeId: data.storeId,
      })
      this.closeCart()
      wx.navigateTo({
        url: `/sub/Pay/pages/checkout/checkout?${query}`,
      })
    },
    handleConfirmSelectionSpec() {
      if (!this.data.skucode) {
        wx.showToast({
          title: '请选择' + this.data.pleaseSelectSku,
          icon: 'none',
        })
        return
      }
      const data = this.data
      this.updateSkuView()
      if (data.skuListMap.length > 0) {
        this.handleAddCartNetQty()
      }
      this.copyCurrentSelect()
    },
    closeCart() {
      this.clearAttributeStatus()
      this.triggerEvent('cancel')
    },
    updateSkuView() {
      const data = this.data
      let salePriceCopy = data.salePriceCopy
      let netqty = data.netqty
      if (data.isCreatePintuanAction) {
        if (data.currentPintuanCampaignSelectSku) {
          salePriceCopy = data.currentPintuanCampaignSelectSku.price
          netqty = data.currentPintuanCampaignSelectSku.netqty
        } else {
          salePriceCopy = data.minimalPriceSku.price
          netqty = -1
        }
      } else if (data.isBuyNow || data.isAddCard || data.isNormal) {
        if (data.currentSelectSku) {
          salePriceCopy = data.currentSelectSku.salePrice
          netqty = data.currentSelectSku.netqty
        } else {
          salePriceCopy = data.salePrice
          netqty = -1
        }
      }
      this.setData({
        salePriceCopy,
        netqty,
      })
    },
    // 处理加入购物车， 再次调用查询购物车接口
    handleAddCartNetQty() {
      addToCart([
        {
          quantity: this.data.countData,
          skuCode: this.data.skucode,
        },
      ])
        .then(res => {
          if (res.code === '0') {
            this.triggerEvent('success')
            this.clearAttributeStatus()
          }
        })
        .catch(e => {
          console.log(e.message)
        })
    },
    clearAttributeStatus() {
      const attrSaleList = this.data.attrSaleList
      attrSaleList.forEach((attr, index) => {
        attr.attributeValueList.forEach((item, _idx) => {
          attrSaleList[index].attributeValueList[_idx].active = false
        })
      })
      this.setData({
        title: '',
        listPrice: '',
        pintuanCampaign: {},
        salePrice: '',
        salePriceCopy: '',
        skuList: null,
        attrSaleList: attrSaleList || null,
        allNetQty: '',
        allNetQtyBackup: '',
        pleaseSelectSku: '',
        soldOut: '',
        picCopy: '',
        brandcode: '',
        categorycode: '',
        categoryname: '',
        brandname: '',
        spuCode: '',
        skucode: '',
        sizeData: '',
        currentSizeValue: '',
        skuListMap: [],
        currentSelectAttrArray: [],
        currentSelectAttrMap: null,
        currentSelectSku: null,
      })
    },
    copyCurrentSelect() {
      const data = this.data
      let _attrSaleList = data.attrSaleList
      let pintuanSkuListMap = data.pintuanSkuListMap
      let skuListMapBackup = data.skuListMapBackup
      let pintuanCurrentSelectAttrMap = data.pintuanCurrentSelectAttrMap
      let currentSelectAttrMapBackup = data.currentSelectAttrMapBackup
      if (data.isCreatePintuanAction) {
        _attrSaleList = JSON.parse(JSON.stringify(data.pintuanAttrSaleList))
        pintuanSkuListMap = JSON.parse(JSON.stringify(data.skuListMap))
        pintuanCurrentSelectAttrMap = JSON.parse(
          JSON.stringify(data.currentSelectAttrArray)
        )
        this.setData({
          pintuanSkuListMap,
          pintuanCurrentSelectAttrMap,
          pintuanCountData: data.countData,
          pintuanNetqty: data.netqty,
          pintuanSkucode: data.skucode,
        })
      }
      if (data.isBuyNow || data.isAddCard || data.isNormal) {
        _attrSaleList = JSON.parse(JSON.stringify(data.attrSaleListBackup))
        skuListMapBackup = JSON.parse(JSON.stringify(data.skuListMap))
        currentSelectAttrMapBackup = JSON.parse(
          JSON.stringify(data.currentSelectAttrArray)
        )
        this.setData({
          skuListMapBackup,
          currentSelectAttrMapBackup,
          countDataBackup: data.countData,
          netqtyBackup: data.netqty,
          skucodeBackup: data.skucode,
        })
      }
      this.setData({
        attrSaleList: _attrSaleList,
      })
    },
    handleError(err) {
      // 打开购物车 初始化数据错误 处理方式
      wx.showModal({
        title: '',
        content: err.errorMsg || err.msg,
        showCancel: false,
        confirmColor: '#333',
        success: () => {
          this.closeCart()
          this.clearAttributeStatus()
        },
      })
    },
    // 判断是否是 拼团订单
    getProductAndCampaignRequest(productId) {
      return app.honghuStore
        .getProductDetailAction({ id: productId })
        .then(product => {
          if (
            product &&
            product.campaign &&
            product.campaign.type === 'NORMAL'
          ) {
            return { campaign: product.campaign }
          } else {
            return {}
          }
        })
    },
    showCart(data) {
      data.storeId &&
        this.setData({
          storeId: data.storeId,
          storeCode: data.storeCode,
        })
      Promise.all([
        getItemDetailV1({
          tenantCode: app.globalData.tenantCode,
          spuCode: data.spuCode,
          storeCode: data.storeCode,
        }),
        this.getProductAndCampaignRequest(data.spuCode),
        getQuotaQualification({
          openId: app.globalData.openid,
          spuCode: data.spuCode,
          tenantCode: app.globalData.tenantCode,
        }),
      ])
        .then(response => {
          let res = response[0]
          let pintuan = response[1]
          let quotaInfo = response[2]
          // 网络请求错误
          if ((res.code && res.code === -1) || !res.data) {
            this.handleError(res)
            return
          }
          // 商品下架
          // if (Number(res.data.saleStatus) === 2) {
          //   this.handleError({
          //     errorMsg: '商品已下架',
          //   })
          //   return
          // }
          this.initData(res.data, pintuan)
          if (quotaInfo.code === '0') {
            this.setData({
              quotaInfo: quotaInfo.data,
            })
          } else {
            console.log('请求限购信息失败')
          }
        })
        .catch(e => {
          console.log('e', e)
        })
    },
    initOptionClickableStatus(attrSaleList, skuList) {
      if (attrSaleList.length !== 1) {
        return
      }
      const validAttrCode = []
      skuList.forEach(sku => {
        sku.attrCodes.forEach(ac => {
          if (sku.netqty > 0) {
            validAttrCode.push(ac)
          }
        })
      })

      const attrItem = attrSaleList[0]
      attrItem.attributeValueList.forEach(option => {
        option.isDisabled = !(validAttrCode.indexOf(option.code) > -1)
      })
      this.setData({ attrSaleList })
    },
    handleUpdateStatus(currentSelectArr, attrSaleList) {
      if (attrSaleList.length === 1) {
        this.handleOneAttrSaleStatus(currentSelectArr, attrSaleList)
      } else {
        this.handleTwoAttrSaleStatus(currentSelectArr, attrSaleList)
      }
    },
    handleOneAttrSaleStatus(currentSelectArr, attrSaleList) {
      let { skuList } = this.data
      attrSaleList[0].attributeValueList.forEach(av => {
        const index = skuList.findIndex(s => s.attrCodes[0] === av.code)
        if (~index && skuList[index].netqty > 0) {
          av.isDisabled = false
        } else {
          av.isDisabled = true
        }
      })
      this.setData({
        attrSaleList,
      })
    },
    handleTwoAttrSaleStatus(currentSelectArr, attrSaleList) {
      let { unavailable, cacheUnavailable, skuList } = this.data
      const len = currentSelectArr.length
      if (len === 0) {
        // 清除所有属性的disabled以及清空unavailable
        unavailable = []
        attrSaleList.forEach(item => {
          item.attributeValueList.forEach(k => {
            k.isDisabled = false
          })
        })
        this.setData({
          unavailable,
          attrSaleList,
        })
      } else {
        // 已选择的二级属性codes
        const _currentSelectArr = currentSelectArr[len - 1]
        const levelTwoAttrCode = _currentSelectArr.attrCode
        const cacheIndex = cacheUnavailable.findIndex(
          cu => cu.sourceAttrCode === _currentSelectArr.attrCode
        )
        if (len >= unavailable.length) {
          if (~cacheIndex) {
            const sIndex = unavailable.findIndex(
              u => u.code === cacheUnavailable[cacheIndex].code
            )
            if (~sIndex) {
              // 存在sku，替换
              unavailable[sIndex].attrCodes =
                cacheUnavailable[cacheIndex].attrCodes
            } else {
              // 不存在sku，添加至unavailable
              unavailable.push({
                code: cacheUnavailable[cacheIndex].code,
                attrCodes: cacheUnavailable[cacheIndex].attrCodes,
              })
            }
          } else {
            // 过滤出skuList已选择的属性的sku
            const someCodes = new Set()
            let someSkuList
            skuList.forEach(s => {
              if (s.attrCodes.some(ac => ac === levelTwoAttrCode)) {
                someSkuList = s
                s.attrCodes.forEach(sa => {
                  if (sa !== levelTwoAttrCode) {
                    someCodes.add(sa)
                  }
                })
              }
            })
            // 筛选出未选择的属性
            const nextAttrSale = attrSaleList.filter(
              as => as.code !== _currentSelectArr.code
            )[0]
            const unavailableValues = new Set()
            // 先判断库存
            if (someSkuList.netqty <= 0) {
              let diffCode
              someSkuList.attrCodes.forEach(sa => {
                if (sa !== levelTwoAttrCode) {
                  diffCode = sa
                }
              })
              unavailableValues.add(diffCode)
            }
            const _someCodes = Array.from(someCodes)
            nextAttrSale.attributeValueList.forEach(av => {
              if (!_someCodes.includes(av.code)) {
                unavailableValues.add(av.code)
              }
            })
            const sIndex = unavailable.findIndex(
              u => u.code === nextAttrSale.code
            )
            if (~sIndex) {
              // 存在sku，替换
              unavailable[sIndex].attrCodes = Array.from(unavailableValues)
            } else {
              // 不存在sku，添加至unavailable
              unavailable.push({
                code: nextAttrSale.code,
                attrCodes: Array.from(unavailableValues),
              })
            }
            cacheUnavailable.push({
              sourceAttrCode: _currentSelectArr.attrCode,
              code: nextAttrSale.code,
              attrCodes: Array.from(unavailableValues),
            })
          }
        } else {
          const levelOneCodes = currentSelectArr.map(item => item.code)
          const delAttrCodes = []
          unavailable.forEach((u, i) => {
            if (levelOneCodes.some(lo => lo === u.code)) {
              delAttrCodes.push(i)
            }
          })
          delAttrCodes.reverse().forEach(d => unavailable.splice(d, 1))
        }
        // 先将所有属性disabled置为false
        attrSaleList.forEach(item => {
          item.attributeValueList.forEach(k => {
            k.isDisabled = false
          })
        })
        unavailable.forEach(un => {
          attrSaleList.forEach(as => {
            if (un.code === as.code) {
              as.attributeValueList.forEach(asa => {
                if (un.attrCodes.some(una => una === asa.code)) {
                  asa.isDisabled = true
                } else {
                  asa.isDisabled = false
                }
              })
            }
          })
        })
        console.log('[][][][][][][][', unavailable, cacheUnavailable)
        this.setData({
          cacheUnavailable,
          unavailable,
          attrSaleList,
        })
      }
    },
    contain(A, B) {
      A = A.slice()
      for (var i = 0, len = B.length; i < len; i++) {
        if (A.indexOf(B[i]) === -1) {
          return false
        } else {
          A.splice(A.indexOf(B[i]), 1)
        }
      }
      return true
    },
    updateOptionClickableStatus(
      code,
      index,
      attrSaleList,
      isSelectCode,
      currentSelectedCode,
      skus
    ) {
      attrSaleList.forEach(attrItem => {
        if (code === attrItem.code) {
          return
        }
        attrItem.attributeValueList.forEach(option => {
          if (!isSelectCode || currentSelectedCode.length === 0) {
            option.isDisabled = false
            return
          }
          const isValidOption = skus.some((sku, index) => {
            const isAllInCurrentAttr = !currentSelectedCode.some(code => {
              return sku.attrCodes.indexOf(code) === -1
            })
            return (
              isAllInCurrentAttr &&
              sku.attrCodes.includes(option.code) &&
              sku.netqty > 0
            )
          })
          option.isDisabled = !isValidOption
        })
      })
    },
    // 库存计算
    calculationTotalInventory(skuList) {
      return skuList.reduce((total, item) => {
        return total + item.netqty
      }, 0)
    },
    formatSkuAttrSaleList(skus) {
      skus.forEach(sku => {
        let attrCodes = []
        sku.attrSaleList.forEach(skuAttrItem => {
          attrCodes = attrCodes.concat(
            skuAttrItem.attributeValueList.map(item => item.code)
          )
        })
        sku.formatAttrCode = attrCodes
      })
      return skus
    },
    initData(result, pintuan, discountObj) {
      let pullOffShelves = Number(result.saleStatus) === 2
      let swiperData = result.itemImageList
      let pic = swiperData && swiperData[0].picUrl
      let picCopy = swiperData && swiperData[0].picUrl
      let skuList = result.skuList
      let attrSaleList = result.attrSaleList
      // 将主规格移至首位
      let MainSkuIndex = 0
      MainSkuIndex = attrSaleList.findIndex(item => {
        return item.attributeValueList[0].itemAttributeValueImageList
      })
      if (MainSkuIndex !== 0) {
        var temp = attrSaleList.splice(MainSkuIndex, 1)
        attrSaleList.unshift(temp[0])
      }
      skuList = this.formatSkuAttrSaleList(skuList)
      let allNetQty = this.calculationTotalInventory(skuList)
      let pleaseSelectSku = attrSaleList.map(item => item.attributeFrontName)
      let soldOut = result.skuList.every(item => item.netqty === 0)
      let sizeList = attrSaleList && result.attrSaleList[0].attributeValueList
      let brandcode = result.brand.code
      let brandname = result.brand.name
      let categorycode = result.categoryList
        ? result.categoryList[result.categoryList.length - 1].categoryPath
        : ''
      let categoryname = result.categoryList ? result.categoryList[0].name : ''
      let spuCode = result.code
      let sizeData = []
      sizeList &&
        sizeList.forEach(item => {
          sizeData.push(item)
        })
      let pintuanCampaign
      if (pintuan.campaign) {
        pintuanCampaign = Object.assign({}, pintuan.campaign)
        pintuanCampaign.productSkus = formatProductSkus(
          pintuanCampaign.productSkus,
          skuList.map(sku => sku.code)
        )
      }
      skuList = skuList.map(item => {
        return {
          ...item,
          attrCodes: item.attrSaleList.map(attr => {
            return attr.attributeValueList[0].code
          }),
        }
      })
      this.setData(
        {
          hasPintuanCampaign: !!pintuan.campaign,
          title: result.title,
          listPrice: result.listPrice,
          salePrice: result.salePrice,
          salePriceCopy: result.salePrice,
          skuList: skuList,
          attrSaleList: attrSaleList || null,
          allNetQty: allNetQty,
          allNetQtyBackup: allNetQty,
          pleaseSelectSku: pleaseSelectSku,
          soldOut: soldOut,
          pullOffShelves: pullOffShelves,
          saleStatus: result.saleStatus,
          fixedListTime: result.fixedListTime,
          brandcode: brandcode,
          categorycode: categorycode,
          categoryname: categoryname,
          brandname: brandname,
          spuCode: spuCode,
          pintuanAttrSaleList: JSON.parse(JSON.stringify(attrSaleList)),
          skucode: '',
          sizeData: sizeData,
          currentType: result.type,
          currentSizeValue: sizeData[0]
            ? sizeData[0].attributeValueFrontName
            : '',
          picCopy: picCopy,
          pic: pic,
          pintuanCampaign: pintuanCampaign || {},
        },
        () => {
          this.triggerEvent('change', true)
          // 初始 sku 是否可选
          // TODO: pdp页面组件化后  根据传入的标志判断是否是活动型选择
          // if (this.data.hasPintuanCampaign) {
          //   this.initOptionClickableStatus(
          //     this.data.pintuanAttrSaleList,
          //     this.data.pintuanCampaign.productSkus
          //   )
          // } else {
          this.initOptionClickableStatus(
            this.data.attrSaleList,
            this.data.skuList
          )
          // }
          this.selectAttrFirst()
        }
      )
    },
  },
})
