import { updateAddress } from '../../../../api/index'
import apiReload from '../../../../utils/reload'
const app = getApp()

Page({
  data: {
    isCheck: 1, // 是否被选中默认地址
    searchData: null,
    addressData: {
      // 地址下拉
      region: ['省', '市', '区'],
      customItem: '全部',
    },
    editAddress: null,
    name: null,
    tel: null,
    address: null,
    code: null,
    isSelectAddress: false,
    shopStyle: {
      color: '#fff',
      selectedColor: '#333333',
    },
    saveLoading: false,
  },
  onLoad: function(options) {
    let isSelectAddress = false
    if (options.isSelectAddress && Object.is(options.isSelectAddress, 'true')) {
      isSelectAddress = true
      this.setData({
        isSelectAddress: isSelectAddress,
      })
    }
    this.setData({
      shopStyle: {
        color: app.globalData.shopStyle[0],
        selectedColor: app.globalData.shopStyle[1],
      },
    })
    let item = JSON.parse(wx.getStorageSync('editAddress'))
    this.setData({
      editAddress: item,
      addressData: {
        region: [item.province, item.city, item.district],
      },
      isCheck: Number(item.isDefault),
      name: item.receiverName,
      tel: item.receiverMobile,
      address: item.address,
      code: item.receiverZipcode,
    })
  },
  bindRegionChange: function(e) {
    const region = e.detail.value
    if (region[0] === '全部' || region[1] === '全部' || region[2] === '全部') {
      wx.showToast({
        title: '请选择完整的地区',
        icon: 'none',
      })
      return
    }
    this.setData({
      addressData: {
        // 地址下拉
        region: e.detail.value,
      },
    })
  },
  bindblurGetName(e) {
    // 获取姓名
    let name = e.detail.value
    this.setData({ name: name })
  },
  bindblurGetTel(e) {
    // 获取电话
    let tel = e.detail.value
    if (tel) {
      if (!/^[1][3,4,5,6,7,8,9][0-9]{9}$/.test(tel)) {
        wx.showToast({
          title: '请输入有效电话号码',
          icon: 'none',
          duration: 1000,
          mask: true,
        })
      } else {
        this.setData({ tel: tel })
      }
    }
  },
  bindblurGetAddress(e) {
    // 详细地址
    let address = e.detail.value
    this.setData({ address: address })
  },
  bindblurGetCode(e) {
    // 获取邮编
    let code = e.detail.value
    this.setData({ code: code })
  },
  clickCurrentStyle(e) {
    // 选中默认地址按钮
    let flag = e.detail.isChecked
    let styleCurrent
    if (!flag) {
      styleCurrent = 0
    } else {
      styleCurrent = 1
    }
    this.setData({ isCheck: styleCurrent })
  },
  validityCheck(obj) {
    if (
      !obj.receiverName ||
      !obj.receiverMobile ||
      !obj.address ||
      obj.addressPicker[0] === '全部' ||
      obj.addressPicker[0] === '省' ||
      obj.addressPicker[1] === '全部' ||
      obj.addressPicker[1] === '市' ||
      obj.addressPicker[2] === '全部' ||
      obj.addressPicker[2] === '区'
    ) {
      wx.showToast({
        title: '请将信息填写完整',
        icon: 'none',
      })
      return false
    } else {
      if (!/^[1][3,4,5,6,7,8,9][0-9]{9}$/.test(obj.receiverMobile)) {
        wx.showToast({
          title: '请输入有效电话号码',
          icon: 'none',
          duration: 1000,
          mask: true,
        })
        return false
      }
      return true
    }
  },
  bindSaveAdress(e) {
    // 点击保持按钮
    if (!app.globalData.unexUserToken) {
      apiReload
        .getUnexUserToken(app, app.globalData.openid)
        .then(res => {
          this.updateAdress(e)
        })
        .catch(() => {
          this.setData({
            saveLoading: false,
          })
          wx.showToast({
            title: '服务器异常，请稍后再试',
            icon: 'none',
          })
        })
    } else {
      this.updateAdress(e)
    }
  },
  updateAdress(e) {
    // 编辑地址后保存按钮
    const form = e.detail.value
    if (this.validityCheck(form)) {
      this.setData({
        saveLoading: true,
      })
      let data = {
        id: this.data.editAddress.id,
        unexUserToken: app.globalData.unexUserToken,
        account: app.globalData.openid,
        isDefault: this.data.isCheck,
        provinceId: 0,
        province: form.addressPicker[0],
        cityId: 1,
        city: form.addressPicker[1],
        townId: 2,
        district: form.addressPicker[2],
        address: form.address,
        receiverName: form.receiverName,
        receiverMobile: form.receiverMobile,
        receiverZipcode: this.data.code,
      }
      updateAddress(data, {
        unexUserToken: app.globalData.unexUserToken,
      })
        .then(res => {
          this.setData({
            saveLoading: false,
          })
          // 视为当前选中
          wx.setStorageSync(
            'checkoutAddress',
            JSON.stringify(
              Object.assign(data, {
                id: res.content,
              })
            )
          )
          app.router.navigateBack()
        })
        .catch(() => {
          this.setData({
            saveLoading: false,
          })
          wx.showToast({
            title: '服务器异常，保存失败',
            icon: 'none',
          })
        })
    }
  },
})
