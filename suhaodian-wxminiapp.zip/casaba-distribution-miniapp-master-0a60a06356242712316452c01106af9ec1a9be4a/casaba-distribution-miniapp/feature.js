export default {
  ENABLE_PDP_GOTO_DISCOUNTS_CAMPAIGN: true,
}
