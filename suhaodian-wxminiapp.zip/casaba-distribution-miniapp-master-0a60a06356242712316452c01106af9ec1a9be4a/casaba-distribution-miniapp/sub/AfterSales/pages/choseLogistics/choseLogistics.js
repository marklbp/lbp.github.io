import { getExpressNames } from '../../../../api/index'
import { set } from '../../../../utils/storage.js'
const app = getApp()
Page({
  data: {
    expressList: null,
  },
  onLoad: function() {
    this.handleGetExpressNames()
  },
  handleGetExpressNames: function() {
    getExpressNames()
      .then(res => {
        console.log(res)
        if (res.code === '0') {
          this.setData({
            expressList: res.data,
          })
        }
      })
      .catch(e => {
        console.log(e)
      })
  },
  goAdressBindViewTap({ currentTarget: { dataset } }) {
    set('chosedExpress', JSON.stringify(dataset.item))
    app.router.navigateBack()
  },
})
