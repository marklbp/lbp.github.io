import React, { Component } from 'react';
// import Dashboard from './components/Dashboard';

export default class Demo extends Component {

  constructor(props) {
    super(props);
    
  }

  /**
   * <Dashboard {...this.props} />
   * @return {[type]} [description]
   */
  render() {
    return (
      <div className="dashboard-page">
        这是默认
      </div>
    );
  }
}
