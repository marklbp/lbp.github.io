/* global Component */
Component({
  externalClasses: ['u-class'],
  relations: {
    '../checkbox/index': {
      type: 'child',
      linked() {
        this.changeCurrent()
      },
      linkChanged() {
        this.changeCurrent()
      },
      unlinked() {
        this.changeCurrent()
      },
    },
  },
  properties: {
    current: {
      type: Array,
      value: [],
      observer: 'changeCurrent',
    },
    multiple: {
      type: Boolean,
      value: true,
    },
  },
  methods: {
    changeCurrent(val = this.data.current) {
      const items = this.getRelationNodes('../checkbox/index')
      const len = items.length
      if (this.data.multiple && len > 0) {
        items.forEach(item => {
          item.changeCurrent(val.indexOf(item.data.value) !== -1)
        })
      }
    },
    emitEvent(current) {
      if (this.data.multiple) {
        this.triggerEvent('change', current)
      } else {
        const items = this.getRelationNodes('../checkbox/index')
        const len = items.length
        if (len > 0) {
          items.forEach(item => {
            if (current.checked) {
              item.changeCurrent(item.data.value === current.value)
            } else {
              item.changeCurrent(false)
            }
          })
        }
        this.triggerEvent('change', current)
      }
    },
  },
})
