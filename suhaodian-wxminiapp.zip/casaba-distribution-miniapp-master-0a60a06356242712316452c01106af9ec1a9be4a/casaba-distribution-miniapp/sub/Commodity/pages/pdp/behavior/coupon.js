// 优惠券、优惠码
import { checkCoupon, sendCoupon } from '../../../../../api/index'

const app = getApp()

export default Behavior({
  data: {
    isShowCouponRule: false,
    couponList: [],
    couponRuleDescList: [],
  },
  methods: {
    handleOpenCouponSheet() {
      setTimeout(() => {
        this.setData({
          hookLayer: true,
        })
      }, 100)
      this.setData({
        isShowCouponRule: true,
      })
    },
    onCouponCancel() {
      this.setData({
        isShowCouponRule: false,
      })
    },
    // 获取优惠券列表
    getCouponList(productData) {
      checkCoupon(
        {
          tenantCode: app.globalData.tenantCode,
          spuCode: this.data.spuCode,
          // prettier-ignore
          categoryCode: productData.categoryList ? productData.categoryList[productData.categoryList.length - 1].categoryPath : '',
          brandCode: productData.brand.code,
        },
        {
          'invoke-source': app.globalData['invoke-source'],
        }
      ).then(res => {
        let couponList = []
        let couponRuleDescList = []
        res.data &&
          res.data.forEach(item => {
            if (item.activityType === '02' && item.couponType === '01') {
              item.status = '0'
              item.sendLoading = false
              couponList.push(item)
              couponRuleDescList.push(item.activityRuleDesc)
            }
          })
        this.setData({
          couponList: couponList,
          couponRuleDescList: couponRuleDescList,
        })
      })
    },
    onDetailClick() {
      console.log(1)
    },
    // 发送优惠券
    onCouponClick({ currentTarget }) {
      const dataset = currentTarget.dataset
      const index = dataset.index
      let couponList = this.data.couponList
      couponList[dataset.index].sendLoading = true
      this.setData({
        couponList: couponList,
      })
      sendCoupon(
        {
          activityCode: dataset.activitycode,
          takeLabel: '02',
          memberLevelCode: '18040300000029',
        },
        {
          unexUserToken: app.globalData.unexUserToken,
          'invoke-source': app.globalData['invoke-source'],
        }
      )
        .then(res => {
          if (res.code === '0') {
            if (res.data) {
              couponList[index].status = '1'
              couponList[index].sendLoading = false
            } else {
              couponList[index].status = '4'
            }
          } else {
            couponList[index].status = '4'
          }
          this.setData({
            couponList: couponList,
          })
        })
        .catch(err => {
          if (err.data.code === '10143034') {
            couponList[index].status = '10143034' // 领取上限
          }
          if (err.data.code === '10143009') {
            couponList[index].status = '10143009' // 库存不足
          }
          couponList[index].sendLoading = false
          this.setData({
            couponList: couponList,
          })
          wx.showModal({
            title: '领取失败',
            content: err.msg,
            showCancel: false,
            confirmColor: '#333',
          })
        })
    },
  },
})
