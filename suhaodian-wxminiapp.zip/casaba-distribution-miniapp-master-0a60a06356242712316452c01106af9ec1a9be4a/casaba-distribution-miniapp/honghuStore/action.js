/* global getApp */
import gql from '../utils/gql'
import request from './request'
import {
  getPintuanProductDetailStr,
  getProductDetailStr,
  getJoinPintuanTeamDetailStr,
  getProductInfoStr,
} from './productGql'
import {
  createPintuanOrderStr,
  getOrderDetailStatusStr,
  joinPintuanTeamStr,
  prepayPintuanOrderStr,
  getPintuanTeamDetailStr,
  getOrderCodesStr,
} from './orderGql'
import { loginStr, updateUserStr } from './userGql'

const getPintuanProductDetailQuery = gql(getPintuanProductDetailStr)
const getProductDetailQuery = gql(getProductDetailStr)
const createPintuanOrderQuery = gql(createPintuanOrderStr)
const joinPintuanTeamQuery = gql(joinPintuanTeamStr)
const prepayPintuanOrderQuery = gql(prepayPintuanOrderStr)
const getOrderDetailStatusQuery = gql(getOrderDetailStatusStr)
const loginQuery = gql(loginStr)
const updateUserQuery = gql(updateUserStr)
const getPintuanTeamDetailQuery = gql(getPintuanTeamDetailStr)
const getOrderCodesQuery = gql(getOrderCodesStr)
const getJoinPintuanTeamDetailQuery = gql(getJoinPintuanTeamDetailStr)
const getProductInfoQuery = gql(getProductInfoStr)

const loginAction = function(appCode, code) {
  return request(loginQuery({ appCode, code }))
}

const updateUserAction = function(data) {
  return request(updateUserQuery({ data }))
}

const getPintuanProductDetailAction = function(id) {
  return request(getPintuanProductDetailQuery({ id }))
}

const getProductDetailAction = function(params) {
  return request(getProductDetailQuery({ ids: [params.id] }))
    .then(res => {
      return res.data.products && res.data.products[0]
    })
    .catch(e => {
      console.log('getPintuanTeamDetailAction error', e)
    })
}

const createPintuanOrderAction = function(data) {
  const app = getApp()

  Object.assign(data, {
    originChannel: 'WECHAT_MINIPROGRAM',
    appCode: app.globalData.appCode,
    paymentProvider: 'WECHAT',
  })
  data.shipment.method = 'EXPRESS'

  return request(createPintuanOrderQuery({ data }))
    .then(response => {
      const result = response.data && response.data.pintuanTeamCreate
      return {
        orderId: result.order.id,
        orderCode: result.order.code,
        teamId: result.pintuanTeam.id,
      }
    })
    .catch(error => {
      throw error[0] && error[0].message
    })
}

const joinPintuanTeamAction = function(data) {
  const app = getApp()
  Object.assign(data, {
    originChannel: 'WECHAT_MINIPROGRAM',
    appCode: app.globalData.appCode,
    paymentProvider: 'WECHAT',
  })
  data.shipment.method = 'EXPRESS'
  delete data.campaignId

  return request(joinPintuanTeamQuery({ data }))
    .then(response => {
      const result = response.data && response.data.pintuanTeamJoin
      return {
        orderId: result.order.id,
        orderCode: result.order.code,
        teamId: result.pintuanTeam.id,
      }
    })
    .catch(error => {
      throw error[0] && error[0].message
    })
}

const prepayPintuanOrderAction = function(id) {
  return request(prepayPintuanOrderQuery({ id }))
    .then(response => {
      return response.data && response.data.orderPrepay
    })
    .catch(error => {
      throw error[0] && error[0].message
    })
}

const getOrderDetailStatusAction = function(id) {
  return request(getOrderDetailStatusQuery({ id }))
    .then(response => {
      return response.data.node
    })
    .catch(error => {
      throw error[0] && error[0].message
    })
}

const getPintuanTeamDetailAction = function(id) {
  return request(getPintuanTeamDetailQuery({ id }))
    .then(response => {
      return response.data.node
    })
    .catch(error => {
      throw error[0] && error[0].message
    })
}

const getOrderCodesAction = function(codes) {
  return request(getOrderCodesQuery({ codes }))
    .then(response => {
      return response.data.byCodes
    })
    .catch(error => {
      throw error[0] && error[0].message
    })
}

const getJoinPintuanTeamDetailAction = function(id, pintuanTeamId) {
  return request(getJoinPintuanTeamDetailQuery({ ids: [id], pintuanTeamId }))
    .then(res => res.data)
    .catch(err => {
      throw err[0] && err[0].message
    })
}

const getProductInfoAction = function(code) {
  return request(getProductInfoQuery({ code }))
    .then(res => res.data)
    .catch(err => {
      throw err[0] && err[0].message
    })
}

module.exports = {
  getPintuanProductDetailAction,
  getOrderDetailStatusAction,
  prepayPintuanOrderAction,
  createPintuanOrderAction,
  getProductDetailAction,
  joinPintuanTeamAction,
  updateUserAction,
  loginAction,
  getPintuanTeamDetailAction,
  getOrderCodesAction,
  getJoinPintuanTeamDetailAction,
  getProductInfoAction,
}
