import InfoDisplayTab from './InfoDisplayTab';

export default InfoDisplayTab;
