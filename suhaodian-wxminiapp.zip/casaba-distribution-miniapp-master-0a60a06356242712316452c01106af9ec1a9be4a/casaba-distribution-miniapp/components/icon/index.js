/* global Component */
Component({
  externalClasses: ['u-class'],
  properties: {
    type: {
      type: String,
      value: '',
    },
    size: {
      type: String,
      value: 14,
    },
    color: {
      type: String,
      value: '',
    },
    image: {
      type: Boolean,
      value: false,
    },
    prefixClass: {
      type: String,
      value: 'icon-',
    },
  },
})
