import hh from '../../../../honghuStore/request'
import { getBargainList } from './gql'
import { fixIOSDate } from '../../utils/util'
Component({
  properties: {
    cid: Number,
    ctype: String,
    commodityList: {
      type: Array,
      value: [],
    },
    mode: {
      type: String,
      value: 'listLineTwo',
    },
    content: {
      type: Object,
      value: null,
      observer: function(newVal) {
        this.setData({
          content: newVal,
        })
      },
    },
  },
  data: {
    _commodityList: [],
    loading: false,
    done: false,
  },
  attached() {
    this.setData({ loading: true, done: false })
    this.initLoad(this.data.commodityList)
  },
  methods: {
    initLoad(cacheProductList) {
      const {
        spellGoodsType,
        autoSelectsort,
        autoSelectNum,
        autohideFailAct,
      } = this.data.content
      hh(getBargainList()).then(res => {
        // step1: 获取后台配置的砍价活动 list
        const bargainList = res.data.shop.campaigns.edges
        if (spellGoodsType === '2') {
          if (bargainList) {
            // step2. 排序出spu下最低秒杀价格的sku
            let finalProductList = this.spuGroup(bargainList)
            // step3. 然后根据后台排序规则进行商品排序
            this.sortProduct(finalProductList, autoSelectsort)
            // step4. 根据是否显示已售罄规则过滤商品；根据数量规则显示相应的数量
            this.showProduct(
              this.filterSoldOut(finalProductList, autohideFailAct),
              autoSelectNum
            )
          }
        } else {
          // step1: 获取后台配置的砍价活动 list
          const bargainList = res.data.shop.campaigns.edges
          const matchBargain = bargainList
            .map(item => {
              const index = cacheProductList.findIndex(
                cp => cp.goodsInfo.actCode === item.node.code
              )
              return ~index ? item : null
            })
            .filter(f => !!f)
          if (matchBargain) {
            // step2. 排序出spu下最低秒杀价格的sku
            let finalProductList = this.spuGroup(matchBargain)
            // step4. 根据是否显示已售罄规则过滤商品；根据数量规则显示相应的数量
            this.showProduct(
              this.filterSoldOut(finalProductList, autohideFailAct),
              -1
            )
          }
          // 后台配置的手动选择
          // const _ids = cacheProductList.map(cp => cp.goodsInfo.actCode)
          // _ids.forEach(_id => {
          //   hh(getBargainDetail({ code: _id })).then(res => {
          //     const matchBargain = res.data.byCode
          //     if (matchBargain) {
          //       const finalProduct = this.spuGroup([matchBargain])
          //       this.showProduct(this.filterSoldOut(finalProduct, autohideFailAct), false, true)
          //     }
          //   })
          // })
        }
      })
    },
    pubRefresh() {
      this.setData({ done: false })
      let _commodityList = this.data._commodityList
      if (this.data.commodityList.length) {
        _commodityList = this.data.commodityList
      }
      this.initLoad(_commodityList)
    },
    spuGroup(productList) {
      let final = []
      final = productList.map((p, index) => {
        return {
          ...p.node.skuList[0].sku.product,
          code: p.node.code,
          netqty: p.node.skuList[0].sku.netqty,
          totalStock: p.node.skuList[0].totalStock, // 参与活动数量
          surplusStock: p.node.skuList[0].surplusStock, // 剩余活动库存
          totalSurplusStock: p.node.totalSurplusStock,
          salePrice: p.node.skuPrice,
          floorPrice: p.node.floorPrice,
          statistics: p.node.statistics,
        }
      })
      return final
    },
    sortProduct(productList, type) {
      if (type === 'newShelve') {
        productList.sort(
          (a, b) =>
            new Date(fixIOSDate(b.listTime)) - new Date(fixIOSDate(a.listTime))
        )
      } else if (type === 'priHighToLow') {
        productList.sort((a, b) => b.floorPrice - a.floorPrice)
      } else if (type === 'priLowToHigh') {
        productList.sort((a, b) => a.floorPrice - b.floorPrice)
      }
    },
    filterSoldOut(productList, isHide) {
      let filteredProduct = []
      filteredProduct = productList
        .map(p => {
          const { remaining, netqty } = this.remainingQuantity(p)
          if (isHide && !netqty) {
            return false
          } else {
            return this.reducer({}, p, { remaining, netqty })
          }
        })
        .filter(f => !!f)
      return filteredProduct
    },
    reducer(source, target, other) {
      return {
        goodsInfo: {
          ...source,
          code: target.code,
          title: target.name,
          picUrl: target.pics && target.pics[0].picUrl,
          salePrice: target.floorPrice,
          listPrice: target.salePrice,
          totalSurplusStock: target.totalSurplusStock,
          helperCount: target.statistics.helperCount,
          remaining: other.remaining,
        },
      }
    },
    remainingQuantity(productSku) {
      // 计算出剩余的件数和库存
      const remaining = productSku.totalSurplusStock
      const netqty = Math.min(productSku.netqty, productSku.totalSurplusStock)
      return { remaining, netqty }
    },
    showProduct(filteredProduct, limitShowNum) {
      this.setData({
        loading: false,
        done: true,
        _commodityList: ~limitShowNum
          ? filteredProduct.splice(0, limitShowNum)
          : filteredProduct,
      })
      console.log('final data: ', this.data._commodityList)
    },
    handleViewMore() {
      const { path } = this.content
      if (path) {
        this.triggerEvent('jump', { url: path })
      }
    },
    handleJump({ currentTarget }) {
      const { code } = currentTarget.dataset.item
      if (code) {
        this.triggerEvent('jump', {
          url: `honghu/pages/bargain/detail/index?scene=${code}`,
        })
      }
    },
  },
})
