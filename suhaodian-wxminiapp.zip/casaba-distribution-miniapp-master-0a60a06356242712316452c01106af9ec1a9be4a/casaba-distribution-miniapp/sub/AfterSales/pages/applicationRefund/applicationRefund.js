const app = getApp()
Page({
  data: {
    productlist: [],
  },
  onLoad: function(options) {
    wx.getStorage({
      key: 'refundProduct',
      success: res => {
        const _data = JSON.parse(res.data)
        let _productlist = []
        _productlist.push(_data)
        this.setData({
          productlist: _productlist,
        })
      },
    })
  },
  // 跳转退款页面
  handleApplyForRefund() {
    app.router.navigateTo('/sub/AfterSales/pages/messageRefund/messageRefund')
  },
})
