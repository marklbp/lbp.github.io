Component({
  properties: {
    uclass: String,
    needForm: {
      type: Boolean,
      value: false,
    },
    showToast: {
      type: Boolean,
      value: true,
    },
    tipsText: {
      type: String,
      value: '请先授权，才能继续下一步操作',
    },
    tapType: {
      type: String,
      value: '',
    },
    extraData: {
      type: String,
      value: '',
    },
    isPopup: {
      type: Boolean,
      value: true,
    },
    enabledTimesValidate: {
      type: Boolean,
      value: false,
    },
    once: Boolean,
  },
  data: {
    hasAuthorized: false,
    times: 0,
  },
  attached() {
    this.checkUserInfo()
  },
  methods: {
    checkUserInfo() {
      wx.getSetting({
        success: res => {
          if (res.authSetting['scope.userInfo']) {
            wx.getUserInfo({
              success: res => {
                this.setData({
                  hasAuthorized: !!res.userInfo,
                })
              },
            })
          }
        },
      })
    },
    onGetUserInfo({ detail }) {
      if (this.data.hasAuthorized) {
        return
      }
      if (detail.iv) {
        this.triggerEvent('success', {
          ...detail,
          tapType: this.data.tapType,
          extraData: this.data.extraData,
        })
      } else {
        this.triggerEvent('cancel', {
          cancel: 'fail',
          tapType: this.data.tapType,
          extraData: this.data.extraData,
        })
        if (this.data.once) {
          this.setData({ times: 1 })
        }
        if (this.data.showToast) {
          wx.showToast({
            title: this.data.tipsText,
            icon: 'none',
          })
        }
      }
    },
    handleTriggerEvent() {
      this.triggerEvent('callback')
    },
  },
})
