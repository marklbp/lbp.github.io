/*
* @Author: mengxiaofei
* @Date:   2019-02-15 14:24:49
* @Last Modified by:   mengxiaofei
* @Last Modified time: 2019-02-19 16:57:15
*/
Component({
  externalClasses: ['u-class', 'u-class-mask', 'u-class-content'],

  properties: {
    direction: {
      type: String,
      value: 'right',
      observer: 'setPosition',
    },
    showmask: {
      type: Boolean,
      value: true,
    },
    width: {
      type: String,
      value: '48%;',
    },
    show: {
      type: Boolean,
      value: false,
    },
  },
  attached() {},

  data: {
    position: 'right: 0;',
    isShow: false,
  },

  methods: {
    setPosition(val) {
      if (this.data.direction === 'left') {
        this.setData({
          position: 'left: 0;',
        })
      }
    },
    doNonthing() {},
    maskClick() {
      this.triggerEvent('close', 'mask')
    },
  },
})
