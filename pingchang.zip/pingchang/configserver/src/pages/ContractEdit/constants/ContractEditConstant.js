import { BaseConstant } from 'base';

class ContractEditConstant extends BaseConstant{
	constructor(){
		super();

		this.key = 'ContractEdit_'
	}
}

export default new ContractEditConstant();