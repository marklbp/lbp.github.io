const app = getApp()

Page({
  data: {
    orderTab: [
      {
        name: '全部订单',
        index: '',
      },
      {
        name: '待付款',
        index: '21',
      },
      {
        name: '待收货',
        index: '41',
      },
    ],
    idx: '',
    pageNum: 1,
    pageSize: 5,
    total: 0,
    hasMoreData: false,
    orderLists: [],
    orderVolume: '',
    OrderVolumeDaily: '',
    shopStyle: {
      color: '#fff',
      selectedColor: '#333333',
    },
  },
  onLoad() {
    this.setData({
      shopStyle: {
        color: app.globalData.shopStyle[0],
        selectedColor: app.globalData.shopStyle[1],
        activityColor: app.globalData.shopStyle[2],
      },
    })
    this.getOrderList()
  },
  bindToggle(e) {
    let currIndex = e.currentTarget.dataset.id
    this.setData({
      idx: currIndex,
      pageNum: 1,
      orderLists: [],
    })
    this.getOrderList(this.data.idx)
  },
  getOrderList(id) {
    let $this = this
    let data = {
      tenantCode: app.globalData.tenantCode,
      openId: app.globalData.openid || wx.getStorageSync('openid'),
      coreOrderStatus: id,
      pageNum: this.data.pageNum,
      pageSize: this.data.pageSize,
    }
    app.https({
      method: 'POST',
      url: '/member/user/friend/order/list',
      data: data,
      header: {
        xAuthToken: app.globalData.xAuthToken,
      },
      success: function(res) {
        if (res.data.code == 0) {
          $this.setData({
            orderVolume: res.data.data.orderVolume,
            OrderVolumeDaily: res.data.data.OrderVolumeDaily,
          })
          const orderLists = res.data.data.body
          const total = res.data.data.page.total
          if ($this.data.pageNum >= total / $this.data.pageSize) {
            $this.setData({
              orderLists: $this.data.orderLists.concat(orderLists),
              hasMoreData: false,
            })
          } else {
            $this.setData({
              orderLists: $this.data.orderLists.concat(orderLists),
              hasMoreData: true,
              pageNum: ++$this.data.pageNum,
            })
          }
        }
      },
      fail: function(res) {
        console.log('res', res)
      },
    })
  },
  onReachBottom() {
    if (this.data.hasMoreData) {
      this.getOrderList(this.data.idx)
    } else {
      wx.showToast({
        title: '没有更多数据',
        icon: 'none',
        duration: 2000,
        mask: true,
      })
    }
  },
})
