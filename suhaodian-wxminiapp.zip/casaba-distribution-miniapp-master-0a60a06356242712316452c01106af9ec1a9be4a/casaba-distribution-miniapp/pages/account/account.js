import {
  getBackImage,
  queryOrder,
  tenantFlag,
  updateUserInfo,
  userStatus,
  queryDistributionConfigureName,
} from '../../api/index'
import apiReload from '../../utils/reload'

const app = getApp()

Page({
  data: {
    idx: 1,
    id: null,
    tabs: [
      {
        tabName: '销售管理',
        index: 0,
      },
      {
        tabName: '个人中心',
        index: 1,
      },
    ],
    orderCount: {
      allPayCount: 0,
      waitPay: 0,
      waitDelive: 0,
      waitCollect: 0,
    },
    distUser: app.globalData.distUser,
    isPopup: true,
    auditStatus: 0,
    showModal: false,
    timer: null,
    distributFlag: null, // 分销开关
    recruitFlag: null, // 招募开关
    distributorCenterFlag: null, // 分销员中心可见性开关
    _distributFlag: null,
    _recruitFlag: null,
    amountAvailable: 0, // 可提现
    shopGains: 0, // 店铺收益
    currShopGains: 0, // 今日收益
    deals: 0, // 成交订单
    currDeals: 0, // 今日成交订单
    platformEarnings: 0, // 平台收益
    currPlatformEarnings: 0, // 今日平台收益
    myFriend: 0, // 我的朋友
    currFriend: 0, // 今日
    scrollHeight: 495,
    backgroundUrl: '', // 背景图
    barTitle: '',
    titleName: '申请加入分销员',
  },
  onLoad() {
    if (this.data.distUser === 1) {
      this.setData({
        idx: 0,
      })
    }
    const distUser = wx.getStorageSync('distUser')
    this.setData({
      distUser: distUser,
    })
    this.initLoad()
    this.queryDistributionConfigureNames()
  },
  onShow() {
    if (app.globalData.xAuthToken) {
      this.bindViewOrderList()
      this.getAllStatus()
    }
  },
  onHide() {
    clearInterval(this.data.timer)
    this.setData({
      timer: null,
    })
  },
  initLoad() {
    this.pollingData()
  },
  /**
   * 查询配置名称
   */
  queryDistributionConfigureNames() {
    const promise = queryDistributionConfigureName({
      tenantCode: app.globalData.tenantCode,
    })
    promise.then(res => {
      const { success, data } = res
      if (success) {
        this.setData({
          titleName: data,
        })
      }
      console.log('res', res)
    })
  },
  pollingData() {
    if (this.data.timer) {
      return
    }
    let pollingCount = 0
    const timer = setInterval(() => {
      if (
        !app.globalData.openid ||
        !app.globalData.xAuthToken ||
        !app.globalData.accountId
      ) {
        pollingCount++
        if (pollingCount > 100) {
          clearInterval(timer)
          this.setData({
            timer: null,
          })
          apiReload
            .getOpenIdAndAuthParam(app)
            .then(() => {
              this.bindViewOrderList()
              this.getAllStatus()
              this.getBackImage()
            })
            .catch(() => {
              wx.showToast({
                title: '服务器出现异常，请稍后再试',
                icon: 'none',
              })
            })
        }
      } else {
        clearInterval(timer)
        this.setData({
          timer: null,
        })
        this.bindViewOrderList()
        this.getAllStatus()
        this.getBackImage()
      }
    }, 100)
    this.setData({ timer: timer })
  },
  onAuthorizedSuccess({ detail }) {
    if (!app.globalData.accountId) {
      apiReload.getAuthParam(app, app.globalData.openid).then(() => {
        this.updateUserInfo(detail)
      })
    } else {
      this.updateUserInfo(detail)
    }
    const childDom = this.selectAllComponents('#authorized')
    childDom.forEach(dom => dom.checkUserInfo())
    app.globalData.userInfo = detail.userInfo
  },
  onAuthorizedCancel() {
    this.setData({ isPopup: false })
  },
  updateUserInfo(detail) {
    updateUserInfo(
      {
        id: app.globalData.accountId,
        openId: app.globalData.openid,
        userName: detail.userInfo.nickName,
        userPhoto: detail.userInfo.avatarUrl,
      },
      {
        unexUserToken: app.globalData.unexUserToken,
      }
    )
  },
  getBackImage() {
    getBackImage(
      {
        tenantCode: app.globalData.tenantCode,
      },
      {
        xAuthToken: app.globalData.xAuthToken,
      }
    )
      .then(res => {
        if (res.code === '0') {
          const result = res.data
          this.setData({
            backgroundUrl: result.imageUrl,
            barTitle: result.name || '个人中心',
          })
        }
        wx.setNavigationBarTitle({
          title: this.data.barTitle || '个人中心',
        })
      })
      .catch(() => {
        wx.setNavigationBarTitle({
          title: '个人中心',
        })
      })
  },
  onCloseModal() {
    this.setData({
      showModal: false,
    })
    wx.removeStorage({ key: 'openShowModal' })
  },
  bindViewOrderList() {
    // 初始化请求订单接口
    let orderList = ['21', '31', '41']
    let taskarr = []
    orderList.forEach(i => {
      taskarr.push(
        queryOrder(
          {
            account: app.globalData.openid,
            accountId: app.globalData.accountId,
            tenantCode: app.globalData.tenantCode,
            pageIndex: 1,
            pageSize: 1,
            months: 3,
            orderStatus: i,
          },
          {
            xAuthToken: app.globalData.xAuthToken,
          }
        )
      )
    })
    Promise.all(taskarr)
      .then(([waitPayRes, waitDeliveRes, waitCollectRes]) => {
        if (waitPayRes.head.code === '0') {
          this.setData({
            'orderCount.waitPay': waitPayRes.body.orderQueryOutPageInfo.total,
          })
        }
        if (waitDeliveRes.head.code === '0') {
          this.setData({
            'orderCount.waitDelive':
              waitDeliveRes.body.orderQueryOutPageInfo.total,
          })
        }
        if (waitCollectRes.head.code === '0') {
          this.setData({
            'orderCount.waitCollect':
              waitCollectRes.body.orderQueryOutPageInfo.total,
          })
        }
        wx.stopPullDownRefresh()
        wx.hideNavigationBarLoading()
      })
      .catch(() => {
        wx.stopPullDownRefresh()
        wx.hideNavigationBarLoading()
      })
  },
  goOrderBindViewTap(e) {
    app.router.navigateTo(
      '/sub/Order/pages/order/order?idx=' + e.currentTarget.dataset.item
    )
  },
  goMyCardViewTap() {
    wx.navigateTo({
      url: '',
    })
  },
  goAdressBindViewTap() {
    app.globalData.isFromAddress = 1 // 全局指定跳转来源
    app.router.navigateTo('/sub/Base/pages/address/address')
  },
  /**
   * 前往分销员中心
   */
  goDistributionCenter() {
    const id = this.data.id
    app.router.navigateTo(`/sub/Distribution/pages/center/center?id=${id}`)
  },
  goCouponsBindViewTap() {
    app.router.navigateTo(`/sub/Marketing/pages/coupon/coupon`)
  },
  bindFreeOpenShop() {
    // 申请加入分销员
    app.router.navigateTo('/sub/Distribution/pages/setupshop/setupshop')
  },
  // 是否展示开店入口
  getStatus() {
    return new Promise((resolve, reject) => {
      tenantFlag(
        {
          tenantCode: app.globalData.tenantCode,
          openId: app.globalData.openid || wx.getStorageSync('openid'),
        },
        {
          xAuthToken: app.globalData.xAuthToken,
        }
      ).then(res => {
        if (res.code === '0') {
          resolve(res)
          const result = res.data
          this.setData({
            distributFlag: result.distributFlag,
            distributorCenterFlag:
              typeof result.distributorCenterFlag !== 'undefined' &&
              result.distributorCenterFlag !== null
                ? result.distributorCenterFlag
                : 1,
            _recruitFlag: result.recruitFlag,
          })
        } else {
          reject(res)
        }
      })
    })
  },

  getAuditStatus() {
    return new Promise((resolve, reject) => {
      userStatus(
        {
          tenantCode: app.globalData.tenantCode,
          openId: app.globalData.openid || wx.getStorageSync('openid'),
        },
        {
          xAuthToken: app.globalData.xAuthToken,
        }
      ).then(res => {
        if (res.code === '0') {
          resolve(res)
        } else {
          reject(res)
        }
      })
    })
  },
  getAllStatus() {
    Promise.all([this.getStatus(), this.getAuditStatus()])
      .then(res => {
        const status = res[0].data
        const auditStatus = res[1].data
        console.log('auditStatus', auditStatus)
        let distUser = app.globalData.distUser
        if (auditStatus.distributorStatus === '0') {
          distUser = 1
          wx.setStorageSync('distUser', '1')
          wx.setStorageSync('auditStatus', '0')
          this.setData({
            distUser: '1',
          })
        }
        this.setData({
          recruitFlag: status.recruitFlag,
          auditStatus: auditStatus.distributorStatus,
          distUser: distUser,
          id: auditStatus.id,
        })
      })
      .catch(err => {
        if (this.data._distributFlag == null) {
          // 判断null是因为，请求是异步的，完全不知道哪个会完成请求
          // 这里是防止getAuditStatus先完成后失败，而没有获取到distributFlag和recruitFlag
          this.getStatus().then(res => {
            this.setData({
              recruitFlag: res.data.recruitFlag,
              auditStatus: null,
            })
          })
        } else {
          this.setData({
            distributFlag: this.data._distributFlag,
            recruitFlag: this.data._recruitFlag,
            auditStatus: null,
          })
        }
        console.error('分销状态', err)
      })
  },
  onPullDownRefresh() {
    wx.showNavigationBarLoading()
    this.bindViewOrderList()
    this.getAllStatus()
    this.getBackImage()
  },
  /**
   * 前往我的会员卡
   */
  goMemberShip() {
    app.router.navigateTo('/sub/Member/pages/myMembershipCard/myMembershipCard')
  },
})
