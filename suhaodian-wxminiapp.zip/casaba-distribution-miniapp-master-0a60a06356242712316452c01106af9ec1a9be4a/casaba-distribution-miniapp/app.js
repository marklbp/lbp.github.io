import {
  weChatUserLoginExt,
  weChatAuthorization,
  createAccount,
  getUnexUserToken,
  getNavigationDetail,
  queryCommonSetting,
  checkIfMajorCustomer,
} from './api/index'
import { isIphoneX } from './utils/util.js'
import Router from './utils/route'
import apiReload from './utils/reload'
import honghuStore from './honghuStore/index'
const http = require('./static/utils/http.js')
const { https, postHttps } = require('./static/utils/https.js')

const defaultTabBarList = [
  {
    pagePath: 'pages/home/home',
    text: '首页',
    iconPath: '/assets/tabbar/home.png',
    selectedIconPath: '/assets/tabbar/home_hover.png',
  },
  {
    pagePath: 'sub/Commodity/pages/plp/plp',
    text: '全部商品',
    iconPath: '/assets/tabbar/kind.png',
    selectedIconPath: '/assets/tabbar/kind_hover.png',
  },
  {
    pagePath: 'sub/Pay/pages/shopcart/shopcart',
    text: '购物车',
    iconPath: '/assets/tabbar/cart.png',
    selectedIconPath: '/assets/tabbar/cart_hover.png',
  },
  {
    pagePath: 'pages/account/account',
    text: '我的',
    iconPath: '/assets/tabbar/user.png',
    selectedIconPath: '/assets/tabbar/user_hover.png',
  },
]

App({
  onPageNotFound(res) {
    if (res.path.includes('activity/activity')) {
      const param = res.path.split('?')[1]
      wx.redirectTo({
        url: '/sub/Decorate/pages/activity/activity' + '?' + param,
      })
    } else {
      wx.redirectTo({
        url: '/sub/Base/pages/404/404',
      })
    }
  },
  onLaunch: function({ path, query }) {
    this.globalData._options = query
    if (path.includes('pages/searchdetail')) {
      if (query.categoryCode) {
        wx.setStorageSync('toPlpOptions', { code: query.categoryCode })
      }
    }
    if (path.includes('pages/storeProducts')) {
      if (query.storeId) {
        const _currentStore = {
          storeCode: query.storeCode,
          storeId: query.storeId,
          storeName: query.storeName,
        }
        this.globalData.currentStore = _currentStore
      }
    }
    this.onCheckVersion()
    wx.getSystemInfo({
      success: res => {
        this.globalData.isIphoneX = isIphoneX(res)
      },
    })
    wx.getNetworkType({
      success: res => {
        if (res.networkType === 'none') {
          wx.setStorageSync('isConnected', false)
        } else {
          wx.setStorageSync('isConnected', true)
        }
      },
    })
    wx.onNetworkStatusChange(res => {
      if (!res.isConnected) {
        wx.showToast({
          title: '当前网络已断开',
          icon: 'none',
          duration: 4000,
        })
      }
      wx.setStorageSync('isConnected', res.isConnected)
    })
    wx.getSetting({
      success: res => {
        if (res.authSetting['scope.userInfo']) {
          wx.getUserInfo({
            success: res => {
              this.globalData.userInfo = res.userInfo
            },
          })
        }
      },
    })
    try {
      const config = wx.getExtConfigSync()
      const globalData = this.globalData
      console.log('extConfig======', config)
      globalData.tenantCode = config.tenantCode
      globalData.appCode = config.appCode
      globalData.API_HOST = config.host.API_HOST
      globalData.DISTRIBUTION_API_HOST = config.host.DISTRIBUTION_API_HOST
      globalData.appName = config.appName
      globalData['invoke-source'] = config.host.invokeSource
      globalData.appInnerCode = config.appInnerCode
      globalData.tabBarList = config.tabBarList
      globalData.pages = config.pages
      globalData.goodsSharePlugin = config.goodsSharePlugin
      wx.setStorageSync('tenantCode', config.tenantCode)
      wx.setStorageSync('appCode', config.appCode)
      wx.setStorageSync('API_HOST', config.host.API_HOST)
      wx.setStorageSync('API_HOST_PLUS', config.host.API_HOST_PLUS)
      wx.setStorageSync('HH_API_HOST', config.host.HH_API_HOST)
      this.getNavigationDetail(config.tenantCode)
      this.getCustomSeting()
      wx.login({
        success: res => {
          this.step1(res.code)
        },
        fail: res => {
          console.error(res)
        },
      })
    } catch (error) {
      console.error(error)
    }
    require('/honghuStore/plugin').init(this)
    this.router = new Router(this)
    this.updateAuthorized()
  },
  onShow() {
    this.regularlyUpdateToken()
    this.getCustomSeting()
    this.handleCheckIfMajorCustomer()
  },
  handleCheckIfMajorCustomer() {
    checkIfMajorCustomer({
      tenantCode: this.globalData.tenantCode,
    })
      .then(res => {
        if (res.data === '1') {
          this.globalData.isMajorCustomer = true
        } else {
          this.globalData.isMajorCustomer = false
        }
      })
      .catch(() => {
        this.globalData.isMajorCustomer = false
      })
  },
  // 获取自定义设置 (logo/sellout/recommand/salesVolume)
  getCustomSeting() {
    queryCommonSetting({
      tenantCode: this.globalData.tenantCode,
    })
      .then(res => {
        if (res.code === '0') {
          this.globalData.customSeting = res.data
          // 消除onLaunch 中的异步任务 结果返回 晚于page-onLoad
          if (this.customCallback) {
            this.customCallback(res.data)
          }
        }
      })
      .catch(e => {
        console.log(e)
      })
  },
  onHide() {
    clearInterval(this.tokenTimer)
    this.tokenTimer = null
  },
  onError(err) {
    console.log('小程序脚本执行或api调用出错了', err)
  },
  globalCart: {},
  tokenTimer: null,
  globalData: {
    isIphoneX: false,
    userInfo: null,
    API_HOST: '',
    tenantCode: '',
    appCode: '',
    appInnerCode: '',
    appType: '',
    appName: '',
    userId: '',
    openid: '',
    distUser: 0,
    auditStatus: null,
    account: '',
    accountId: '',
    shareAccountId: '',
    userCode: '',
    shopCartItem: null,
    unexUserToken: '', // 购物车需要的unexUserToken
    productlist: [], // checkout页面商品信息（方便返回页面时拿到）
    addressInfo: null, // 显示在checkout的添加地址信息
    xAuthToken: null,
    token: null,
    amount: null,
    isFromAddress: null, // 制定地址列表页面跳转来源
    isDefaultAddressed: false, // 是否有默认地址
    activityDetail: '', // 战队活动详情
    teamId: '', // 战队id
    navigationConfig: [], // 导航设置
    shopStyle: [], // 样式
    tabBarList: defaultTabBarList, // tabbarList
    pages: [],
    goodsSharePlugin: false,
    customSeting: null, // 自定义通用设置
    isMajorCustomer: false, // 是否为大客户商户 PACS
    formIds: [],
    _options: null,
  },
  globalCallbacks: {
    // honghu插件选择地址会在把callback放在此处供选择地址页面通知
    chooseAddress: undefined,
  },
  step1(wxCode) {
    weChatUserLoginExt(
      {
        code: wxCode,
        spreadCodeUnique: this.globalData._options.spreadCodeUnique
          ? this.globalData._options.spreadCodeUnique
          : null,
      },
      {
        appCode: this.globalData.appCode,
      }
    )
      .then(res => {
        const data = {
          sessionKey: res.data.session_key,
          openid: res.data.openid,
          distUser: res.data.distUser,
          auditStatus: res.data.distributorStatus || '',
          user: res.data.user && JSON.parse(res.data.user),
          spreadCodeSkipUrl: res.data.spreadCodeSkipUrl,
        }
        this.globalData.openid = data.openid
        this.globalData.distUser = data.distUser
        this.globalData.auditStatus = data.auditStatus
        this.globalData.userId = data.user ? data.user.id : ''
        wx.setStorage({
          key: 'distUser',
          data: data.distUser,
        })
        wx.setStorage({
          key: 'auditStatus',
          data: data.auditStatus,
        })
        wx.setStorage({
          key: 'openid',
          data: data.openid,
        })
        wx.setStorage({
          key: 'session_key',
          data: data.sessionKey,
        })
        let spreadCodeSkipUrl = data.spreadCodeSkipUrl
        this.step2(data.openid, spreadCodeSkipUrl)
      })
      .catch(err => {
        if (err.statusCode === '424') {
          wx.showModal({
            title: '',
            content: err.msg,
            showCancel: false,
          })
        }
      })
  },
  step2(openid, spreadCodeSkipUrl = '0') {
    // 第三方登录验证接口1 - 之前是在这里拿用户的unexUserToken，但是这里的unexUserToken无法用于购物车查询、创建订单、支付
    weChatAuthorization({
      tenantCode: this.globalData.tenantCode,
      appType: '05',
      appIdentifier: openid,
    })
      .then(res => {
        if (res.header.xAuthToken) {
          this.globalData.xAuthToken = res.header.xAuthToken
        }
        this.globalData.account = res.data.content.account
        this.globalData.accountId = res.data.content.accountId
        this.globalData.userCode = res.data.content.userCode
        this.globalData.appType = res.data.content.appType
        // this.globalData.unexUserToken = res.data.content.unexUserToken
        if (!this.globalData.accountId) {
          this.step3(openid)
        } else {
          this.goHomeOrSetShop(spreadCodeSkipUrl)
        }
        wx.setStorage({
          key: 'accountId',
          data: res.data.content.accountId,
        })
      })
      .catch(err => {
        console.error('/authorization', err)
      })
    // 第三方登录验证接口2 - 获取的unexUserToken可以用于小程序内所有需要unexUserToken的接口, 即casaba+ unex接口
    getUnexUserToken(openid, {
      'invoke-source': this.globalData['invoke-source'],
    })
      .then(res => {
        if (res.data.unexUserToken) {
          this.globalData.unexUserToken = res.data.unexUserToken
          wx.setStorage({
            key: 'token_set_time',
            data: String(Date.now()),
          })
        }
      })
      .catch(err => {
        console.error('/validate.do', err)
      })
  },
  step3(openid) {
    createAccount({
      tenantCode: this.globalData.tenantCode,
      account: openid,
      sharedUserOpenid: wx.getStorageSync('sharerOpenId'),
      password: '123456',
      status: '01',
      source: '01',
      isReceiveEmail: '1',
      isReceiveMsg: '1',
      emailVerification: '1',
      mobileVerification: '1',
      appType: '05',
      appIdentifier: openid,
      appToken: 'test',
      spreadCodeUnique: this.globalData._options.spreadCodeUnique
        ? this.globalData._options.spreadCodeUnique
        : null,
    })
      .then(res => {
        const { statusCode } = res
        let spreadCodeSkipUrl = null
        if (Object.is(statusCode, '200')) {
          if (res.data) {
            this.globalData.accountId = res.data.content
            try {
              spreadCodeSkipUrl = res.data.spreadCodeSkipUrl
              this.goHomeOrSetShop(spreadCodeSkipUrl)
            } catch (err) {
              console.log('err', err)
            }
          }
          this.step2(this.globalData.openid, spreadCodeSkipUrl)
        } else {
          if (res.msg === '此账号已存在') {
            return
          }
          wx.showModal({
            content: '用户登录异常',
            showCancel: false,
            confirmText: '重试',
            success: () => {
              this.step3(openid)
            },
          })
        }
      })
      .catch(err => {
        if (err.msg === '此账号已存在') {
          return
        }
        wx.showModal({
          content: '用户登录异常',
          showCancel: false,
          confirmText: '重试',
          success: () => {
            this.step3(openid)
          },
        })
      })
  },
  regularlyUpdateToken() {
    wx.getStorage({
      key: 'token_set_time',
      success: res => {
        if (res.data) {
          const expTime = Number(res.data) + 10 * 60 * 1000
          let now = Date.now()
          if (now > expTime) {
            this.globalData.unexUserToken = null
            this.globalData.xAuthToken = null
            if (this.globalData.openid) {
              apiReload.getAuthParam(this, this.globalData.openid)
              apiReload
                .getUnexUserToken(this, this.globalData.openid)
                .then(() => {
                  this.regularlyUpdateToken()
                })
            } else {
              apiReload.getOpenIdAndToken(this).then(() => {
                apiReload.getAuthParam(this, this.globalData.openid)
                this.regularlyUpdateToken()
              })
            }
          } else {
            if (!this.tokenTimer) {
              this.globalData.unexUserToken = null
              this.globalData.xAuthToken = null
              if (this.globalData.openid) {
                apiReload.getAuthParam(this, this.globalData.openid)
                apiReload.getUnexUserToken(this, this.globalData.openid)
              } else {
                apiReload.getOpenIdAndToken(this).then(() => {
                  apiReload.getAuthParam(this, this.globalData.openid)
                })
              }
            }
            this.tokenTimer = setInterval(() => {
              now = Date.now()
              if (now > expTime) {
                this.globalData.unexUserToken = null
                this.globalData.xAuthToken = null
                if (this.globalData.openid) {
                  clearInterval(this.tokenTimer)
                  apiReload.getAuthParam(this, this.globalData.openid)
                  apiReload
                    .getUnexUserToken(this, this.globalData.openid)
                    .then(() => {
                      this.regularlyUpdateToken()
                    })
                } else {
                  clearInterval(this.tokenTimer)
                  apiReload.getOpenIdAndToken(this).then(() => {
                    apiReload.getAuthParam(this, this.globalData.openid)
                    this.regularlyUpdateToken()
                  })
                }
              }
            }, 1000)
          }
        }
      },
    })
  },
  onCheckVersion() {
    const updateManager = wx.getUpdateManager()

    updateManager.onCheckForUpdate(function(res) {
      // 请求完新版本信息的回调
      console.log('请求新版本信息的回调=====', res.hasUpdate)
    })

    updateManager.onUpdateReady(function() {
      wx.showModal({
        title: '更新提示',
        content: '新版本已经准备好，是否重启应用？',
        success: function(res) {
          if (res.confirm) {
            updateManager.applyUpdate()
          }
        },
      })
    })

    updateManager.onUpdateFailed(function() {
      // 新版本下载失败
    })
  },
  updateAuthorized() {
    this.getUserAuthSettingAction().then(authSetting => {
      this.honghuStore.isAuthorized = !!authSetting['scope.userInfo']
    })
  },
  getUserAuthSettingAction() {
    return new Promise((resolve, reject) => {
      wx.getSetting({
        success(res) {
          resolve(res.authSetting)
        },
        fail(error) {
          reject(error)
        },
      })
    })
  },
  // 获取导航栏配置以及全局配色
  getNavigationDetail(tenantCode) {
    getNavigationDetail(tenantCode).then(res => {
      try {
        // prettier-ignore
        this.globalData.shopStyle = res.data.shopStyleDto.styleColor.split(',')
        this.globalData.shopStyle[0] = '#fff'
        // this.globalData.shopStyle = '#fff,#eba02d,#12b4f4'.split(',');
      } catch (e) {
        this.globalData.shopStyle = '#fff,#eba02d,#12b4f4'.split(',')
      }
    })
  },
  /**
   * 前往首页或者申请成为分销员
   * spreadCodeSkipUrl: 推广码跳转 (0:首页 1：申请分销员页面)
   */
  goHomeOrSetShop(spreadCodeSkipUrl) {
    if (Object.is(spreadCodeSkipUrl, '1')) {
      wx.redirectTo({
        url: '/sub/Distribution/pages/setupshop/setupshop',
      })
    }
  },
  http: http,
  https: https,
  honghuStore,
  postHttps,
})
