export function getMinimalPriceSku(skus) {
  const initSku = { price: Infinity }

  return skus.reduce((pre, cur) => {
    if (pre.price < cur.price) {
      return pre
    }
    return cur
  }, initSku)
}
