module.exports = {
  extends: 'standard',
  plugins: ['json'],
  globals: {
    App: true,
    Page: true,
    Component: true,
    Behavior: true,
    getApp: true,
    wx: true,
    getCurrentPages: true,
    getRegExp: true,
  },
  rules: {
    'comma-dangle': ['error', 'only-multiline'],
    'space-before-function-paren': ['error', 'never'],
    'no-extend-native': [
      'error',
      {
        exceptions: ['Number'],
      },
    ],
    eqeqeq: ['warn'],
  },
}
