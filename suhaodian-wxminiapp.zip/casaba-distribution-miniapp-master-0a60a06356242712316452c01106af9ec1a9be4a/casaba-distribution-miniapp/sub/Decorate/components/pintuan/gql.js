import gql from '../../../../utils/gql'

const queryPintuanDetail = `
query getPintuanDetail($code: String!, $after: String) {
  shop {
    ongoingCampaignProductsConnection(type: NORMAL, campaignCode: $code, first: 40, after: $after) {
      edges {
        node {
          name
          saleStatus
          listTime
          spuCode: code
          pics: itemImageList {
            picUrl
          }
          skus {
            code
            sales
            netqty
            listPrice
            salePrice
          }
          campaign {
            code
            name
            limitNumber
            status
            type
            productSkus {
              code
              sales
              netqty
              pintuanPrice
              salePrice
              listPrice
            }
          }
        }
        cursor
      }
      pageInfo {
        startCursor
        endCursor
        hasNextPage
      }
    }
  }
}
`
export const getPintuanDetail = gql(queryPintuanDetail)
