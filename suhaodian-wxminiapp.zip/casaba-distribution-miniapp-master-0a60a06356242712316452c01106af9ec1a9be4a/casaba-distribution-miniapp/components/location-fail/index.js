/* global Component */
Component({
  externalClasses: ['u-class-icon'],
  options: {
    multipleSlots: true,
  },
  methods: {
    handleOpenSetting() {
      wx.openSetting({})
    },
  },
})
