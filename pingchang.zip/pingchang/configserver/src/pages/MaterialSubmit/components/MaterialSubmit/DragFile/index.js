import DragFile from './DragFile';

export default DragFile;