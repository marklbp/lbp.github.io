import gql from '../../../../utils/gql'
const BargainFragment = `
fragment BargainFragment on BargainCampaign {
  id
  code
  name
  availablePeriod {
    start
    end
  }
  bargainType
  floorPrice
  skuPrice
  skuList {
    sku {
      code
      netqty
      salePrice
      product {
        name
        listTime
        pics: itemImageList {
          picUrl
        }
      }
    }
    totalStock
    surplusStock
  }
  totalSurplusStock
  statistics {
    helperCount
  }
}
`
const queryBargainDetail = `
query getBargainDetail($code: String!) {
  byCode(typename: "BargainCampaign",code: $code) {
    ... on BargainCampaign {
      ...BargainFragment
    }
  }
}

${BargainFragment}
`
const queryBargainList = `
query getBargainList{
  shop {
    campaigns(type: BARGAIN, first: 100) {
      edges {
        node {
          ... on BargainCampaign {
            ...BargainFragment
          }
        }
      }
    }
  }
}

${BargainFragment}
`
export const getBargainDetail = gql(queryBargainDetail)
// 因为砍价活动是一对一的关系，即一个商品对应一个活动
// 如果后台选择了好几个，则会调用好几次getBargainDetail接口，为了减少调用则用getBargainList
export const getBargainList = gql(queryBargainList)
