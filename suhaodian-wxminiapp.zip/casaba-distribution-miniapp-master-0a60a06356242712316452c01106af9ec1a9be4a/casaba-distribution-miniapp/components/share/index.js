/* global Component */
Component({
  options: {
    multipleSlots: true,
  },
  properties: {
    custom: {
      type: Boolean,
      value: true,
    },
    visible: {
      type: Boolean,
      value: false,
    },
    imgLoading: {
      type: Boolean,
      value: true,
    },
    tipsText: {
      type: String,
      value: '邀请好友开店，一起来赚钱',
    },
    filePath: {
      type: String,
      value: '',
    },
    header: {
      type: Boolean,
      value: false,
    },
  },

  data: {
    momentsVisible: false,
    actions: [
      {
        name: '发送给朋友',
        openType: 'share',
      },
      {
        name: '生成海报',
      },
    ],
  },

  methods: {
    onCancel() {
      this.triggerEvent('cancel')
    },
    handleClickItem({ detail }) {
      const index = detail.index + 1
      if (index === 2) {
        this.triggerEvent('clickMoment', {})
        this.setData({
          momentsVisible: true,
        })
      }
    },

    handleOpenShareMoments() {
      this.triggerEvent('clickMoment', {})
      this.setData({
        momentsVisible: true,
      })
    },
    onMomentsSuccess() {
      this.setData({
        momentsVisible: false,
      })
    },
    onMomentsCancel() {
      this.setData({
        momentsVisible: false,
      })
    },
  },
})
