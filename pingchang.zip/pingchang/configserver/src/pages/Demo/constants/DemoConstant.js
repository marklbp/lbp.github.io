import BaseConstant from '../../../base/constants/BaseConstant';

class DemoConstant extends BaseConstant{
	constructor(){
		super();

		this.key = 'DEMO_'
	}
}

export default new DemoConstant();