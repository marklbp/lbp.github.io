import LoanDetails from './LoanDetails';

export default LoanDetails;
