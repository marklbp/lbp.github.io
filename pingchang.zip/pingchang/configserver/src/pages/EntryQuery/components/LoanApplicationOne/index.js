import LoanApplicationOne from './LoanApplicationOne';

export default LoanApplicationOne;
