import React, { Component } from 'react';
// import AccountDetail from './components/AccountDetail';

export default class Demo extends Component {

  constructor(props) {
    super(props);
    
  }

  /**
   * <AccountDetail {...this.props} />
   * @return {[type]} [description]
   */
  render() {
    return (
      <div className="account-page">
        这是详情
      </div>
    );
  }
}
