import { createAddress } from '../../../../api/index'
import apiReload from '../../../../utils/reload'
const app = getApp()
Page({
  data: {
    isCheck: 0, // 是否被选中默认地址
    searchData: null,
    addressData: {
      // 地址下拉
      region: ['省', '市', '区'],
      customItem: '全部',
      addColor: '#BABABA',
    },
    name: '',
    tel: '',
    address: '',
    code: '',
    addressInfo: null,
    isSelectAddress: false,
    shopStyle: {
      color: '#fff',
      selectedColor: '#333333',
    },
    saveLoading: false,
  },
  onLoad: function(options) {
    let isSelectAddress = false
    if (options.isSelectAddress && Object.is(options.isSelectAddress, 'true')) {
      isSelectAddress = true
      this.setData({
        isSelectAddress: isSelectAddress,
      })
    }
    this.setData({
      shopStyle: {
        color: app.globalData.shopStyle[0],
        selectedColor: app.globalData.shopStyle[1],
      },
    })
  },
  bindRegionChange: function(e) {
    // 获取地址值
    const region = e.detail.value
    if (region[0] === '全部' || region[1] === '全部' || region[2] === '全部') {
      wx.showToast({
        title: '请选择完整的地区',
        icon: 'none',
      })
      return
    }
    this.setData({
      addressData: {
        // 地址下拉
        region: e.detail.value,
        addColor: '#2E2E2E',
      },
    })
  },
  bindblurGetName(e) {
    // 获取姓名
    let name = e.detail.value
    this.setData({ name: name })
  },
  bindblurGetTel(e) {
    // 获取电话
    let tel = e.detail.value
    if (tel) {
      this.setData({ tel: tel })
    }
  },
  bindblurGetAddress(e) {
    // 详细地址
    let address = e.detail.value
    this.setData({ address: address })
  },
  bindblurGetCode(e) {
    // 获取邮编
    let code = e.detail.value
    this.setData({ code: code })
  },
  clickCurrentStyle(e) {
    // 选中默认地址按钮
    let flag = e.detail.isChecked
    let styleCurrent
    if (!flag) {
      styleCurrent = 0
    } else {
      styleCurrent = 1
    }
    this.setData({ isCheck: styleCurrent })
  },
  validityCheck(obj) {
    if (
      !obj.name ||
      !obj.tel ||
      !obj.address ||
      obj.addressData.region[0] === '省' ||
      obj.addressData.region[1] === '市' ||
      obj.addressData.region[2] === '区'
    ) {
      wx.showToast({
        title: '请将信息填写完整',
        icon: 'none',
      })
      return false
    } else {
      if (!/^[1][3,4,5,6,7,8,9][0-9]{9}$/.test(obj.tel)) {
        wx.showToast({
          title: '请输入有效电话号码',
          icon: 'none',
          duration: 1000,
          mask: true,
        })
        return false
      }
      return true
    }
  },
  bindSaveAdress() {
    // 点击保持按钮
    if (!app.globalData.unexUserToken) {
      apiReload
        .getUnexUserToken(app, app.globalData.openid)
        .then(res => {
          console.log('res', res)
          this.createAddress()
        })
        .catch(() => {
          wx.showToast({
            title: '服务器异常，请稍后再试',
            icon: 'none',
          })
        })
    } else {
      this.createAddress()
    }
  },
  createAddress() {
    if (this.validityCheck(this.data)) {
      this.setData({
        saveLoading: true,
      })
      let data = {
        unexUserToken: app.globalData.unexUserToken,
        account: app.globalData.openid,
        isDefault: this.data.isCheck,
        provinceId: 0,
        province: this.data.addressData.region[0],
        cityId: 1,
        city: this.data.addressData.region[1],
        districtId: 2,
        district: this.data.addressData.region[2],
        address: this.data.address,
        receiverName: this.data.name,
        receiverMobile: this.data.tel,
        receiverZipcode: this.data.code,
      }
      createAddress(data, {
        unexUserToken: app.globalData.unexUserToken,
      })
        .then(res => {
          this.setData({ saveLoading: false })
          if (res.ok) {
            const pages = getCurrentPages()
            let checkoutPages = [
              'sub/Pay/pages/checkout/checkout',
              'honghu/pages/orderConfirm/index',
            ]
            if (
              pages[pages.length - 3] &&
              checkoutPages.includes(pages[pages.length - 3].route)
            ) {
              app.router.navigateBack(2)
            } else {
              app.router.navigateBack()
            }
            // 视为当前选中
            wx.setStorageSync(
              'checkoutAddress',
              JSON.stringify(
                Object.assign(data, {
                  id: res.content,
                })
              )
            )
          } else {
            wx.showModal({
              title: '提示',
              content: res.msg,
            })
          }
        })
        .catch(() => {
          this.setData({ saveLoading: false })
          wx.showToast({
            title: '服务器异常，保存失败',
            icon: 'none',
          })
        })
    }
  },
})
