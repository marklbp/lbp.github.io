import SetFontMenus from './SetFontMenus';

export default SetFontMenus;