import CreateActivityForm from './CreateActivityForm';

export default CreateActivityForm;
