---
  项目的整体描述
  1. 技术栈
  2. 工程化：工程质量 - 保证代码的统一以及代码质量
  3. 性能优化 - 持续化的过程
  4. 目录结构 - 可扩展，结构清晰
  5. tabbar开关设置
  6. 其他说明
  tips：用编辑器的预览观看最佳，微信开发者工具无法预览，使用其他编辑器
---

# 目录

- [技术栈](#技术栈)
- [工程化](#工程化)
- [性能优化](#性能优化)
- [目录结构](#目录结构)
- [tabbar开关设置](#tabbar开关设置)
- [其他说明](#其他说明)

# 项目概述

## 技术栈

- `es6`
- `GraphQL`
- 微信原生小程序语言 `wxml、wxss、wxs`

[⬆️](#目录)

## 工程化

工程化是一个非常大的概念，而工程质量是其中一部分，包含四个部分

- 代码规范：规范必须在制定完成后，项目成员强制执行的
    1. `js规范`：使用的是[eslint:standard](https://cn.eslint.org/docs/rules/#possible-errors), 覆盖了几项，具体查看`.eslintrc.js`，可以阅读下[爱彼迎airbnb编写的风格](https://github.com/lin-123/javascript)，很有用。还有就是必要的`注释`，该项目代码基本上是业务代码，写好一些方法及逻辑的`注释`，有助于观看和维护，还有重要的一点就是命名规范，命名一定要清晰明确，变量和函数用`小驼峰`，常亮`大写`，类和构造函数用`大驼峰`，私有方法和私有属性用`前缀_+小驼峰`，写在util里的方法`注释`要有`函数说明`，`参数说明@param`，`返回值说明@return`，这个参考[JSDoc](http://www.css88.com/doc/jsdoc/)，函数的前缀参考下面表格，如果函数名称的含义超出下面的选项，直接写名称：

        |  前缀    |  含义                |  返回值  |
        |---------|---------------------|---------|
        |  can    |  判断是否可执行某个动作  |  Boolean |
        |  has    |  判断是否还有某个值     | Boolean |
        |  is     |  判断是否为某个值       | Boolean |
        |  get    |  获取某个值            | any |
        |  set    |  设置某个值            | any |
        |  on    |  监听原生api事件或自定义组件emit出来事件 | any |
        |  handle |  处理用户的操作，一般就是写在wxml里的事件，比例bind:tap,bind:input等         | any |
        |  pub    |  跨组件或页面调用的事件，就是说父组件调用子组件的方法，来改变子组件内部的数据及状态，页面与页面之间也是这个意思   | any |
    2. `wxss规范`：**不要用id选择器，少用后代选择器和子选择器，最优的是class选择器**，class命名参考[BEM规范](http://getbem.com/naming/)，当嵌套过深时，命名会过于繁琐，在[w3cplus](https://www.w3cplus.com/search/node/bem)上有很多关于BEM规范的介绍以及扩展，大体上理念就是清晰简洁明确，微信官方UI框架`weui`也是采用`BEM规范`

        ``` html
        <!-- 这是普通的class命名 -->
        <view class="title">
          <view class="icon"></view>
          <view class="text"></view>
        </view>

        <!-- 这是采用BEM规范的class命名 -->
        <view class="title">
          <view class="title__icon"></view>
          <view class="title__text"></view>
        </view>
        ```
        ``` css
        /* bad */
        /* 后代选择器 */
        page .title {}
        page .title .icon {}
        /* 子选择器 */
        page > view {}

        /* good */
        .title {}
        .icon {}
        .text {}

        /* best */
        .title {}
        .title__icon {}
        .title__text {}
        ```
    3. `wxml规范`：层级清晰、根据页面的内容进行功能块的分割，`功能UI上脱离主内容区，技术上脱离文档流的块（弹出层、通知栏等）`无需放在主内容块中，应与主内容块同级

- 代码检验：官方已支持npm，在`微信开发者工具`里已启用`编译前预处理命令: npm run lint:fix`，具体使用为点击`工具栏`上方的`编译`(在`预览`按钮旁边)，结果会在`调试器`的`控制台`打印（只有报错`error`了，才会停止重新加载动作），已引入`eslint`作为`js`**代码质量**的检测工具（后续会引入`ts`的类型说明文件`.d.ts`，来加强代码质量的检验，也能增强代码智能提示），`prettier`作为`js`**代码美观**的格式化工具，**保证代码的统一和质量**，开发完成后`push`代码必须先通过`npm run lint`，当然有时候肯定会忘记，这时候会在`push之前`在做一层`预提交（强检验）`，利用`git hooks: pre-commit`，`husky lint-staged`在`git commit`的时候进行检测，如果失败，则无法`push`，具体流程如下：

  ``` cmd
  -> 工作区的代码编写完成，准备提交
  -> git add 添加到暂存区
  -> 执行 git commit
  -> husky注册在git pre-commit的钩子调起 lint-staged
  -> lint-staged 取得所有被提交的文件依次执行写好的任务（ESLint 和 Prettier）
  -> 如果有错误（没通过ESlint检查）则停止任务，等待下次commit，同时打印错误信息
  -> 成功提交
  ```

  [prettier配置](https://prettier.io/docs/en/options.html)，[lint-staged配置](https://github.com/okonet/lint-staged#configuration)

  ``` json
  // package.json
  "scripts": {
    // 代码编写完成，准备提交前运行的脚本命令，先格式化，再检测，直接运行npm run lint:fix
    // 这里可以直接在开发者工具点击编译就可以处理，然在打开控制台，如果eslint未通过则会报错
    "lint:base": "eslint --ext .js",
    "lint": "npm run format && npm run lint:base -- ./*.js {api,utils}/*.js {components,pages,sub}/**/*.js",
    "lint:fix": "npm run lint -- --fix",
    "format": "prettier --no-semi --single-quote --trailing-comma es5 --write './*.{js,json}' '{api,utils}/*.js' '{components,pages,sub}/**/*.js'"
  },
  "husky": {
    "hooks": {
      "pre-commit": "lint-staged"
    }
  },
  "lint-staged": {
    "linters": {
      "*.{js,json}": [
        "prettier --no-semi --single-quote --trailing-comma es5 --write",
        "eslint --fix",
        "git add"
      ]
    }
  },
  ```

- 代码测试：~~因小程序环境的特殊，官方暂时没有提供测试框架~~，**官方已发布`测试工具集`，后续将逐步引入，进行`单元测试`**

- 代码提交：尽量将`commit细化`以及`commit信息明确`，最好是一个改动一个`commit`，方便其他人员查看以及回退，**发版记得打`tag`，格式`v版本号-日期`，例：`v2.0.65-20190319`**

  ``` plaintext
  feat: 新功能（feature）
  fix: 修复BUG
  doc: 文档（documentation），日志
  style: 格式（不更改代码逻辑）
  refactor: 重构（即不属于feat，也不属于fix）
  perf: 性能提升，优化
  test: 调试，发布sit、uat测试
  chore: 构建过程 或 辅助工具 的 变动
  ===== ===== ===== ===== ===== ===== ===== =====
  Commit示例: feat: add message action in store
  ```

[⬆️](#目录)

## 性能优化

[建议先去看下官方的优化建议](https://developers.weixin.qq.com/miniprogram/dev/framework/performance/tips.html)

- 代码：1. 根据功能模块来划分代码，商品详情现在功能模块太大了，代码行数已经暴增到1300多了，可以说很难阅读和维护了，必须得切割开来，根据功能模块来切分文件，例如活动将新建一个`activity.js`，通过`Behavior`来加载，类似`Vue`的`mixins`，因为现在商品详情是利用`Component`来构造的了；2. 每次`setData`都传递大量新数据，很多页面都有这个问题，其实这里还牵扯到一个问题是不是所有数据都得存在`data`里，这里就得了解`小程序运行原理`，官方已经说了`视图层`和`逻辑层`是两个不同的进程，而视图层的渲染的数据来自逻辑层的data，所以如果我们将所有数据都放在data里，明显会影响传递的速度，引用官方的说明`用户传输的数据，需要将其转换为字符串形式传递，同时把转换后的数据内容拼接成一份 JS 脚本，再通过执行 JS 脚本的形式传递到两边独立环境。`，所以`data`里的数据必须是干净的视图层所需数据，后续将逐步对文件进行优化，将逻辑层数据写在`store`里，需要注意的是可以往`Page`构造参数里写入`store`，而`Component`构造函数则不允许

- 图片：图片是最占资源的，最好不好存储 **大图片**，**渲染图片是非常耗性能** 的，尤其是在安卓机下，大图对性能的影响尤其严重，这里说一下图片大小计算原理，假设一张图片100*100像素的，图像上就有10000个像素点，如果每个像素点的值都是用`RGBA`来存储，那就是说每个像素都有`4个通道`，每个通道`1个字节（8bit = 1byte）`，所以该图片大小大概为`39KB（10000 \* 1 \* 4 / 1024）`，**图片现在已全部上传至阿里云服务器，通过oss的api压缩优化，详情见[components/image](./components/image/index.js)**

- 文件：~~需求不断的提升，文件也越来越多，也导致了用户首次下载资源的速度快慢，所以多余的代码和图片该删除的都删除，开发者工具编译的时候已经帮我们压缩了代码和图片，为了提升用户体验，后续将会采用`分包机制`，将`首屏`所需要的文件放在`主包`里，提升下载及打度~~，**分包已完成**

[⬆️](#目录)

## 目录结构

> 已采用分包机制，详情见[subpackage.md](./subpackage.md)

``` tree
├── README.md             项目的说明
├── CHANGELOG.md          项目的版本日志
├── subpackage.md         小程序分包说明
├── app.json              小程序配置
├── project.config.json   小程序的项目配置
├── ext.json              小程序第三方模板配置
├── package.json          npm的包依赖配置
├── api                   后台服务接口
├── components            公共组件
├── filter                小程序wxs
├── pages                 小程序多页面
├── static                工具函数
├── styles                样式目录-公共、变量
├── template              小程序模板
├── utils                 工具类
├── honghu                鸿鹄子包-营销活动页
├── honghuStore           拼团目录，因商品、订单、营销三个包都有使用，放置在主包内
└── sub                   子包目录
    ├── Base                基础
    ├── Decorate            建站
    ├── Commodity           商品
    ├── Pay                 支付
    ├── Order               订单
    ├── Member              会员
    ├── Marketing           营销
    ├── Store               门店
    ├── AfterSales          售后
    └── Distribution        分销
```

[⬆️](#目录)

## tabbar开关设置

**注**：**因涉及到可以自由开关tabbar的原因，无法在每个调用`switchTab/navigateTo`的地方去判断，代码可维护性就差了，现在app里注入`router`，通过调用`app.router.navigateTo(path)`来进行所有页面的跳转，wxml里也不要使用`<navigator></navigator>`，请在js里跳转，详情见[route.js](./utils/route.js#L25)**

``` js
//app.js
import Router from './utils/route'
this.router = new Router(this)

//a.js
const app = getApp()
app.router.navigateTo('pages/home/home')
```

### 开启tabbar

- 当开启后，`ext.json`里会写入`extJSON.tabbar`和`extJSON.ext.tabBarList`
  + `extJSON.tabbar`是为了小程序编译初始化时配置底部的tabbar
  + `extJSON.ext.tabBarList`是为了小程序启动后，程序内知晓导航的配置，以方便调用`switchTab`

### 关闭tabbar

- 当关闭后，`ext.json`里会写入`extJSON.pages`和`extJSON.ext.pages`，不会写入`extJSON.tabbar`
  + `extJSON.pages`是为了小程序编译初始化时配置首页，即取pages数组第一个页面
  + `extJSON.ext.pages`是为了小程序启动后，程序内知晓首页的配置，以方便回到首页
  + 不会写入`extJSON.tabbar`是为了判断小程序是否配置了tabbar

[⬆️](#目录)

## 其他说明

### 自定义tabbar在安卓机上有严重的性能问题，出现原因是装修配置了多个大图，plp是长列表商品图，导致卡顿、掉帧，切换tabbar严重的卡死，现已切回原生tabbar，新增了`one、two、three`，用于tabbar自定义装修页的承载，新增`activity`，用于页面内微页面链接跳转的内容承载页

### 以下说明是自定义tabbar碰到的问题及解决方案（现已弃用）

- `自定义tabbar`，现在的做法是将所有tabbar页面以组件的形式引入在`pages/tabbar/tabbar`中，这样子做解决了两大问题
  1. 一开始是多页面，切换`tabbar`页`闪屏`，原理是调用微信`重定向`的api，本质是关闭本页面打开新页面，所以会看到闪屏。而将`tabbar`页面集中在一个文件里以`ifelse`的形式就不会出现闪屏
  2. 从二级及以上页面返回到`tabbar`页面时，为了不造成`tabbar`页左上角有返回按钮，先返回到`路由栈`的顶层，`重定向`到指定的`tabbar`页，这样子就会先看到`栈顶`的页面，`用户体验`极差，例如：首页 -> 商品详情（用户想去购物车页）-> **先回到`路由栈顶`的页面，即首页** -> `重定向`到购物车。可能会疑惑，难道直接调用`navigateTo`不好吗，当然可以，但是小程序有`10层`页的限制，那当页面达到`10层`后，页面的跳转，必须得用`redirectTo`，相当于你后续的跳转都是`重定向`，这肯定存在很大的问题，如果用户在商品详情页和购物车页之间一直跳，重定向会闪屏不说，当返回时会不断看到商品详情和购物车页好几次。而现在的做法是，还是以上面的例子来说明，例如：首页 -> 商品详情（去购物车）-> 在商品详情页先调用`tabbar.js`里的方法，将`data`值修改（此时首页已经切换到了购物车），调用`navigateBack`

      ``` js
      // tabbar.js
      data: {
        current: 0
      },
      // 处理二级及以上页面返回tabbar页面,此方法是在栈底页直接调用
      pubTabBarNav (current) {
        this.setData({
          current: current
        })
      }

      // pdp.js
      handleToShoppingCart () {
        const route = getCurrentPages()
        route[0].pubTabBarNav(2)
        wx.navigateBack()
      }
      ```

- `配置tabbar`：tabbar的每个项的文字、icon、顺序的配置。首先最重要的是知道哪几个页面是可以作为`tabbar`页，为什么这个很重要，因为现在所有的`tabbar`页都集中在一个文件里，利用`ifelse`来渲染，那当`tabbar`的顺序改变了，该怎么办，现在是写死的

    ``` html
    <block wx:if="{{ current === 0 }}"><home id="tabbar-home"/></block>
    <block wx:if="{{ current === 1 }}"><plp  id="tabbar-plp"/></block>
    <block wx:if="{{ current === 2 }}"><shopcart id="tabbar-shopcart" bindto="handleToPlp"/></block>
    <block wx:if="{{ current === 3 }}"><account id="tabbar-account"/></block>
    ```

    那如果我们知道了`tabbar`只能配置为`首页(home)`、`全部商品(plp)`、`购物车(shopcart)`、`个人中心(accout)`，就可以这么做

      ``` html
      <block wx:if="{{ current === 0 }}">
        <home wx:if="{{ tabBarList[0].name === 'home' }}" id="tabbar-home" />
        <plp wx:if="{{ tabBarList[0].name === 'plp' }}" id="tabbar-plp" />
        <shopcart wx:if="{{ tabBarList[0].name === 'shopcart' }}" id="tabbar-shopcart" bindto="handleToPlp" />
        <account wx:if="{{ tabBarList[0].name === 'account' }}" id="tabbar-account" />
      </block>
      <block wx:if="{{ current === 1 }}">
        <home wx:if="{{ tabBarList[1].name === 'home' }}" id="tabbar-home" />
        <plp wx:if="{{ tabBarList[1].name === 'plp' }}" id="tabbar-plp" />
        <shopcart wx:if="{{ tabBarList[1].name === 'shopcart' }}" id="tabbar-shopcart" bindto="handleToPlp" />
        <account wx:if="{{ tabBarList[1].name === 'account' }}" id="tabbar-account" />
      </block>
      <block wx:if="{{ current === 2 }}">
        <home wx:if="{{ tabBarList[2].name === 'home' }}" id="tabbar-home" />
        <plp wx:if="{{ tabBarList[2].name === 'plp' }}" id="tabbar-plp" />
        <shopcart wx:if="{{ tabBarList[2].name === 'shopcart' }}" id="tabbar-shopcart" bindto="handleToPlp" />
        <account wx:if="{{ tabBarList[2].name === 'account' }}" id="tabbar-account" />
      </block>
      <block wx:if="{{ current === 3 }}">
        <home wx:if="{{ tabBarList[3].name === 'home' }}" id="tabbar-home" />
        <plp wx:if="{{ tabBarList[3].name === 'plp' }}" id="tabbar-plp" />
        <shopcart wx:if="{{ tabBarList[3].name === 'shopcart' }}" id="tabbar-shopcart" bindto="handleToPlp" />
        <account wx:if="{{ tabBarList[3].name === 'account' }}" id="tabbar-account" />
      </block>
      ```

    没办法，小程序里`js`无法去操作`wxml`，也没有提供`render`函数，无法像`vue`、`react`那样，只能使用这么笨拙的方法，所以必须知道是哪几个页才能配置成`tabbar`页。
    配置的数据从后台接口拿到后，还需要做一层映射，保存到`本地缓存`中，要考虑到其他页跳转`tabbar`页的时候使用的索引，是根据配置的顺序来的

      ``` js
      // tabbar.js
      getNavigationDetail () {
        api.getTabBarSetting().then(res => {
          let navigationConfig = res.data.navigationDto
          let tabBarList = []
          navigationConfig.map((item, index) => {
            if (item.url) {
              const name = /(\/[a-zA-Z0-9]*)+/.exec(item.url)[1].replace('/', '')
              const query = item.url.split('?')[1] || null
              tabBarList.push({
                name: name,
                index: index,
                query: query,
                tap: index === 0 ? 1 : 0, // 这里为什么加这个，下面讲
              })
            }
          })
          wx.setStorage({
            key: 'tabBarList',
            data: JSON.stringify(tabBarList)
          })
        })
      }

      // pdp.js
      handleToShoppingCart () {
        const route = getCurrentPages()
        const tabBarList = JSON.parse(wx.getStorageSync('tabBarList'))
        // 此时的索引必须从缓存中读取了
        const index = tabBarList.findIndex(item => item.name === 'shopcart')
        if (~index) {
          route[0].pubTabBarNav(index)
        }
        wx.navigateBack()
      }
      ```
    **如果后续版本官方支持自定义tabbar**，上面所说的方法都可以干掉，直接采用原生。那做法就炒鸡简单，二级页直接调用`wx.switchTab`，根本不需要考虑配置的顺序如何，返回`tabbar`页也不会出现`栈顶`页了，切换也不会`闪屏`了。`tabbar`配置项就能直接调用微信提供的`api`来配置，当然微信必须得支持咯！

- `tabbar集中在一个页面所带来的问题以及解决方案`

  1. 右上角和扫码分享：当把原始tabbar页面以组件的形式引入到一个页面是，分享怎么解决，像购物车、个人中心这样隐私的页面不可能会让用户分享，那可不可以在切换到购物车、个人中心页的时候关闭右上角的分享按钮呢，答案是可以的，微信原生提供了[能力](https://developers.weixin.qq.com/miniprogram/dev/api/share/wx.hideShareMenu.html)，就是使用`wx.hideShareMenu`，那如果需要自定义分享数据时，必须在组件在生命周期ready钩子上将需要自定义的数据emit出去

      ``` js
      // home.js
      properties: {
        pageId: String, // url?的参数可以直接写在这里
        query: {
          type: String,
          observer: function(val) {
            let query = parseUrlQuery(val)
            if (query && query.pageId) {
              this.setData({
                pageId: query.pageId,
              })
              this.bindViewHomeData()
            }
          },
        },
      }
      ready() {
        this.emitShareOpts(this.data.pageId)
      },
      methods: {
        emitShareOpts(query) {
          const path = query ? '/pages/tabbar/tabbar?pageName=home&pageId=' + query.pageId : '/pages/tabbar/tabbar?pageName=home'
          this.triggerEvent('share', {
            name: 'home',
            data: {
              title: '首页',
              path: path
            }
          })
        },
      }

      // tabbar.js
      // 监听组件emit的分享数据
      onEmitShareOpts({ detail }) {
        const shareOpts = this.store.shareOpts
        shareOpts[detail.name] = detail.data
      },
      onShareAppMessage() {
        const shareOpts = this.store.shareOpts
        const currentPageName = this.store.pageName
        return {
          title: shareOpts[currentPageName].title,
          path: shareOpts[currentPageName].path,
          imageUrl: shareOpts[currentPageName].imageUrl || ''
        }
      },
      ```

  2. 下拉刷新、上拉加载：`tabbar`页肯定会有这种需求，所以在`tabbar.json`里必须开启此能力，开启后，相当于所有的`tabbar`页都能下拉上拉了，那可以在不需要的地方隐藏此能力吗，不能，因为在`.json`里开启后，在小程序初始化完成后，此能力就存在于页面中，官方只提供了停止的能力，即`wx.stopPullDownRefresh`，那解决了这个问题后，在父组件上下拉后内如何触发子组件的方法呢，那很明显了，就是获取子组件，然后调用子组件暴露的一个方法，具体如下：

    ``` html
    <!-- 在wxml内为组件添加id属性，用于在js内获取该组件实例 -->
    <home id="tabbar-home" />
    <plp id="tabbar-plp" />
    <shopcart id="tabbar-shopcart" />
    <account id="tabbar-account" />
    ```
    ``` js
    // 上拉加载
    onReachBottom() {
      if (this.data.tabBarList.length > 0) {
        const name = this.data.tabBarList[this.data.current].name
        if (name) {
          // 在需要的组件内暴露的方法onReachBottom，如果不需要则不用写
          const ctx = this.selectComponent('#tabbar-' + name)
          if (ctx.onReachBottom) {
            ctx.onReachBottom()
          }
        }
      }
    },
    onPullDownRefresh() {
      if (this.data.tabBarList.length > 0) {
        const name = this.data.tabBarList[this.data.current].name
        if (name) {
          const ctx = this.selectComponent('#tabbar-' + name)
          if (ctx.onPullDownRefresh) {
            // 在需要的组件内暴露的方法onPullDownRefresh，如果不需要则不用写
            ctx.onPullDownRefresh()
          } else {
            // 购物车不需要则可以直接stop
            wx.stopPullDownRefresh()
          }
        }
      }
    },
    ```

  3. `ifelse渲染`，`tabbar`切换会使组件的生命周期不断触发：原生的`tabbar`切换，`onLoad`只会被触发一次，而现在是以组件的形式引入到页面中，且以`ifelse`来渲染，就会造成组件不断的加载、卸载，一切换就会去请求数据，用户体验是非常差的，那我想让现在的组件形式与原生一致，只触发一次，那我就去翻文档看看有没有api支持，就在翻的时候看到了`hidden`，诶，这个可以，立马就将`ifelse`替换成了`hidden`，这里有一点需要注意一下，之前用`ifelse`使用`<block>`标签的，这是`无状态`的，当用`hidden`是无效的，这里必须替换成`<view>`。换了`hidden`后，果然，所有组件只触发了一次，但又暴露了一个问题，就是在一进入这个页面会触发下面所有组件的生命周期，这明显不合理，肯定是在切换到该组件页的时候才去加载，一开始我想用`缓存`计数解决，切换到该组件就为点击数量`+1`，初始为`0`，组件内if判断为`1`才加载数据，就可以实现`onLoad`，然后在`observer`里判断`大于1`，刷新数据，可以实现`onShow`，想了想，不可以用`缓存`的形式，这种计数状态必须是一个`会话期`，或者称`小程序使用期`，离开小程序该状态必须被销毁，可能想到用`removeStorage`来移除，但是在代码会在代码中注入这些，阅读是不好理解，而且set，remove是分散在两文件里的，所以用了另一种方法，用`data`和组件的`Prop`来实现，而且逻辑清晰，更易阅读理解，具体实现如下：

      ``` html
      <!-- 注入一个tap点击计数属性，来实现onLoad和onshow -->
      <home tap="{{ tabBarList[0].tap }}" id="tabbar-home" />
      <plp tap="{{ tabBarList[0].tap }}" id="tabbar-plp" />
      <shopcart tap="{{ tabBarList[0].tap }}" id="tabbar-shopcart" bindto="handleToPlp" />
      <account tap="{{ tabBarList[0].tap }}" id="tabbar-account" />
      ```
      ``` js
      // tabbar.js 父组件
      {
        ...省略部分代码
        tabBarList.push({
          name: name,
          index: index,
          query: query,
          tap: index === 0 ? 1 : 0, // index === 0 ,这个判断是因为在进入tabbar后必然后有个就是第一个，被加载显示出来，所以第一个初始为1
        })
      }
      // 监听tabbar切换
      onTabBarClick({ detail }) {
        let tabBarList = this.data.tabBarList
        // 当前索引的tabbar加1
        tabBarList[detail.current].tap++
        this.setData({
          current: detail.current,
          path: detail.path,
          tabBarList: tabBarList,
        })
        this.handleShowShareMenu()
        wx.setStorageSync('tabBarIndex', detail.current)
      }

      // home.js 其他tabbar组件页类似 子组件
      properties: {
        tap: {
          type: Number,
          observer: function(val) {
            if (val === 1) {
              // 实现onLoad
              this.setData({
                listLoading: true,
              })
              this.bindViewHomeData()
            } else if (val > 1) {
              // TODO: 实现onShow, 购物车就需要不断请求
              ...
            }
          }
        },
      },
      attached: function() {
        if (this.data.tap === 1) {
          this.setData({
            listLoading: true,
          })
          this.bindViewHomeData()
        }
      },
      ```

- 日志上报、性能监控、错误报警、页面埋点等后续有需要在引入

[⬆️](#目录)
