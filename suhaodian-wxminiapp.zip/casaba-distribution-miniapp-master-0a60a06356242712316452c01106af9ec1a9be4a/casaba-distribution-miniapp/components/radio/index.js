var behaviorShopStyle = require('../../utils/behavior-shop-style.js')
Component({
  externalClasses: ['u-class'],
  behaviors: [behaviorShopStyle],
  relations: {
    '../radio-group/index': {
      type: 'parent',
    },
  },
  properties: {
    value: {
      type: String,
      value: '',
    },
    checked: {
      type: Boolean,
      value: false,
    },
    disabled: {
      type: Boolean,
      value: false,
    },
    color: {
      type: String,
      value: '',
    },
    position: {
      type: String,
      value: 'left', // left right
      observer: 'setPosition',
    },
  },

  data: {
    checked: false,
    positionCls: `u-radio-left`,
  },
  ready() {
    console.log(this.data.shopStyle)
  },
  methods: {
    changeCurrent(current) {
      this.setData({ checked: current })
    },
    radioChange() {
      if (this.data.disabled) return
      const item = { checked: !this.data.checked, value: this.data.value }
      const parent = this.getRelationNodes('../radio-group/index')[0]
      parent ? parent.emitEvent(item) : this.triggerEvent('change', item)
    },
    setPosition() {
      this.setData({
        positionCls:
          this.data.position.indexOf('left') !== -1
            ? `u-radio-left`
            : `u-radio-right`,
      })
    },
  },
})
