import BaseConstant from '../../../base/constants/BaseConstant';

class DashboardConstant extends BaseConstant{
	constructor(){
		super();

		this.key = 'DASHBOARD_'
	}
}

export default new DashboardConstant();