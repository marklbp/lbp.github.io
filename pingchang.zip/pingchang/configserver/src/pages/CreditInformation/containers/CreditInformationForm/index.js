import CreditInformationForm from './CreditInformationForm';

export default CreditInformationForm;
