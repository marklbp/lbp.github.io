// sub/Distribution/pages/incomeDetails/incomeDetails.js
import { getIncomeDetail } from '../../../../api/index.js'
const app = getApp()
Page({
  /**
   * 页面的初始数据
   */
  data: {
    index: 1,
    animationData: null,
    orderStatus: -1,
    incomeList: [
      // {
      //   id: 0,
      //   detailDesc: '', // 描述
      //   amount: '', // 金额
      //   createTime: '', // 下单时间
      //   orderId: '' // 订单号
      // }
    ],
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    this.getIncomeDetail()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {},

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {},

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {},

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {},

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {},

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {},

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {},
  /**
   * 激活标签页
   */
  activeTab(e) {
    const animation = wx.createAnimation({
      duration: 400,
      timingFunction: 'linear',
    })
    const device = wx.getSystemInfoSync().screenWidth
    let left = (e.target.dataset.status - 1) * 0.25 + 0.125
    left = (left - 7.5 / device) * 100
    animation.left(`${left}%`).step()
    const dataset = e.target.dataset
    this.setData({
      status: dataset.status,
      orderStatus: dataset.orderstatus,
      animationData: animation.export(),
    })
    this.getIncomeDetail()
  },
  /**
   * 获取收入明细
   */
  getIncomeDetail() {
    const orderStatus = this.data.orderStatus
    const promise = getIncomeDetail({
      userId: app.globalData.userId,
      status: Object.is(orderStatus, -1) ? undefined : orderStatus,
    })
    promise.then(res => {
      const { code, data } = res
      if (Object.is(code, '0')) {
        this.setData({
          incomeList: data,
        })
      }
    })
  },
})
