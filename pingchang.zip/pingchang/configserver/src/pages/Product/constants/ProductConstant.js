import BaseConstant from '../../../base/constants/BaseConstant';

class ProductConstant extends BaseConstant{
	constructor(){
		super();

		this.key = 'PRODUCT_'
	}
}

export default new ProductConstant();