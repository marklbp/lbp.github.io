import SetFontCustomDialog from './SetFontCustomDialog';

export default SetFontCustomDialog;