import ProcessDetailItem from './ProcessDetailItem';

export default ProcessDetailItem;