/**
  connectionType: 'system', // 系统system, 小程序tinyCode, 自定义custom
  systemLinkObj: { //选择系统链接时的对象
    systemLinkType: 'system', //链接type，system系统页面，micro微页面， goodsclass商品分类， goodsdetail商品详情， marketing营销互动， stores门店
    currentLink: '',//选择的链接url
    currentText: '',//选择的链接text
    marketType: '', //营销互动下选择的营销活动类型
    categoryObj: {},//系统system下，选择的商品分类或者门店信息
  }
  tinyCodeType: '', //connectionType为tinyCode时才有值，tinyCodeSelf: 我的小程序，tinyCodeElse: 其它小程序
  tinyAppid: '', // appid，其它小程序时须填写
  附：为了兼容老数据在选择内部系统连接时 原先的跳转链接字段会和新功能中的currentLink保持一致
 */

const emit = function(url) {
  this.triggerEvent('jump', { url })
}
const parseQueryString = function(argu) {
  const str = argu.split('?')[1]
  const result = {}
  const temp = str.split('&')
  for (let i = 0; i < temp.length; i++) {
    const temp2 = temp[i].split('=')
    result[temp2[0]] = temp2[1]
  }
  return result
}

function link(source, oldLink) {
  const initEmit = emit.bind(this)
  // 判断是否为老数据
  if (source.systemLinkObj) {
    const { connectionType, systemLinkObj, tinyCodeType } = source
    const { currentLink, systemLinkType, categoryObj } = systemLinkObj
    // 判断新连接字段是否为空
    if (currentLink || (!currentLink && systemLinkType === 'stores')) {
      if (connectionType === 'system') {
        _systemLink(initEmit, currentLink, systemLinkType, categoryObj)
      } else if (connectionType === 'tinyCode') {
        _tinyCodeLink(tinyCodeType, oldLink, initEmit)
      } else if (connectionType === 'custom') {
        _customLink(source, initEmit)
      }
    } else {
      if (connectionType === 'tinyCode') {
        _tinyCodeLink(tinyCodeType, oldLink, initEmit)
      } else if (connectionType === 'custom') {
        _customLink(source, initEmit)
      } else {
        initEmit(oldLink)
      }
    }
  } else {
    initEmit(oldLink)
  }
}

function _systemLink(initEmit, currentLink, systemLinkType, categoryObj) {
  if (
    systemLinkType === 'system' ||
    systemLinkType === 'micro' ||
    systemLinkType === 'goodsdetail' ||
    systemLinkType === 'marketing'
  ) {
    initEmit(currentLink)
  } else if (systemLinkType === 'graphic') {
    initEmit(`${currentLink}`)
  } else if (systemLinkType === 'goodsclass') {
    let code
    if (categoryObj.code) {
      code = categoryObj.code
    } else {
      const qs = parseQueryString(currentLink)
      code = qs.categoryCode
    }
    wx.setStorage({
      key: 'toPlpOptions',
      data: { code },
      success() {
        initEmit('sub/Base/pages/searchdetail/searchdetail')
      },
    })
  } else if (systemLinkType === 'stores') {
    const app = getApp()
    const qs = parseQueryString(currentLink)
    if (qs.storeId) {
      const _currentStore = {
        storeCode: qs.storeCode,
        storeId: qs.storeId,
        storeName: qs.storeName,
      }
      app.globalData.currentStore = _currentStore
    }
    initEmit('sub/Store/pages/storeProducts/index')
  }
}

function _tinyCodeLink(tinyCodeType, oldLink, initEmit) {
  if (tinyCodeType === 'tinyCodeSelf') {
    initEmit(oldLink)
  }
}

function _customLink(source, initEmit) {
  const reg = /^https?:\/\/mp\.weixin\.qq\.com/
  const url = source.swiper2Url || source.titleMoreUrl || source.navigation2Url
  // 以https://mp.weixin.qq.com开头，则为公众号图文链接
  if (reg.test(url)) {
    initEmit(`/sub/Base/pages/webview/webview?src=${encodeURIComponent(url)}`)
  } else {
    initEmit(url)
  }
}

export default link
