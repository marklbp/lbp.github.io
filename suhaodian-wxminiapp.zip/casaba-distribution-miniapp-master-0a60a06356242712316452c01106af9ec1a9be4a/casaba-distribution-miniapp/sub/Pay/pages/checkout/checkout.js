import {
  filterUseableCoupon,
  getItemDetailBySku,
  shoppingCartOrderSettle,
  productsByActivity,
  getStoreDetail,
  checkAvailable,
  queryInvoice,
  queryDeliverySetting,
  getStoreList,
  queryShopMessage,
} from '../../../../api/index'
import apiReload from '../../../../utils/reload'
import { safeGet, formatPrice } from '../../../../utils/util'
import queryString from '../../../../utils/query-string'
import { storeMapper } from '../../../../utils/store'
import {
  showToast,
  // hideToast,
  showLoading,
  hideLoading,
  PROMPT_DURATION_TIME,
} from '../../../../honghuStore/uiHelper'
import {
  HONGHU_ORDER_STATUS_KEY,
  HONGHU_PINTUAN,
} from '../../../../honghuStore/constant'
import DISTRIBUTION_TYPE from '../../../../constant/distribution-type'
import ORDER_TYPE from '../../../../constant/order-type'
const app = getApp()

// 加法
Number.prototype.add = function(arg) {
  var r1, r2, m
  try {
    r1 = this.toString().split('.')[1].length
  } catch (e) {
    r1 = 0
  }
  try {
    r2 = arg.toString().split('.')[1].length
  } catch (e) {
    r2 = 0
  }
  m = Math.pow(10, Math.max(r1, r2))
  return (this * m + arg * m) / m
}

Page({
  data: {
    isShowReloadBtn: false,
    listLoading: false,
    timer: null,
    isProduct: false,
    fromPage: '',
    productlist: [],
    promoProducts: null,
    productPromoAmount: [],
    addressInfo: null,
    amount: 0,
    amount1: null, // 备份计算最好价钱
    productAmount: 0,
    coupon: 0,
    discount: 0,
    discountCode: '',
    token: '',
    addressData: [],
    remark: '',
    inputRemarking: false,
    isTrueFase: 'false',
    isDefaultAddressed: false,
    couponMask: false,
    couponList: [],
    currentSelectCouponCode: [],
    currentCouponRule: [],
    currentFaceValue: '',
    useCoupon: [],
    useCouponRule: [],
    exchangeDiscountCode: [],
    giftProductList: [],
    giftProductListCache: [],
    activityList: [],
    activityNameList: [],
    exchangeLoading: false,
    exchangeSuccess: false,
    currentTab: 0,
    exchangeErrorMsg: '',
    scrollHeight: 495,
    freight: 0,
    amountTrue: true,
    catalogueIndex: -1,
    selectGift: [],
    ruleMask: false,
    baoyou: false,
    pintuanOrderId: '',
    isCreatePintuanAction: false,
    isJoinPintuanAction: false,
    pintuanOrderCode: '',
    pintuanNewTeamId: '',
    pintuanTeamId: '',
    storeId: null,
    store: {},
    shopStyle: {},
    selfPickUpInfo: null,
    currentShippingMethod: 0,
    invoiceflag: false, // 是否开具发票
    invoiceList: [],
    currentInvoice: null,
    currentType: 0,
    distributionMode: null, // 配送方式
    location: null,
    shopInfo: null,
    isIphoneX: false,
  },
  onShow: function() {
    wx.getSystemInfo({
      success: res => {
        const wh = res.windowHeight
        const scrollHeight = wh - 50
        this.setData({
          scrollHeight: scrollHeight,
        })
      },
    })
    const checkoutAddress = wx.getStorageSync('checkoutAddress')

    let addressInfo = checkoutAddress ? JSON.parse(checkoutAddress) : null
    let promoProducts = [] // 筛选用户购物车中可用优惠券的所需商品列表
    let currentType = app.globalData.productlist[0].currentType
    const productlist = app.globalData.productlist.map(item => {
      promoProducts.push({
        quantity: item.count,
        selectionFlag: '01', // 默认不勾选
        spuCode: item.spuCode,
        categoryCode: item.categorycode,
        productPrice: item.saleprice,
        skuCode: item.skucode,
        brandCode: item.brandcode,
      })
      return {
        activityId: '0',
        brandCode: item.brandcode,
        brandName: item.brandname,
        categoryCode: item.categorycode,
        categoryName: item.categoryname,
        count: item.count,
        title: item.title,
        isGift: '0',
        marketPrcie: item.saleprice,
        returnType: '14',
        sellPrice: item.saleprice,
        listprice: item.listprice,
        skuId: item.skucode, // 因目前不确定传啥值，固暂时传空值
        skuName: item.title, // 因目前不确定传啥值，固暂时传空值
        image: item.image,
        tax: 0,
        omsCode: item.extentionCode ? item.extentionCode : item.skucode,
        skucode: item.skucode,
        spuCode: item.spuCode,
        lineCode: 1,
        skuListMap: item.skuListMap,
        pintuanCampaignProduct: item.pintuanCampaignProduct,
        pintuanCampaignSkuId: item.pintuanCampaignSkuId,
        total: (item.saleprice * item.count).toFixed(2),
      }
    })
    this.setData({
      productlist,
      currentType,
      shopStyle: app.globalData.shopStyle,
      promoProducts: promoProducts,
    })

    this.queryInvoicefn()
    if (addressInfo) {
      this.setData({
        addressInfo: addressInfo,
      })
    } else {
      this.setData({
        addressInfo: null,
      })
    }
    // 1. 查询是否开启商家配送/门店自提 2. 门店商品不可选择门店 3. 门店商品不显示向右箭头
    this.pollingData()
  },
  onLoad: function(options) {
    options.pintuanTeamId =
      options.pintuanTeamId && decodeURIComponent(options.pintuanTeamId)
    this.setData({
      isTrueFase: options.isTrueFase || 'false',
      fromPage: options.fromPage || '',
      listLoading: true,
      isCreatePintuanAction: options.isCreatePintuanAction === 'true',
      isJoinPintuanAction: options.pintuanTeamId
        ? options.pintuanTeamId.length > 0
        : false,
      pintuanTeamId: options.pintuanTeamId || '',
      storeId: options.storeId || null,
    })
  },
  onUnload() {
    wx.removeStorageSync('checkoutAddress')
    wx.removeStorageSync('selectInvoice')
  },
  load(location) {
    getStoreList({
      longitude: location.longitude,
      latitude: location.latitude,
      tenantCode: app.globalData.tenantCode,
      pageNum: 1,
      pageSize: 10,
    }).then(response => {
      const stores = safeGet(response, 'data.list', []).map(storeMapper)
      this.setData({
        store: stores[0],
      })
    })
  },
  getLocation() {
    return new Promise((resolve, reject) => {
      wx.getLocation({
        type: 'wgs84',
        success: res => {
          this.setData({
            location: res,
          })
          resolve(res)
        },
        fail: error => {
          reject(error)
        },
      })
    })
  },
  handleQueryShopMessage() {
    // 查询 网店信息
    queryShopMessage({
      tenantCode: app.globalData.tenantCode,
    })
      .then(res => {
        if (res.code === '0') {
          this.setData({
            shopInfo: res.data[0].storeResponse[0],
          })
        } else {
          console.log('网店信息查询失败', res)
        }
      })
      .catch(e => {
        console.log('网店信息查询失败', e)
      })
  },
  handleQueryDeliverySetting() {
    queryDeliverySetting({
      tenantCode: app.globalData.tenantCode,
    })
      .then(res => {
        let distributionMode = safeGet(res, 'data', {})
        distributionMode = Object.assign(distributionMode, {
          express: !!+distributionMode.express,
          pickUpByCustomer: !!+distributionMode.pickUpByCustomer,
        })
        if (!distributionMode.express && distributionMode.pickUpByCustomer) {
          // 自提
          this.setData({
            currentShippingMethod: 1,
          })
        } else if (
          this.data.currentType === '3' ||
          (distributionMode.express && !distributionMode.pickUpByCustomer)
        ) {
          // 配送
          this.setData({
            currentShippingMethod: 0,
          })
        }
        // 如果是自提获取 最近门店
        this.setData({
          distributionMode: distributionMode,
        })

        // 如果商家配送开启 查询网店唯一标识
        if (distributionMode.express) {
          this.handleQueryShopMessage()
        }
        const pages = getCurrentPages()
        let prevPage = pages[pages.length - 2]
        if (prevPage && prevPage.route === 'sub/Store/pages/storeList/index') {
          this.setData({
            currentShippingMethod: 1,
          })
          return
        }
        const store = safeGet(app, 'globalData.currentStore')
        if (distributionMode.pickUpByCustomer && !this.data.storeId) {
          if (store) {
            this.setData({
              store,
            })
          } else if (!this.data.location) {
            this.getLocation().then(location => {
              this.load(location)
            })
          } else if (this.data.location) {
            this.load(this.data.location)
          }
        }
      })
      .catch(e => {
        console.log('店铺配送设置错误', e)
      })
  },
  pollingData() {
    if (this.data.timer) {
      return
    }
    let pollingCount = 0
    const timer = setInterval(() => {
      if (!app.globalData.openid || !app.globalData.unexUserToken) {
        pollingCount++
        if (pollingCount > 100) {
          clearInterval(timer)
          this.setData({
            timer: null,
          })
          apiReload
            .getOpenIdAndToken(app)
            .then(res => {
              this.initData(app.globalData.unexUserToken)
            })
            .catch(() => {
              this.setData({
                listLoading: false,
                isShowReloadBtn: true,
              })
            })
        }
      } else {
        clearInterval(timer)
        this.setData({
          timer: null,
        })
        this.initData(app.globalData.unexUserToken)
      }
    }, 100)
    this.setData({
      timer: timer,
    })
  },
  initData(token) {
    this.getShopCartProductAmount(token)
    this.handleFilterUseableCoupon(token)
    this.handleQueryDeliverySetting()
    if (this.data.storeId) {
      this.loadStoreDetail()
    }
    this.getAddresslist(token).then(res => {
      if (res.data.ok) {
        if (res.data.content.length > 0) {
          let addressData = res.data.content
          let addressInfo = null
          for (const item of addressData) {
            if (item.isDefault === '1') {
              addressInfo = item
              break
            } else {
              addressInfo = addressData[0]
            }
          }
          const checkoutAddress = wx.getStorageSync('checkoutAddress')
          let _addressInfo = checkoutAddress
            ? JSON.parse(checkoutAddress)
            : addressInfo
          this.setData({
            addressInfo: _addressInfo,
            listLoading: false,
          })
          console.log(this.data.distributionMode)
          this.getFreight()
        }
      }
    })
    if (!this.data.addressInfo) {
    }
  },
  onCouponCancel() {
    const couponCodeList = this.data.currentSelectCouponCode
    if (
      couponCodeList.length === 0 &&
      this.data.exchangeDiscountCode.length === 0
    ) {
      this.getShopCartProductAmount(app.globalData.unexUserToken)
      this.setData({
        baoyou: false,
        useCoupon: [],
        useCouponRule: [],
      })
    }
    this.setData({
      couponMask: false,
    })
  },
  handleUseCoupon() {
    const couponCodeList = this.data.currentSelectCouponCode
    if (couponCodeList.length > 0) {
      let productItems = app.globalData.productlist.map(item => {
        return {
          quantity: item.count,
          skuCode: item.skucode,
        }
      })
      let couponCodes = []
      couponCodeList.forEach(item => {
        if (item.rewardType === '05') {
          this.setData({
            baoyou: true,
          })
        }
        if (item.isReward) {
          couponCodes.push(item.couponCode)
        }
      })
      shoppingCartOrderSettle(
        {
          couponCodes: couponCodes.join(','),
          productItems: productItems,
        },
        {
          unexUserToken: app.globalData.unexUserToken,
          'invoke-source': app.globalData['invoke-source'],
        }
      ).then(res => {
        if (res.code === '0') {
          let amount = res.data.amount
          this.setData({
            amount: amount,
            amount1: amount,
            coupon: res.data.coupon,
            discount: res.data.discount,
            useCoupon: couponCodeList,
            useCouponRule: this.data.currentCouponRule,
          })
          this.getGifts(res)
          this.freightAmount()
        }
      })
    } else {
      this.getShopCartProductAmount(app.globalData.unexUserToken)
      this.setData({
        baoyou: false,
        useCouponRule: [],
      })
    }
    this.setData({
      couponMask: false,
    })
  },
  handleUseDiscountCode() {
    let exchangeDiscountCode = this.data.exchangeDiscountCode
    if (
      exchangeDiscountCode.length > 0 &&
      exchangeDiscountCode[0].effectiveFlag
    ) {
      let productItems = app.globalData.productlist.map(item => {
        return {
          quantity: item.count,
          skuCode: item.skucode,
        }
      })
      shoppingCartOrderSettle(
        {
          couponCodes: exchangeDiscountCode[0].code,
          productItems: productItems,
        },
        {
          unexUserToken: app.globalData.unexUserToken,
          'invoke-source': app.globalData['invoke-source'],
        }
      )
        .then(res => {
          this.getGifts(res, true)
          this.setData({
            amount: res.data.amount,
            amount1: res.data.amount,
            coupon: res.data.coupon,
            discount: res.data.discount,
          })
          this.freightAmount()
        })
        .catch(err => {
          this.setData({
            discountCode: '',
            exchangeErrorMsg: err.msg || '',
            exchangeLoading: false,
          })
        })
      this.setData({
        useCoupon: exchangeDiscountCode,
        useCouponRule: [],
        giftProductList: this.data.giftProductListCache,
      })
    } else {
      this.getShopCartProductAmount(app.globalData.unexUserToken)
    }
    this.setData({
      useCouponRule: [],
      couponMask: false,
    })
  },
  onCouponSelectChange(e) {
    // useable 0 不可用 1 已选 -1 未选
    const detail = e.detail
    const dataset = e.currentTarget.dataset
    const couponRule = this.data.currentCouponRule

    let couponListBak = this.data.couponList
    let currentSelectCouponCode = this.data.currentSelectCouponCode

    let couponCode = dataset.couponcode
    currentSelectCouponCode = []
    if (detail.checked) {
      wx.showToast({
        title: '处理中',
        icon: 'none',
        mask: true,
        duration: 50000,
      })
      if (currentSelectCouponCode.length > 0) {
        let coupons = currentSelectCouponCode.map(i => i.couponCode)
        couponCode += ',' + coupons.join(',')
      }
      couponListBak = couponListBak.map(j => {
        if (j.couponCode === couponCode) {
          j['useable'] = 1
          currentSelectCouponCode.push(j)
        } else if (j['useable'] !== 0) {
          j['useable'] = -1
        }
        return j
      })
      this.setData({
        couponList: couponListBak,
        currentSelectCouponCode: currentSelectCouponCode,
      })
    } else {
      let index = currentSelectCouponCode.findIndex(
        j => j.couponCode === couponCode
      )
      currentSelectCouponCode.splice(index, 1)
      couponListBak = couponListBak.map(j => {
        if (j.couponCode === couponCode) {
          j['useable'] = -1
        }
        return j
      })
      this.setData({
        couponList: couponListBak,
        currentSelectCouponCode: currentSelectCouponCode,
      })
      return
    }

    filterUseableCoupon(
      {
        couponCodes: couponCode,
        promoProducts: this.data.promoProducts,
      },
      {
        unexUserToken: app.globalData.unexUserToken,
        'invoke-source': app.globalData['invoke-source'],
      }
    )
      .then(res => {
        if (res.code === '0') {
          // let list = []
          // list =
          //   res.data &&
          //   res.data.filter(item => {
          //     return item.couponStatus === '02'
          //   })
          // for (let i = 0; i < list.length; i++) {
          //   for (let j = 0; j < couponListBak.length; j++) {
          //     if (list[i].couponCode === couponListBak[j].couponCode) {
          //       console.log(1)
          //       if (!list[i].isReward && list[i].useable !== 0) {
          //         couponListBak[j].useable = -1
          //       }
          //     }
          //   }
          // }
          wx.hideToast()
          this.setData({
            // couponList: couponListBak,
            currentSelectCouponCode: currentSelectCouponCode,
            currentCouponRule: couponRule,
            exchangeErrorMsg: '',
          })
        }
      })
      .catch(e => {
        console.log(e)
        wx.hideToast()
      })
  },
  handleFilterUseableCoupon(token) {
    filterUseableCoupon(
      {
        couponCodes: '',
        promoProducts: this.data.promoProducts,
      },
      {
        unexUserToken: token,
        'invoke-source': app.globalData['invoke-source'],
      }
    ).then(res => {
      if (res.code === '0') {
        let list = []
        if (res.data) {
          list = res.data.filter(item => {
            if (item.isReward) {
              item.useable = -1
            } else {
              item.useable = 0
            }
            return item.couponStatus === '02'
          })
        }
        this.setData({
          couponList: list,
        })
      }
    })
  },
  handleOpenCouponMask() {
    this.setData({
      couponMask: true,
      exchangeErrorMsg: '',
    })
  },
  handleTabChange(e) {
    const index = e.currentTarget.dataset.index
    this.setData({
      currentTab: index,
    })
  },
  handleDiscountInput(e) {
    const value = e.detail.value
    this.setData({
      discountCode: value,
      exchangeErrorMsg: '',
    })
  },
  handleExchange() {
    let exchangeDiscountCode = this.data.exchangeDiscountCode
    if (
      exchangeDiscountCode.some(code => code.code === this.data.discountCode)
    ) {
      wx.showToast({
        title: '您已兑换过该优惠码',
        icon: 'none',
      })
      this.setData({ discountCode: '' })
      return
    }
    this.setData({
      exchangeDiscountCode: [],
      exchangeLoading: true,
    })
    checkAvailable(
      {
        couponCodes: this.data.discountCode,
        tenantCode: app.globalData.tenantCode,
        userCode: app.globalData.userCode,
        sandboxTest: '00',
        promoProducts: this.data.promoProducts,
      },
      {
        unexUserToken: app.globalData.unexUserToken,
      }
    )
      .then(res => {
        if (res.code === '0') {
          const _data = res.data
          _data.forEach(code => {
            if (code.couponCode === this.data.discountCode) {
              wx.showToast({
                title: '兑换成功',
                icon: 'none',
              })
              // TODO 获取 优惠券详细信息
              filterUseableCoupon(
                {
                  couponCodes: code.couponCode,
                  promoProducts: this.data.promoProducts,
                },
                {
                  unexUserToken: app.globalData.unexUserToken,
                  'invoke-source': app.globalData['invoke-source'],
                }
              ).then(resdata => {
                const coupons = resdata.data
                var result = coupons.filter(function(couponDetail) {
                  return couponDetail.couponCode === code.couponCode
                })
                exchangeDiscountCode = [
                  {
                    ...result[0],
                    code: result[0].couponCode,
                    effectiveFlag: !result[0].falseReason,
                  },
                ]
                this.setData({
                  discountCode: '',
                  exchangeLoading: false,
                  exchangeDiscountCode: exchangeDiscountCode,
                })
              })
            }
          })
          delete res.data
          res.data = { shoppingCartOuts: _data }
          this.getGifts(res, true)
        } else {
          this.setData({
            discountCode: '',
            exchangeErrorMsg: res.message,
            exchangeLoading: false,
          })
        }
      })
      .catch(err => {
        this.setData({
          discountCode: '',
          exchangeErrorMsg: err.message,
          exchangeLoading: false,
        })
      })
  },
  handleInputRemark(e) {
    this.setData({
      remark: e.detail.value,
      inputRemarking: false,
    })
  },
  getShopCartProductAmount(token) {
    if (this.data.isCreatePintuanAction || this.data.isJoinPintuanAction) {
      const amount = this.data.productlist.reduce((cur, pre) => {
        return cur + Number.parseFloat(pre.total)
      }, 0)
      return this.setData({
        amount,
        amount1: amount,
        listLoading: false,
      })
    }
    let productItems = app.globalData.productlist.map(item => {
      return {
        quantity: item.count,
        skuCode: item.skucode,
      }
    })
    shoppingCartOrderSettle(
      {
        productItems: productItems,
      },
      {
        unexUserToken: token,
        'invoke-source': app.globalData['invoke-source'],
      }
    )
      .then(res => {
        if (res.code === '0') {
          let amount = res.data.amount
          this.getGifts(res)
          this.setData({
            isProduct: true,
            amount: amount,
            amount1: amount,
            productAmount: res.data.productAmount,
            coupon: res.data.coupon,
            discount: res.data.discount,
            isShowReloadBtn: false,
            listLoading: false,
          })
          this.freightAmount()
        }
      })
      .catch(err => {
        if (
          err.data.code === '511101101' ||
          err.data.code === '511101102' ||
          err.data.code === '511101103' ||
          err.data.code === '511101104' ||
          err.data.code === '511101105'
        ) {
          wx.showModal({
            title: '',
            content: err.data.message,
            showCancel: false,
            confirmColor: '#333',
            success: () => {
              app.router.navigateBack()
            },
          })
          return
        }
        this.setData({
          isShowReloadBtn: true,
          listLoading: false,
        })
      })
  },
  getGifts(res, cache) {
    let gifts = []
    let giftGroup = [] // 将不同活动(包括券)的分组，以便在选择是分类
    let giftProductList = []
    let activityList = []
    let activityNameList = []
    let _activityList = []
    let productPromoAmount = []
    res.data.ableCartItems &&
      res.data.ableCartItems.forEach(item => {
        productPromoAmount.push({
          skuCode: item.skuCode,
          promoAmount: item.skuPromoPrice,
        })
      })
    this.setData({ productPromoAmount })
    res.data.shoppingCartOuts &&
      res.data.shoppingCartOuts.forEach(item => {
        if (item.effectiveFlag && item.gifts) {
          gifts.push({
            activityId: item.activityCode,
            activityName: item.activityName,
            giftLimitMax: item.giftLimitMax,
            gift: item.gifts,
          })
          giftGroup.push({
            activityId: item.activityCode,
            activityName: item.activityName,
            giftLimitMax: item.giftLimitMax,
          })
        }
        if (item.effectiveFlag) {
          if (item.rewardType === '05') {
            this.setData({
              baoyou: true,
            })
          }
          activityList.push(item)
          if (item.activityType === '01') {
            activityNameList.push(item.activityName)
          }
        }
      })
    activityList.forEach(item => {
      ;(function(I, root) {
        productsByActivity(
          {
            data: {
              activityCode: item.activityCode,
            },
          },
          {
            'invoke-source': app.globalData['invoke-source'],
          }
        ).then(ac => {
          I.activityBegin = ac.data.activityBegin
          I.activityEnd = ac.data.activityEnd
          _activityList.push(I)
          root.setData({
            activityList: _activityList,
            // catalogueIndex: activityList.length === 1 ? 0 : -1,
          })
        })
      })(item, this)
    })
    if (gifts.length > 0) {
      gifts.forEach((item, index) => {
        item.gift.forEach(gItem => {
          getItemDetailBySku({
            tenantCode: app.globalData.tenantCode,
            skuCode: gItem.skuCode,
          })
            .then(skuRes => {
              if (skuRes.code === -1) {
                return
              }
              let result = skuRes.data
              let attrSaleList = result.skuList[0].attrSaleList
              let sku = []
              let skuListMap = []
              attrSaleList.forEach(subItem => {
                skuListMap.push({
                  code: subItem.attributeValueList[0].attributeValueCode,
                  attributeValueFrontName:
                    subItem.attributeValueList[0].attributeValueFrontName,
                })
                sku.push(subItem.attributeValueList[0].attributeValueFrontName)
              })
              giftProductList.push({
                activityId: item.activityId,
                activityName: item.activityName,
                giftLimitMax: item.giftLimitMax,
                title: result.title,
                saleprice: result.skuList[0].salePrice,
                listprice: result.skuList[0].listPrice,
                count: 1,
                netqty: gItem.skuNum,
                brandcode: result.brand.code,
                brandname: result.brand.name,
                categorycode:
                  result.categoryList[result.categoryList.length - 1]
                    .categoryPath,
                categoryname:
                  result.categoryList[result.categoryList.length - 1].name,
                image: result.itemImageList[0].picUrl,
                spuCode: result.code,
                skucode: gItem.skuCode,
                skuListMap: skuListMap,
                sku: sku.join('，'),
                attrValue: sku.join('，'),
                isGift: '1',
              })
              if (cache) {
                this.setData({
                  giftProductListCache: giftProductList,
                })
              } else {
                this.setData({
                  giftProductList: giftProductList,
                  selectGift: giftProductList,
                })
              }
              wx.setStorage({
                key: 'gift',
                data: JSON.stringify(giftProductList),
              })
              wx.setStorage({
                key: 'giftGroup',
                data: JSON.stringify(giftGroup),
              })
            })
            .catch(err => {
              console.error('通过sku找商品详情', err)
            })
        })
      })
    } else {
      this.setData({
        giftProductList: giftProductList,
      })
    }
    this.setData({
      activityList: activityList,
      activityNameList: activityNameList.join('；'),
    })
  },
  bindViewGoAddress(e) {
    let cityId = e.currentTarget.dataset.cityid
    const query = queryString({
      isSelectAddress: true,
      id: cityId,
    })
    app.router.navigateTo(`/sub/Base/pages/address/address?${query}`)
  },
  getAddresslist(token) {
    // 初始化查询地址列表
    let data = {}
    return new Promise((resolve, reject) => {
      app.http({
        url: '/member/mall/MemAddress/queryByDTO',
        data: data,
        header: {
          unexUserToken: token,
        },
        success: res => {
          resolve(res)
        },
        fail: res => {
          reject(res)
        },
      })
    })
  },
  loadStoreDetail() {
    getStoreDetail(app.globalData.tenantCode, this.data.storeId)
      .then(res => {
        const store = safeGet(res, 'data', {})
        this.setData({
          store,
        })
      })
      .catch(() => {
        this.setData({
          showReloadBtn: true,
        })
      })
  },
  handleShippingMethodChange(e) {
    const currentShippingMethod = e.detail.current
    this.setData({
      currentShippingMethod,
    })
  },
  changeShippingMethod(event) {
    const currentShippingMethod = event.currentTarget.dataset.current
    if (this.data.currentShippingMethod === +currentShippingMethod) {
      return
    }
    this.setData(
      {
        currentShippingMethod,
      },
      () => {
        // 更换 显示的应付金额
        this.freightAmount()
      }
    )
  },
  handleShippingMethodTouchMove(event) {
    const store = this.data.store
    if (!store.distribution || !store.selfPickUp) {
      return false
    }
  },
  handleSelfPickUpInfoChange(event) {
    this.setData({
      selfPickUpInfo: event.detail,
    })
  },
  handleOpenStoreLocation() {
    // 自提  1.门店商品的自提打开地图  2. 其他商品跳转选择门店
    if (this.data.storeId) {
      const store = this.data.store
      if (store && store.latitude && store.longitude) {
        const latitude = store.latitude
        const longitude = store.longitude
        wx.openLocation({
          latitude,
          longitude,
          name: store.locationName,
          address: store.address,
        })
      }
    } else {
      app.router.navigateTo('/sub/Store/pages/storeList/index')
    }
  },
  deletProduct() {
    const $this = this
    const productlist = this.data.productlist
    // if (productlist.length === 0) {
    //   return
    // }
    const skuCode = productlist.map(item => {
      return item.skucode
    })
    let data = {
      skuList: skuCode,
    }
    app.http({
      url: '/shoppingCart/deleteProduct',
      data: data,
      header: {
        'content-type': 'application/json', // 默认值
        unexUserToken: app.globalData.unexUserToken,
        'invoke-source': app.globalData['invoke-source'],
      },
      success: function(res) {
        if (res && res.data.code === 0) {
          app.globalData.productlist = []
        }
      },
      fail: function(res) {},
      complete() {
        $this.setData({
          clickPay: false,
        })
      },
    })
  },
  computedFloat(price) {
    return price.toFixed(2)
  },
  bindClickPayBtn(data) {
    let formId = data.detail
    // 立即支付按钮
    if (this.data.clickPay) {
      return
    }
    if (this.data.currentShippingMethod === 0 && !this.data.addressInfo) {
      // 商家配送
      wx.showToast({
        title: '请填写收货地址',
        icon: 'none',
        duration: 1000,
      })
      return
    } else if (
      this.data.currentShippingMethod === 1 &&
      !this.data.selfPickUpInfo
    ) {
      wx.showToast({
        title: '请填写提货信息',
        icon: 'none',
        duration: 1000,
      })
      return
    }

    if (!app.globalData.accountId || !app.globalData.xAuthToken) {
      apiReload
        .getAuthParam(app, app.globalData.openid)
        .then(res => {
          let token = res.data.data.unexUserToken
          this.setData(
            {
              token: token,
              clickPay: true,
            },
            () => {
              if (
                this.data.isCreatePintuanAction ||
                this.data.isJoinPintuanAction
              ) {
                return this.handlePintuanOrder()
              }
              this.handlePay(formId)
            }
          )
        })
        .catch(e => {
          console.log('catch err', e)
          wx.showModal({
            title: '',
            content: '服务器异常，请重新点击支付',
            showCancel: false,
          })
        })
    } else {
      if (this.data.isCreatePintuanAction || this.data.isJoinPintuanAction) {
        return this.handlePintuanOrder()
      }
      this.setData(
        {
          clickPay: true,
        },
        () => {
          this.handlePay(formId)
        }
      )
    }
  },
  handlePintuanOrder() {
    const data = this.data
    const product = data.productlist[0]
    let orderData = {
      productSkuId: product.pintuanCampaignSkuId,
      productId: product.pintuanCampaignProduct.id,
      sellingPrice: product.sellPrice,
      quantity: product.count,
      campaignId: product.pintuanCampaignProduct.campaign.id,
      isInvoice: false,
      shipment: {
        address: {
          countryName: '',
          provinceName: data.addressInfo.province,
          cityName: data.addressInfo.city,
          districtName: data.addressInfo.district,
          detailInfo: data.addressInfo.address,
          consigneeName: data.addressInfo.receiverName,
          consigneePhoneNumber: data.addressInfo.receiverMobile,
          postalCode: data.addressInfo.receiverZipcode,
        },
      },
    }
    const createOrderAction = data.isJoinPintuanAction
      ? app.honghuStore.joinPintuanTeamAction
      : app.honghuStore.createPintuanOrderAction
    orderData = data.isJoinPintuanAction
      ? Object.assign({}, { teamId: this.data.pintuanTeamId }, orderData)
      : orderData

    showLoading()
    createOrderAction(orderData)
      .then(response => {
        data.pintuanOrderCode = response.orderCode
        data.pintuanNewTeamId = response.teamId
        data.pintuanOrderId = response.orderId
        this.setData(data)
        return app.honghuStore.prepayPintuanOrderAction(response.orderId)
      })
      .then(prepay => {
        hideLoading()
        const payment = Object.assign({}, prepay, {
          success: () => {
            showToast({ title: '支付成功' })
            setTimeout(() => {
              this.checkPaidOrderStatus(this.data.pintuanOrderId, () => {
                const query = queryString({
                  id: this.data.pintuanOrderCode,
                  type: HONGHU_PINTUAN,
                })
                app.router.redirectTo(
                  `/sub/Order/pages/orderdetail/orderdetail?${query}`
                )
              })
            }, 3000)
          },
          fail: () => {
            showToast({ title: '支付失败' })
            this.skipPageWhenPayed(false)
          },
        })
        wx.requestPayment(payment)
      })
      .catch(message => {
        hideLoading()
        message && showToast({ title: message })
      })
  },
  skipPageWhenPayed(isSuccessPayed = true) {
    let path
    if (isSuccessPayed) {
      path = `/sub/Marketing/pages/pintuanDetail/pintuanDetail?orderId=${
        this.data.pintuanOrderCode
      }&teamId=${this.data.pintuanNewTeamId}`
    } else {
      path = `/sub/Order/pages/orderdetail/orderdetail?id=${
        this.data.pintuanOrderCode
      }&type=${HONGHU_PINTUAN}`
    }
    app.router.redirectTo(path)
  },
  checkPaidOrderStatus(orderId, timeoutCallback) {
    showLoading({ title: '处理中...', mask: true })
    let counter = 0
    this.checkTimer = setInterval(() => {
      if (counter === 30) {
        clearInterval(this.checkTimer)
        hideLoading()
        return showToast({
          title: '订单处理超时',
          success: () => {
            setTimeout(() => {
              timeoutCallback()
            }, PROMPT_DURATION_TIME)
          },
        })
      }
      counter++
      app.honghuStore
        .getOrderDetailStatusAction(orderId)
        .then(order => {
          if (order.status !== HONGHU_ORDER_STATUS_KEY.CREATED) {
            hideLoading()
            clearInterval(this.checkTimer)
            this.skipPageWhenPayed()
          }
        })
        .catch(message => {
          hideLoading()
          message && showToast({ title: message })
        })
    }, 1000)
  },
  invoiceSwitchChange(e) {
    let flag = e.detail.isChecked
    this.setData({
      invoiceflag: flag,
    })
  },
  handlePay(formId) {
    const useCoupon = this.data.useCoupon
    let activityIds = []
    let orderActivityinfoInList = []
    this.data.activityList.forEach(item => {
      activityIds.push(item.activityCode)
      orderActivityinfoInList.push({
        activityId: item.activityCode,
        price: item.promoRewardAmount,
        activityName: item.activityName,
        activityType: item.activityType,
        activityTypeId: item.activityType,
      })
    })
    let couponCodes = []
    useCoupon.forEach(item => {
      couponCodes.push(item.couponCode)
    })
    let orderAllProduct = app.globalData.productlist
    if (this.data.selectGift.length > 0) {
      orderAllProduct = orderAllProduct.concat(this.data.selectGift)
    }
    const orderProductInList = orderAllProduct.map(item => {
      const promoAmount = this.data.productPromoAmount.filter(
        promo => promo.skuCode === item.skucode
      )

      return {
        activityId: item.isGift
          ? item.activityId
          : activityIds.length > 0
            ? activityIds.join(',')
            : '0',
        brandCode: item.brandcode,
        brandName: item.brandname,
        categoryCode: item.categorycode,
        categoryName: item.categoryname,
        count: item.isGift ? item.netqty : item.count,
        isGift: item.isGift ? item.isGift : '0',
        marketPrcie: item.saleprice,
        listPrice: item.listprice,
        returnType: '14',
        attribute: item.attrValue,
        sellPrice: item.saleprice,
        promoPrice: !item.isGift
          ? promoAmount.length > 0
            ? promoAmount[0].promoAmount
            : 0
          : 0,
        skuId: item.skucode, // 因目前不确定传啥值，固暂时传空值
        skuName: item.title, // 因目前不确定传啥值，固暂时传空值
        image: item.image,
        tax: 0,
        omsCode: item.extentionCode ? item.extentionCode : item.skucode,
        spuCode: item.spucode || item.spuCode,
        lineCode: 1,
        model: '31',
      }
    })
    const storeId = this.data.storeId
    const isExpress = this.data.currentShippingMethod === 0
    const addressInfo = this.data.addressInfo
    const selfPickUpInfo = this.data.selfPickUpInfo

    let orderReceiptInfoIn = isExpress
      ? {
        address: addressInfo.address,
        city: addressInfo.city,
        district: addressInfo.district,
        mobile: addressInfo.receiverMobile,
        name: addressInfo.receiverName,
        province: addressInfo.province,
        zipcode: addressInfo.receiverZipcode,
      }
      : {
        mobile: selfPickUpInfo.mobile,
        name: selfPickUpInfo.name,
        address: this.data.store.address,
        province: ' ',
        city: ' ',
        district: ' ',
      }
    // 优惠券
    const orderDeductioninfoInList = [
      {
        deductionType: '11',
        deductionId: couponCodes.join(','),
        deductionAmount: this.data.coupon,
      },
    ]
    // 订单类型
    let orderType =
      this.data.currentType !== '3'
        ? ORDER_TYPE.CUSTOMER.code
        : ORDER_TYPE.VIRTUAL.code
    // 快递类型
    let distributionType
    if (this.data.currentShippingMethod === 0) {
      distributionType = DISTRIBUTION_TYPE.INTRA_CITY.code
    } else {
      distributionType = DISTRIBUTION_TYPE.PICKUP.code
    }
    // 发票参数提交
    let currentInvoice = this.data.currentInvoice
    let isInvoice = this.data.invoiceflag && currentInvoice ? 1 : 0
    let orderInvoiceIn = {}
    let content = []
    // 发票内容
    this.data.productlist.forEach(item => {
      content.push(item.title + ' X' + item.count + '共 ￥' + item.total)
    })
    if (this.data.invoiceflag && currentInvoice) {
      orderInvoiceIn = {
        bankAccount: currentInvoice.bankAccount || '', // 银行账户:选择增值税发票时，该项为必填
        address: currentInvoice.address || '', //  收票地址:选择增值税发票时，该项为必填
        mail: '', // 邮箱
        city: currentInvoice.address || '', // 收票地址市代码:选择增值税发票时，该项为必填
        mobile: currentInvoice.phone || '', // 手机:选择增票时，该字段为必填
        telephone: currentInvoice.phone || '', // 注册电话:选择增值税发票时，该项为必填
        title: currentInvoice.company || '', // 发票抬头
        taxCode: currentInvoice.remark === '0' ? currentInvoice.taxCode : '', // 纳税人识别码 发票类型为增票或者普通发票抬头非个人时，该字段为必填
        content: content.join(','), // 发票内容
        mode: '', // 开票方式:选择增值税发票时，该项为必填，目前版本下仅为“订单完成后寄送”
        bank: currentInvoice.bank || '', // 开户银行:选择增值税发票时，该项为必填
        province: '', // 收票地址省代码:选择增值税发票时，该项为必填
        companyAddress: '', // 注册地址:选择增值税发票时，该项为必填
        district: '', // 收票地址区县代码:选择增值税发票时，该项为必填
        name: '', // 收票人姓名:选择增值税发票时，该项为必填
        invoiceType: '11', // 发票类型: 11普通发票, 21增值税发票, 31电子发票
        company: '',
      }
    }
    let storeInfo = {}
    if (+this.data.currentShippingMethod === 1) {
      storeInfo = {
        storeCode: this.data.storeId || this.data.store.storeId,
        shopCode: this.data.storeId || this.data.store.storeId,
      }
    } else {
      storeInfo = {
        storeCode: this.data.shopInfo.storeCode,
        shopCode: this.data.shopInfo ? this.data.shopInfo.storeCode : '',
      }
    }
    let data = Object.assign(
      {
        userCode: app.globalData.userCode,
        account: app.globalData.openid,
        accountId: app.globalData.accountId,
        shareAccount: wx.getStorageSync('sharerOpenId'),
        shareAccountId: app.globalData.shareAccountId,
        amount: this.data.amount1,
        coupon: this.data.coupon,
        discount: this.data.discount,
        distributionType: distributionType,
        freePostage: String(Number(this.data.baoyou)),
        freight:
          this.data.baoyou || storeId || +this.data.currentShippingMethod === 1
            ? 0
            : this.data.freight,
        giftCard: 0,
        isInvoice: isInvoice,
        tenantCode: app.globalData.tenantCode,
        orderPorductInList: orderProductInList,
        orderReceiptInfoIn: orderReceiptInfoIn,
        orderType: orderType,
        productAmount: this.data.productAmount,
        remarkBuyer: this.data.remark,
        tax: 0,
        terminal: '51', // 需要建站给到
        payMent: 'paypal',
        chanCode: '03', // 不确定03是啥
        orderInvoiceIn: orderInvoiceIn,
        formId: formId,
      },
      useCoupon.length > 0 ? { orderDeductioninfoInList } : {},
      orderActivityinfoInList.length > 0
        ? { orderActivityinfoInList: orderActivityinfoInList }
        : {},
      storeInfo
    )
    console.log('下单', data)
    app.http({
      url: '/casaba/trade/createOrder',
      data: data,
      header: {
        xAuthToken: app.globalData.xAuthToken,
        unexUserToken: app.globalData.unexUserToken,
        'invoke-source': app.globalData['invoke-source'],
      },
      success: res => {
        if (res.data && res.data.data) {
          let orderId = res.data.data.orderId
          let iphone = data.orderReceiptInfoIn.mobile
          if (!orderId) {
            wx.showModal({
              content: '下单失败',
              showCancel: false,
            })
            console.log('下单失败错误：', res)
            this.setData({
              clickPay: false,
            })
          } else {
            let orderId = res.data.data.orderId
            let orderTime = res.data.data.orderTime
            //   this.bindPayMent(orderId, orderTime)
            if (this.data.amount === '0') {
              const query = queryString({
                orderId: orderId,
                receivedAmount: 0,
                iphone: iphone,
              })
              app.router.redirectTo(
                `/sub/Pay/pages/paysuccess/paysuccess?${query}`
              )
            } else {
              this.bindPayMent(orderId, orderTime, iphone)
            }
          }
        } else {
          wx.showModal({
            content: '下单失败',
            showCancel: false,
          })
          console.log('下单失败错误：', res)
          this.setData({
            clickPay: false,
          })
        }
        if (Object.is(this.data.isTrueFase, 'false')) {
          this.deletProduct()
        }
      },
      fail: function(res) {
        console.log(Object.is(this.data.isTrueFase, 'false'))
        if (Object.is(this.data.isTrueFase, 'false')) {
          this.deletProduct()
        }
      },
    })
  },

  // 应付= 接口应付+运费
  freightAmount() {
    let amount1 = Number(this.data.amount1)
    let freight = Number(this.data.freight)
    if (+this.data.currentShippingMethod === 0) {
      amount1 = this.data.baoyou ? amount1 : amount1.add(freight)
    }
    this.setData({
      amount: formatPrice(amount1), // 在页面上展示的价格，实际调用接口的金额为不加运费的
    })
  },
  // 运费请求
  getFreight() {
    if (
      this.data.currentType === '3' ||
      this.data.isJoinPintuanAction ||
      this.data.isCreatePintuanAction
    ) {
      return
    }
    let body = this.data.addressInfo
    let spuCodes = []
    this.data.productlist.map(item => {
      spuCodes.push({
        spuCode: item.spuCode,
        count: item.count,
        skuCode: item.skucode,
      })
    })
    let here = '北京市上海市天津市重庆市'
    let here1 = '河北省河南省湖北省海南省'
    let city = null
    if (here.indexOf(body.province) === -1) {
      city = body.city
      if (here1.indexOf(body.province) !== -1) {
        if (body.city === '省直辖县级行政区划') {
          city = body.province + body.city
        }
      }
    } else {
      city = body.district
    }

    let data11 = {
      province: body.province,
      city: city,
      spuCodes: spuCodes,
      tenantCode: app.globalData.tenantCode,
    }
    this.getFreights(data11)
  },
  getFreights(data11) {
    app.http({
      url: '/fare/getFreight',
      data: data11,
      success: res => {
        if (res.data.code === '0') {
          this.setData({
            freight: res.data.data.freight,
          })
          this.freightAmount()
          console.log(res.data.data.freight, '运费数据')
        } else {
          this.getFreights(data11)
        }
      },
      fail: function(res) {
        console.log('res', res)
      },
    })
  },
  bindPayMent(orderId, orderTime, iphone) {
    // 支付接口
    let $this = this
    let data = {
      channelType: 'weixin',
      currency: 'cny',
      extendParams:
        '{"openid":"' +
        app.globalData.openid +
        '","spbill_create_ip":"127.0.0.1"}',
      memo: orderId,
      orderDesc: orderId,
      payAmount: this.data.amount,
      paymentType: 'applet',
      tenantCode: app.globalData.tenantCode,
      tenantOrderNo: orderId,
      tenantOrderTime: orderTime,
      tenantReturnUrl: 'https://casabaplus.baozun.com',
    }
    app.http({
      // http://10.45.60.130:8002
      url: '/casaba/trade/payOrder',
      data: data,
      header: {
        xAuthToken: app.globalData.xAuthToken,
        unexUserToken: app.globalData.unexUserToken,
        'invoke-source': app.globalData['invoke-source'],
      },
      success: function(res) {
        if (res.data.code !== '0') {
          if (res.data.code === '511202112') {
            wx.showModal({
              title: '微信支付',
              content: '卖家还没开通微信支付，请联系卖家',
              showCancel: false,
              success: () => {
                app.router.redirectTo(
                  `/sub/Pay/pages/againMoney/againMoney?orderId=${orderId}`
                )
                $this.setData({
                  clickPay: false,
                })
              },
            })
          } else {
            wx.showModal({
              title: '微信支付',
              content: res.data.msg || res.data.errMsg || '服务器出错',
              showCancel: false,
              success: () => {
                app.router.redirectTo(
                  `/sub/Pay/pages/againMoney/againMoney?orderId=${orderId}`
                )
                $this.setData({
                  clickPay: false,
                })
              },
            })
          }
        } else {
          // 发起支付
          wx.requestPayment({
            timeStamp: res.data.data.weixin_timestamp,
            nonceStr: res.data.data.weixin_nonce_str,
            package: res.data.data.weixin_wx_package,
            signType: 'MD5',
            paySign: res.data.data.weixin_sign,
            fail: function(res) {
              if (res.errMsg.split(' ')[1] === 'cancel') {
                wx.showToast({
                  title: '取消支付',
                  icon: 'none',
                  duration: 2000,
                })
                app.router.redirectTo(
                  `/sub/Pay/pages/againMoney/againMoney?orderId=${orderId}`
                )
              } else {
                wx.showToast({
                  title: '支付失败',
                  icon: 'none',
                  duration: 2000,
                })
                app.router.redirectTo(
                  `/sub/Pay/pages/againMoney/againMoney?orderId=${orderId}`
                )
              }
              // 目前没有支付失败页面，暂时注释
              // setTimeout(function () {
              //   options.failToUrl && wx.redirectTo({url: options.failToUrl})
              // }, 2000)
            },
            success: function() {
              wx.showToast({
                title: '支付成功',
                icon: 'success',
                duration: 2000,
              })
              setTimeout(function() {
                const query = queryString({
                  orderId: orderId,
                  receivedAmount: data.payAmount,
                  iphone: iphone,
                })
                app.router.redirectTo(
                  `/sub/Pay/pages/paysuccess/paysuccess?${query}`
                )
              }, 2000)
            },
            complete() {
              $this.setData({
                clickPay: false,
              })
            },
          })
        }
      },
      fail: function(res) {
        $this.setData({
          clickPay: false,
        })
        console.log('支付失败', res)
        app.router.navigateTo(
          '/sub/Pay/pages/againMoney/againMoney?orderId=' + orderId
        )
      },
    })
  },
  handleOpenRuleSheet() {
    this.setData({
      ruleMask: true,
    })
  },
  onRuleCancel() {
    this.setData({
      ruleMask: false,
    })
  },
  handleToSelectGift() {
    app.router.navigateTo('/sub/Marketing/pages/gift/gift')
  },
  pubSelectGift(gift) {
    this.setData({
      selectGift: gift,
    })
  },
  handleCatalogueChange({ currentTarget }) {
    const index = currentTarget.dataset.index
    if (index === this.data.catalogueIndex) {
      this.setData({
        catalogueIndex: -1,
      })
    } else {
      this.setData({
        catalogueIndex: index,
      })
    }
    // this.setData({
    //   catalogueIndex: e.currentTarget.dataset.index,
    // })
  },
  // 获取发票列表
  queryInvoicefn() {
    queryInvoice(
      {},
      {
        unexUserToken: app.globalData.unexUserToken,
      }
    ).then(res => {
      if (res.code === '0') {
        if (res.data.length === 0) {
          wx.removeStorageSync('selectInvoice')
          this.setData({
            currentInvoice: null,
          })
        } else {
          // TODO: 遍历 获取信息修改后正确的当前发票信息
          const currentInvoice = wx.getStorageSync('selectInvoice')
          if (currentInvoice) {
            this.setData({
              currentInvoice: this.getRightInvoice(
                JSON.parse(currentInvoice),
                res.data
              ),
            })
          } else {
            this.setData({
              currentInvoice: res.data[0],
            })
          }
        }
        this.setData({
          invoiceList: res.data,
        })
      }
    })
  },
  getRightInvoice(localInvoice, invoiceList) {
    // 遍历获取正确的发票信息
    let result
    invoiceList.forEach(item => {
      if (item.id === localInvoice.id) {
        result = item
      }
    })
    return result
  },
  handleChoseInvoice() {
    let url = ''
    if (this.data.invoiceList.length > 0) {
      let invoiceId = this.data.currentInvoice.id
      url = `/sub/Pay/pages/invoice/invoice?isSelect=${invoiceId}`
    } else {
      url = '/sub/Pay/pages/editInvoice/editInvoice'
    }
    app.router.navigateTo(url)
  },
  handleReload() {
    this.setData({
      listLoading: true,
    })
    this.pollingData()
  },
})
