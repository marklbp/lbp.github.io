/* global wx */
import { getExtConfig } from '../../utils/util'
let API_HOST = '' // dev  wxb32912486da40799
let API_HOST_PLUS = '' // plus
let appCode = '' // sit  wx97e37f0dc189c657

getExtConfig({}).then(res => {
  API_HOST = res.extConfig.host.API_HOST
  API_HOST_PLUS = res.extConfig.host.API_HOST_PLUS
  appCode = res.extConfig.appCode
})
function http(opts, flag = true) {
  let header
  let url
  flag &&
    wx.showLoading({
      title: '数据请求中...',
      mask: true,
    })
  if (opts.header) {
    opts.header.appCode = appCode
    header = opts.header
  } else {
    header = {
      'content-type': 'application/json',
      appCode: appCode,
    }
  }
  if (opts.url.includes('casaba-plus')) {
    url = API_HOST_PLUS
  } else if (opts.url.includes('http')) {
    url = ''
  } else {
    url = API_HOST
  }
  wx.request({
    method: 'POST',
    url: url + opts.url,
    data: opts.data,
    header: header,
    success: function(res) {
      opts.success && opts.success(res)
    },
    fail: function(res) {
      opts.fail && opts.fail(res)
    },
    complete: function() {
      flag && wx.hideLoading()
    },
  })
}

module.exports = http
