import {
  reciveThesholdCard,
  getMemberCardList,
  queryThesholdCard,
} from '../../../../api/index.js'
const app = getApp()
Page({
  /**
   * 页面的初始数据
   */
  data: {
    cards: [],
    size: 0,
    showUserDesc: '',
    showUserPower: '',
    id: 0,
    baseCardId: 0,
    effectiveType: 1, // 会员有效期类型:1：无限期，2:激活之日起生效N天，3：指定有效时间区间
    effectiveDay: null, // 生效的N天
    startTime: '', // 会员生效开始时间
    endTime: '', // 会员生效结束时间
    activate: '',
    cardName: '',
    logoUrl: '',
    merName: null, // 商户名称
    coverImage: '', // 背景图片
    backgroundColor: '', // 背景颜色
    profitFreeShipping: null, // 包邮-不为空就显示
    profitDiscount: null, // 折扣-不为空就显示
    profitCoupon: null, // 优惠券-不为空就显示
    profitPoint: null, // 积分-不为空就显示
    accountId: null,
    useRemark: '',
    activateType: '', // 判断激活方式
    reciew: false,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    if (options.baseCardId) {
      this.setData({
        baseCardId: options.baseCardId,
      })
    }
    const baseCardId = this.data.baseCardId
    this.getOpenId(baseCardId)
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {},
  getOpenId(baseCardId, time = 0) {
    clearTimeout(time)
    time = setTimeout(() => {
      if (wx.getStorageSync('tenantCode')) {
        this.queryThesholdCards(baseCardId)
      } else {
        this.getOpenId(baseCardId, time)
      }
    }, 100)
  },
  /**
   * 查询会员卡
   */
  queryThesholdCards(baseCardId) {
    const promise = queryThesholdCard({
      id: baseCardId,
      tenantCode: wx.getStorageSync('tenantCode'),
    })
    promise.then(res => {
      let {
        id,
        effectiveType,
        effectiveDay = 0,
        endTime,
        startTime,
        activate,
        cardName,
        logoUrl,
        profitFreeShipping,
        profitDiscount,
        profitCoupon,
        profitPoint,
        merName,
        backgroundColor,
        coverImage,
        useRemark,
      } = res.data
      let activateType = 1
      let _activate = false
      if (activate === 1) {
        _activate = false
        activateType = '1'
      } else if (activate === 2) {
        _activate = false
        activateType = '2'
      } else {
        _activate = true
      }

      if (profitDiscount) {
        profitDiscount = Number.parseFloat(profitDiscount).toFixed(1)
      }
      this.setData({
        startTime,
        activateType,
        effectiveType,
        effectiveDay,
        endTime,
        baseCardId: id,
        activate: _activate,
        backgroundColor,
        cardName,
        logoUrl,
        profitFreeShipping,
        profitDiscount,
        profitCoupon,
        profitPoint,
        coverImage,
        merName,
        useRemark,
      })
    })
  },
  /**
   * 获取会员卡集合
   */
  getMemberCardLists() {
    const currentTime = new Date().getTime()
    if (this.data.startTime) {
      let startTimes = this.getTimes(this.data.startTime)
      if (startTimes > currentTime) {
        wx.showModal({
          title: '提示',
          content: '有效期起始时间大于当前时间',
        })
        this.setData({
          reciew: true,
        })
        return
      }
    }

    const _baseCardId = this.data.baseCardId
    const promise = getMemberCardList({
      tenantCode: wx.getStorageSync('tenantCode'),
      openId: wx.getStorageSync('openid'),
    })
    promise
      .then(res => {
        const { data } = res
        const card = data.filter(item =>
          Object.is(item.baseCardId, _baseCardId)
        )
        let {
          id,
          activate,
          cardCode,
          createTime,
          cardName,
          logoUrl,
          coverImage,
          profitFreeShipping,
          profitDiscount,
          profitCoupon,
          profitPoint,
          merName,
          cardDefault,
          backgroundColor,
          useRemark,
          activateType,
          accountId,
          effectiveType,
          effectiveDay = 0,
          endTime,
        } = card[0]
        profitDiscount = Number.parseFloat(profitDiscount).toFixed(1)
        this.setData({
          size: data.length,
          id,
          activate,
          cardCode,
          createTime,
          cardName,
          logoUrl,
          coverImage,
          profitFreeShipping,
          profitDiscount,
          profitCoupon,
          profitPoint,
          merName,
          cardDefault,
          backgroundColor,
          useRemark,
          activateType,
          accountId,
          effectiveType,
          effectiveDay,
          endTime,
        })
        this.goMembershipDetails()
      })
      .catch(() => {})
  },
  /**
   * 前往会员卡详细信息
   */
  goMembershipDetails() {
    const data = this.data
    let url = null
    if (data.activate) {
      url = `../membershipCardDetails/membershipCardDetails`
    } else {
      url = `../receiveMembershipCard/receiveMembershipCard`
    }
    wx.navigateTo({
      url: `${url}?id=${data.id}&activate=${data.activate}&cardcode=${
        data.cardCode
      }&createtime=${data.createTime}&cardName=${data.cardName}&logoUrl=${
        data.logoUrl
      }&coverImage=${data.coverImage}&profitFreeShipping=${
        data.profitFreeShipping
      }&profitDiscount=${data.profitDiscount}&profitCoupon=${
        data.profitCoupon
      }&profitPoint=${data.profitPoint}&merName=${data.merName}&cardDefault=${
        data.cardDefault
      }&backgroundColor=${data.backgroundColor}&size=${data.size}&useRemark=${
        data.useRemark
      }&activateType=${data.activateType}&accountId=${
        data.accountId
      }&effectiveType=${data.effectiveType}&effectiveDay=${
        data.effectiveDay
      }&endTime=${data.endTime}`,
    })
  },
  /**
   * 更新出会员权益样式
   */
  updateMemberPower() {
    const data = this.data
    if (Object.is(data.showUserPower, 'showUserPower')) {
      data.showUserPower = 'closeUserPower'
    } else {
      data.showUserPower = 'showUserPower'
    }
    this.setData(data)
  },
  onPageScroll: function(e) {
    if (e.scrollTop < 0) {
      wx.pageScrollTo({
        scrollTop: 0,
      })
    }
  },
  /**
   * 更新出示会员卡样式
   */
  updateShowUserDesc() {
    const data = this.data
    if (Object.is(data.showUserDesc, 'showUserDesc')) {
      data.showUserDesc = 'closeUserDesc'
    } else {
      data.showUserDesc = 'showUserDesc'
    }
    this.setData(data)
  },
  /**
   * 定时器 ， 验证accountId
   */
  setTime(time = 0) {
    clearTimeout(time)
    time = setTimeout(() => {
      if (
        wx.getStorageSync('openid') &&
        wx.getStorageSync('accountId') &&
        wx.getStorageSync('tenantCode')
      ) {
        this.reciveCard()
      } else {
        this.setTime(time)
      }
    }, 100)
  },
  /**
   * 获取时间的毫秒数
   */
  getTimes(endTime) {
    const year = endTime.substring(0, 4)
    const month = endTime.substring(5, 7) - 1
    const day = endTime.substring(8, 10)
    const hours = endTime.substring(11, 13)
    const minutes = endTime.substring(14, 16)
    const seconds = endTime.substring(17, 19)
    endTime = new Date()
    endTime.setFullYear(year, month, day)
    endTime.setHours(hours)
    endTime.setMinutes(minutes)
    endTime.setSeconds(seconds)
    endTime = endTime.getTime()
    return endTime
  },
  /**
   * 领取无门卡会员卡
   */
  reciveCard() {
    if (this.data.endTime) {
      const currentTime = new Date().getTime()
      let endTime = this.getTimes(this.data.endTime)
      if (currentTime > endTime) {
        wx.showModal({
          title: '提示',
          content: '会员卡已过期',
        })
        return
      }
    }
    const promise = reciveThesholdCard({
      memberId: wx.getStorageSync('accountId'),
      tenantCode: wx.getStorageSync('tenantCode'),
      openId: wx.getStorageSync('openid'),
      baseCardId: this.data.baseCardId,
    })
    promise.then(res => {
      const { success, message } = res
      if (success) {
        this.getMemberCardLists()
      } else {
        this.setData({
          reciew: true,
        })
        wx.showModal({
          title: '提示',
          content: message,
          success: res => {
            if (res.confirm) {
              this.getMemberCardLists()
            }
          },
        })
        this.setData({
          activate: true,
        })
      }
    })
  },
  handleGoHome() {
    app.router.navigateTo('/pages/home/home')
  },
})
