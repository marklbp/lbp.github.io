import ReactDom from 'react-dom'
import HelloWordCom from './app.jsx'

ReactDom.render(HelloWordCom, document.getElementById('app'))