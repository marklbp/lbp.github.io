/**
 * 检测倒计时是否已结束
 * @param {Object} time
 * @param {String} time.day
 * @param {String} time.hours
 * @param {String} time.minutes
 * @param {String} time.seconds
 */
export function detectionTime(time) {
  return (
    time.day === '00' &&
    time.hours === '00' &&
    time.minutes === '00' &&
    time.seconds === '00'
  )
}

/**
 * 获取活动（距开始or结束）剩余时间
 * @param {Date} start
 * @param {Date} end
 * @param {Boolean} hasDay
 */
export function getRemainingTime(start, end, hasDay = false) {
  const originTime = new Date(1970, 0, 1, 0, 0, 0, 0)
  let differenceTimestamp = new Date(end) - new Date(start)
  if (differenceTimestamp < 0) {
    differenceTimestamp = 0
  }
  const differenceTime = new Date(parseInt(differenceTimestamp))
  const result = {
    day: '00',
    hours: '00',
    minutes: '00',
    seconds: '00',
  }
  differenceTime.setHours(differenceTime.getHours() - 8)
  result.day =
    differenceTime.getDate() -
    originTime.getDate() +
    (differenceTime.getMonth() - originTime.getMonth()) * 30
  result.hours = differenceTime.getHours() - originTime.getHours()
  result.minutes = differenceTime.getMinutes() - originTime.getMinutes()
  result.seconds = differenceTime.getSeconds() - originTime.getSeconds()
  if (hasDay) {
    return {
      day: padTime(result.day),
      hours: padTime(result.hours),
      minutes: padTime(result.minutes),
      seconds: padTime(result.seconds),
    }
  } else {
    result.hours = result.hours + result.day * 24
    return {
      hours: padTime(result.hours),
      minutes: padTime(result.minutes),
      seconds: padTime(result.seconds),
    }
  }
}

/**
 * 格式化时间戳
 * @param {String|Number} stamp 时间戳
 */
export function formatTimeStamp(stamp) {
  stamp = Number.parseInt(stamp, 10)
  const time = new Date(stamp)
  const yy = time.getFullYear()
  const mm = time.getMonth() + 1
  const dd = time.getDate()
  const HH = time.getHours()
  const MM = time.getMinutes()
  const SS = time.getSeconds()
  return {
    year: yy,
    month: padTime(mm),
    day: padTime(dd),
    hours: padTime(HH),
    minutes: padTime(MM),
    seconds: padTime(SS),
  }
}

/**
 * 设置UTC-北京时区
 * @param {Number|String} yy 年
 * @param {Number|String} mm 月
 * @param {Number|String} dd 日
 * @param {Number|String} HH 时
 * @param {Number|String} MM 分
 * @param {Number|String} SS 秒
 * @returns {String} 2019-03-10T12:00:00+08:00
 */
export function setUTCString(yy, mm, dd, HH, MM, SS) {
  return `${yy}-${padTime(mm)}-${padTime(dd)}T${padTime(HH)}:${padTime(
    MM
  )}:${padTime(SS)}+08:00`
}

/**
 * 时间补零
 * @param {String} t
 * @returns {String} 01 , 10
 */
export function padTime(t) {
  t = Number.parseInt(t, 10)
  if (t < 10) {
    return `0${t}`
  }
  return t.toString()
}

/**
 * 修复IOS下时间格式符号
 * @param {String} date
 */
export function fixIOSDate(date) {
  if (!date) {
    return date
  }
  return date.replace(/-/g, '/')
}

/**
 * 判断两时间之差是否小于0
 * @param {Date|String} a
 * @param {Date|String} b
 * @returns {Boolean}
 */
function isTimeStampLtOrEqToZero(a, b) {
  return new Date(a) - new Date(b) <= 0
}
/**
 * 处理限时折扣周期重复，日、周、月
 * @param {Date} now
 * @param {Date} period
 * @param {String} type
 * @param {Array} periodPonit
 * @returns {String} Date.UTC string
 */
export function periodTime(now, period, type = 'daily', periodPonit) {
  const nowYear = now.getFullYear()
  const nowMonth = now.getMonth() + 1
  const nowDay = now.getDate()
  const nowWeek = now.getDay() === 0 ? 7 : now.getDay()

  // 不管是日、周、月，都有一个固定的 时、分、秒
  const periodHours = period.getHours()
  const periodMinutes = period.getMinutes()
  const periodSeconds = period.getSeconds()

  // 先设置下个周期重复的时间
  let _periodTime = setUTCString(
    nowYear,
    nowMonth,
    nowDay,
    periodHours,
    periodMinutes,
    periodSeconds
  )
  if (type === 'weekly') {
    // 获取起始周期重复时间点
    const point = periodPonit[0]
    // 格式化时间戳的对象
    let ts
    // 是1天的时间戳
    const oneDayTimeStamp = 24 * 60 * 60 * 1000
    //  point - nowWeek || 7 - (nowWeek - point) : 得出的是今日距离下次的周期点的天数
    // ep：nowWeek=4（星期四）, point=1（星期一），得出距离下次还有 星期五、星期六、星期天、星期一，4天
    const _day = point > nowWeek ? point - nowWeek : 7 - (nowWeek - point)
    // 先判断现在的星期时间是否在周期重复内，false: 不在周期内
    if (!periodPonit.includes(nowWeek)) {
      ts = formatTimeStamp(Date.now() + _day * oneDayTimeStamp)
    } else {
      // 判断现在的活动周期时间点是否已结束
      if (isTimeStampLtOrEqToZero(_periodTime, now)) {
        // 已结束，判断现在的星期数的索引
        const index = periodPonit.indexOf(nowWeek)
        // 是否存在周期内
        if (~index) {
          // +1，判断是否还在周期内
          if (periodPonit[index + 1]) {
            // 只需加1天的时间戳
            ts = formatTimeStamp(Date.now() + oneDayTimeStamp)
          } else {
            // 距离下次的周期点的天数的时间戳
            ts = formatTimeStamp(Date.now() + _day * oneDayTimeStamp)
          }
        } else {
          // 距离下次的周期点的天数的时间戳
          ts = formatTimeStamp(Date.now() + _day * oneDayTimeStamp)
        }
      } else {
        ts = formatTimeStamp(Date.now())
      }
    }
    // 最后得出下个星期的重复时间点
    _periodTime = setUTCString(
      ts.year,
      ts.month,
      ts.day,
      periodHours,
      periodMinutes,
      periodSeconds
    )
  } else if (type === 'monthly') {
    // 获取月起始周期重复时间点
    const point = periodPonit[0]
    // 先判断现在的日期时间是否在周期重复内，false: 不在周期内
    if (!periodPonit.includes(nowDay)) {
      _periodTime = setMonthPeriodPoint(
        nowYear,
        nowMonth,
        point,
        periodHours,
        periodMinutes,
        periodSeconds
      )
    } else {
      // 判断现在的活动周期时间点是否已结束
      if (isTimeStampLtOrEqToZero(_periodTime, now)) {
        _periodTime = setMonthPeriodPoint(
          nowYear,
          nowMonth,
          point,
          periodHours,
          periodMinutes,
          periodSeconds
        )
      }
    }
  } else {
    // 每天重复
    if (isTimeStampLtOrEqToZero(_periodTime, now)) {
      const ts = formatTimeStamp(Date.now() + 24 * 60 * 60 * 1000)
      _periodTime = setUTCString(
        ts.year,
        ts.month,
        ts.day,
        periodHours,
        periodMinutes,
        periodSeconds
      )
    }
  }
  return _periodTime
}

function setMonthPeriodPoint(
  nowYear,
  nowMonth,
  point,
  periodHours,
  periodMinutes,
  periodSeconds
) {
  let _periodTime
  // 下个月份
  const nextMonth = nowMonth + 1
  // 月份+1后，超过12，则年份 +1
  const _nowYear = nextMonth > 12 ? nowYear + 1 : nowYear
  const _nextMonth = nextMonth > 12 ? nextMonth - 12 : nextMonth
  _periodTime = setUTCString(
    _nowYear,
    _nextMonth,
    point,
    periodHours,
    periodMinutes,
    periodSeconds
  )
  // 判断下个月的point日期📅是否与周期重复点相同，因为分平年闰年，2月有28，29
  if (new Date(_periodTime).getDate() !== point) {
    // 进入了这里，表明设置的point为29，30，31，而平年2月并没有这几天，所以需下下月才会开始活动
    // 下下个月份
    const next2Month = nowMonth + 2
    // 月份+2后，超过12，则年份 +1
    const _nowYear = next2Month > 12 ? nowYear + 1 : nowYear
    const _next2Month = next2Month > 12 ? next2Month - 12 : next2Month
    _periodTime = setUTCString(
      _nowYear,
      _next2Month,
      point,
      periodHours,
      periodMinutes,
      periodSeconds
    )
  }
  return _periodTime
}
