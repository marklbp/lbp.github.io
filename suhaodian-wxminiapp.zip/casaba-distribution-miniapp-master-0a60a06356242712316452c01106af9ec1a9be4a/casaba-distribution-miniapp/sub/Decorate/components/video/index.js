Component({
  properties: {
    content: {
      type: Object,
      value: null,
    },
    padding: {
      type: Boolean,
      value: false,
    },
  },

  data: {
    showDesc: false,
    isPlaying: false,
    elementTop: 0,
  },
  methods: {
    pubStop() {
      this.setData({ isPlaying: false })
    },
    handlePlay() {
      this.getElementPosition()
      this.triggerEvent('play', {
        status: 'play',
        node: this.__wxExparserNodeId__,
      })
    },
    handleVideoEnded() {
      this.setData({ isPlaying: false })
      this.triggerEvent('play', {
        status: 'stop',
        node: this.__wxExparserNodeId__,
      })
    },
    getElementPosition() {
      const query = wx.createSelectorQuery().in(this)
      query
        .select('#js-element')
        .boundingClientRect(res => {
          this.setData({
            elementTop: res.top,
            isPlaying: true,
          })
        })
        .exec()
    },
    handleShowDesc() {
      let showDesc = this.data.showDesc
      this.setData({
        showDesc: !showDesc,
      })
    },
    catchtouchmove() {},
  },
})
