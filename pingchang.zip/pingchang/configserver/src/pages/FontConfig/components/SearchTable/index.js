import SearchTable from './SearchTable';

export default SearchTable;
