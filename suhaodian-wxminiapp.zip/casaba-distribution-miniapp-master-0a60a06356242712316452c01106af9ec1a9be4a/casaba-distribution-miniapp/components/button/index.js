// https://developers.weixin.qq.com/miniprogram/dev/component/button.html
var behaviorShopStyle = require('../../utils/behavior-shop-style.js')
Component({
  externalClasses: ['u-class'],
  behaviors: [behaviorShopStyle],
  properties: {
    needForm: {
      type: Boolean,
      value: false,
    },
    type: {
      type: String,
      value: '', // default primary success warning error ghost gradient
    },
    size: {
      type: String,
      value: '', // default large small mini
    },
    shape: {
      type: String,
      value: '', // circle ellipse default:square
    },
    long: {
      type: Boolean,
      value: false,
    },
    disabled: {
      type: Boolean,
      value: false,
    },
    loading: {
      type: Boolean,
      value: false,
    },
    customstyle: {
      type: String,
      value: '',
    },
    plain: Boolean,
    formType: String, // submit reset
    openType: String, // 微信开放能力
    appParameter: String, // 打开 APP 时，向 APP 传递的参数
    lang: {
      type: String,
      value: 'en',
    },
    hoverStopPropagation: {
      type: Boolean,
      value: false,
    },
    hoverStartTime: {
      type: Number,
      value: 20,
    },
    hoverStayTime: {
      type: Number,
      value: 70,
    },
    sessionFrom: String,
    sendMessageTitle: String,
    sendMessagePath: String,
    sendMessageImg: String,
    showMessageCard: Boolean,
  },

  methods: {
    handleContact({ detail }) {
      this.triggerEvent('contact', detail)
    },
    handleGetPhoneNumber({ detail }) {
      this.triggerEvent('getphonenumber', detail)
    },
    handleGetUserInfo({ detail }) {
      this.triggerEvent('getuserinfo', detail)
    },
    handleError({ detail }) {
      this.triggerEvent('error', detail)
    },
    handleOpenSetting({ detail }) {
      this.triggerEvent('opensetting', detail)
    },
  },
})
