/* global wx, Component */
Component({
  properties: {
    visible: {
      type: Boolean,
      value: false,
    },
    filePath: {
      type: String,
      value: '',
    },
    imgLoading: {
      type: Boolean,
      value: true,
    },
  },

  data: {
    saveLoading: false,
    closeInside: false,
    visibleModal: false,
  },

  ready() {
    wx.getSystemInfo({
      success: res => {
        const winHeight = res.windowHeight
        const limitHeight = 489 + 40 + 10
        if (winHeight < limitHeight) {
          this.setData({ closeInside: true })
        }
      },
    })
  },

  methods: {
    onCancel() {
      this.triggerEvent('cancel')
    },
    handleSaveImage() {
      if (this.data.saveLoading || !this.data.visible) return
      wx.getSetting({
        success: res => {
          this.setData({ saveLoading: true })
          if (res.authSetting['scope.writePhotosAlbum'] == undefined) {
            wx.authorize({
              scope: 'scope.writePhotosAlbum',
              success: res2 => {
                wx.saveImageToPhotosAlbum({
                  filePath: this.data.filePath,
                  success: () => {
                    wx.showToast({
                      title: '已保存到相册',
                      icon: 'none',
                      success: () => {
                        this.triggerEvent('success')
                      },
                    })
                  },
                })
              },
              fail: () => {
                wx.showModal({
                  title: '保存相册',
                  content: '小程序需要访问你的权限，才能保存',
                  complete: () => {
                    this.triggerEvent('cancel')
                  },
                })
              },
              complete: () => {
                this.setData({ saveLoading: false })
              },
            })
          } else if (res.authSetting['scope.writePhotosAlbum'] === false) {
            this.setData({
              visibleModal: true,
            })
          } else {
            wx.saveImageToPhotosAlbum({
              filePath: this.data.filePath,
              success: () => {
                wx.showToast({
                  title: '已保存到相册',
                  icon: 'none',
                  success: () => {
                    this.triggerEvent('success')
                  },
                })
              },
              complete: () => {
                this.setData({ saveLoading: false })
              },
            })
          }
        },
      })
    },
    handleOpenSetting({ detail }) {
      this.setData({
        visibleModal: false,
      })
      if (detail.authSetting['scope.writePhotosAlbum']) {
        wx.saveImageToPhotosAlbum({
          filePath: this.data.filePath,
          success: () => {
            wx.showToast({
              title: '已保存到相册',
              icon: 'none',
              success: () => {
                this.triggerEvent('success')
              },
            })
          },
          complete: () => {
            this.setData({ saveLoading: false })
          },
        })
      } else {
        this.setData({
          saveLoading: false,
        })
      }
    },
    onCancelModal() {
      this.setData({
        visibleModal: false,
        saveLoading: false,
      })
    },
  },
})
