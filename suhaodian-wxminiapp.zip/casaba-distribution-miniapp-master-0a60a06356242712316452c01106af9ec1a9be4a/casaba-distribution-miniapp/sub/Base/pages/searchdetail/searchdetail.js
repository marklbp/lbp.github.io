import {
  getItemListbyConditionsV1,
  queryProdCategory,
} from '../../../../api/index'
import filterBehaivor from './behavior/filter'
import queryString from '../../../../utils/query-string'
import MARKETING_TYPE from '../../../../constant/marketing-type'
const app = getApp()

Component({
  behaviors: [filterBehaivor],
  data: {
    isSearching: false,
    isActive: 4,
    item: {
      historyList: [],
      value: '',
    },
    itemSortList: '',
    upSort: true,
    scrollHeight: 495,
    isShowReloadBtn: false,
    listLoading: false,
    moreLoading: false,
    lastPage: 1,
    noMore: false,
    showProdType: false,
    prodTypeList: [], // 筛选条件列表
    prodTypeChooseList: [], // 选中的筛选条件code
    conditionList: [], // 选中的筛选条件
    current: 0,
    offsetLeft: 0,
    moveDistance: 0,
    shopStyle: {
      color: '#fff',
      selectedColor: '#333333',
      auxiliaryColor: '#F4766E',
    },
    isFromCategory: false,
    product: {},
    tabs: [
      {
        name: '综合',
      },
      {
        name: '销量',
      },
      {
        name: '新品',
      },
      {
        name: '价格',
        showIcon: true,
      },
      {
        name: '筛选',
        showIcon: true,
        iconPosition: 'left',
        canActive: false,
        dividingLine: true,
      },
    ],
  },
  attached() {
    this.setData({
      shopStyle: {
        color: app.globalData.shopStyle[0],
        selectedColor: app.globalData.shopStyle[1],
        auxiliaryColor: app.globalData.shopStyle[2],
      },
    })
    let options = wx.getStorageSync('toPlpOptions', null)
    wx.getSystemInfo({
      success: res => {
        const wh = res.windowHeight
        const scrollHeight = wh - 58 - 50
        this.setData({ scrollHeight: scrollHeight })
      },
    })
    wx.getStorage({
      key: 'searchKey',
      success: res => {
        this.setData({
          'item.historyList': res.data,
        })
      },
    })
    if (options) {
      let prodTypeChooseList = [options.code]
      this.setData({
        prodTypeChooseList: prodTypeChooseList,
        isSearching: true,
        isFromCategory: true,
        currentChoseType: options,
        conditionList: [
          {
            key: 'categoryCode',
            value: prodTypeChooseList,
            valueType: 'list',
          },
        ],
      })
      this.searchProdType()
      wx.setNavigationBarTitle({
        title: options.name,
      })
    }
  },
  detached() {
    // 关闭可能存在的 购物车弹窗
    wx.setStorageSync('toPlpOptions', null)
    this.setData({
      showCart: false,
    })
  },
  methods: {
    // 关键字搜索
    handleGetProductListByKeyword(value) {
      this.setData({
        searchText: value,
        noMore: false,
        listLoading: true,
        lastPage: 1,
        isActive: 4,
      })
      this.getProductList()
    },
    addCartSuccess() {
      wx.showToast({
        title: '加入购物车成功',
        icon: 'none',
        duration: 1000,
      })
      this.setData({
        showCart: false,
      })
    },
    addCartCancel() {
      this.setData({
        showCart: false,
      })
    },
    onCartCancel() {
      this.selectComponent('#cart-container').clearAttributeStatus()
      this.setData({
        showCart: false,
      })
    },
    handleTabChange(e) {
      let data = e.detail
      switch (data.index) {
        case 0:
          this.handleGeneralProduct(data.index)
          break
        case 1:
          this.bindViewHotProduct(data.index)
          break
        case 2:
          this.bindViewNewProduct(data.index)
          break
        case 3:
          this.bindViewPriceProduct(data.index)
          break
        case 4:
          this.showCondition1()
          break
      }
    },
    handleGeneralProduct(index) {
      wx.pageScrollTo({
        scrollTop: 0,
        duration: 0,
      })
      this.setData({
        itemSortList: '',
        isActive: index,
        listLoading: true,
        lastPage: 1,
        noMore: false,
        productListData: [],
      })
      this.getProductList()
    },
    addShopCart({ currentTarget: { dataset } }) {
      // 传入 spuCode 门店code 获取商品详情
      this.selectComponent('#cart-container').showCart({
        spuCode: dataset.code,
        storeCode: this.data.storeCode,
      })
    },
    // 价格排序
    bindViewPriceProduct(index) {
      let upSort = true
      if (index === this.data.isActive) {
        upSort = !this.data.upSort
      }
      this.setData({
        itemSortList: 'sale_price',
        upSort: upSort,
        isActive: index,
        listLoading: true,
        lastPage: 1,
        noMore: false,
        productListData: [],
      })
      this.getProductList()
    },
    // 新品排序
    bindViewNewProduct(index) {
      this.setData({
        itemSortList: 'list_time',
        isActive: index,
        listLoading: true,
        lastPage: 1,
        noMore: false,
        productListData: [],
      })
      this.getProductList()
    },
    // 销量排序,综合排序
    bindViewHotProduct(index) {
      this.setData({
        itemSortList: 'sales',
        isActive: index,
        listLoading: true,
        lastPage: 1,
        noMore: false,
        productListData: [],
      })
      this.getProductList()
    },
    getInfoByCode(spuArr, cb) {
      let task = []
      spuArr.forEach(item => {
        task.push(app.honghuStore.getProductInfoAction(item.code))
        if (item.activitySorts && item.activitySorts.length > 0) {
          // 去重
          let sourceTags = Array.from(new Set(item.activitySorts))
          item.tags = this.transformTags(sourceTags)
        } else {
          item.tags = []
        }
      })
      Promise.all(task).then(info => {
        info.forEach((item, index) => {
          const { campaign } = item.byCode
          if (campaign) {
            spuArr[index].campaign = {
              ...campaign,
              type: this.formatCampaignType(campaign),
            }
            // spuArr[index].tags.push(
            //   this.formatCampaignType(campaign)
            // )
            // 多人拼团 可以与促销共存
            if (
              campaign['__typename'] === MARKETING_TYPE.PINTUAN.type &&
              campaign.pintuanType === 'NORMAL'
            ) {
              spuArr[index].tags.unshift(this.formatCampaignType(campaign))
            } else {
              spuArr[index].tags = [this.formatCampaignType(campaign)]
            }
          }
        })
        cb && cb(spuArr)
      })
    },
    transformTags(sourceTags) {
      const tagMap = new Map([
        ['1', '单品'],
        ['2', '满减'],
        ['3', '满折'],
        ['4', '特价'],
        ['5', '满包邮'],
        ['6', '赠品'],
        ['7', '捆绑'],
        ['8', '满送'],
      ])
      return sourceTags.map(item => tagMap.get(item))
    },
    formatCampaignType(campaign) {
      let result = ''
      switch (campaign['__typename']) {
        case MARKETING_TYPE.PINTUAN.type:
          if (campaign.pintuanType === 'NORMAL') {
            result = '多人拼团'
          } else if (campaign.pintuanType === 'CASH_BACK') {
            result = '返现拼团'
          }
          break
        case MARKETING_TYPE.SECKILL.type:
          result = '秒杀'
          break
        case MARKETING_TYPE.BARGAIN.type:
          result = '砍价'
          break
        case MARKETING_TYPE.LIMITTIMEDISCOUNTS.type:
          result = '限时折扣'
          break
        case MARKETING_TYPE.STEPPEDGROUPBUY.type:
          result = '阶梯团购'
          break
        case MARKETING_TYPE.PACKBUY.type:
          result = '打包一口价'
          break
        case MARKETING_TYPE.REDUCEPRICEBUY.type:
          result = '降价拍'
          break
      }
      return result
    },
    getProductList(isLoadMore) {
      let data = this.createParam()
      getItemListbyConditionsV1(data)
        .then(res => {
          if (res.content.data) {
            this.getInfoByCode(res.content.data, result => {
              let _productList
              if (isLoadMore) {
                _productList = this.data.productListData || []
                _productList = _productList.concat(result)
              } else {
                _productList = result || []
              }
              this.setData({
                productListData: _productList,
                isSearching: true,
                listLoading: false,
                isShowReloadBtn: false,
                showProdType: false,
                moreLoading: false,
              })
            })
          } else {
            this.setData({
              productListData: isLoadMore ? this.data.productListData : [],
              isSearching: true,
              listLoading: false,
              isShowReloadBtn: false,
              showProdType: false,
              noMore: true,
              moreLoading: false,
            })
          }
        })
        .catch(err => {
          this.setData({
            listLoading: false,
            moreLoading: false,
          })
          wx.showToast({
            title: '加载过程出现异常，请重试',
            icon: 'none',
          })
          console.error('/getItemListbyConditionsV1', err)
        })
    },
    createParam() {
      let itemSortList = this.data.itemSortList
      let searchText = this.data.searchText
      let currentChoseType = this.data.currentChoseType
      let currentSelectBrand = this.data.currentSelectBrand
      let noMore = this.data.noMore
      let data = {
        tenantCode: app.globalData.tenantCode,
        itemSortList: [],
        conditionList: [
          {
            key: 'saleStatus',
            value: ['1'],
            valueType: 'basic',
          },
        ],
        page: {
          page: noMore ? this.data.lastPage : this.data.lastPage++,
          size: 6,
        },
      }
      if (itemSortList && itemSortList.length > 0) {
        data.itemSortList.push({
          name: itemSortList,
          sort: itemSortList === 'sale_price' ? (!this.data.upSort ? 1 : 0) : 1,
        })
      }
      if (searchText) {
        data.conditionList.push({
          key: 'keyword',
          value: [searchText],
          valueType: 'list',
        })
      }
      if (currentChoseType) {
        data.conditionList.push({
          key: 'categoryCode',
          value: [currentChoseType.code],
          valueType: 'list',
        })
      }
      if (currentSelectBrand && currentSelectBrand.length > 0) {
        data.conditionList.push({
          key: 'brandCode',
          value: currentSelectBrand,
          valueType: 'list',
        })
      }
      if (this.data.minPrice || this.data.maxPrice) {
        data.conditionList.push({
          key: 'salePrice',
          value: [this.data.minPrice, this.data.maxPrice],
          valueType: 'basic',
        })
      }
      return data
    },
    onReachBottom(e) {
      if (this.data.noMore) {
        return
      }
      this.setData({
        listLoading: false,
        moreLoading: true,
      })
      this.getProductList(true)
    },
    handleHistoryTag({ currentTarget }) {
      const value = currentTarget.dataset.item
      this.setData({
        'item.value': value,
      })
      this.handleGetProductListByKeyword(value)
    },

    bindInput(e) {
      const value = e.detail.value
      let isFromCategory = this.data.isFromCategory
      if (!value) {
        if (!isFromCategory) {
          this.setData({
            isSearching: false,
          })
        } else {
          this.searchProdType()
        }
      } else {
        this.setData({
          'item.value': value,
        })
      }
    },
    /**
     * 像本地存储中追加新的字段
     */
    setLocalstore: function({ detail }) {
      let value = detail ? detail.value : ''
      let historyList = this.data.item.historyList
      if (!value) {
        return
      }
      historyList.push(value)
      historyList = Array.from(new Set(historyList))
      if (historyList.length > 10) {
        historyList.shift()
      }
      this.setData({
        'item.historyList': historyList,
        'item.value': value,
      })
      wx.setStorage({
        key: 'searchKey',
        data: historyList,
      })

      this.handleGetProductListByKeyword(value)
    },
    /**
     * 清除历史纪录
     */
    removeHistoryList() {
      this.setData({
        'item.historyList': [],
      })
      wx.removeStorage({ key: 'searchKey' })
    },
    /**
     * 清除
     */
    clearValue: function(e) {
      let isFromCategory = this.data.isFromCategory
      let conditionList = this.data.conditionList
      this.setData({
        'item.value': '',
        isSearching: !!isFromCategory,
        productListData: [],
      })
      if (isFromCategory) {
        let index = conditionList.findIndex(item => {
          return item.key === 'keyword'
        })
        conditionList.splice(index, 1)
        this.setData(
          {
            conditionList: conditionList,
          },
          () => {
            this.searchProdType()
          }
        )
      } else {
        this.setData({
          noMore: false,
          itemSortList: [],
          conditionList: [],
          currentChoseType: null,
          currentSelectBrand: [],
          currentSelectLabel: [],
        })
      }
    },

    // 商品筛选
    showProdType() {
      this.setData({
        showProdType: true,
      })

      let params = {
        tenantCode: app.globalData.tenantCode,
      }
      queryProdCategory(params).then(res => {
        if (res.code === '0') {
          this.setData({
            prodTypeList: res.data.data,
          })
        }
      })
    },
    hideProdType() {
      this.setData({
        showProdType: false,
      })
    },
    handleCartChange(data) {
      this.setData({
        showCart: data.detail,
      })
    },
    // 查看筛选
    searchProdType() {
      this.setData({
        listLoading: true,
        lastPage: 1,
        showProdType: false,
        noMore: false,
      })
      this.getProductList()
    },
    urlFactory(data) {
      let url = ''
      let campaign = data.campaign
      switch (campaign.__typename) {
        case MARKETING_TYPE.SECKILL.type:
          url = `/honghu/pages/seckill/detail/index?scene=${campaign.code}`
          break
        case MARKETING_TYPE.BARGAIN.type:
          url = `/honghu/pages/bargain/detail/index?scene=${campaign.code}`
          break
        case MARKETING_TYPE.LIMITTIMEDISCOUNTS.type:
          url = `/honghu/pages/discount/pdp/index?scene=${data.code}`
          break
        case MARKETING_TYPE.STEPPEDGROUPBUY.type:
          url = `/honghu/pages/steppedGroupBuy/pdp/index?scene=${campaign.code}`
          break
        case MARKETING_TYPE.PINTUAN.type:
          if (campaign.pintuanType === 'NORMAL') {
            url = `/sub/Commodity/pages/pdp/pdp?spuCode=${data.code}`
          } else if (campaign.pintuanType === 'CASH_BACK') {
            url = `/honghu/pages/pintuanCashBack/pdp/index?scene=${data.code}`
          }
          break
        case MARKETING_TYPE.PACKBUY.type:
          url = `/honghu/pages/packBuy/pdp/index?scene=${data.code}`
          break
        case MARKETING_TYPE.REDUCEPRICEBUY.type:
          url = `/honghu/pages/reducePriceAuction/pdp/index?scene=${
            campaign.code
          }`
      }
      return url
    },
    goPdp({ currentTarget: { dataset } }) {
      const { store, item } = dataset
      if (item.campaign) {
        let url = this.urlFactory(item)
        app.router.navigateTo(url)
      } else {
        const query = queryString({
          storeId: store ? store.storeId : '',
          storeCode: store ? store.storeCode : '',
          spuCode: item.spuCode || item.code || '',
          src: item.pic || item.itemImageList[0].picUrl || '',
        })
        app.router.navigateTo(`/sub/Commodity/pages/pdp/pdp?${query}`)
      }
    },
  },
})
