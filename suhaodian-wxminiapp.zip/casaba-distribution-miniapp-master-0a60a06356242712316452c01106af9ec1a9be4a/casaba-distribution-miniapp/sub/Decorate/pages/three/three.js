import { getPageDetail } from '../../../../api/index'
import { getExtConfig } from '../../../../utils/util'
import * as dnt from '../../../../template/decoration'
const app = getApp()
Page({
  data: {
    homeData: [],
    isShowReloadBtn: false,
    listLoading: false,
    barTitle: '',
    background: '#FFFFFF',
    tap: 1,
    tabBarLists: [],
  },
  store: {
    allVideoComponentNode: [],
    currentVideoNode: '',
  },
  onLoad() {
    // 开启转发按钮，并带上shareTicket信息
    wx.showShareMenu({ withShareTicket: true })
    this.setData({
      listLoading: true,
    })
  },
  onShow() {
    this.initLoad()
  },
  onUnload() {
    this.selectAllComponents('#js-marketing').forEach(
      c => c.pubClearTimer && c.pubClearTimer()
    )
  },
  onHide() {
    this.selectAllComponents('#js-marketing').forEach(
      c => c.pubClearTimer && c.pubClearTimer()
    )
  },
  initLoad() {
    this.getHomeData(this.refreshMarketingComponent)
    this.refreshBaseComponents()
  },
  handleReload() {
    this.initLoad()
  },
  setNavigationBarTitle(obj) {
    wx.setNavigationBarTitle({
      title: obj.name || '',
    })
  },
  setNavigationBarColor(obj) {
    wx.setNavigationBarColor({
      frontColor: obj.nameColor || '#000000',
      backgroundColor: obj.titleBgColor || '#FFFFFF',
      animation: {
        duration: 0,
        timingFunc: 'easeIn',
      },
    })
  },
  getHomeData(cb) {
    getExtConfig().then(c => {
      getPageDetail({
        tenantCode: c.extConfig.tenantCode,
        url: 'sub/Decorate/pages/three/three',
      })
        .then(res => {
          dnt.getCallBack(this, res, cb)
        })
        .catch(() => this.handleCatchError())
    })
  },
  handleCatchError() {
    dnt.handleCatchError(this)
  },
  onEmitJump({ detail }) {
    app.router.navigateTo(detail.url)
  },
  onVideoPlay({ detail }) {
    if (detail.status === 'play') {
      const allVideoComponentNode = this.store.allVideoComponentNode
      allVideoComponentNode.forEach(node => {
        if (node !== detail.node) {
          node.pubStop()
        }
      })
      this.store.currentVideoNode = detail.node
    }
  },
  onShareAppMessage() {
    return {
      title: this.data.barTitle,
      path: '/sub/Decorate/pages/three/three',
    }
  },
  onPullDownRefresh() {
    wx.showNavigationBarLoading()
    this.getHomeData(this.refreshMarketingComponent)
    this.refreshBaseComponents()
  },
  refreshBaseComponents() {
    this.selectAllComponents(`#js-base`).forEach(c =>
      setTimeout(() => {
        if (c.pubRefresh) {
          c.pubRefresh()
        }
      }, 16)
    )
  },
  refreshMarketingComponent() {
    this.selectAllComponents('#js-marketing').forEach(c =>
      setTimeout(() => {
        if (c.pubRefresh) {
          c.pubRefresh()
        }
      }, 16)
    )
  },
  catchtouchmove() {},
})
