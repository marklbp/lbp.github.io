import ProcessAuthEdit from './ProcessAuthEdit';

export default ProcessAuthEdit;
