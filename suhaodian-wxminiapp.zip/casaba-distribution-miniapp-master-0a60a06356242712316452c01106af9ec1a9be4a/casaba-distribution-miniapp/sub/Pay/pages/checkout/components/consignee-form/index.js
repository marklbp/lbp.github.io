import { throttle } from '../../../../../../utils/function'

Component({
  externalClasses: [],
  options: {
    multipleSlots: true,
  },
  data: {
    name: null,
    mobile: null,
    error: {},
  },
  properties: {
    store: {
      type: Object,
      value: {},
    },
    phone: String,
  },
  methods: {
    handleMakePhoneCall: throttle(function() {
      if (this.data.phone) {
        wx.makePhoneCall({
          phoneNumber: this.data.phone,
        })
      }
    }, 100),
    handleItemChange(e) {
      const dataset = e.currentTarget.dataset
      const value = e.detail.value
      const type = dataset.type
      this.setData({
        [type]: value,
      })
      this.checkData(type, value)
    },
    checkData(type, value) {
      const mobileReg = /^1\d{10}$/
      const validate = type === 'mobile' ? mobileReg.test(value) : !!value
      this.setData({
        error: {
          ...this.data.error,
          [type]: !validate,
        },
      })
      const name = this.data.name
      const mobile = this.data.mobile
      if (name && mobileReg.test(mobile)) {
        this.triggerEvent('change', {
          name,
          mobile,
        })
      } else {
        this.triggerEvent('change', null)
      }
    },
  },
})
