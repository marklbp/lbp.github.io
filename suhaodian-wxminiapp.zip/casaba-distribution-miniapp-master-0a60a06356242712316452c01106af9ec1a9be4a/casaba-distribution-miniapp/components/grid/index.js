/* global Component */
Component({
  externalClasses: ['u-class'],
  relations: {
    '../grid-item/index': {
      type: 'child',
      linked(target) {
        this.setGridItemWidth()
      },
      linkChanged(target) {
        this.setGridItemWidth()
      },
      unlinked() {
        this.setGridItemWidth()
      },
    },
  },
  ready() {
    this.setGridItemWidth()
  },
  methods: {
    setGridItemWidth(target) {
      const nodes = this.getRelationNodes('../grid-item/index')
      const width = 100 / nodes.length
      nodes.forEach(item => {
        item.setData({
          width: width + '%',
        })
      })
    },
  },
})
