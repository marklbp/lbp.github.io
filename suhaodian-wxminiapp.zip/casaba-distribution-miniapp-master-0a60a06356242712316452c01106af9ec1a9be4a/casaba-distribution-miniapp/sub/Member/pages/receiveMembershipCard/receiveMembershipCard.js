// pages/membershipCardDetails/membershipCardDetails.js
import {
  getActiveCardToken,
  sendActiveCardCode,
  checkActiveCardCode,
  activateMemberCard,
} from '../../../../api/index.js'
const app = getApp()
Page({
  /**
   * 页面的初始数据
   */
  data: {
    reciveMemberCard: false, // 领取会员卡
    reloadSubmit: false,
    showMemberCard: false, // 出示会员卡
    showUserDesc: '',
    showUserPower: '',
    animationData: {},
    deleteAnimationData: {},
    id: 0,
    cardcode: 0,
    createtime: '',
    activate: '',
    cardName: '',
    logoUrl: '',
    encoderQRCode: '', // 二维码
    barCode: '', // 条形码
    merName: null, // 商户名称
    coverImage: '', // 背景图片
    backgroundColor: '', // 背景颜色
    profitFreeShipping: null, // 包邮-不为空就显示
    profitDiscount: null, // 折扣-不为空就显示
    profitCoupon: null, // 优惠券-不为空就显示
    profitPoint: null, // 积分-不为空就显示
    cardDefault: null,
    accountId: null,
    size: 0, // 总的卡片数
    useRemark: '',
    activateType: '', // 判断激活方式
    phone: '',
    token: null,
    validCode: '',
    isSend: false,
    codeTime: 60,
    effectiveType: 1,
    effectiveDay: 0,
    endTime: '',
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    const data = this.data
    data.id = options.id
    data.activate = options.activate
    if (
      Object.is(typeof options.activate, 'string') &&
      Object.is(options.activate, 'false')
    ) {
      data.activate = false
    } else {
      data.activate = true
    }
    data.createtime = options.createtime
    data.cardcode = options.cardcode
    data.cardName = options.cardName
    data.merName = options.merName
    data.logoUrl = options.logoUrl
    // debugger
    data.accountId = options.accountId
    data.profitFreeShipping = options.profitFreeShipping
    if (
      options.profitDiscount &&
      options.profitDiscount !== 'null' &&
      options.profitDiscount !== 'undefined'
    ) {
      data.profitDiscount = Number.parseFloat(options.profitDiscount).toFixed(1)
    } else {
      if (options.profitDiscount === 'undefined') {
        data.profitDiscount = null
      } else {
        data.profitDiscount = options.profitDiscount
      }
    }
    data.profitPoint = options.profitPoint
    if (options.profitDiscount === 'undefined') {
      data.profitDiscount = null
    }
    data.profitCoupon = options.profitCoupon
    if (options.profitCoupon === 'undefined') {
      data.profitCoupon = null
    }
    data.cardDefault = options.cardDefault
    data.coverImage = options.coverImage
    data.backgroundColor = options.backgroundColor
    data.size = options.size
    data.useRemark = options.useRemark
    data.activateType = options.activateType
    data.effectiveType = Number.parseInt(options.effectiveType)
    data.effectiveDay = options.effectiveDay
    data.endTime = options.endTime
    this.setData(data)
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    console.log('pages', this.data.reciveMemberCard)
    if (this.data.reciveMemberCard) {
      this.setData({
        reloadSubmit: true,
      })
    }
    const data = this.data
    const promise = getActiveCardToken()
    promise.then(res => {
      // debugger
      const { success } = res
      if (success) {
        data.token = res.data
        this.setData(data)
      }
    })
  },

  /**
   * 更新出会员权益样式
   */
  updateMemberPower() {
    const data = this.data
    if (Object.is(data.showUserPower, 'showUserPower')) {
      data.showUserPower = 'closeUserPower'
    } else {
      data.showUserPower = 'showUserPower'
    }
    this.setData(data)
  },
  onPageScroll: function(e) {
    if (e.scrollTop < 0) {
      wx.pageScrollTo({
        scrollTop: 0,
      })
    }
  },
  /**
   * 更新出示会员卡样式
   */
  updateShowUserDesc() {
    const data = this.data
    if (Object.is(data.showUserDesc, 'showUserDesc')) {
      data.showUserDesc = 'closeUserDesc'
    } else {
      data.showUserDesc = 'showUserDesc'
    }
    this.setData(data)
  },
  /**
   * 立即领取
   */
  reciveMemberCard() {
    const data = this.data
    data.reciveMemberCard = true
    this.setData(data)
  },
  /**
   * 取消删除会员卡
   */
  cancelReciveMemberCard(e) {
    const data = this.data
    data.reciveMemberCard = false
    this.setData(data)
  },
  /**
   * 更新电话
   */
  updatePhone(e) {
    // if (!this.validatePhone()) {
    //   return
    // }
    // console.log('e', e.detail.value)
    this.setData({
      phone: e.detail.value,
    })
  },
  /**
   * 更新验证码
   */
  updateValidCode(e) {
    // console.log('e', e.detail.value)
    this.setData({
      validCode: e.detail.value,
    })
  },
  updateTime() {
    let codeTime = this.data.codeTime
    this.setData({
      codeTime: --codeTime,
    })
    setTimeout(() => {
      if (codeTime > 0) {
        this.updateTime()
      } else {
        this.setData({
          isSend: false,
          codeTime: 60,
        })
      }
    }, 1000)
  },
  /**
   * 验证手机号是否为空， 符合正则要求
   */
  validatePhone() {
    const phone = this.data.phone
    if (!phone) {
      wx.showModal({
        title: '提示',
        content: '请输入手机号',
      })
      return false
    }
    const regExp = /^[1][3,4,5,7,8][0-9]{9}$/
    if (!phone.match(regExp)) {
      wx.showModal({
        title: '提示',
        content: '请输入11位手机号，暂不支166、199 、198号段',
      })
      return false
    }
    return true
  },
  /**
   * 验证手机验证码
   */
  validateCode() {
    const regExp = /^\d{4}$/
    const code = this.data.validCode
    if (Object.is(code, '')) {
      wx.showModal({
        title: '提示',
        content: '请输入验证码',
      })
      return
    }
    if (!code.match(regExp)) {
      wx.showModal({
        title: '提示',
        content: '请输入四位数字',
      })
      return false
    }
    return true
  },
  /**
   * 发送手机验证码
   */
  getValidCode() {
    if (!this.validatePhone()) {
      return
    }
    this.setData({
      isSend: true,
    })
    this.updateTime()
    const data = this.data
    const promise = getActiveCardToken()
    promise.then(res => {
      // debugger
      const { success } = res
      if (success) {
        data.token = res.data
        this.setData(data)

        // const data = this.data
        const promise = sendActiveCardCode({
          mobilePhone: data.phone,
          token: data.token,
        })
        promise.then(res => {
          const { success } = res
          if (success) {
          }
        })
      }
    })
  },
  /**
   * 领取会员卡直接前往会员卡详情
   */
  nextReciveMemberCard() {
    if (!this.validatePhone()) {
      return
    }
    if (!this.validateCode()) {
      return
    }
    let promise = null
    const data = this.data
    // if (data.reloadSubmit) {

    // } else {

    // }
    if (Object.is(data.activateType, '2')) {
      promise = checkActiveCardCode({
        mobilePhone: data.phone,
        activeCode: data.validCode,
      })
    } else {
      promise = activateMemberCard({
        relationId: data.id,
        userId: wx.getStorageSync('distUser'),
        activatieType: data.activateType,
        accountId: data.accountId,
        tenantCode: wx.getStorageSync('tenantCode'),
        mobile: data.phone,
        activeCode: data.validCode,
      })
    }
    promise.then(res => {
      const { success, message } = res
      if (success) {
        this.handlerNext()
      } else {
        wx.showModal({
          title: '提示',
          content: message,
        })
      }
    })
  },
  /**
   * 处理下一步回调
   */
  handlerNext() {
    const data = this.data
    let url = null
    if (Object.is(data.activateType, '2')) {
      url = `../improveBasicInformation/improveBasicInformation`
    } else {
      url = `../membershipCardDetails/membershipCardDetails`
      this.setData({
        activate: true,
      })
    }
    wx.navigateTo({
      url: `${url}?id=${data.id}&activate=${data.activate}&cardcode=${
        data.cardcode
      }&createtime=${data.createtime}&cardName=${data.cardName}&logoUrl=${
        data.logoUrl
      }&coverImage=${data.coverImage}&profitFreeShipping=${
        data.profitFreeShipping
      }&profitDiscount=${data.profitDiscount}&profitCoupon=${
        data.profitCoupon
      }&profitPoint=${data.profitPoint}&merName=${data.merName}&cardDefault=${
        data.cardDefault
      }&backgroundColor=${data.backgroundColor}&size=${data.size}&useRemark=${
        data.useRemark
      }&phone=${data.phone}&activeCode=${data.validCode}&activateType=${
        data.activateType
      }&accountId=${data.accountId}&effectiveType=${
        data.effectiveType
      }&effectiveDay=${data.effectiveDay}&endTime=${data.endTime}`,
    })
  },
  handleGoHome() {
    app.router.navigateTo('/pages/home/home')
  },
})
