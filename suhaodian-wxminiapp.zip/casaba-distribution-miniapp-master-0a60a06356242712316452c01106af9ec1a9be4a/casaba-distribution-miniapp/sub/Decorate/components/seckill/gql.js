import gql from '../../../../utils/gql'
const query = `
query getSeckillDetail {
  shop {
    campaigns(type: SECKILL,first: 100) {
      pageInfo {
        startCursor
        endCursor
        hasPreviousPage
        hasNextPage
      }
      edges {
        node {
          id
          code
          name
          ... on SeckillCampaign {
            code
            name
            limitPerMember
            status
            warmUpAt
            createdAt
            availablePeriod {
              start
              end
            }
            product {
              spuCode: code
              pics: itemImageList {
                picUrl
              }
              name
              saleStatus
              listTime
            }
            productSkus {
              code
              status
              netqty
              listPrice
              salePrice
              seckillPrice
              seckillInventory
              seckillSoldNum
            }
          }
        }
      }
    }
  }
}
`
export const getSeckillDetail = gql(query)
