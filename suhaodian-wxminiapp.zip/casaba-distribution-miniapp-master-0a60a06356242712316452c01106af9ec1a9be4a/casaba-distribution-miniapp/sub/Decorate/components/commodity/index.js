Component({
  properties: {
    commodityList: {
      type: Array,
      value: [],
    },
    mode: {
      type: String,
      value: 'listLineTwo',
    },
    content: {
      type: Object,
      value: null,
    },
  },
  methods: {
    handleJump({ currentTarget }) {
      const code = currentTarget.dataset.item.code
      if (code) {
        this.triggerEvent('jump', {
          url: `/sub/Commodity/pages/pdp/pdp?spuCode=${code}`,
        })
      }
    },
  },
})
