import ProdSeachList from './ProdSeachList';

export default ProdSeachList;
