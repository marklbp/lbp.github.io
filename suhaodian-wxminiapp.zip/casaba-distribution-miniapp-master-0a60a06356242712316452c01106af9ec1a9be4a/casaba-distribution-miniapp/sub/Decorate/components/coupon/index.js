import {
  getShopsCoupon,
  getAutoQueryShopCoupon,
  sendCoupon,
} from '../../../../api/index'
import apiReload from '../../../../utils/reload'
const app = getApp()
Component({
  properties: {
    cid: Number,
    ctype: String,
    mode: {
      type: String,
      value: 'style1',
    },
    list: {
      type: Array,
      value: [],
    },
    content: {
      type: Object,
      value: null,
    },
  },
  data: {
    loading: false,
    done: false,
    couponList: [],
    timer: null,
  },
  attached() {
    this.pollingData()
  },
  methods: {
    pollingData() {
      if (this.data.timer) {
        return
      }
      let pollingCount = 0
      const timer = setInterval(() => {
        if (!app.globalData.userCode) {
          pollingCount++
          if (pollingCount > 70) {
            clearInterval(timer)
            this.setData({
              timer: null,
            })
            apiReload.getOpenIdAndAuthParam(app).then(res => {
              this.initLoad()
            })
          }
        } else {
          clearInterval(timer)
          this.setData({
            timer: null,
          })
          this.initLoad()
        }
      }, 100)
      this.setData({ timer: timer })
    },
    initLoad() {
      this.setData({ loading: true, done: false })
      const { spellGoodsType, ishideFaileCou, showNum } = this.data.content
      const tenantCode = app.globalData.tenantCode
      if (spellGoodsType === '1') {
        getShopsCoupon({
          tenantCode: tenantCode,
          userCode: app.globalData.userCode,
          activityCodes: this.getCouponActivityIds(this.data.list),
          type: Number(!ishideFaileCou),
        })
          .then(res => {
            if (res.code === '0') {
              const result = res.data
              for (const k of result) {
                k.loading = true
                k.type = spellGoodsType
                if (k.receiveStatus === 4) {
                  k.status = 2
                } else if (k.receiveStatus === 5) {
                  k.status = 1
                } else {
                  k.status = 0
                }
              }
              this.setData({
                couponList: result,
                loading: false,
                done: true,
              })
              setTimeout(() => {
                this.co(result)
              }, 0)
            } else {
              this.setData({ loading: false })
            }
          })
          .catch(() => {
            this.setData({ loading: false })
          })
      } else {
        getAutoQueryShopCoupon({
          tenantCode: tenantCode,
          userCode: app.globalData.userCode,
          pageCount: showNum,
          type: Number(!ishideFaileCou),
        })
          .then(res => {
            if (res.code === '0') {
              const result = res.data
              for (const k of result) {
                k.loading = true
                k.type = spellGoodsType
                if (k.receiveStatus === 4) {
                  k.status = 1
                } else if (k.receiveStatus === 5) {
                  k.status = 1
                } else {
                  k.status = 0
                }
              }
              this.setData({
                couponList: result,
                loading: false,
                done: true,
              })
              setTimeout(() => {
                this.co(result)
              }, 0)
            } else {
              this.setData({ loading: false })
            }
          })
          .catch(() => {
            this.setData({ loading: false })
          })
      }
    },
    pubRefresh() {
      this.setData(
        {
          couponList: [],
        },
        () => {
          this.initLoad()
        }
      )
    },
    rpxToPx(windowWidth) {
      return windowWidth / 750
    },
    co(arr) {
      let cw = {
        n: {
          style1: 75,
          style2: 55,
          style3: 70,
          style4: 80,
        },
        m: {
          style1: 72,
          style2: 84,
          style3: 46,
          style4: 84,
        },
      }
      const systemInfo = wx.getSystemInfoSync()
      if (systemInfo) {
        const w = systemInfo.windowWidth
        const PX = this.rpxToPx(w)
        cw = {
          n: {
            style1: 170 * PX,
            style2: 110 * PX,
            style3: 140 * PX,
            style4: 160 * PX,
          },
          m: {
            style1: 144 * PX,
            style2: 168 * PX,
            style3: 92 * PX,
            style4: 168 * PX,
          },
        }
      }
      const cf = {
        n: {
          style1: 34,
          style2: 40,
          style3: 46,
          style4: 46,
        },
        m: {
          style1: 28,
          style2: 30,
          style3: 28,
          style4: 30,
        },
      }
      let fixedWidth
      let fixedFontSize
      if (arr.length > 1) {
        fixedWidth = cw.m[this.data.mode]
        fixedFontSize = cf.m[this.data.mode]
      } else {
        fixedWidth = cw.n[this.data.mode]
        fixedFontSize = cf.n[this.data.mode]
      }
      const query = wx.createSelectorQuery().in(this)
      query
        .selectAll('#js-price')
        .boundingClientRect(
          res => {
            res.forEach((d, i) => {
              if (d.width > fixedWidth) {
                let _size = (fixedWidth / d.width) * fixedFontSize
                arr[i].fontSize =
                  _size > fixedFontSize ? fixedFontSize + 'r' : _size
                arr[i].loading = false
              } else {
                arr[i].loading = false
              }
            })
            this.setData({
              couponList: arr,
            })
          },
          () => {
            arr.forEach(k => (k.loading = false))
            this.setData({
              couponList: arr,
            })
          }
        )
        .exec()
    },
    getCouponActivityIds(arr) {
      return arr.map(c => c.content.activityCode)
    },
    refeshCoupon(type) {
      const { ishideFaileCou, showNum } = this.data.content
      const tenantCode = app.globalData.tenantCode
      if (type === '1') {
        getShopsCoupon({
          tenantCode: tenantCode,
          userCode: app.globalData.userCode,
          activityCodes: this.getCouponActivityIds(this.data.list),
          type: Number(!ishideFaileCou),
        }).then(res => {
          if (res.code === '0') {
            const result = res.data
            const couponList = this.data.couponList
            couponList.forEach(cl =>
              result.forEach(v => {
                if (cl.activityCode === v.activityCode) {
                  if (v.receiveStatus === 4) {
                    cl.status = 2
                  } else if (v.receiveStatus === 5) {
                    cl.status = 1
                  } else {
                    cl.status = 0
                  }
                }
              })
            )
            this.setData({
              couponList: couponList,
            })
          }
        })
      } else {
        getAutoQueryShopCoupon({
          tenantCode: tenantCode,
          userCode: app.globalData.userCode,
          pageCount: showNum,
          type: Number(!ishideFaileCou),
        }).then(res => {
          if (res.code === '0') {
            const result = res.data
            const couponList = this.data.couponList
            couponList.forEach(cl =>
              result.forEach(v => {
                if (cl.activityCode === v.activityCode) {
                  if (v.receiveStatus === 4) {
                    cl.status = 2
                  } else if (v.receiveStatus === 5) {
                    cl.status = 1
                  } else {
                    cl.status = 0
                  }
                }
              })
            )
            this.setData({
              couponList: couponList,
            })
          }
        })
      }
    },
    sendCoupons(index, activitycode, type) {
      let couponList = this.data.couponList
      sendCoupon({
        activityCode: activitycode,
        takeLabel: '02',
        userCode: app.globalData.userCode,
      })
        .then(res => {
          if (res.code === '0') {
            this.refeshCoupon(type)
            wx.showToast({
              title: '领取成功',
              icon: 'none',
            })
          } else {
            if (res.statusCode === '9998') {
              if (res.msg === '没有足够的促销券码库存') {
                couponList[index].status = 2
              } else if (res.msg.indexOf('超出用户领取上限') > -1) {
                couponList[index].status = 1
              } else {
                wx.showToast({
                  title: res.msg,
                  icon: 'none',
                })
              }
            }
            this.setData({ couponList })
          }
        })
        .catch(err => {
          if (err.data.code === '10143034') {
            couponList[index].status = 2 // 领取上限
          }
          if (err.data.code === '10143009') {
            couponList[index].status = 2 // 库存不足
          }
          this.setData({ couponList })
          wx.showToast({
            title: err.msg,
            icon: 'none',
          })
        })
    },
    handleSendCoupon({ currentTarget }) {
      const { index, activitycode, type } = currentTarget.dataset
      if (!app.globalData.userCode && !app.globalData.unexUserToken) {
        apiReload.getxAuthTokenAndunexUserToken(app).then(() => {
          this.sendCoupons(index, activitycode, type)
        })
      } else {
        this.sendCoupons(index, activitycode, type)
      }
    },
  },
})
