const displayMax = 999
const max = 40000
const km = 1000

export default distance => {
  if (distance < km) {
    return `${Math.round(distance)}m`
  } else if (distance < displayMax * km) {
    return `${Math.round(parseFloat(distance / km) * 100) / 100}km`
  } else if (distance < max * km) {
    return `>${displayMax}km`
  }
  return ''
}
