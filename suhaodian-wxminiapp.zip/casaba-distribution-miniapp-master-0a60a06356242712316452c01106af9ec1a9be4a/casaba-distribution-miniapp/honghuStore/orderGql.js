export const createPintuanOrderStr = `mutation($data: PintuanTeamCreateV2Input!) {
  pintuanTeamCreate(input: $data) {
    pintuanTeam{
      id
      code  
    }
    order: marketingOrder{
      id
      code
      type
      status   
    }
  }
}`

export const joinPintuanTeamStr = `mutation($data: PintuanTeamJoinV2Input!) {
  pintuanTeamJoin(input: $data) {
    pintuanTeam{
        id
        code
      }
      order: marketingOrder{
        id
        code
      }
  }
}`

export const prepayPintuanOrderStr = `mutation ($id: ID!) {
  orderPrepay: marketingOrderPrepay(marketingOrderId: $id) {
      ... on WeixinMiniprogramPaymentRequest {
        timeStamp
        nonceStr
        package
        signType
        paySign
      }
    }
}`

export const getOrderDetailStatusStr = `query($id: ID!) {
 node (id: $id) {
    ... on MarketingOrder {
      id
      status
    }
  }
}
`

export const getPintuanTeamDetailStr = `query($id: ID!){
  node(id: $id) {
    ... on PintuanTeam {
      id
      code
      campaign{
        id
        name
      }
      creator{
        id
        code
        nickName
        avatarUrl
      }
      createdAt
      startedAt
      endedAt
      status
      limitNumber
      currentNumber
      members{
        id
        code
        avatarUrl
        nickName
      }
      productSkus{
        id
        code
        listPrice
        salePrice
        price: pintuanPrice
        creatorPrice
        attrSaleList{
            code
            attributeFrontName
            attributeValueList{
              code
              attributeValueName
              attributeValueFrontName
              attributeValuePicURL
              itemAttributeValueImageList{
                picUrl
                saleAttributeId
                saleAttributeValue
              }
            }
         }
        campaign{
          name
          code
        }
      }
      product: pintuanCampaignProduct {
        id
        name
        salePrice
        listPrice
        itemImageList{
          saleAttributeId
          picUrl
        }
      }
    }
  }
}`

export const getOrderCodesStr = `query($codes: [String!]!) {
  byCodes(typename: "MarketingOrder", codes: $codes) {
    ...on MarketingOrder {
      id
      status
      code
      type
      member {
        id
        code
      }
      team {
        id
        endedAt
        updatedAt
        status
        limitNumber
        creator {
          id
          code
          nickName
          avatarUrl
        }
        members {
          id
          code
          avatarUrl
          nickName
        }
        campaign { type }
        currentNumber
        productSkus {
          pintuanPrice
          creatorPrice
        }
      }
      items {
        quantity
        price
        productSku {
          listPrice
          salePrice
          attrSaleList {
            attributeValueList {
              attributeValueFrontName
              itemAttributeValueImageList {
                picUrl
              }
            }
          }
          product {
            id
            code
            name
          }
        }
      }
    }
  }
}`
