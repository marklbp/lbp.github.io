import LoanDetail from './LoanDetail';

export default LoanDetail;
