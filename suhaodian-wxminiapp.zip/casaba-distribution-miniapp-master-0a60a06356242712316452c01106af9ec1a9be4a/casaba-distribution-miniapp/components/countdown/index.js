import { getRemainingTime } from '../../static/utils/remainingTime'
import currentServerTime from '../../utils/currentServerTime'
const remainingTime = {
  hours: '00',
  minutes: '00',
  seconds: '00',
}

Component({
  properties: {
    teamEndTime: {
      type: String,
      value: '',
    },
  },
  data: {
    remainingTime: remainingTime,
    timer: null,
  },
  attached() {
    if (new Date(this.data.teamEndTime) - currentServerTime() > 0) {
      this.setTimer()
    } else {
      this.triggerEvent('refresh', {})
    }
  },
  detached() {
    this.clearTimer()
  },
  methods: {
    setTimer() {
      this.setData({
        remainingTime: getRemainingTime(this.data.teamEndTime),
      })
      this.setData({
        timer: setInterval(() => {
          if (new Date(this.data.teamEndTime) - currentServerTime() <= 0) {
            this.clearTimer()
            this.triggerEvent('refresh', {})
            this.setData({
              remainingTime: remainingTime,
            })
          } else {
            this.setData({
              remainingTime: getRemainingTime(this.data.teamEndTime),
            })
          }
        }, 1000),
      })
    },
    clearTimer() {
      clearInterval(this.data.timer)
    },
  },
})
