Component({
  externalClasses: ['u-class'],
  properties: {
    src: {
      type: String,
      value: '',
    },
    img: {
      type: String,
      value: '',
    },
    hookLayer: {
      // 视频的层级处于webview上，防止其他弹出层被覆盖
      type: Boolean,
      value: false,
      observer: function(val) {
        this.ctx.pause()
        this.setData({ play: !val })
      },
    },
  },

  data: {
    play: false,
    duration: '',
  },

  ready() {
    this.ctx = wx.createVideoContext('u_video', this)
  },
  methods: {
    handleEnded(e) {
      this.triggerEvent('play', { play: false })
      this.ctx.stop()
      this.setData({ play: false })
    },
    handlePlay(e) {
      this.triggerEvent('play', { play: true })
      this.setData({ play: true })
      setTimeout(() => {
        this.ctx.play()
      }, 100)
    },
    handleCancel() {
      this.triggerEvent('play', { play: false })
      this.ctx.pause()
      this.setData({ play: false })
    },
    handleError() {
      this.setData({ error: true })
    },
  },
})
