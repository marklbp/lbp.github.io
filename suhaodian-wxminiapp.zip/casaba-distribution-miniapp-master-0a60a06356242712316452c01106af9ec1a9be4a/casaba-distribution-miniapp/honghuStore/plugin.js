import { getFreight } from '../utils/express'
import { safeGet } from '../utils/util'
import apiReload from '../utils/reload'
import { queryAddress, queryCouponDetail } from '../api/index'

const {
  tenantCode,
  appCode,
  host: { HH_API_HOST },
} = wx.getExtConfigSync()
let currentEnv = HH_API_HOST.replace(/^.*honghuapi-([a-z]+)\..*$/, '$1')
if (HH_API_HOST === 'https://honghuapi.baozun.com') {
  currentEnv = 'prod'
}
function formatAddress({
  address: detailInfo,
  city: cityName,
  district: districtName,
  receiverMobile: telNumber,
  receiverName: userName,
  province: provinceName,
  receiverZipcode: postalCode,
}) {
  return {
    userName,
    postalCode,
    // countyName: '',
    provinceName,
    cityName,
    districtName,
    detailInfo,
    // nationalCode: '',
    telNumber,
    // errMsg: '',
  }
}

export function init(app) {
  app.honghuConfig = {
    currentEnv,
    tenantCode,
    appCode,
    navigateTo: {
      home() {
        app.router.navigateTo('/pages/home/home')
        // const homePath = app.globalData.tabBarList[0].pagePath
        // wx.switchTab({
        //   url: `${homePath.startsWith('/') ? '' : '/'}${homePath}`,
        // })
      },
      orderDetail({ navigateTo, orderId }) {
        navigateTo({
          url: `/sub/Order/pages/orderdetail/orderdetail?id=${orderId}`,
        })
      },
      pdp({ navigateTo, spuCode }) {
        navigateTo({ url: `/sub/Commodity/pages/pdp/pdp?spuCode=${spuCode}` })
      },
      shoppingCart({ navigateTo }) {
        app.router.navigateTo('/sub/Pay/pages/shopcart/shopcart')
        // const isTabBarPage = app.globalData.tabBarList.some(item =>
        //   item.pagePath.includes('pages/shopcart/shopcart')
        // )
        // const url = '/sub/Pay/pages/shopcart/shopcart'
        // if (isTabBarPage) {
        //   wx.switchTab({
        //     url,
        //   })
        // } else {
        //   navigateTo({
        //     url,
        //   })
        // }
      },
    },
    getMiniProgramCodeApi({ pagePath, scene, success, fail }) {
      if (!pagePath || !scene) {
        return fail('参数错误')
      }
      return success(
        `${
          app.globalData.API_HOST
        }/wechat/ma/getWxQrcodeByTenantCode?tenantCode=${
          app.globalData.tenantCode
        }&page=pages/home/home&width=160&scene=${scene}`
      )
    },
    chooseAddress({ navigateTo, success }) {
      getApp().globalCallbacks.chooseAddress = addr => {
        return success(formatAddress(addr))
      }
      navigateTo({
        url: '/sub/Base/pages/address/address?isSelectAddress=true',
      })
    },
    getDefaultAddress({ success, fail }) {
      const currentAddress = wx.getStorageSync('checkoutAddress')
      currentAddress
        ? success(formatAddress(JSON.parse(currentAddress)))
        : queryAddress({}, { unexUserToken: app.globalData.unexUserToken })
          .then(({ ok, content, msg }) => {
            if (ok && content.length > 0) {
              return content.find(({ isDefault }) => isDefault === '1')
            }
            throw new Error(msg || '没有默认地址')
          })
          .then(address => {
            if (!address) {
              throw new Error('没有默认地址')
            }
            return address
          })
          .then(address => success(formatAddress(address)))
          .catch(e => fail(e))
    },
    getShopStyle() {
      return getApp().globalData.shopStyle
    },
    getFreight({ address, products, success }) {
      console.log('get freight form this address：', address, products)
      getFreight(address, products).then(res => {
        const freight = safeGet(res, 'data.freight')
        success &&
          success({
            freight: parseFloat(freight),
          })
      })
    },
    wxRequestPayment: wx.requestPayment,
    getUserInfo({ success, fail }) {
      const { unexUserToken, accountId } = app.globalData
      if (unexUserToken && accountId) {
        return success({
          userToken: unexUserToken,
          userCode: accountId,
        })
      }
      apiReload
        .getOpenIdAndAuthParam(app)
        .then(({ data: { content: { accountId, unexUserToken } } }) => ({
          userCode: accountId,
          userToken: unexUserToken,
        }))
        .then(success)
        .catch(fail)
    },
    getCouponDetail({ code, success, fail }) {
      queryCouponDetail(
        {
          activityCode: code,
          tenantCode: app.globalData.tenantCode,
        },
        {
          unexUserToken: app.globalData.unexUserToken,
          'invoke-source': app.globalData['invoke-source'],
          xAuthToken: app.globalData.xAuthToken,
        }
      )
        .then(res => {
          if (res.code === '0') {
            return success(res.data)
          } else {
            fail(res.message || '优惠券获取失败')
            wx.showModal({
              title: '提示',
              content: res.message || '优惠券获取失败',
              showCancel: false,
              confirmColor: '#333',
            })
          }
        })
        .catch(e => {
          fail(e.msg)
          wx.showModal({
            title: '提示',
            content: e.msg || '优惠券获取失败',
            showCancel: false,
            confirmColor: '#333',
          })
        })
    },
  }
}
