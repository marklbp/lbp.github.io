// teamPeoplePanel.js

import currentServerTime from '../../../../../utils/currentServerTime'
import { getRemainingTime } from '../../../../../static/utils/remainingTime'

const getInitRemainingTime = () => ({
  hours: '00',
  minutes: '00',
  seconds: '00',
})

Component({
  properties: {
    team: {
      type: Object,
      value: {},
    },
    large: {
      type: Boolean,
      value: false,
    },
  },
  data: {
    defaultAvatar: '/assets/user.png',
    remainingTime: getInitRemainingTime(),
    timer: null,
  },

  attached() {
    if (new Date(this.data.team.endedAt) - currentServerTime() > 0) {
      this.setTimer(this.data.team.endedAt)
    } else {
      this.triggerEvent('refresh', {})
    }
  },
  methods: {
    detached() {
      this.clearTimer()
    },
    clearTimer() {
      clearInterval(this.data.timer)
    },
    updateRemainingTime(time) {
      this.setData({
        remainingTime: time,
      })
    },
    setTimer(time) {
      this.updateRemainingTime(getRemainingTime(time))
      this.setData({
        timer: setInterval(() => {
          if (new Date(time) - currentServerTime() <= 0) {
            this.clearTimer()
            this.triggerEvent('refresh', {})
            this.updateRemainingTime(getInitRemainingTime())
          } else {
            this.updateRemainingTime(getRemainingTime(time))
          }
        }, 1000),
      })
    },
    handleJoinTeamClick() {
      this.triggerEvent('onJoinTeam', { teamId: this.data.team.id })
    },
    onAuthorizationCancel(arg) {
      this.triggerEvent('onAuthorizationCancel', { detail: arg.detail })
    },
    onAuthorizationSuccess(arg) {
      console.log('onAuthorizationSuccess ', arg)
      this.triggerEvent('onAuthorizationSuccess', arg.detail)
    },
  },
})
