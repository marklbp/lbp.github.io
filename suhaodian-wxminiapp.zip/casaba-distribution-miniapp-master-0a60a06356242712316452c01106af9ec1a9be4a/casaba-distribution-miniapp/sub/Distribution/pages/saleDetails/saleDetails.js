// sub/Distribution/pages/incomeDetails/incomeDetails.js
import { getOrderList } from '../../../../api/index.js'
const app = getApp()
Page({
  /**
   * 页面的初始数据
   */
  data: {
    index: 1,
    orderStatus: -1,
    animationData: null,
    orderList: [
      // {
      //   orderUser: '', // 下单人
      //   openId: '', // openId
      //   coreOrderId: 'VSL123456789', // OrderId
      //   userName: 'Berryz', // 用户名
      //   userPhoto: './uesr1.png', // 用户图片
      //   firstCommision: 19.08, // 收益
      //   orderStatus: 0, // 分销状态
      //   coreOrderStatusName: '已失效', // 分销状态名称
      //   orderAmount: 109.08, // 订单金额
      //   productCount: 2, // 共几件商品
      //   createTime: '2018-02-28 00:00:00', // 下单时间
      //   updateTime: '',
      //   productVo: [  // 商品列表
      //     {
      //       skuName: 'ONITZUGA 鬼洗春夏款复古牛仔裤 潮牌必备', // sku名称
      //       count: 1, // 数量
      //       image: 'https://product-res.baozun.com/sandbox/88000785/images/1551082865799d548874a-8ef9-45a2-80de-823406c6c5e51.jpg', // 图片
      //       sellPrice: 10.08, // 商品价格
      //       attribute: '', //
      //       model: 0 // 收益比例
      //     }
      //   ]
      // }
    ],
    page: null,
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    this.getOrderList({})
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {},

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {},

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {},

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {},

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {},

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {
    const page = this.data.page
    const currentTotal = page.pageNum * page.pageSize
    if (currentTotal < page.total) {
      this.getOrderList({
        pageNum: ++page.pageNum,
        pageSize: 5,
      })
    }
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {},
  /**
   * 激活标签页
   */
  activeTab(e) {
    const animation = wx.createAnimation({
      duration: 400,
      timingFunction: 'linear',
    })
    const device = wx.getSystemInfoSync().windowWidth
    const left = (e.target.dataset.index - 1) * 0.25 + 0.125
    const width = device * left - 7.5
    animation.left(width).step()
    const dataset = e.target.dataset
    this.setData({
      index: dataset.index,
      orderStatus: dataset.status,
      animationData: animation.export(),
      orderList: [],
    })
    this.getOrderList({})
  },
  /**
   * 查询订单列表
   */
  getOrderList({ pageNum = 1, pageSize = 5 }) {
    const promise = getOrderList({
      tenantCode: app.globalData.tenantCode,
      openId: app.globalData.openid || wx.getStorageSync('openid'),
      orderStatus: Object.is(this.data.orderStatus, -1)
        ? undefined
        : this.data.orderStatus,
      pageNum,
      pageSize,
    })
    promise
      .then(res => {
        const {
          code,
          data: { body, page },
        } = res
        if (Object.is(code, '0')) {
          const orderList = this.data.orderList.concat(body)
          this.setData({
            orderList: orderList,
            page: page,
          })
        }
      })
      .catch(err => {
        console.log('异常', err)
      })
  },
})
