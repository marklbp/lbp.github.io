import {
  getReturnDetail,
  closeRefundment,
  querySettings,
  getReturnLogistics,
  getExpressDetails,
  queryOrderOpenDetail,
} from '../../../../api/index'
import { get } from '../../../../utils/storage.js'

const app = getApp()
Page({
  data: {
    rejectedInfo: null,
    returnId: '',
    refundTotalCount: '',
    statusTitle: '',
    productlist: null,
    listLoading: false,
    isShowReloadBtn: false,
    sellerInfo: null,
    logisticsSaved: false,
    logisticsInfo: null,
    logistics: [],
    onlyRefund: false,
  },
  formatStatusText(status) {
    var statusTitle = ''
    if (this.data.onlyRefund) {
      switch (status) {
        case '11':
          statusTitle = '退款信息已提交，请等待卖家审核'
          break
        case '51':
          statusTitle = '退款审核已通过，等待退款'
          break
        case '61':
          statusTitle = '退款成功'
          break
        case '71':
          statusTitle = '退款申请已撤销'
          break
        case '81':
          statusTitle = '退款审核未通过'
          break
      }
    } else {
      switch (status) {
        case '11':
          statusTitle = '退货信息已提交，请等待卖家审核'
          break
        case '51':
          statusTitle = '商家已收货'
          break
        case '61':
          statusTitle = '退货成功'
          break
        case '21':
        case '31':
          statusTitle = '退货审核已通过'
          break
        case '71':
          statusTitle = '退货申请已撤销'
          break
        case '81':
          statusTitle = '退货审核未通过'
          break
      }
    }
    this.setData({
      statusTitle: statusTitle,
    })
  },
  onLoad: function(query) {
    // 获取退货详情
    this.setData({
      returnId: query.returnId,
      orderId: query.orderId,
    })
    var postdata = {
      tenantCode: app.globalData.tenantCode,
      orderId: this.data.orderId,
    }
    query.mode && this.changemode(query.mode)
    this.queryReturnOrderDetail(postdata)
    this.getReturnLogistics()
    this.stateLogis()
  },
  querysellerInfo() {
    let $this = this
    querySettings({
      // app.globalData.tenantCode
      // '88000101'
      tenantCode: app.globalData.tenantCode,
    })
      .then(res => {
        if (res.code === '0') {
          if (res.data.province) {
            $this.setData({
              sellerInfo: {
                address:
                  res.data.province +
                  res.data.city +
                  res.data.districtTown +
                  res.data.detailAddress,
                ...res.data,
              },
            })
          }
        }
      })
      .catch(e => {
        console.log('err', e)
      })
  },
  changemode(mode) {
    if (mode === '41') {
      // 仅退款
      wx.setNavigationBarTitle({
        title: '退款详情',
      })
      this.setData({
        onlyRefund: true,
      })
    } else if (mode === '11') {
      // 退货退款
      this.setData({
        onlyRefund: false,
      })
    }
  },
  queryReturnOrderDetail(data) {
    this.setData({
      listLoading: true,
    })
    getReturnDetail(data)
      .then(res => {
        if (res.code === '0') {
          const result = res.data[0]
          const ro = get('rejectedProduct', [])
          const orderPorductOutList = [ro]
          let refundTotalCount = 0
          const _product = result.lines.map(i => {
            const someItem = orderPorductOutList.find(j => j.skuId === i.skuId)
            if (someItem) {
              return {
                ...someItem,
                ...i,
              }
            } else {
              return i
            }
          })
          _product.forEach(i => {
            // i.isGift === undefined 防止getStorageSync出错的判断
            if (i.isGift === '0' || i.isGift === undefined) {
              refundTotalCount += i.count
            }
          })

          this.changemode(result.returnMode)
          this.formatStatusText(result.status)
          if (result.status === '21' || result.status === '31') {
            this.querysellerInfo()
          }

          this.setData({
            rejectedInfo: result,
            refundTotalCount: refundTotalCount,
            productlist: _product,
            listLoading: false,
            isShowReloadBtn: false,
          })
        }
      })
      .catch(() => {
        this.setData({
          listLoading: false,
          isShowReloadBtn: true,
        })
      })
  },
  handleReload() {
    this.setData({ isShowReloadBtn: false })
    var postdata = {
      tenantCode: app.globalData.tenantCode,
      orderId: this.data.orderId,
    }
    this.queryReturnOrderDetail(postdata)
  },
  handleUndoApplyFor() {
    this.setData({ isShowUndoOrder: true })
  },
  hideUndoOrder() {
    this.setData({ isShowUndoOrder: false })
  },
  handleHideUndoOrder({ currentTarget: { dataset } }) {
    if (dataset.type === 'confirm') {
      this.setData({ refundConfirmLoading: true })
      closeRefundment({
        returnId: this.data.returnId,
      })
        .then(res => {
          if (res.code === '0') {
            this.setData({
              refundConfirmLoading: false,
              isShowUndoOrder: false,
              'rejectedInfo.status': '71',
            })
            wx.showToast({
              title: '撤销退款申请成功',
              icon: 'none',
            })
            this.queryOrderOpenDetail()
          }
        })
        .catch(() => {
          this.setData({
            refundConfirmLoading: false,
            isShowUndoOrder: false,
          })
        })
    }
  },
  queryOrderOpenDetail() {
    var refundOrder = wx.getStorageSync('refundOrder')
    refundOrder = JSON.parse(refundOrder)
    queryOrderOpenDetail(
      {
        orderId: refundOrder.orderId,
        tenantCode: app.globalData.tenantCode,
      },
      {
        xAuthToken: app.globalData.xAuthToken,
      }
    )
      .then(res => {
        if (res.head.code === '0') {
          const productlist = res.body.orderPorductOutList
          const currentproduct = productlist.find(
            j => j.skuId === refundOrder.skuId
          )
          wx.setStorageSync(
            'refundOrder',
            JSON.stringify({
              ...currentproduct,
              orderStatus: res.body.orderStatus,
            })
          )
        } else {
          this.setData({
            refundConfirmLoading: false,
            isShowUndoOrder: false,
          })
        }
      })
      .catch(e => {
        this.setData({
          refundConfirmLoading: false,
          isShowUndoOrder: false,
        })
      })
  },
  inputLogistics() {
    app.router.redirectTo(
      `/sub/AfterSales/pages/returnLogistics/returnLogistics?returnId=${
        this.data.returnId
      }`
    )
  },
  handleReloadApplyFor() {
    var refundOrder = wx.getStorageSync('refundOrder')
    refundOrder = JSON.parse(refundOrder)
    if (refundOrder.orderStatus === '31') {
      app.router.redirectTo(
        `/sub/AfterSales/pages/rejectedGoods/rejectedGoods?mode=0`
      )
    } else {
      app.router.redirectTo('/sub/AfterSales/pages/applyService/applyService')
    }
  },
  handleContact() {
    wx.request({
      url:
        'https://api.weixin.qq.com/cgi-bin/message/custom/send?access_token=ACCESS_TOKEN',
    })
  },
  goAdressBindViewTap() {
    app.router.navigateTo(
      `/sub/AfterSales/pages/returnLogistics/returnLogistics?returnId=${
        this.data.returnId
      }`
    )
  },
  getReturnLogistics() {
    var refundOrder = wx.getStorageSync('refundOrder')
    refundOrder = JSON.parse(refundOrder)
    getReturnLogistics({
      orderId: refundOrder.orderId,
      spuCode: refundOrder.spuCode,
    })
      .then(res => {
        if (res.code === '0') {
          this.setData({
            logisticsSaved: true,
            logisticsInfo: res.data[0],
          })
          this.getExpressDetails({
            expressCompany: res.data[0]['expressCompany'],
            expressNumber: res.data[0]['expressNumber'],
          })
        }
      })
      .catch(e => {
        console.log(e)
      })
  },
  // 物流信息查询
  stateLogis() {
    let $this = this
    let refundOrder = wx.getStorageSync('refundOrder')
    if (refundOrder) {
      refundOrder = JSON.parse(refundOrder)
    }
    let data = {
      orderNumber: refundOrder.orderId,
      tenantCode: app.globalData.tenantCode,
    }
    app.http({
      url: '/express/getExpressDetails',
      data: data,
      success: function(res) {
        let list = []
        list.push({
          context: '您的订单正在处理',
          time: refundOrder.createTime,
        })
        if (res.data.data.data) {
          res.data.data.data = [...res.data.data.data, ...list]
        } else {
          res.data.data.data = [...list]
        }
        $this.setData({
          logistics: res.data.data,
        })
      },
    })
  },
  // 获取物流详情
  getExpressDetails(data) {
    getExpressDetails(data)
      .then(res => {
        if (res.code === '0') {
          this.setData({
            logisticsInfo: Object.assign(this.data.logisticsInfo, {
              lists: res.data,
            }),
          })
        }
      })
      .catch(e => {
        console.log('物流详情错误', e)
      })
  },
})
