import request from '../utils/http'
/**
 * 获取导航栏的配置，以及全站的配色方案
 * @param {string} tenantCode 商户号
 */
export function getNavigationDetail(tenantCode) {
  return request.post('/page/navigation/detailAll', {
    tenantCode: tenantCode,
  })
}

/**
  获取阿里oss图片的信息
  */
export function getOSSImageInfo(url) {
  return request.get(url + '?x-oss-process=image/info')
}

/**
 * 获取个人中心背景图的配置
 */
export function getBackImage(data, header) {
  return request.post('/page/backImage/detail', data, {
    header: header,
  })
}

/**
 * 获取装修微页面详情
 */
export function getPageDetail(data) {
  return request.post('/navigation/getPageDetail', data)
}

/**
 * 获取装修组件：优惠券 - 手动选择
 */
export function getShopsCoupon(data) {
  return request.post('/coupon/shops/get', data)
}
/**
 * 获取装修组件：优惠券 - 自动选择
 */
export function getAutoQueryShopCoupon(data) {
  return request.post('/coupon/shops/autoQuery', data)
}
/**
 * 1. 获取微信OpenId, 分销员distUser
 * http://rap2.taobao.org/repository/editor?id=21973&mod=41735&itf=296066
 * @param {string} code 微信登录api获取的code
 */
export function weChatUserLoginExt(data, header) {
  return request.post('/service-wechat/wechat/user/login_ext', data, {
    header,
  })
}

/**
 * 2. 后台授权认证，获取相关数据
 * 这里需要1返回的openid，必须等待1回调完成
 * http://showdoc.baozun.com/web/#/19?page_id=764
 */
export function weChatAuthorization(data) {
  return request.post('/member/account/validate/authorization', data, {}, true)
}

/**
 * 3. 注册获取accountId
 * 只有2没有返回accountId的时候才会调用这个接口
 * http://showdoc.baozun.com/web/#/19?page_id=750
 */
export function createAccount(data) {
  return request.post('/member/account/create', data)
}

/**
 * 获取unexusertoken
 * http://showdoc.baozun.com/web/#/11?page_id=598
 * @param {string} openId 用户的openid
 */
export function getUnexUserToken(openId, header) {
  return request.post(
    '/member/account/third/validate.do',
    {
      appIdentifier: openId,
      appType: '05',
    },
    {
      header: header,
    }
  )
}

export function updateUserInfo(data, header) {
  return request.post('/member/mall/account/info/updateUser', data, {
    header: header,
  })
}
/**
 * 获取优惠券详情 对外 分享优惠券查询优惠券详情
 * @Author mengxiaofei
 * @Date   2019-01-04T14:41:46+0800
 * @param  {[Object]}                 data   请求体
 * @param  {[Object]}                 header 请求头
 * @return {[type]}                        [description]
 */
export function activityDetail(data, header) {
  return request.post('/coupon/v1/query/coupon/activity/detail.do', data, {
    header: header,
  })
}

/**
 * 查询发票列表
 * @Author mengxiaofei
 * @Date   2019-01-04T14:43:54+0800
 * @param  {[Object]}                 data   请求体
 * @param  {[Object]}                 header 请求头
 * http://rap2.taobao.org/repository/editor?id=21973&mod=190545&itf=748064
 */
export function queryInvoice(data, header) {
  return request.post('/member/invoice/query', data, {
    header: header,
  })
}
/**
 * 会员新增发票
 * @Author mengxiaofei
 * @Date   2019-01-07T14:33:29+0800
 * @param  {Object}                 data   请求体
 * @param  {Object}                 header 请求头
 * http://rap2.taobao.org/repository/editor?id=21973&mod=190545&itf=748058
 */
export function addInvoice(data, header) {
  return request.post('/member/invoice/create', data, {
    header: header,
  })
}
/**
 * 会员修改发票信息
 * @Author mengxiaofei
 * @Date   2019-01-07T14:35:05+0800
 * @param  {Object}                 data   请求体
 * @param  {Object}                 header 请求头
 * http://rap2.taobao.org/repository/editor?id=21973&mod=190545&itf=748066
 */
export function updateInvoice(data, header) {
  return request.post('/member/invoice/update', data, {
    header: header,
  })
}
/**
 * 会员删除发票信息
 * @Author mengxiaofei
 * @Date   2019-01-07T14:37:45+0800
 * @param  {Object}                 data   请求体
 * @param  {Object}                 header 请求头
 * http://rap2.taobao.org/repository/editor?id=21973&mod=190545&itf=748070
 */
export function delInvoice(data, header) {
  return request.post('/member/invoice/delete', data, {
    header: header,
  })
}

/**
 * 通过accountId获取openid
 * @param {string} userAccountIds 用户的AccountId
 */
export function getOpenIdByAccountId(userAccountIds) {
  return request.post('/member/mall/account/getAccountOpenIdsByAccountIds', {
    userAccountIds: [userAccountIds],
  })
}

/**
 * 首页定制数据
 */
export function queryDiscreteness(data) {
  return request.post('/discreteness/query', data)
}

/**
 * 申请分销员
 * http://rap2.taobao.org/repository/editor?id=21973&mod=41735&itf=296073
 */
export function registerDistUser(data) {
  return request.post('/member/account/openShop', data)
}

export function queryCouponDetailUser(data) {
  return request.post('/v1/coupon/code/find', data)
}

/**
 * 开店接口，无店铺则新建，有店铺则更新
 * http://rap2.taobao.org/repository/editor?id=21973&mod=41735&itf=334517
 */
export function openShop(data) {
  return request.post('/shop/insert', data)
}

/**
 * 是否展示开店的入口
 */
export function tenantFlag(data, header) {
  return request.post('/member/account/tenant/flag', data, {
    header: header,
  })
}

/**
 * 销售订单管理
 */
export function userSaleManage(data, header) {
  return request.post('/member/account/user/sale_manage', data, {
    header: header,
  })
}

/**
 * 申请分销员状态
 */
export function userStatus(data, header) {
  return request.post('/member/account/user/status', data, {
    header: header,
  })
}

/**
 *
 * @param {Object tenantCode} data
 * @param {Object} header
 */
export function querySettings(data, header) {
  return request.post('/shop/querySettings', data, {
    header: header,
  })
}

/**
 * 获取物流公司
 */
export function getExpressNames(data, header) {
  return request.get('/express/getExpressNames', data, {
    header: header,
  })
}

/**
 * 保存退回商品物流信息
 */
export function saveReturnLogistics(data, header) {
  return request.post('/product/returnedProduct/save', data, {
    header: header,
  })
}

/**
 * 查询退回商品物流信息
 * http://rap2.taobao.org/repository/editor?id=21973&mod=137950&itf=713604
 */
export function getReturnLogistics(data, header) {
  return request.post('/product/returnedProduct/getMessage', data, {
    header: header,
  })
}

/**
 * 根据 快递公司 及 快递单号长沙县物流详情
 * http://rap2.taobao.org/repository/editor?id=21973&mod=137950&itf=713544
 */
export function getExpressDetails(data, header) {
  return request.post(
    '/express/getExpressDetailsByExpressCompanyAndExpressNumber',
    data,
    {
      header: header,
    }
  )
}

/**
 * 获取店铺基本信息
 * common 服务
 */

export function getBaseInfo(data, header) {
  return request.post('/merchant/info', data, {
    header: header,
  })
}

/**
 * 优惠券： 根据商品查询优惠券活动列表
 * http://showdoc.baozun.com/web/#/19?page_id=1727
 */
export function checkCoupon(data, header) {
  return request.post(
    '/coupon/v1/query/coupon/activities/by/product.do',
    data,
    {
      header: header,
    }
  )
}

/**
 * 优惠券： 根据会员，查询有效的优惠券列表
 * http://showdoc.baozun.com/web/#/19?page_id=1726
 */
export function queryCouponByUser(data, header) {
  return request.post('/coupon/v1/query/coupons/by/user.do', data, {
    header: header,
  })
}

/**
 * 优惠券： 发放优惠券给用户
 * http://showdoc.baozun.com/web/#/19?page_id=1723
 */
export function sendCoupon(data, header) {
  return request.post('/coupon/v1/send/coupon/to/user.do', data, {
    header: header,
  })
}

/**
 * 优惠券： 筛选用户购物车中可用优惠券
 * http://showdoc.baozun.com/web/#/19?page_id=1725
 */
export function filterUseableCoupon(data, header) {
  return request.post('/coupon/v1/filter/useable/coupons.do', data, {
    header: header,
  })
}

/**
 * 优惠券： 检查优惠码是否可用
 */
export function checkAvailable(data, header) {
  return request.post('/activity/shoppingcart/query', data, {
    header: header,
  })
}
/**
 * 优惠券： 查询店铺下优惠券列表
 */
export function queryShopCoupon(data, header) {
  // http://10.45.60.43:8002
  return request.post('/coupon/shop', data, {
    header: header,
  })
}

/**
 * 优惠券：查询用户优惠券
 * @param data
 * @param header
 * @returns {*}
 */
export function queryCoupons(data, header) {
  return request.post('/coupon/v1/query/coupons/by/user.do', data, {
    header: header,
  })
}

/**
 * 优惠券：查询优惠券详情
 * @param data
 * @param header
 * @returns {*}
 */
export function queryCouponDetail(data, header) {
  return request.post('/coupon/getDetail', data, {
    header: header,
  })
}

/**
 * 优惠券：推荐商品/适用商品
 * @param data
 * @param header
 * @returns {*}
 */
export function queryRecommendProd(data, header) {
  return request.post('/coupon/selectProductsByCoupon', data, {
    header: header,
  })
}

/**
 * 活动：单品促销
 */
export function querySkuPrice(data, header) {
  return request.post('/promotion/v1/activity/skuprice/query', data, {
    header: header,
  })
}

/**
 * 活动：根据商品查询活动
 */
export function activitiesByProduct(data, header) {
  return request.post('/promotion/v1/query/activities/by/product.do', data, {
    header: header,
  })
}

/**
 * 活动：根据活动查商品
 * http://showdoc.baozun.com/web/#/19?page_id=1731
 */
export function productsByActivity(data, header) {
  return request.post('/promotion/v1/query/products/by/activity.do', data, {
    header: header,
  })
}

/**
 * 商品列表：根据搜索条件返回商品列表
 * https://showdoc.baozun.com/web/#/22?page_id=739
 */
export function getItemListbyConditionsV1(data) {
  return request.post('/pim/solr/item/getItemListbyConditionsV1', data)
}

/**
 * 通过商品spuCode和accountId获取商品id
 * @param {string} scene accountId_spuCode_这里根据业务来
 */
export function getProductIdBySpuCode(scene) {
  return request.post('/item/getAccountItemId', {
    scene: scene,
  })
}

/**
 * 通过商品Id获取spuCode
 * @param {string} data accountId_productId
 */
export function getSpuCodeByProductId(data) {
  return request.post('/item/getShareString', {
    id: data,
  })
}

/**
 * 商品详情：根据商品编码获取商品详情明细
 * https://showdoc.baozun.com/web/#/22?page_id=736
 */
export function getItemDetailV1(data) {
  return request.post('/pim/solr/item/getItemDetailV1', data)
}

/**
 * 商品详情： 根据SKU编码获取商品详情明细
 * https://showdoc.baozun.com/web/#/22?page_id=738
 */
export function getItemDetailBySku(data) {
  return request.post('/pim/solr/item/getItemDetailBySkuV1', data)
}

/**
 * 购物车：查询购物车的商品信息、 价格、 促销信息等。
 * http://showdoc.baozun.com/web/#/19?page_id=1647
 */
export function queryShoppingCart(data, header) {
  return request.post('/shoppingCart/queryShoppingCart', data, {
    header: header,
  })
}

/**
 * 购物车：加入购物车
 * http://showdoc.baozun.com/web/#/19?page_id=1642
 */
export function shoppingCartAddProduct(data, header) {
  return request.post('/shoppingCart/addProduct', data, {
    header: header,
  })
}

/**
 * 购物车：修改购物车选中状态
 * http://showdoc.baozun.com/web/#/19?page_id=1649
 */
export function shoppingCartUpdateSelect(data, header) {
  return request.post('/shoppingCart/updateSelect', data, {
    header: header,
  })
}

/**
 * 购物车：游客或会员可以通过选中购物车内的商品， 进行删除操作
 * http://showdoc.baozun.com/web/#/19?page_id=1641
 */
export function shoppingCartDeleteProduct(data, header) {
  return request.post('/shoppingCart/deleteProduct', data, {
    header: header,
  })
}

/**
 * 购物车：变更购物车内的商品数量
 * http://showdoc.baozun.com/web/#/19?page_id=1645
 */
export function shoppingCartUpdateProductCount(data, header) {
  return request.post('/shoppingCart/updateProductCount', data, {
    header: header,
  })
}

/**
 * 订单：计算确认订单页的价格
 */
export function shoppingCartOrderSettle(data, header) {
  return request.post('/shoppingCart/orderSettle', data, {
    header: header,
  })
}

/**
 *  根据搜索条件返回商品列表
 */
export function searchProductByCondition(data, header) {
  return request.post('/pim/solr/item/searchProductByCondition', data, {
    header: header,
  })
}

/**
 * 获取品牌列表
 */
export function getBrandList(data, header) {
  return request.post('/product/brand/list', data, {
    header: header,
  })
}

/**
 * 查询用户对限购商品的购买资格
 * http://rap2.taobao.org/repository/editor?id=21973&mod=135305&itf=797007
 */
export function getQuotaQualification(data, header) {
  return request.post('/product/getQuotaQualification', data, {
    header: header,
  })
}

/**
 * 校验购物车中的限购商品是否满足限购条件
 */
export function checkQuotaProducts(data, header) {
  return request.post('/shoppingcart/checkQuotaProducts', data, {
    header: header,
  })
}

/**
 * 订单：订单列表查询
 * http://showdoc.baozun.com/web/#/13?page_id=13
 */
export function queryOrder(data, header) {
  return request.post('/unex-order/orderopen/queryOrder', data, {
    header: header,
  })
}

/**
 * 订单：订单详情查询
 * http://showdoc.baozun.com/web/#/13?page_id=14
 */
export function queryOrderOpenDetail(data, header) {
  return request.post('/unex-order/orderopen/queryOrderOpenDetail', data, {
    header: header,
  })
}

/**
 * 地址：地址列表
 */
export function queryAddress(data, header) {
  return request.post('/member/mall/MemAddress/queryByDTO', data, {
    header: header,
  })
}

/**
 * 地址：新建地址
 */
export function createAddress(data, header) {
  return request.post('/member/mall/MemAddress/create', data, {
    header: header,
  })
}

/**
 * 地址：更新地址
 */
export function updateAddress(data, header) {
  return request.post('/member/mall/MemAddress/update', data, {
    header: header,
  })
}

/**
 * 地址：删除地址
 */
export function deleteAddress(data, header) {
  return request.post('/member/mall/MemAddress/deleteById', data, {
    header: header,
  })
}

/**
 * 退货：退货详情，根据orderid查询
 * http://showdoc.baozun.com/web/#/19?page_id=2135
 */
export function returnOrderByOrderId(data, header) {
  return request.post('/return-order/query/list/byOrderId.do', data, {
    header: header,
  })
}

/**
 * 退款：创建退款单
 * http://showdoc.baozun.com/web/#/13?page_id=160
 */
export function createRefundment(data, header) {
  return request.post('/refund/createRefund', data, {
    header: header,
  })
}

/**
 * 退款：获取退款单列表
 * http://showdoc.baozun.com/web/#/13?page_id=169
 */
export function getRefundmentList(data, header) {
  return request.post('/unex-order/refundment/getRefundmentList', data, {
    header: header,
  })
}

/**
 * 退款：根据退款单编号，获取退款单明细
 * http://rap2.taobao.org/repository/editor?id=21973&mod=137950&itf=649243
 */
export function getReturnDetail(data, header) {
  return request.post('/refund/getRefundmentMoneyDetail', data, {
    header: header,
  })
}

/**
 * 退款：退款单取消
 * http://rap2.taobao.org/repository/editor?id=21973&mod=137950&itf=648726
 */
export function closeRefundment(data, header) {
  return request.post('/refund/closeReturn', data, {
    header: header,
  })
}

/**
 * 退货：根据退换货单号查询退换货详情  含换货状态
 * @param {Object} data { returnId: String }
 * @param {Object} header {}
 */
export function queryReturnOrderDetail(data, header) {
  return request.post('/refund/orderDetail', data, {
    header: header,
  })
}

/**
 * 确认收货：确认收货
 */
export function orderConfirmGoods(data, header) {
  return request.post('/casaba/trade/dealWithOrderReceived', data, {
    header: header,
  })
}

/**
 * 门店：获取门店列表
 */
export function getStoreList(data) {
  return request.get('/store/query', data)
}
// 查询网店信息
export function queryShopMessage(data) {
  return request.post('/shop/queryShopMessage', data)
}

/**
 * 门店：获取门店详情
 */
export function getStoreDetail(tenantCode, storeId) {
  return request.get('/store/detail', {
    tenantCode,
    storeId,
  })
}

/**
 * 门店商品列表：根据搜索条件返回门店商品列表
 */
export function getStoreProduct(data) {
  return request.post('/store/products', data)
}

/**
 * 订单详情：门店自提订单确认收货
 */
export function confirmGoods(tenantCode, orderId, header) {
  return request.put(
    '/unex-pickup-order/status',
    {
      tenantCode,
      orderId,
    },
    {
      header,
    }
  )
}
/**
 * 查询通用设置
 * @Author mengxiaofei
 * @Date   2019-01-23T14:59:28+0800
 * @param  {[type]}                 data [description]
 * @return {[type]}                      [description]
 */
export function queryCommonSetting(data, header) {
  return request.post('/shop/queryCommSetting', data, {
    header: header,
  })
}
/**
 * 会员下单计算折扣金额
 * @Author mengxiaofei
 * @Date   2019-01-23T13:16:28+0800
 * @param  {[type]}                 data [description]
 * @return {[type]}                      [description]
 */
export function calcMemberPrice(data) {
  return request.post('/casaba/trade/calculationDiscount', data)
}
/**
 * 会员卡-删除会员卡
 * data: 删除参数（id）
 * return 返回Promise对象
 */
export function deleteMemberShopCard(data) {
  return request.post('/card/delete', data)
}
/**
 * 会员卡 - 用户设置默认会员卡
 * data: 用户id(accountId)
 * data: 操作者id(操作者id)
 * data: 会员卡id(relationId)
 */
export function defaultMemberCard(data) {
  return request.post('/card/defaultMemberCard', data)
}
/**
 * 会员卡-会员卡列表
 * data 获取参数
 * return 返回promise对象
 */
export function getMemberCardList(data) {
  return request.post('/card/wxCardList', data)
}
/**
 * 会员卡-出示会员卡
 * data 获取参数
 * return 返回promise对象
 */
export function showShowMemberCardData(data) {
  return request.post('/card/getCardNumber', data)
}
/**
 * 会员卡-二维码
 * data 获取参数
 * return 返回promise对象
 */
export function getEncoderQRCode(data) {
  return request.post('/card/encoderQRCode', data)
}

/**
 * 会员卡-条形码
 * data 获取参数
 * return 返回promise对象
 */
export function getEncoderBarCode(data) {
  return request.post('/card/getEncoderBarCode', data)
}

/**
 * 查询店铺有效期与是否打烊
 */
export function queryEffectiveDay(data) {
  return request.post('/member/tenant/expireDay', data)
}

export function getAutoCancelRule(tenantCode) {
  return request.post('/refund/getAutoCancelRule', {
    tenantCode,
  })
}

export function getFreightFromAddress(data) {
  return request.post('/fare/getFreight', data)
}

/**
 * 查询商品种类列表
 * @param data
 * @returns {*}
 */
export function queryProdCategory(data) {
  return request.post('/category/list', data)
}
/**
 * 查询省、市、区
 */
export function obtainSubAddressByPid(data, header) {
  return request.post('/back/memAddress/obtainSubAddressByPid', data, {
    header,
  })
}
/**
 * 激活会员卡签名
 */
export function getActiveCardToken() {
  return request.get('/card/getActiveCardToken')
}
/**
 * 短信验证码
 */
export function sendActiveCardCode(data) {
  return request.post('/card/sendActiveCardCode', data)
}
/**
 * 检验短信验证码
 */
export function checkActiveCardCode(data) {
  return request.post('/card/checkActiveCardCode', data)
}
/**
 * 激活会员卡
 */
export function activateMemberCard(data) {
  return request.post('/card/front/relation/activateMemberCard', data)
}
/**
 * 领取无门槛会员卡
 */
export function reciveThesholdCard(data) {
  return request.post('/card/back/card/getCard', data)
}
/**
 * 会员卡-详情-back
 */
export function queryThesholdCard(data) {
  return request.post('/card/back/card/detail', data)
}
/**
 * 获取优惠券
 */
export function getCouponTreasure(data) {
  return request.post('/member/activity/receive', data)
}
/**
 * 获取全部地址
 */
export function getAllAddress() {
  return request.get('/area/getAllSubAreas')
}

/**
 * 获取店铺的配送设置
 * @Date   2019-03-04T17:48:38+0800
 * http://rap2.taobao.org/repository/editor?id=21973&mod=186719&itf=869984
 */
export function queryDeliverySetting(data, header) {
  return request.post('/shop/queryDeliverySetting', data, {
    header,
  })
}

/**
 * 解码手机号码
 */
export function getPhone(data) {
  // return request.post('/decode/wxapp/phone', data)
  return new Promise((resolve, reject) => {
    wx.request({
      url: `${wx.getStorageSync('API_HOST')}/decode/wxBindphone`,
      // url: `http://10.45.60.25:18020/decode/wxBindphone`,
      data: data,
      header: {},
      method: 'POST',
      dataType: 'json',
      responseType: 'json/application',
      success: function(res) {
        resolve(res)
      },
      fail: function(res) {},
      complete: function(res) {},
    })
  })
}
/**
 * 获取配置菜单名称
 */
export function queryDistributionConfigureName(data) {
  return request.post('/font/distribution/queryDistributionConfigureName', data)
}
/**
 * 查询招募计划申请成为分销员页面文档
 */
export function queryPromotionPlan(data) {
  return request.post('/font/distribution/queryPromotionPlan', data)
}
/**
 * C端-分销中心显示
 */
export function querySaleManage(data) {
  return request.post('/member/account/user/sale_manage', data)
}

/**
 * C端-收入明细
 */
export function getIncomeDetail(data) {
  return request.post('/income/getIncomeDetail', data)
}

/**
 * C端-销售明细
 */
export function getOrderList(data) {
  return request.post('/member/user/friend/order/list', data)
}

/**
 * C端-分销邀请人明细
 */
export function getFriendList(data) {
  return request.post('/member/user/friend/list', data)
}

/**
 * C端-分销员我的邀请码
 */
export function invitationCode(data) {
  return request.post('/user/invitationCode', data)
}

/**
 * C端-分销员我的客户
 */
export function myClientList(data) {
  return request.post('/member/user/next/list', data)
}

/**
 * 查询当前商户是否 为 PACS 商户
 */
export function checkIfMajorCustomer(data) {
  return request.post('/tenant/checkIfMajorCustomer', data)
}
/**
 * 保存formId
 */
export function saveFormId(data) {
  return request.post('/common/system/batchSaveFormId', data)
}

/**
 * 查询分类模版
 */
export function queryCategoryTemplate(data) {
  return request.post('/category/queryCategoryModel', data)
}
