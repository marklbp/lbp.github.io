/* global wx */
import {
  hideLoading,
  navigateTo,
  PROMPT_DURATION_TIME,
  showLoading,
  showToast,
} from './uiHelper'
import { HONGHU_ORDER_STATUS_KEY, HONGHU_PINTUAN } from './constant'
import { prepayPintuanOrderAction, getOrderDetailStatusAction } from './action'

function checkPaidOrderStatus(orderId, orderCode, teamId, timeoutCallback) {
  let checkTimer = null
  showLoading({ title: '处理中...', mask: true })
  let counter = 0
  checkTimer = setInterval(() => {
    if (counter === 30) {
      clearInterval(this.checkTimer)
      hideLoading()
      return showToast({
        title: '订单处理超时',
        success: () => {
          setTimeout(() => {
            timeoutCallback()
          }, PROMPT_DURATION_TIME)
        },
      })
    }
    counter++
    getOrderDetailStatusAction(orderId)
      .then(order => {
        console.log(order)
        if (order.status !== HONGHU_ORDER_STATUS_KEY.CREATED) {
          hideLoading()
          clearInterval(checkTimer)
          skipPageWhenPayed(orderCode, teamId)
        }
      })
      .catch(message => {
        hideLoading()
        message && showToast({ title: message })
      })
  }, 1000)
}

function skipPageWhenPayed(orderCode, teamId, isSuccessPayed = true) {
  let path
  if (isSuccessPayed) {
    path = `/sub/Marketing/pages/pintuanDetail/pintuanDetail?orderId=${orderCode}&teamId=${teamId}`
  } else {
    path = `/sub/Order/pages/orderDetail/orderDetail?id=${orderCode}&type=${HONGHU_PINTUAN}`
  }
  navigateTo(path)
}

export function payment(orderId, orderCode, teamId, _this) {
  prepayPintuanOrderAction(orderId)
    .then(prepay => {
      hideLoading()
      const payment = Object.assign({}, prepay, {
        success: () => {
          showToast({ title: '支付成功' })
          _this.handleReload()
          setTimeout(() => {
            checkPaidOrderStatus(orderId, orderCode, teamId, () =>
              navigateTo(
                `/sub/Order/pages/orderDetail/orderDetail?id=${orderCode}&type=${HONGHU_PINTUAN}`
              )
            )
          }, 1000)
        },
        fail: () => {
          showToast({ title: '支付失败' })
          this.skipPageWhenPayed(orderCode, teamId, false)
        },
      })
      wx.requestPayment(payment)
    })
    .catch(message => {
      hideLoading()
      message && showToast({ title: message })
    })
}
