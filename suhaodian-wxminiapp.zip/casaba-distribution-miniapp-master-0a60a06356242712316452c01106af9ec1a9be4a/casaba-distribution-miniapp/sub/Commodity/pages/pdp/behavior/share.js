// 普通分享，分销分享
import { roundRect } from '../../../../../utils/canvas'
import { transformPrice, transformDate } from '../../../../../utils/util'
import {
  getSpuCodeByProductId,
  getProductIdBySpuCode,
} from '../../../../../api/index'

const app = getApp()

export default Behavior({
  // 视图层数据
  data: {
    isNormalShare: false,
    isDistributionShare: false,
    shareMomentsImage: '',
    momentsImgLoading: true,
    headPicturePath: '',
    QSCodeUrl: '',
    shareWeChatImage: '',
    productId: '',
    shareString: '',
  },
  methods: {
    // 显示分销分享弹出层
    handleShowDistribution() {
      this.setData({
        isDistributionShare: true,
      })
      setTimeout(() => {
        this.setData({
          hookLayer: true,
        })
      }, 100)
    },
    // 隐藏分销分享弹出层
    onHideDistribution() {
      this.setData({
        isDistributionShare: false,
      })
    },
    // 显示普通分享弹出层
    handleShowNormalShare() {
      this.setData({
        isNormalShare: true,
      })
      setTimeout(() => {
        this.setData({
          hookLayer: true,
        })
      }, 100)
    },
    // 隐藏普通分享弹出层
    onHideNormalShare() {
      this.setData({
        isNormalShare: false,
      })
    },
    // 监听用户点击生成海报
    onClickMoment() {
      if (!this.data.shareMomentsImage) {
        const headImgUrl = this.data.headPicturePath
        wx.getImageInfo({
          src: headImgUrl,
          success: imgInfo => {
            this.drawMomentsImage(headImgUrl, this.data.QSCodeUrl, imgInfo)
          },
        })
      }
    },
    // 通过商品id获取spuCode
    getSpuCodeByProductId(id, pintuanTeamId, reloadProductDetail) {
      getSpuCodeByProductId(id)
        .then(res => {
          if (res.code === '0') {
            const result = res.data
            this.setData({
              spuCode: result.split('_')[1],
            })
            reloadProductDetail && this.bindGetProductDetail(pintuanTeamId)
          }
          this.getWeChatCode()
        })
        .catch(err => {
          console.error(err)
          this.setData({
            showReloadBtn: true,
          })
        })
    },
    // 通过spuCode获取id
    getProductIdBySpuCode(
      accountId,
      spuCode,
      pintuanTeamId,
      reloadProductDetail
    ) {
      getProductIdBySpuCode(
        `${accountId}_${spuCode}_${app.globalData.tenantCode}`
      ).then(res => {
        if (res.code === '0') {
          this.setData({
            shareString: res.data,
          })
          reloadProductDetail && this.bindGetProductDetail(pintuanTeamId)
          this.getWeChatCode()
        }
      })
    },
    // 下载分享到朋友圈所需的小程序二维码
    getWeChatCode() {
      return new Promise((resolve, reject) => {
        wx.downloadFile({
          url: `${
            app.globalData.API_HOST
          }/wechat/ma/getwxacode_ext?page=sub/Commodity/pages/pdp/pdp&scene=${
            this.data.shareString
          }&appCode=${app.globalData.appCode}&width=430`,
          success: res => {
            this.setData({ QSCodeUrl: res.tempFilePath })
            resolve(res)
          },
          fail: err => {
            reject(err)
          },
        })
      })
    },
    // 下载商品头图
    downloadHeadImg(url) {
      return new Promise((resolve, reject) => {
        wx.downloadFile({
          url: url,
          success: res => {
            this.setData({
              headPicturePath: res.tempFilePath,
            })
            resolve(res)
          },
          fail: err => {
            reject(err)
          },
        })
      })
    },
    // 绘制分享到朋友圈的图片
    drawMomentsImage(imgUrl, qsCodeUrl, imgInfo) {
      let title = ''
      if (this.data.title.length > 9) {
        title = this.data.title.slice(0, 9) + '...'
      } else {
        title = this.data.title
      }
      console.log('开始绘制朋友圈图片')
      const nickName = app.globalData.userInfo
        ? app.globalData.userInfo.nickName
        : '您的朋友'
      const ctx = wx.createCanvasContext('shareImage', this)
      roundRect(ctx, 0, 0, 8, 300, 400)
      ctx.setFillStyle('#666')
      ctx.setFontSize(16)
      ctx.fillText(title, 20, 40)
      ctx.setFillStyle('#2E2E2E')
      ctx.setFontSize(18)
      ctx.fillText(
        '￥' +
          transformPrice(
            this.data.hasPintuanCampaign
              ? this.data.minimalPriceSku.price
              : this.data.salePrice
          ),
        20,
        73
      )
      ctx.setFillStyle('#999')
      ctx.setFontSize(10)
      ctx.fillText(`${transformDate()}  ${nickName}向你推荐`, 20, 95)

      // 小程序码
      ctx.drawImage(qsCodeUrl, 200, 20, 75, 75)

      // 产品图
      const w = (260 / imgInfo.height) * imgInfo.width
      const h = (260 / imgInfo.width) * imgInfo.height
      if (w > 260 && h <= 260) {
        const y = 130 - h / 2
        ctx.drawImage(imgUrl, 20, y + 120, 260, h)
      } else {
        const x = 130 - w / 2
        ctx.drawImage(imgUrl, x + 20, 120, w, 260)
      }
      ctx.draw(false, () => {
        wx.canvasToTempFilePath(
          {
            canvasId: 'shareImage',
            success: res => {
              this.setData({
                shareMomentsImage: res.tempFilePath,
                momentsImgLoading: false,
              })
              console.log('绘制朋友圈图片成功', res.tempFilePath)
            },
            fail: res => {
              console.log('导出图片失败', res)
            },
          },
          this
        )
      })
    },
    // 绘制分享到朋友的图片
    drawShareWeChatImage(imgUrl, imgInfo) {
      const ctx = wx.createCanvasContext('shareWechat', this)
      let salePrice = transformPrice(
        this.data.hasPintuanCampaign
          ? this.data.minimalPriceSku.price
          : this.data.salePrice
      )
      let listPrice = transformPrice(
        this.data.hasPintuanCampaign ? this.data.salePrice : this.data.listPrice
      )
      roundRect(ctx, 0, 0, 4, 400, 320, {
        tl: false,
        tr: false,
        bl: false,
        br: false,
      })
      // ctx.restore()
      ctx.setFillStyle('#ED6347')
      ctx.setFontSize(24)
      let campaignInfoWidth = 0
      let campaignInfo = ''
      if (this.data.hasPintuanCampaign) {
        campaignInfo = `${this.data.pintuanCampaign.limitNumber}人团`
        campaignInfoWidth = ctx.measureText(campaignInfo).width
        ctx.fillText(campaignInfo, 0, 30)
      }
      const saleWidth = ctx.measureText('￥' + salePrice).width
      ctx.fillText('￥' + salePrice, campaignInfoWidth, 30)
      ctx.setFillStyle('#999999')
      ctx.setFontSize(18)
      const listWidth = ctx.measureText('￥' + listPrice).width
      ctx.fillText('￥' + listPrice, campaignInfoWidth + saleWidth + 10, 30)
      ctx.beginPath()
      ctx.setStrokeStyle('#999999')
      ctx.setLineWidth(1)
      ctx.moveTo(campaignInfoWidth + saleWidth + 10, 23)
      ctx.lineTo(campaignInfoWidth + saleWidth + listWidth + 12, 23)
      ctx.stroke()
      const w = (280 / imgInfo.height) * imgInfo.width
      const h = (400 / imgInfo.width) * imgInfo.height
      if (w > 400 && h <= 280) {
        const y = 140 - h / 2
        ctx.drawImage(imgUrl, 0, y + 40, 400, h)
      } else {
        const x = 200 - w / 2
        ctx.drawImage(imgUrl, x, 40, w, 280)
      }
      ctx.draw(false, () => {
        wx.canvasToTempFilePath({
          canvasId: 'shareWechat',
          success: res => {
            this.setData({ shareWeChatImage: res.tempFilePath })
          },
        })
      })
    },
  },
})
