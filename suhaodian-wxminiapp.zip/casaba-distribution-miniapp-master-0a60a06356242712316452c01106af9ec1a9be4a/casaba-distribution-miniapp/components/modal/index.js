/* global Component */
const app = getApp()
Component({
  externalClasses: ['u-class', 'u-class-mask'],
  options: {
    multipleSlots: true,
  },
  properties: {
    visible: {
      type: Boolean,
      value: false,
    },
    title: {
      type: String,
      value: '',
    },
    icon: {
      type: Object,
      value: null,
    },
    iconimg: {
      type: String,
      value: '',
    },
    showClose: {
      type: Boolean,
      value: false,
    },
    showOk: {
      type: Boolean,
      value: true,
    },
    showCancel: {
      type: Boolean,
      value: true,
    },
    openType: String,
    okText: {
      type: String,
      value: '确定',
    },
    cancelText: {
      type: String,
      value: '取消',
    },
    // 按钮组，有此值时，不显示 ok 和 cancel 按钮
    actions: {
      type: Array,
      value: [],
    },
    // horizontal || vertical
    actionMode: {
      type: String,
      value: 'horizontal',
    },
  },
  data: {
    shopStyle: {
      color: '#fff',
      selectedColor: '#333333',
      auxiliaryColor: '#F4766E',
    },
  },
  attached() {
    this.setData({
      shopStyle: {
        color: app.globalData.shopStyle[0],
        selectedColor: app.globalData.shopStyle[1],
        auxiliaryColor: app.globalData.shopStyle[2],
      },
    })
  },
  methods: {
    handleItem({ currentTarget = {} }) {
      const dataset = currentTarget.dataset || {}
      const { index } = dataset
      this.triggerEvent('click', { index })
    },
    handleOk() {
      if (this.data.openType) return
      this.triggerEvent('ok')
    },
    handleCancel() {
      this.triggerEvent('cancel')
    },
    handleOpenSetting({ detail }) {
      if (this.data.openType) {
        this.triggerEvent('opensetting', detail)
      }
    },
    preventTouchMove() {
      return false
    },
  },
})
