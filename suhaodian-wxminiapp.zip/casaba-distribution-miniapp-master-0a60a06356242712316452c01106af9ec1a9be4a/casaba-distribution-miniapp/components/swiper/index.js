Component({
  externalClasses: ['u-class'],
  properties: {
    data: {
      type: Array,
      value: [],
      observer: function(val) {
        let arr = []
        let _list = []
        let videoIndex = []
        val.forEach((item, index) => {
          for (let key in item) {
            if (
              /(http:\/\/|https:\/\/|)?.*\.(png|jpg|jpeg|gif|svg|PNG|JPG|JPEG|GIF|SVG)$/.test(
                item[key]
              )
            ) {
              _list.push(item[key])
              arr.push({
                type: 'image',
                src: item[key],
              })
            }
            if (
              /(http:\/\/|https:\/\/|)?.*\.(mp4|m3u8|rmvb|avi|swf|3gp|mkv|flv|ogg|MP4|M3U8|RMVB|AVI|SWF|3GP|MKV|FLV|OGG)$/.test(
                item[key]
              )
            ) {
              videoIndex.push(index)
              arr.push({
                type: 'video',
                src: item[key],
              })
            }
          }
        })
        // 将视频放置在第一个
        if (videoIndex.length && arr.length > 1) {
          videoIndex.reverse().forEach(vi => {
            const videoItem = arr.splice(vi, 1)
            arr.unshift(videoItem[0])
          })
        }
        if (arr.length === 1) {
          this.setData({ touch: true })
        }
        this.setData({ list: arr, _list: _list })
      },
    },
    hookLayer: {
      // 视频的层级处于webview上，防止其他弹出层被覆盖
      type: Boolean,
      value: false,
    },
    position: {
      type: String,
      value: 'center',
    },
    indicatorType: {
      type: String,
      value: 'rect', // rect strip dot pagination type为dot是采用微信原生的dot pagination 页码指示符
    },
    indicatorDots: {
      type: Boolean,
      value: false,
    },
    indicatorColor: {
      type: String,
      value: 'rgba(0, 0, 0, .3)', // rgba(59, 57, 57, 0.5)
    },
    indicatorActiveColor: {
      type: String,
      value: '#000000', // #F4766E
      observer: function(color) {
        if (!color) {
          this.setData({
            indicatorActiveColor: '#000',
          })
        }
      },
    },
    autoplay: {
      type: Boolean,
      value: false,
    },
    current: {
      type: Number,
      value: 0,
    },
    currentItemId: {
      // 当前所在滑块的 item-id ，不能与 current 被同时指定
      type: String,
      value: '',
    },
    interval: {
      type: Number,
      value: 5000,
    },
    duration: {
      type: Number,
      value: 500,
    },
    circular: {
      type: Boolean,
      value: false,
    },
    vertical: {
      type: Boolean,
      value: false,
    },
    previousMargin: {
      type: String,
      value: '0px',
    },
    nextMargin: {
      type: String,
      value: '0px',
    },
    displayMultipleItems: {
      type: Number,
      value: 1,
    },
    skipHiddenItemLayout: {
      type: Boolean,
      value: false,
    },
    p: String, // 详情见image组件
  },

  data: {
    list: [],
    _list: [],
    imgLoaded: false,
    current: 0,
    touch: false,
    showAn: true,
    play: false,
  },

  ready() {
    this.ctx = wx.createVideoContext('u_video', this)
  },

  methods: {
    handleChange({ detail }) {
      let touch = true
      let showAn = true
      if (detail.source === 'autoplay') {
        touch = false
        showAn = false
      }
      this.setData({
        current: detail.current,
        touch: touch,
        showAn: showAn,
      })
      this.triggerEvent('change', { detail })
    },
    handleFinish({ detail }) {
      if (detail.source === 'autoplay') {
        this.setData({
          showAn: true,
        })
      } else {
        if (this.data.list.length === 1) {
          return
        }
        if (detail.current === this.data.current) {
          this.setData({
            touch: true,
            showAn: false,
          })
          setTimeout(() => {
            this.setData({
              touch: false,
              showAn: true,
            })
          }, 100)
        } else {
          this.setData({
            touch: false,
            showAn: true,
          })
        }
      }
      this.triggerEvent('animationfinish', { detail })
    },
    handleLoad({ currentTarget }) {
      const index = currentTarget.dataset.index
      const len = this.data._list.length
      if (index + 1 >= len) {
        this.setData({
          imgLoaded: true,
        })
      }
    },
    onVideoPlay({ detail }) {
      this.setData({
        play: detail.play,
        hookLayer: false,
      })
    },
  },
})
