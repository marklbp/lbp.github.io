export default {
  EXPRESS: {
    code: '11',
    label: '快递',
  },
  PICKUP: {
    code: '21',
    label: '门店自提',
  },
  INTRA_CITY: {
    code: '31',
    label: '商家配送',
  },
}
