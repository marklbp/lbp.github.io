//  shoppingCartAddProduct
import {
  getItemListbyConditionsV1,
  updateUserInfo,
} from '../../../../api/index'
import feature from '../../../../feature'
import queryString from '../../../../utils/query-string'
import delay from '../../../../utils/delay'
import filterBehaivor from './behavior/filter'
import MARKETING_TYPE from '../../../../constant/marketing-type'
import {
  PINTUAN_CAMPAIGN_STATUS,
  TEAM_STATUS_KEY,
} from '../../../../honghuStore/constant'

const app = getApp()
Component({
  behaviors: [filterBehaivor],
  data: {
    productListData: [],
    isActive: 4,
    itemSortList: 'sales',
    upSort: true,
    isShowReloadBtn: false,
    listLoading: false,
    moreLoading: false,
    lastPage: 1,
    noMore: false,
    showProdType: false,
    prodTypeChooseList: [], // 选中的筛选条件code
    conditionList: [], // 选中的筛选条件
    searchText: '', // 搜索关键字
    isSearching: false,
    showCart: false,
    storeCode: '',
    pintuanCampaign: {},
    skuList: null,
    attrSaleList: null,
    allNetQty: null,
    pleaseSelectSku: [],
    storeId: '',
    soldOut: null,
    pic: null,
    picCopy: '',
    listPrice: '',
    salePrice: '',
    listPriceCopy: '',
    currentPintuanCampaignSelectSku: '',
    salePriceCopy: '',
    minimalPriceSku: {},
    skuListMap: [],
    currentSelectAttrArray: [],
    isCreatePintuanAction: false,
    isNormal: true,
    currentSelectSku: null,
    netqty: -1,
    hasPintuanCampaign: false,
    allNetQtyBackup: null,
    brandcode: '',
    categorycode: '',
    categoryname: '',
    brandname: '',
    spuCode: '',
    skucode: '',
    sizeData: null,
    currentSizeValue: '',
    goPdpWait: false,
    title: '',
    shopStyle: {
      color: '#fff',
      selectedColor: '#333333',
      auxiliaryColor: '#F4766E',
    },
    categoryOptions: null, // 分类页来源的 参数
    offsetLeft: 0,
    moveDistance: 0,
    current: 0,
    tabs: [
      {
        name: '综合',
      },
      {
        name: '销量',
      },
      {
        name: '新品',
      },
      {
        name: '价格',
        showIcon: true,
      },
      {
        name: '筛选',
        showIcon: true,
        iconPosition: 'left',
        canActive: false,
        dividingLine: true,
      },
    ],
    product: {},
  },
  detached() {
    // 关闭可能存在的 购物车弹窗
    this.setData({
      showCart: false,
      condition1: false,
      condition2: false,
    })
  },
  attached() {
    this.setData({
      shopStyle: {
        color: app.globalData.shopStyle[0],
        selectedColor: app.globalData.shopStyle[1],
        auxiliaryColor: app.globalData.shopStyle[2],
      },
      prodTypeChooseList: [],
      conditionList: [],
    })
    wx.setNavigationBarTitle({
      title: '全部商品',
    })
    this.initLoad()
  },
  methods: {
    initLoad() {
      this.setData({
        listLoading: true,
        lastPage: 1,
        isActive: 4,
        itemSortList: '',
      })
      this.getProductList()
    },
    handleTabChange(e) {
      let data = e.detail
      switch (data.index) {
        case 0:
          this.handleGeneralProduct(data.index)
          break
        case 1:
          this.handleHotProduct(data.index)
          break
        case 2:
          this.handleNewProduct(data.index)
          break
        case 3:
          this.handlePriceProduct(data.index)
          break
        case 4:
          this.showCondition1(data.index)
          break
      }
    },
    handleGeneralProduct(index) {
      wx.pageScrollTo({
        scrollTop: 0,
        duration: 0,
      })
      this.setData({
        itemSortList: '',
        isActive: index,
        listLoading: true,
        lastPage: 1,
        noMore: false,
        productListData: [],
      })
      this.getProductList()
    },
    gopdp({ currentTarget: { dataset } }) {
      const item = dataset.item
      let $this = this
      this.setData({
        goPdpWait: true,
      })
      wx.navigateTo({
        url: `/pages/pdp/pdp?spuCode=${item.spuCode}&src=${item.src}`,
        complete: function() {
          $this.setData({
            goPdpWait: false,
          })
        },
      })
    },
    getProductDetailFromHonghu(id, pintuanTeamId) {
      return pintuanTeamId
        ? app.honghuStore
          .getJoinPintuanTeamDetailAction(id, pintuanTeamId)
          .then(
            ({ products, pintuanTeam: { status, campaign } }) =>
              status === TEAM_STATUS_KEY.STARTED
                ? { product: products[0], campaign }
                : this.getProductAndCampaign(id)
          )
        : this.getProductAndCampaign(id)
    },
    getProductAndCampaign(productId) {
      return app.honghuStore
        .getProductDetailAction({ id: productId })
        .then(product => {
          if (product && product.campaign) {
            if (
              feature.ENABLE_PDP_GOTO_DISCOUNTS_CAMPAIGN &&
              product.campaign.discountsStatus === 'IN_PROGRESS'
            ) {
              const query = queryString({
                code: product.code,
              })
              wx.redirectTo({
                url: `/honghu/pages/discount/pdp/index?${query}`,
              })
              return delay(2000, {})
            } else if (
              product.campaign.status === PINTUAN_CAMPAIGN_STATUS.STARTED
            ) {
              return { product, campaign: product.campaign }
            }
          }
          return {}
        })
    },
    addCartSuccess() {
      wx.showToast({
        title: '加入购物车成功',
        icon: 'none',
        duration: 1000,
      })
      this.setData({
        showCart: false,
      })
    },
    addCartCancel() {
      this.setData({
        showCart: false,
      })
    },
    // 处理加入购物车动画
    handleAddCartAnimatinend(e) {
      this.setData({
        addCartAnimatin: false,
      })
    },
    updateUserInfo(detail) {
      updateUserInfo(
        {
          id: app.globalData.accountId,
          openId: app.globalData.openid,
          userName: detail.userInfo.nickName,
          userPhoto: detail.userInfo.avatarUrl,
        },
        {
          unexUserToken: app.globalData.unexUserToken,
        }
      )
    },
    handleReload() {
      this.initLoad()
    },
    createParam() {
      let itemSortList = this.data.itemSortList
      let searchText = this.data.searchText
      let currentChoseType = this.data.currentChoseType
      let currentSelectBrand = this.data.currentSelectBrand
      let noMore = this.data.noMore
      let data = {
        tenantCode: app.globalData.tenantCode,
        itemSortList: [],
        conditionList: [
          {
            key: 'saleStatus',
            value: ['1'],
            valueType: 'basic',
          },
        ],
        page: {
          page: noMore ? this.data.lastPage : this.data.lastPage++,
          size: 6,
        },
      }
      if (itemSortList && itemSortList.length > 0) {
        data.itemSortList.push({
          name: itemSortList,
          sort: itemSortList === 'sale_price' ? (!this.data.upSort ? 1 : 0) : 1,
        })
      }
      if (searchText) {
        data.conditionList.push({
          key: 'keyword',
          value: [searchText],
          valueType: 'list',
        })
      }
      if (currentChoseType) {
        data.conditionList.push({
          key: 'categoryCode',
          value: [currentChoseType.code],
          valueType: 'list',
        })
      }
      if (currentSelectBrand && currentSelectBrand.length > 0) {
        data.conditionList.push({
          key: 'brandCode',
          value: currentSelectBrand,
          valueType: 'list',
        })
      }
      if (this.data.minPrice || this.data.maxPrice) {
        data.conditionList.push({
          key: 'salePrice',
          value: [this.data.minPrice, this.data.maxPrice],
          valueType: 'basic',
        })
      }
      return data
    },
    getInfoByCode(spuArr, cb) {
      let task = []
      spuArr.forEach(item => {
        task.push(app.honghuStore.getProductInfoAction(item.code))
        if (item.activitySorts && item.activitySorts.length > 0) {
          // 去重
          let sourceTags = Array.from(new Set(item.activitySorts))
          item.tags = this.transformTags(sourceTags)
        } else {
          item.tags = []
        }
      })
      Promise.all(task).then(info => {
        info.forEach((item, index) => {
          const { campaign } = item.byCode || {}
          if (campaign) {
            spuArr[index].campaign = {
              ...campaign,
              type: this.formatCampaignType(campaign),
            }
            // spuArr[index].tags.push(
            //   this.formatCampaignType(campaign)
            // )
            if (
              campaign['__typename'] === MARKETING_TYPE.PINTUAN.type &&
              campaign.pintuanType === 'NORMAL'
            ) {
              spuArr[index].tags.unshift(this.formatCampaignType(campaign))
            } else {
              spuArr[index].tags = [this.formatCampaignType(campaign)]
            }
          }
        })
        cb && cb(spuArr)
      })
    },
    transformTags(sourceTags) {
      const tagMap = new Map([
        ['1', '单品'],
        ['2', '满减'],
        ['3', '满折'],
        ['4', '特价'],
        ['5', '满包邮'],
        ['6', '赠品'],
        ['7', '捆绑'],
        ['8', '满送'],
      ])
      return sourceTags.map(item => tagMap.get(item))
    },
    formatCampaignType(campaign) {
      let result = ''
      switch (campaign['__typename']) {
        case MARKETING_TYPE.PINTUAN.type:
          if (campaign.pintuanType === 'NORMAL') {
            result = '多人拼团'
          } else if (campaign.pintuanType === 'CASH_BACK') {
            result = '返现拼团'
          }
          break
        case MARKETING_TYPE.SECKILL.type:
          result = '秒杀'
          break
        case MARKETING_TYPE.BARGAIN.type:
          result = '砍价'
          break
        case MARKETING_TYPE.LIMITTIMEDISCOUNTS.type:
          result = '限时折扣'
          break
        case MARKETING_TYPE.STEPPEDGROUPBUY.type:
          result = '阶梯团购'
          break
        case MARKETING_TYPE.PACKBUY.type:
          result = '打包一口价'
          break
        case MARKETING_TYPE.REDUCEPRICEBUY.type:
          result = '降价拍'
          break
      }
      return result
    },
    getProductList(isLoadMore) {
      let data = this.createParam()
      getItemListbyConditionsV1(data)
        .then(res => {
          if (res.content.data) {
            this.getInfoByCode(res.content.data, result => {
              let _productList
              if (isLoadMore) {
                _productList = this.data.productListData || []
                _productList = _productList.concat(result)
              } else {
                _productList = result || []
              }
              this.setData({
                productListData: _productList,
                listLoading: false,
                moreLoading: false,
              })
            })
            if (res.content.count < data.page.size) {
              this.setData({ noMore: true })
            }
          } else {
            this.setData({
              listLoading: false,
              moreLoading: false,
              productListData: isLoadMore ? this.data.productListData : [],
              noMore: true,
            })
          }
          wx.stopPullDownRefresh()
          wx.hideNavigationBarLoading()
          this.setData({
            showReloadBtn: false,
          })
        })
        .catch(err => {
          wx.stopPullDownRefresh()
          wx.hideNavigationBarLoading()
          this.setData({
            listLoading: false,
            showReloadBtn: true,
            moreLoading: false,
          })
          console.error('/getItemListbyConditionsV1', err)
        })
    },
    onReachBottom(e) {
      if (this.data.noMore) {
        return
      }
      this.setData({
        listLoading: false,
        moreLoading: true,
      })
      this.getProductList(true)
    },
    onPullDownRefresh() {
      this.setData({
        lastPage: 1,
        noMore: false,
      })
      wx.showNavigationBarLoading()
      this.getProductList()
    },
    updateSearch({ detail }) {
      let value = detail ? detail.value : ''
      this.setData({
        searchText: value,
      })
    },
    confirmSearch({ detail }) {
      let value = detail ? detail.value : ''
      this.setData({
        searchText: value,
        noMore: false,
      })
      this.initLoad()
    },
    clearValue() {
      this.setData(
        {
          searchText: '',
          lastPage: 1,
        },
        () => {
          this.getProductList()
        }
      )
    },
    addShopCart({ currentTarget: { dataset } }) {
      // 传入 spuCode 门店code 获取商品详情
      this.selectComponent('#cart-container').showCart({
        spuCode: dataset.code,
        storeCode: this.data.storeCode,
      })
    },
    onCartCancel() {
      this.selectComponent('#cart-container').clearAttributeStatus()
      this.setData({
        showCart: false,
      })
    },
    handleCartChange(data) {
      this.setData({
        showCart: data.detail,
      })
    },
    urlFactory(data) {
      let url = ''
      let campaign = data.campaign
      switch (campaign.__typename) {
        case MARKETING_TYPE.SECKILL.type:
          url = `/honghu/pages/seckill/detail/index?scene=${campaign.code}`
          break
        case MARKETING_TYPE.BARGAIN.type:
          url = `/honghu/pages/bargain/detail/index?scene=${campaign.code}`
          break
        case MARKETING_TYPE.LIMITTIMEDISCOUNTS.type:
          url = `/honghu/pages/discount/pdp/index?scene=${data.code}`
          break
        case MARKETING_TYPE.STEPPEDGROUPBUY.type:
          url = `/honghu/pages/steppedGroupBuy/pdp/index?scene=${campaign.code}`
          break
        case MARKETING_TYPE.PINTUAN.type:
          if (campaign.pintuanType === 'NORMAL') {
            url = `/sub/Commodity/pages/pdp/pdp?spuCode=${data.code}`
          } else if (campaign.pintuanType === 'CASH_BACK') {
            url = `/honghu/pages/pintuanCashBack/pdp/index?scene=${data.code}`
          }
          break
        case MARKETING_TYPE.PACKBUY.type:
          url = `/honghu/pages/packBuy/pdp/index?scene=${data.code}`
          break
        case MARKETING_TYPE.REDUCEPRICEBUY.type:
          url = `/honghu/pages/reducePriceAuction/pdp/index?scene=${
            campaign.code
          }`
      }
      return url
    },
    goPdp({ currentTarget: { dataset } }) {
      const { store, item } = dataset
      if (item.campaign) {
        let url = this.urlFactory(item)
        app.router.navigateTo(url)
      } else {
        const query = queryString({
          storeId: store ? store.storeId : '',
          storeCode: store ? store.storeCode : '',
          spuCode: item.spuCode || item.code || '',
          src:
            item.pic ||
            (item.itemImageList && item.itemImageList[0].picUrl) ||
            '',
        })
        app.router.navigateTo(`/sub/Commodity/pages/pdp/pdp?${query}`)
      }
    },
  },
})
