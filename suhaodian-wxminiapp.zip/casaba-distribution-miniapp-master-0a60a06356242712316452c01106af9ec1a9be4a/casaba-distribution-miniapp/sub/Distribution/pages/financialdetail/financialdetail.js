const app = getApp()

Page({
  data: {
    tabs: [
      {
        text: '已结算',
        id: 3,
      },
      {
        text: '入账中',
        id: 1,
      },
      {
        text: '待确认',
        id: 0,
      },
    ],
    idx: 3,
    listDeatil: [],
    userId: '',
  },
  onLoad(options) {
    this.setData({ userId: options.userId })
    this.queryDetail(this.data.idx)
  },
  bindToggle(e) {
    let index = e.currentTarget.dataset.id
    this.setData({ idx: index })
    this.queryDetail(index)
  },
  queryDetail(id) {
    let $this = this
    let data = {
      userId: $this.data.userId,
      status: id,
    }
    app.https({
      method: 'POST',
      url: '/income/getIncomeDetail',
      data: data,
      header: {
        xAuthToken: app.globalData.xAuthToken,
      },
      success: function(res) {
        const listDeatil = res.data.data
        $this.setData({ listDeatil: listDeatil })
      },
      fail: function(res) {
        console.log('res', res)
      },
    })
  },
})
