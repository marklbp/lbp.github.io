import CarType from './CarType';

export default CarType;
