/* global Component */
Component({
  externalClasses: ['u-class'],
  relations: {
    '../grid/index': {
      type: 'parent',
    },
    // '../grid/icon': {
    //   type: 'child'
    // }
  },
  data: {
    width: '33.33%',
  },
})
