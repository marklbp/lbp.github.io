import EntryTrack from './EntryTrack';

export default EntryTrack;
