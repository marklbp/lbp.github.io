import { queryOrderOpenDetail } from '../../../../api/index'
import {
  padTime,
  getRemainingTime,
} from '../../../../static/utils/remainingTime'
import pay from '../../../../filter/pay'
import apiReload from '../../../../utils/reload'
const app = getApp()

Page({
  data: {
    orderId: '',
    autoCancelRule: false,
    orderInfo: null,
    enableShowView: false,
    remainingTime: '',
  },
  onLoad: function(options) {
    this.setData({
      orderId: options.orderId,
    })
    this.handlequeryOrderOpenDetail(options)
  },
  updateRemainingTime(scheduleCancelTime) {
    scheduleCancelTime = scheduleCancelTime.replace(/-/g, '/')
    this.setData({
      remainingTime: getRemainingTime(scheduleCancelTime, 'BY_DAY'),
      enableShowView: true,
    })
    this.data.remainingTimer = setInterval(() => {
      this.setData({
        remainingTime: getRemainingTime(scheduleCancelTime, 'BY_DAY'),
      })
    }, 1000)
  },
  handlequeryOrderOpenDetail(options) {
    let $this = this
    if (!app.globalData.xAuthToken) {
      apiReload.getOpenIdAndAuthParam(app).then(() => {
        this.queryOrderOpenDetailfn(options)
          .then(res => {
            if (res.head.code === '0') {
              if (res.body.scheduleCancelTime === '9999-12-31 23:59:59') {
                $this.setData({
                  autoCancelRule: false,
                  enableShowView: true,
                })
              } else {
                $this.setData({
                  autoCancelRule: true,
                })
                const scheduleCancelTime = this.getRemainingTimeTarget(res.body)
                $this.updateRemainingTime(scheduleCancelTime)
              }
              $this.setData({
                orderInfo: res.body,
              })
            } else {
              $this.setData({
                autoCancelRule: false,
                enableShowView: true,
              })
            }
          })
          .catch(e => {
            $this.setData({
              autoCancelRule: false,
              enableShowView: true,
            })
          })
      })
    } else {
      this.queryOrderOpenDetailfn(options)
        .then(res => {
          if (res.head.code === '0') {
            if (res.body.scheduleCancelTime === '9999-12-31 23:59:59') {
              $this.setData({
                autoCancelRule: false,
                enableShowView: true,
              })
            } else {
              $this.setData({
                autoCancelRule: true,
              })
              const scheduleCancelTime = this.getRemainingTimeTarget(res.body)
              $this.updateRemainingTime(scheduleCancelTime)
            }
            $this.setData({
              orderInfo: res.body,
            })
          } else {
            $this.setData({
              autoCancelRule: false,
              enableShowView: true,
            })
          }
        })
        .catch(e => {
          $this.setData({
            autoCancelRule: false,
            enableShowView: true,
          })
        })
    }
  },
  getRemainingTimeTarget(order) {
    let scheduleCancelTime = order.scheduleCancelTime

    // 营销订单特殊处理。 所有营销订单 scheduleCancelTime 固定为 'scheduleCancelTime'， 支付结束倒计时固定为五分钟
    if (scheduleCancelTime === '2999-10-10 00:00:00' && order.orderDate) {
      const orderDate = new Date(order.orderDate.replace(/-/g, '/'))
      scheduleCancelTime = new Date(
        orderDate.getTime() + 5 * 60 * 1000
      ).toUTCString()
    }
    return scheduleCancelTime
  },
  queryOrderOpenDetailfn(options) {
    return queryOrderOpenDetail(
      {
        orderId: options.orderId,
        tenantCode: app.globalData.tenantCode,
      },
      {
        xAuthToken: app.globalData.xAuthToken,
      }
    )
  },
  getReaminingTime(start, end) {
    start = start.replace(/-/g, '/')
    end = end.replace(/-/g, '/')
    const result = {
      day: '00',
      hours: '00',
      minutes: '00',
      seconds: '00',
    }
    const originTime = new Date(1970, 0, 1, 0, 0, 0, 0)
    const endTime = new Date(end)
    const startTime = new Date(start)
    let differenceTimestamp = endTime - startTime
    if (differenceTimestamp < 0) {
      differenceTimestamp = 0
    }
    const differenceTime = new Date(parseInt(differenceTimestamp))
    differenceTime.setHours(differenceTime.getHours() - 8)
    result.day =
      differenceTime.getDate() -
      originTime.getDate() +
      (differenceTime.getMonth() - originTime.getMonth()) * 30
    result.hours = differenceTime.getHours() - originTime.getHours()
    result.minutes = differenceTime.getMinutes() - originTime.getMinutes()
    result.seconds = differenceTime.getSeconds() - originTime.getSeconds()
    this.setData({
      reaminingTime: {
        day: padTime(result.day),
        hours: padTime(result.hours),
        minutes: padTime(result.minutes),
        seconds: padTime(result.seconds),
      },
      enableShowView: true,
    })
  },
  orderOpen() {
    let orderId = this.data.orderId
    app.router.navigateTo(
      '/sub/Order/pages/orderdetail/orderdetail?id=' + orderId
    )
  },
  payAgain() {
    let $this = this
    this.queryOrderOpenDetailfn({
      orderId: this.data.orderId,
    })
      .then(res => {
        if (res.head.code === '0') {
          pay(res.body)
        } else {
          $this.setData({
            autoCancelRule: false,
            enableShowView: true,
          })
        }
      })
      .catch(e => {
        $this.setData({
          autoCancelRule: false,
          enableShowView: true,
        })
      })
  },
})
