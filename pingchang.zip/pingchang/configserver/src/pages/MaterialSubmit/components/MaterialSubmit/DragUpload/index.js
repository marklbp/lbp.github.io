import DragUpload from './DragUpload.jsx';

export default DragUpload;