import ApprovalBox from './ApprovalBox';

export default ApprovalBox;
