const app = getApp()
Component({
  properties: {
    content: {
      type: Object,
      value: null,
    },
    placeholder: {
      type: String,
      value: '搜索...',
    },
  },
  methods: {
    handleToSearchPage() {
      app.router.navigateTo('/sub/Base/pages/searchdetail/searchdetail')
    },
  },
})
