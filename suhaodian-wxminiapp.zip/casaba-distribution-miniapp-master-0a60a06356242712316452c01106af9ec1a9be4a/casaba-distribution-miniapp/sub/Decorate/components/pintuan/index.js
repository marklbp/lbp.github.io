import hh from '../../../../honghuStore/request'
import { PINTUAN_CAMPAIGN_STATUS as STATUS } from '../../../../honghuStore/constant'
import { getPintuanDetail } from './gql'

Component({
  properties: {
    cid: Number,
    ctype: String,
    commodityList: {
      type: Array,
      value: [],
    },
    mode: {
      type: String,
      value: 'listLineTwo',
    },
    content: {
      type: Object,
      value: null,
      observer: function(newVal) {
        this.setData({
          content: newVal,
        })
      },
    },
  },
  data: {
    _commodityList: [],
    loading: false,
    done: false,
  },
  attached() {
    this.setData({ loading: true, done: false })
    this.initLoad(this.data.commodityList)
  },
  methods: {
    initLoad(cacheProductList) {
      const {
        spellActityType,
        spellGoodsType,
        autoSelectsort,
        autoSelectNum,
        autohideFailAct,
      } = this.data.content
      const { id: code } = spellActityType
      hh(getPintuanDetail({ code })).then(res => {
        // step1: 获取后台配置的拼团活动ID(currentPintuanId), 拿到鸿鹄拼团接口返回的活动列表(pintuanList)
        const pintuanList =
          res.data.shop.ongoingCampaignProductsConnection.edges
        if (pintuanList.length === 0) {
          this.setData({
            loading: false,
            done: true,
            _commodityList: [],
          })
          return
        }
        if (spellGoodsType === '2') {
          // 后台配置的自动选择
          // step2. 过滤出spu下最低拼团价格的sku
          let finalProductList = this.spuGroup(pintuanList)
          // 然后根据后台排序规则进行商品排序
          this.sortProduct(finalProductList, autoSelectsort)
          // step3. 根据是否显示已售罄规则过滤商品
          // step4. 根据数量规则显示相应的数量
          this.showProduct(
            this.filterSoldOut(finalProductList, autohideFailAct),
            autoSelectNum
          )
        } else {
          // 后台配置的手动选择
          const _pintuanList = pintuanList
            .map(p => {
              for (const cp of cacheProductList) {
                if (cp.goodsInfo.code === p.node.spuCode) {
                  const skus = p.node.skus
                  const _skus = skus.filter(
                    s => s.code === cp.goodsInfo.currentSkuCode
                  )
                  p.node.skus = _skus
                  return p
                }
              }
            })
            .filter(f => !!f)
          let finalProductList = this.spuGroup(_pintuanList)
          this.sortProduct(finalProductList, autoSelectsort)
          this.showProduct(
            this.filterSoldOut(finalProductList, autohideFailAct),
            -1
          )
        }
      })
    },
    pubRefresh() {
      this.setData({ done: false })
      let _commodityList = this.data._commodityList
      if (this.data.commodityList.length) {
        _commodityList = this.data.commodityList
      }
      this.initLoad(_commodityList)
    },
    fixIOSDate(date) {
      return date.replace(/-/g, '/')
    },
    spuGroup(productList) {
      const final = productList.map(p => {
        const skus = p.node.skus
        const productSkus = p.node.campaign.productSkus
        const _skus = skus
          .map(sku => {
            for (const pSku of productSkus) {
              let _matchSku
              if (sku.code === pSku.code) {
                const netqty = Math.min(sku.netqty, pSku.netqty)
                _matchSku = {
                  listPrice: pSku.salePrice,
                  salePrice: pSku.pintuanPrice,
                  netqty,
                }
                return _matchSku
              }
            }
          })
          .filter(f => !!f)
          .sort((a, b) => a.salePrice - b.salePrice)[0]
        return {
          code: p.node.campaign.code,
          status: p.node.campaign.status,
          limitNumber: p.node.campaign.limitNumber,
          picUrl: p.node.pics[0].picUrl,
          title: p.node.name,
          listTime: p.node.listTime,
          spuCode: p.node.spuCode,
          ..._skus,
        }
      })
      return final
    },
    sortProduct(productList, type) {
      if (type === 'newShelve') {
        productList.sort(
          (a, b) =>
            new Date(this.fixIOSDate(b.listTime)) -
            new Date(this.fixIOSDate(a.listTime))
        )
      } else if (type === 'priHighToLow') {
        productList.sort((a, b) => b.salePrice - a.salePrice)
      } else if (type === 'priLowToHigh') {
        productList.sort((a, b) => a.salePrice - b.salePrice)
      }
    },
    filterSoldOut(productList, isHide, status, limitNumber) {
      let filteredProduct = []
      if (isHide) {
        filteredProduct = productList.filter(
          p => p.netqty && p.status === STATUS.STARTED
        )
      } else {
        filteredProduct = productList.filter(
          p => p.status === STATUS.STARTED || p.status === STATUS.ENDED
        )
      }
      return filteredProduct
    },
    showProduct(filteredProduct, limitShowNum) {
      this.setData({
        loading: false,
        done: true,
        _commodityList: ~limitShowNum
          ? filteredProduct.splice(0, limitShowNum).map(p => ({
            goodsInfo: p,
          }))
          : filteredProduct.map(p => ({ goodsInfo: p })),
      })
    },
    handleViewMore() {
      const { path } = this.content
      if (path) {
        this.triggerEvent('jump', { url: path })
      }
    },
    handleJump({ currentTarget }) {
      const { spuCode, picUrl } = currentTarget.dataset.item
      if (spuCode) {
        this.triggerEvent('jump', {
          url: `/sub/Commodity/pages/pdp/pdp?spuCode=${spuCode}&src=${picUrl}`,
        })
      }
    },
  },
})
