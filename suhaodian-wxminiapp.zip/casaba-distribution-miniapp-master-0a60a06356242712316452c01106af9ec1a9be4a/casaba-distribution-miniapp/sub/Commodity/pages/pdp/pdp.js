import { parseUrlQuery } from '../../../../utils/util'
import {
  getItemDetailV1,
  getQuotaQualification,
  queryAddress,
  queryEffectiveDay,
} from '../../../../api/index'
import apiReload from '../../../../utils/reload'
/**
 * behavior：https: //developers.weixin.qq.com/miniprogram/dev/framework/custom-component/behaviors.html
 * 根据功能模块切分文件
 * 1. 优惠券码
 * 2. 活动
 * 3. 拼团
 * 4. 分享
 * 5. 购物车
 * 6. 分销
 * 记得写好注释
 */
import queryString from '../../../../utils/query-string'
import couponBehaivor from './behavior/coupon'
import activityBehaivor from './behavior/activity'
import pintuanBehaivor from './behavior/pintuan'
import shareBehaivor from './behavior/share'
import shoppingCartBehaivor from './behavior/shoppingCart'
import distributionBehaivor from './behavior/distribution'
import serviceBehaivor from './behavior/service'

const app = getApp()

Component({
  behaviors: [
    couponBehaivor,
    activityBehaivor,
    pintuanBehaivor,
    shareBehaivor,
    shoppingCartBehaivor,
    distributionBehaivor,
    serviceBehaivor,
  ],
  properties: {
    // url？后面的参数可以直接写在这里获取
    spuCode: String,
    src: String,
    scene: String,
    pintuanTeamId: String,
    sharerOpenId: String,
    sharerDistUser: String,
    sharerName: String,
    storeId: String,
    storeCode: String,
    query: {
      type: String,
      observer: function(val) {
        let options = parseUrlQuery(val)
        if (options) {
          const scene = options.scene && decodeURIComponent(options.scene).split
          const placeholderImage = options.src
          wx.setStorageSync('sharerOpenId', options.sharerOpenId)
          console.log('分享人options', options)
          if (scene) {
            options.shareString = scene
          }
          Object.assign(options, {
            isAuthorized: app.honghuStore.isAuthorized,
            placeholderImage: placeholderImage || '',
            sharerDistUser: options.sharerDistUser || 0,
            sharerName: options.sharerName || '',
            sharerOpenId: options.sharerOpenId || '',
            shopStyle: {
              color: app.globalData.shopStyle[0],
              selectedColor: app.globalData.shopStyle[1],
              auxiliaryColor: app.globalData.shopStyle[2],
            },
          })
          this.setData(options)
          this.pollingData()
          !!options.spuCode && this.bindGetProductDetail()
        }
      },
    },
    tap: {
      type: Number,
      observer: function(val) {
        wx.setNavigationBarTitle({
          title: '商品详情',
        })
        if (val === 1) {
          this.pollingData()
        }
      },
    },
    component: {
      type: Boolean,
      value: false,
    },
  },
  data: {
    day: 1,
    isShowReloadBtn: false,
    hookLayer: false,
    backHome: false,
    isNormal: false,
    clickAuthBtnType: '',
    refusedToAuth: true,
    swiperData: [],
    title: '',
    subtitle: '',
    currentSelectSku: null,
    listPrice: null,
    salePrice: null,
    listPriceCopy: null,
    salePriceCopy: null,
    brandcode: null,
    brandname: null,
    categorycode: null,
    categoryname: null,
    spuCode: null,
    skucode: '',
    skucodeBackup: null,
    pintuanSkucode: null,
    netqty: -1,
    netqtyBackup: -1,
    pintuanNetqty: -1,
    isShowMask: false,
    countData: 1,
    countDataBackup: -1,
    pintuanCountData: -1,
    saleStatus: '',
    fixedListTime: '',
    soldOut: false,
    pullOffShelves: false,
    ruleData: {
      brand: '',
    },
    jscdscript: '',
    isHtmlTag: true,
    isNotTagHasImg: false,
    skuList: [],
    skuListMap: [],
    skuListMapBackup: [],
    pintuanSkuListMap: [],
    pleaseSelectSku: [],
    currentSelectAttrArray: [],
    currentSelectAttrMapBackup: [],
    pintuanCurrentSelectAttrMap: [],
    attrSaleList: [],
    attrSaleListBackup: [],
    sizeData: [],
    currentSizeValue: null,
    pic: null, // 规则上面的图片skuListMap
    picCopy: null,
    descriptionpic: null,
    timer: null,
    placeholderImage: '',
    dataLoaded: false,
    shopStyle: {
      color: '#fff',
      selectedColor: '#333333',
      auxiliaryColor: '#F4766E',
    },
    priceObj: null,
    listPriceObj: null,
    currentType: 0,
    recProducts: true, // 是否显示推荐商品
    showSaleNum: false,
    isShowSocialTeamModal: false,
    socialTeamBlockTopHeight: 0,
    quotaInfo: null,
    disabledAttrCode: [],
    isSharing: false,
    attrSaleNameList: [],
    shareProduct: {},
    goodsSharePlugin: false,
    isShowPintuanRule: false,
  },
  pageLifetimes: {
    show() {
      if (!app.globalData.openid) {
        apiReload
          .getOpenId(app)
          .then(res => {
            this.handleGetQuotaQualification()
          })
          .catch(() => {
            if (!app.globalData.openid) {
              this.setData({ isShowReloadBtn: true })
            }
          })
      } else {
        this.handleGetQuotaQualification()
      }
    },
  },
  attached() {
    this.queryEffectiveDays(() => {
      if (app.globalData.customSeting) {
        this.setData({
          recProducts: app.globalData.customSeting.recProducts === '1',
          showSaleNum: app.globalData.customSeting.salesVolume === '1',
        })
      }
      this.setData({
        distUser: wx.getStorageSync('distUser'),
      })
      if (!this.data.component) {
        wx.setNavigationBarTitle({
          title: '商品详情',
        })
        const options = this.data
        const scene = options.scene && decodeURIComponent(options.scene)
        const placeholderImage = options.src
        options.backHome = getCurrentPages().length === 1
        wx.setStorageSync('sharerOpenId', options.sharerOpenId)
        Object.assign(options, {
          isAuthorized: app.honghuStore.isAuthorized,
          placeholderImage: placeholderImage || '',
          sharerDistUser: options.sharerDistUser || 0,
          sharerName: options.sharerName || '',
          sharerOpenId: options.sharerOpenId || '',
          shopStyle: {
            color: app.globalData.shopStyle[0],
            selectedColor: app.globalData.shopStyle[1],
            auxiliaryColor: app.globalData.shopStyle[2],
          },
          goodsSharePlugin: app.globalData.goodsSharePlugin || false,
        })
        options.pintuanTeamId =
          options.pintuanTeamId && decodeURIComponent(options.pintuanTeamId)
        if (options.pintuanTeamId) {
          options.pintuanActionButtonText = '参与拼团'
        }
        if (scene) {
          options.shareString = scene
          app.globalData.shareAccountId = scene.split('_')[0]
        }
        this.setData(options)
        this.pollingData(options.pintuanTeamId)
        !!options.spuCode && this.bindGetProductDetail(options.pintuanTeamId)
      }
    })
  },
  ready() {},
  detached() {
    clearInterval(this.data.timer)
    wx.removeStorageSync('sharerOpenId')
    this.setData({
      timer: null,
    })
    console.log(app.globalData.customSeting)
  },
  methods: {
    on_error(err) {
      console.log('分享错误', err)
    },
    handleGetQuotaQualification() {
      getQuotaQualification({
        openId: app.globalData.openid,
        spuCode: this.data.spuCode,
        tenantCode: app.globalData.tenantCode,
      })
        .then(res => {
          if (res.code === '0') {
            this.setData({
              quotaInfo: res.data,
            })
          } else {
            console.log('限购请求失败')
          }
        })
        .catch(e => {
          console.log('限购', e)
        })
    },
    pollingData(pintuanTeamId) {
      if (this.data.timer) {
        return
      }
      let pollingCount = 0
      const timer = setInterval(() => {
        if (
          !app.globalData.openid ||
          !app.globalData.unexUserToken ||
          !app.globalData.accountId
        ) {
          pollingCount++
          if (pollingCount > 70) {
            clearInterval(timer)
            this.setData({
              timer: null,
            })
            apiReload
              .getOpenIdAndToken(app)
              .then(res => {
                apiReload.getAuthParam(app, app.globalData.openid).then(() => {
                  this.data.shareString &&
                    this.getSpuCodeByProductId(
                      this.data.shareString,
                      pintuanTeamId,
                      true
                    )
                  this.data.spuCode &&
                    this.getProductIdBySpuCode(
                      app.globalData.accountId,
                      this.data.spuCode,
                      pintuanTeamId,
                      true
                    )
                })
                this.getShopCartProductCount()
                this.handleGetQuotaQualification()
                this.setData({
                  distUser: app.globalData.distUser,
                  sameUser: app.globalData.openid === this.data.sharerOpenId,
                })
              })
              .catch(() => {
                if (!app.globalData.accountId) {
                  this.setData({ isShowReloadBtn: true })
                }
                console.error('获取openid或unexusertoken或accountId出错')
              })
          }
        } else {
          clearInterval(timer)
          this.data.shareString &&
            this.getSpuCodeByProductId(
              this.data.shareString,
              pintuanTeamId,
              true
            )
          this.data.spuCode &&
            this.getProductIdBySpuCode(
              app.globalData.accountId,
              this.data.spuCode
            )
          this.getShopCartProductCount()
          this.handleGetQuotaQualification()
          this.setData({
            distUser: this.data.distUser || wx.getStorageSync('distUser'),
            sameUser: app.globalData.openid === this.data.sharerOpenId,
            timer: null,
          })
        }
      }, 100)
      this.setData({
        timer: timer,
      })
    },
    maxOfArray(arr) {
      return {
        max: Math.max.apply(Math, arr),
        min: Math.min.apply(Math, arr),
      }
    },
    initDisabledSku() {
      const skuList = this.data.skuList
      if (skuList.length === 1) {
        return
      }
      const disabledAttrCode = []
      skuList.forEach(sku => {
        if (sku.netqty === 0) {
          const target = sku.attrSaleList.map(item => {
            return {
              code: item.code,
              skucode: item.attributeValueList[0].code,
            }
          })
          disabledAttrCode.push(target)
        }
      })
      // 库存为 0 的sku组合
      console.log(disabledAttrCode)
      this.setData({
        disabledAttrCode: disabledAttrCode,
      })
    },
    bindGetProductDetail(pintuanTeamId) {
      Promise.all([
        getItemDetailV1({
          tenantCode: app.globalData.tenantCode,
          spuCode: this.data.spuCode,
          storeCode: this.data.storeCode,
        }),
        this.getProductDetailFromHonghu(this.data.spuCode, pintuanTeamId),
      ])
        .then(response => {
          const res = response[0]
          const honghuCampaign = response[1]
          if (res.code === -1) {
            // 商品不存在 或其他原因
            wx.showToast({
              title: res.errorMsg,
              icon: 'none',
              duration: 2000,
            })
            const route = getCurrentPages()
            setTimeout(() => {
              if (route.length === 1) {
                app.router.navigateTo('/pages/home/home')
              } else {
                app.router.navigateBack()
              }
            }, 2000)
            // wx.showModal({
            //   title: '',
            //   content: res.errorMsg,
            //   showCancel: false,
            //   confirmColor: '#333',
            //   success: () => {
            //     const route = getCurrentPages()
            //     if (route.length === 1) {
            //       app.router.navigateTo('/pages/home/home')
            //     } else {
            //       app.router.navigateBack()
            //     }
            //   },
            // })
            return
          }
          if (!res.data) {
            wx.showModal({
              title: '',
              content: res.errorMsg || res.msg,
              showCancel: false,
              confirmColor: '#333',
              success: () => {
                const route = getCurrentPages()
                if (route.length === 1) {
                  app.router.navigateTo('/pages/home/home')
                } else {
                  app.router.navigateBack()
                }
              },
            })
            return
          }

          let pullOffShelves = Number(res.data.saleStatus) === 2
          let result = res.data
          let skuList = result.skuList
          let attrSaleList = result.attrSaleList

          skuList = this.formatSkuAttrSaleList(skuList)
          this.updateHonghuCampaignProduct(
            honghuCampaign,
            skuList,
            pintuanTeamId
          )
          let allNetQty = this.calculationTotalInventory(skuList)
          let pleaseSelectSku = attrSaleList.map(
            item => item.attributeFrontName
          )
          let soldOut = result.skuList.every(item => item.netqty === 0)
          let sizeList =
            attrSaleList && result.attrSaleList[0].attributeValueList
          let swiperData = result.itemImageList
          let pic = swiperData && swiperData[0].picUrl
          let brandcode = result.brand.code
          let brandname = result.brand.name
          let categorycode = result.categoryList
            ? result.categoryList[result.categoryList.length - 1].categoryPath
            : ''
          let categoryname = result.categoryList
            ? result.categoryList[0].name
            : ''
          let spuCode = result.code
          // let skucode = result.skuList[0].code
          let priceList = result.skuList.map(i => i.salePrice)
          let listPriceList = result.skuList.map(j => j.listPrice)
          let priceObj = this.maxOfArray(priceList)
          let listPriceObj = this.maxOfArray(listPriceList)
          let descriptionpic = ''
          let pattern = /<("[^"]*"|'[^']*'|[^'">])*?>/
          let isHtmlTag = 0
          let isNotTagHasImg = 0
          let jscdscript = ''
          let regResult = pattern.exec(result.description)
          let htmlTagStr = '<(h1|h2|h3|h4|h5|p|div|ul|ol|li|table)'
          let formatHtmlPattern = new RegExp(htmlTagStr, 'g')
          if (regResult) {
            if (/<blockquote/.test(result.description)) {
              result.description = result.description.replace(
                /blockquote/g,
                'div'
              )
              if (/<figure/.test(result.description)) {
                isHtmlTag = 1
                jscdscript = result.description
                  .replace(/figure/g, 'div')
                  .replace(
                    /<img/gi,
                    `<img style="max-width:100%;display:block;margin:0 auto;" `
                  )
                  .replace(formatHtmlPattern, function(a, b) {
                    if (b === 'ul' || b === 'ol' || b === 'li') {
                      return `${a} style="display: block;"`
                    }
                    return `${a}`
                  })
              }
            } else if (/<figure/.test(result.description)) {
              isHtmlTag = 1
              jscdscript = result.description
                .replace(/figure/g, 'div')
                .replace(
                  /<img/gi,
                  `<img style="max-width:100%;display:block;margin:0 auto;" `
                )
                .replace(formatHtmlPattern, function(a, b) {
                  if (b === 'ul' || b === 'ol' || b === 'li') {
                    return `${a} style="display: block;"`
                  }
                  return `${a}`
                })
            } else if (/(<|\/>)/.test(result.description)) {
              isHtmlTag = 1
              jscdscript = result.description
                .replace(/figure/g, 'div')
                .replace(
                  /<img/gi,
                  `<img style="max-width:100%;display:block;margin:0 auto;" `
                )
                .replace(formatHtmlPattern, function(a, b) {
                  if (b === 'ul' || b === 'ol' || b === 'li') {
                    return `${a} style="display: block;`
                  }
                  return `${a}`
                })
            } else {
              descriptionpic = result.description
                .replace(/<p>/g, '')
                .replace(/<\/p>/g, '')
                .replace(/&nbsp;/g, '')
                .split(',')
              if (
                descriptionpic &&
                descriptionpic.some(item => /https:\/\//.test(item))
              ) {
                isNotTagHasImg = 1
              }
            }
          } else {
            descriptionpic = result.description && result.description.split(',')
            if (
              descriptionpic &&
              descriptionpic.some(item => /https:\/\//.test(item))
            ) {
              isNotTagHasImg = 1
            }
          }
          jscdscript = jscdscript
            .replace(/<mark/g, '<span')
            .replace(/<\/mark>/g, '</span>')
            .replace(/<p/g, '<p class="richText-p"')
            .replace(/<h2/g, '<h2 class="richText-h2"')
            .replace(/<h3/g, '<h3 class="richText-h3"')
            .replace(/<h4/g, '<h4 class="richText-h4"')
          if (Array.isArray(descriptionpic)) {
            descriptionpic = descriptionpic.filter(
              item => !Object.is(item, '&nbsp;')
            )
          }
          let sizeData = []
          let commission = result.commission
          this.setData({
            priceObj: priceObj,
            listPriceObj: listPriceObj,
            commission: commission,
            listPrice: result.listPrice,
            salePrice: result.salePrice,
            listPriceCopy: result.listPrice,
            salePriceCopy: result.salePrice,
          })
          this.getSaleNum(result.skuList[0].code)
          this.getActivityList(result)
          this.getCouponList(result)
          sizeList &&
            sizeList.forEach(item => {
              sizeData.push(item)
            })
          const urls = swiperData ? swiperData[0].picUrl : ''
          // 下载头图并绘制分享好友图
          this.downloadHeadImg(urls).then(res => {
            const headImgUrl = res.tempFilePath
            wx.getImageInfo({
              src: headImgUrl,
              success: imgInfo => {
                this.drawShareWeChatImage(headImgUrl, imgInfo)
              },
            })
          })
          skuList = skuList.map(item => {
            return {
              ...item,
              attrCodes: item.attrSaleList.map(attr => {
                return attr.attributeValueList[0].code
              }),
            }
          })
          let query = queryString({
            spuCode: spuCode,
            src: pic,
            storeCode: this.data.storeCode || '',
            storeId: this.data.storeId || '',
          })
          let currentPath = `/sub/Commodity/pages/pdp/pdp?${query}`
          let shareProduct = {
            item_code: result.code,
            title: result.title,
            desc: result.title, // description
            category_list: result.categoryList.map(item => item.name),
            image_list: result.itemImageList
              ? result.itemImageList.map(item => item.picUrl)
              : [],
            src_mini_program_path: currentPath,
            brand_info: {
              name: '',
              logo: '',
              phone: '',
            },
            sku_list: skuList.map(item => {
              return {
                sku_id: item.code,
                price: (item.salePrice >>> 0) * 100, // 现价 无符号整数
                original_price: (item.listPrice >>> 0) * 100, // 原价 无符号整数
                status: soldOut ? 3 : +result.saleStatus, // item.status
                sku_attr_list: item.attrSaleList.map(skuattr => {
                  return {
                    name: skuattr.attributeFrontName,
                    value:
                      skuattr.attributeValueList[0].attributeValueFrontName,
                  }
                }),
              }
            }),
          }
          console.log('haowushangp', JSON.stringify(shareProduct))
          this.setData({
            isRequestingTeamInfo: false,
            dataLoaded: true,
            title: result.title,
            subtitle: result.subTitle ? result.subTitle : '',
            listPrice: result.listPrice,
            salePrice: result.salePrice,
            listPriceCopy: result.listPrice,
            soldOut: soldOut,
            pullOffShelves: pullOffShelves,
            saleStatus: result.saleStatus,
            fixedListTime: result.fixedListTime,
            brandcode: brandcode,
            categorycode: categorycode,
            categoryname: categoryname,
            brandname: brandname,
            spuCode: spuCode,
            skucode: '',
            commission: commission,
            descriptionpic: descriptionpic || '',
            jscdscript: jscdscript,
            isHtmlTag: isHtmlTag,
            isNotTagHasImg: isNotTagHasImg,
            ruleData: {
              brand: result.brand.code,
            },
            pic: pic,
            picCopy: pic,
            swiperData: swiperData,
            skuList: skuList,
            allNetQty: allNetQty,
            allNetQtyBackup: allNetQty,
            attrSaleList: attrSaleList || null,
            attrSaleListBackup: attrSaleList,
            attrSaleNameList: attrSaleList.map(item => {
              return item.attributeFrontName
            }),
            pintuanAttrSaleList: JSON.parse(JSON.stringify(attrSaleList)),
            pleaseSelectSku: pleaseSelectSku,
            sizeData: sizeData,
            currentType: result.type,
            currentSizeValue: sizeData[0]
              ? sizeData[0].attributeValueFrontName
              : '',
            shareProduct: shareProduct,
          })
          queryAddress(
            {},
            {
              unexUserToken: app.globalData.unexUserToken,
            }
          )
            .then(res => {
              this.getFreight(skuList[0]['code'], res)
            })
            .catch(e => {
              // 地址不存在  采用默认运费 5.00
            })
          // 获取当前分类下产品
          this.handleGetItemListbyConditionsV1()
        })
        .catch(err => {
          this.setData({
            isShowReloadBtn: true,
          })
          console.error('商品详情：', err)
        })
    },
    formatSkuAttrSaleList(skus) {
      skus.forEach(sku => {
        let attrCodes = []
        sku.attrSaleList.forEach(skuAttrItem => {
          attrCodes = attrCodes.concat(
            skuAttrItem.attributeValueList.map(item => item.code)
          )
        })
        sku.formatAttrCode = attrCodes
      })
      return skus
    },
    calculationTotalInventory(skuList) {
      return skuList.reduce((total, item) => {
        return total + item.netqty
      }, 0)
    },
    openSelection() {
      if (this.data.hasPintuanCampaign) {
        return this.handleCreatePintuan()
      }
      this.setData({
        isCreatePintuanAction: false,
        isBuyNow: false,
        isAddCard: false,
        isNormal: true,
        attrSaleList: this.data.attrSaleListBackup,
      })
      this.initDisabledSku()
      this.handleShowSelectionSpec()
    },
    // 默认选中首个 sku
    selectAttrFirst() {
      if (
        this.data.currentSelectSku ||
        (this.data.hasPintuanCampaign && !this.data.isCampaignEnd)
      ) {
        return
      }
      let attrSaleList = this.data.attrSaleList
      // 找到第一个有库存的商品
      const hasNetqty = this.data.skuList.find(s => s.netqty > 0)
      if (hasNetqty) {
        hasNetqty.attrSaleList.forEach((item, index) => {
          const oneIndex = attrSaleList.findIndex(a => a.code === item.code)
          const oneItem = attrSaleList.find(a => a.code === item.code)
          const twoIndex = oneItem
            ? oneItem.attributeValueList.findIndex(
              a => a.code === item.attributeValueList[0].code
            )
            : 0
          this.handleSelectAttr({
            currentTarget: {
              dataset: {
                attributefrontname: item.attributeFrontName,
                attributename:
                  item.attributeValueList[0].attributeValueFrontName,
                code: item.code,
                attrcode: item.attributeValueList[0].code,
                index: oneIndex || 0,
                idx: twoIndex || 0,
                disabled: item.attributeValueList[0].isDisabled,
              },
            },
          })
        })
      }
    },
    handleShowSelectionSpec() {
      const data = this.data
      if (data.soldOut) {
        return
      }
      if (!this.data.attrSaleList) {
        wx.showModal({
          title: '',
          content: '该商品没有设置规格',
          showCancel: false,
          confirmColor: '#333',
        })
        return
      }

      // this.updateSkuView()
      this.setData({
        isShowMask: true,
      })
      // 初始 sku 是否可选
      if (data.isCreatePintuanAction) {
        this.initOptionClickableStatus(
          this.data.pintuanAttrSaleList,
          this.data.pintuanCampaign.productSkus
        )
      } else {
        this.initOptionClickableStatus(
          this.data.attrSaleList,
          this.data.skuList
        )
      }
      setTimeout(() => {
        this.setData({
          hookLayer: true,
        })
      }, 100)
      setTimeout(() => {
        if (data.isCreatePintuanAction) {
          const skuListMap = JSON.parse(
            JSON.stringify(this.data.pintuanSkuListMap)
          )
          this.setData({
            skuListMap,
            netqty: data.pintuanNetqty,
            countData: data.pintuanCountData,
            skucode: data.pintuanSkucode,
            attrSaleList: this.data.pintuanAttrSaleList,
            currentSelectAttrArray: JSON.parse(
              JSON.stringify(this.data.pintuanCurrentSelectAttrMap)
            ),
          })
        }
        if (data.isBuyNow || data.isAddCard || data.isNormal) {
          const skuListMap = JSON.parse(
            JSON.stringify(this.data.skuListMapBackup)
          )
          this.setData({
            skuListMap,
            netqty: data.netqtyBackup,
            countData: data.countDataBackup,
            skucode: data.skucodeBackup,
            attrSaleList: this.data.attrSaleListBackup,
            currentSelectAttrArray: JSON.parse(
              JSON.stringify(this.data.currentSelectAttrMapBackup)
            ),
          })
        }
        this.selectAttrFirst()
        // if (this.data.pintuanCampaign.productSkus) {
        //   this.handleUpdateStatus(
        //     this.data.currentSelectAttrArray,
        //     this.data.attrSaleList,
        //     this.data.pintuanCampaign.productSkus,
        //     this.data.skuList.length
        //   )
        // }
      }, 16)
    },
    updateSkuView() {
      const data = this.data
      let salePriceCopy = data.salePriceCopy
      let netqty = data.netqty
      if (data.isCreatePintuanAction) {
        if (data.currentPintuanCampaignSelectSku) {
          salePriceCopy = data.currentPintuanCampaignSelectSku.price
          netqty = data.currentPintuanCampaignSelectSku.netqty
        } else {
          salePriceCopy = data.minimalPriceSku.price
          netqty = -1
        }
      } else if (data.isBuyNow || data.isAddCard || data.isNormal) {
        if (data.currentSelectSku) {
          salePriceCopy = data.currentSelectSku.salePrice
          netqty = data.currentSelectSku.netqty
        } else {
          salePriceCopy = data.salePrice
          netqty = -1
        }
      }
      this.setData({
        salePriceCopy,
        netqty,
      })
    },
    onSpecCancel() {
      this.setData({
        isShowMask: false,
      })
      this.copyCurrentSelect()
      this.setData({
        isCreatePintuanAction: false,
        isBuyNow: false,
        isAddCard: false,
      })
      setTimeout(() => {
        // 300ms延迟，因为按钮组会突然从两个变成一个
        this.setData({
          isNormal: false,
        })
      }, 200)
    },
    copyCurrentSelect() {
      const data = this.data
      let _attrSaleList = data.attrSaleList
      let pintuanSkuListMap = data.pintuanSkuListMap
      let skuListMapBackup = data.skuListMapBackup
      let pintuanCurrentSelectAttrMap = data.pintuanCurrentSelectAttrMap
      let currentSelectAttrMapBackup = data.currentSelectAttrMapBackup
      if (data.isCreatePintuanAction) {
        _attrSaleList = JSON.parse(JSON.stringify(data.pintuanAttrSaleList))
        pintuanSkuListMap = JSON.parse(JSON.stringify(data.skuListMap))
        pintuanCurrentSelectAttrMap = JSON.parse(
          JSON.stringify(data.currentSelectAttrArray)
        )
        this.setData({
          pintuanSkuListMap,
          pintuanCurrentSelectAttrMap,
          pintuanCountData: data.countData,
          pintuanNetqty: data.netqty,
          pintuanSkucode: data.skucode,
        })
      }
      if (data.isBuyNow || data.isAddCard || data.isNormal) {
        _attrSaleList = JSON.parse(JSON.stringify(data.attrSaleListBackup))
        skuListMapBackup = JSON.parse(JSON.stringify(data.skuListMap))
        currentSelectAttrMapBackup = JSON.parse(
          JSON.stringify(data.currentSelectAttrArray)
        )
        this.setData({
          skuListMapBackup,
          currentSelectAttrMapBackup,
          countDataBackup: data.countData,
          netqtyBackup: data.netqty,
          skucodeBackup: data.skucode,
        })
      }
      this.setData({
        attrSaleList: _attrSaleList,
      })
    },
    handleConfirmSelectionSpec() {
      const data = this.data
      if (!data.skucode) {
        wx.showToast({
          title: '请选择' + this.data.pleaseSelectSku,
          icon: 'none',
        })
        return
      }
      this.updateSkuView()
      if (data.skucode) {
        if (data.isAddCard) {
          this.canAddShoppingCart()
        }
        if (data.isBuyNow || data.isCreatePintuanAction) {
          this.setProductList()
        }
      }
      this.copyCurrentSelect()
      this.setData({
        isShowMask: false,
      })
    },
    onChangeCount({ detail }) {
      let quotaInfo = this.data.quotaInfo
      if (quotaInfo.isQuota === '1') {
        if (detail.value === quotaInfo.canBuy) {
          wx.showToast({
            title: `每人限购${quotaInfo.canBuy}件`,
            icon: 'none',
          })
        }
      }
      this.setData({
        countData: detail.value,
      })
    },
    updateCurrentSku(data, skuCode) {
      const currentSku = data.skuList.find(sku => {
        return sku.code === skuCode
      })
      data.currentSelectSku = currentSku
    },
    handleSelectAttr({ currentTarget: { dataset } }) {
      const data = this.data
      const skuList = data.skuList
      let currentSelectAttrArray = data.currentSelectAttrArray
      const attrSaleList = data.attrSaleList
      const attrSaleLen = attrSaleList.length
      const pleaseSelectSku = data.pleaseSelectSku
      const attributeFrontName = dataset.attributefrontname
      const attributeName = dataset.attributename
      const code = dataset.code
      const attrCode = dataset.attrcode
      const LevelOneIndex = dataset.index // attrSaleList下一级索引
      const LevelTwoIndex = dataset.idx // attrSaleList下二级索引
      const disabled = dataset.disabled // 拼团-无效的attr，直接return，不走流程
      if (disabled) {
        return
      }
      // step1. 将当前的选择属性以Map结构存储下来，遍历attrSaleList
      // let isSelectCode = true
      let currentSelectAttrMap = new Map()
      currentSelectAttrArray.push({
        code: code,
        attrCode: attrCode,
        attributeName: attributeName,
      })
      currentSelectAttrArray.forEach(sa => {
        currentSelectAttrMap.set(sa.code, {
          attrCode: sa.attrCode,
          attributeName: sa.attributeName,
        })
      })
      attrSaleList[LevelOneIndex].attributeValueList.forEach(
        (item, index, self) => {
          if (LevelTwoIndex === index) {
            // 取反active
            self[index].active = !self[index].active
            if (self[index].active) {
              // 未选择->已选择
              const i = pleaseSelectSku.findIndex(p => p === attributeFrontName)
              ~i && data.pleaseSelectSku.splice(i, 1)
            } else {
              // 已选择->未选择
              let deleteArr = []
              currentSelectAttrArray.forEach((sa, i) => {
                if (sa.code === code) {
                  deleteArr.push(i)
                }
              })
              deleteArr
                .reverse()
                .forEach(del => currentSelectAttrArray.splice(del, 1))
              currentSelectAttrMap.delete(code)
              pleaseSelectSku.push(attributeFrontName)
              // isSelectCode = false
            }
          } else {
            const delIndex = currentSelectAttrArray.findIndex(d => {
              return d.attrCode === item.code
            })
            ~delIndex && currentSelectAttrArray.splice(delIndex, 1)
            self[index].active = false
          }
        }
      )
      // 设置skuListMap
      data.currentSelectAttrArray = currentSelectAttrArray
      data.currentSelectAttrMap =
        currentSelectAttrMap.size === 0 ? null : currentSelectAttrMap
      data.skuListMap = Array.from(currentSelectAttrMap.values(), item => {
        return {
          attrCode: item.attrCode,
          attributeName: item.attributeName,
        }
      })

      // 拼团 - 当属性选择完毕，更新属性状态
      // const currentSelectedCode = data.skuListMap.map(item => item.attrCode)
      if (this.data.isCreatePintuanAction) {
        // this.updateOptionClickableStatus(
        //   code,
        //   LevelOneIndex,
        //   attrSaleList,
        //   isSelectCode,
        //   currentSelectedCode,
        //   data.pintuanCampaign.productSkus
        // )
        this.handleUpdateStatus(
          currentSelectAttrArray,
          attrSaleList,
          data.pintuanCampaign.productSkus,
          data.skuList.length
        )
      } else {
        this.handleUpdateStatus(
          currentSelectAttrArray,
          attrSaleList,
          data.skuList,
          data.skuList.length
        )
      }
      // step2. 将已经选择属性的长度与skuList的长度对比
      // 相等 - 属性已经全部选择完毕，去匹配对应的sku，拿到skuItem（价格、库存、图片）
      // 不相等 - 取消选择或未完全选择，将对应的数据置为初始值
      let currentAttrList = currentSelectAttrArray.map(attr => attr.attrCode)
      const skuItem = skuList.find(item => {
        const isAllInCurrentAttr = currentAttrList.every(code => {
          return item.formatAttrCode.indexOf(code) > -1
        })
        return isAllInCurrentAttr ? item : false
      })
      if (JSON.stringify(data.pintuanCampaign) !== '{}') {
        // 更新当前拼团的sku
        this.updateCurrentSelectSku(
          data,
          attrSaleList.length === currentSelectAttrArray.length
            ? skuItem.code
            : undefined
        )
      }

      let _selectAttrImage = data.picCopy
      if (currentSelectAttrMap.size === attrSaleLen) {
        // let hasImageField = false
        if (skuItem) {
          const MainSkuIndex = skuItem.attrSaleList.findIndex(item => {
            return item.attributeValueList[0].itemAttributeValueImageList
          })
          const attrImgList =
            skuItem.attrSaleList[MainSkuIndex].attributeValueList[0]
              .itemAttributeValueImageList
          if (attrImgList.length === 1) {
            _selectAttrImage = attrImgList[0].picUrl
          } else if (attrImgList.length > 1) {
            // 获取与sku里面图片相同长度的attrSaleList的属性长度
            const __MainSkuIndex = attrSaleList.findIndex(item => {
              return item.attributeValueList[0].itemAttributeValueImageList
            })

            const _index = __MainSkuIndex === LevelOneIndex ? LevelTwoIndex : 0
            _selectAttrImage = attrImgList[_index].picUrl
          }
          data.skucode = skuItem.code
          data.skucodeBackup = skuItem.code
          data.netqty = skuItem.netqty
          data.netqtyBackup = skuItem.netqty
          data.salePriceCopy = skuItem.salePrice
          data.listPriceCopy = skuItem.listPrice
          data.countData = skuItem.netqty === 0 ? 0 : 1
          data.countDataBackup = skuItem.netqty === 0 ? 0 : 1
          data.picCopy = _selectAttrImage || data.pic
          // 普通立即购买更新当前的sku
          this.updateCurrentSku(data, skuItem.code)
        }
      } else {
        data.netqty = -1
        data.netqtyBackup = -1
        data.skucode = ''
        data.countData = -1
        data.countDataBackup = -1
        data.salePriceCopy = data.salePrice
        data.listPriceCopy = data.listPrice
        data.picCopy = _selectAttrImage || data.pic
      }
      this.setData(data)
    },
    onShareAppMessage(res) {
      const openid = wx.getStorageSync('openid')
      const distUser = wx.getStorageSync('distUser')
      const nickName = app.globalData.userInfo
        ? app.globalData.userInfo.nickName
        : ''
      const query = queryString({
        spuCode: this.data.spuCode,
        sharerOpenId: openid,
        sharerDistUser: distUser,
        sharerName: nickName,
        src: this.data.placeholderImage,
        storeId: this.data.storeId,
        storeCode: this.data.storeCode,
      })
      return {
        title: `${this.data.title}`,
        path: `/sub/Commodity/pages/pdp/pdp?${query}`,
        imageUrl: this.data.shareWeChatImage,
      }
    },
    handleBackHome() {
      app.router.navigateTo('/pages/home/home')
    },
    contactCustomer() {
      wx.request({
        url:
          'https://api.weixin.qq.com/cgi-bin/message/custom/send?access_token=ACCESS_TOKEN',
      })
    },
    handleReload() {
      this.setData({
        isShowReloadBtn: false,
        dataLoaded: false,
      })
      this.pollingData(this.data.pintuanTeamId)
    },
    /**
     * [queryEffectiveDays 查询有效天数，与是否过期]
     * @return {[type]} [description]
     */
    queryEffectiveDays(callback) {
      const promise = queryEffectiveDay({
        merCode: wx.getStorageSync('tenantCode'),
      })
      promise.then(res => {
        const { code, data } = res
        if (Object.is(code, '0')) {
          if (data.day <= 0) {
            wx.redirectTo({
              url: '/sub/Member/pages/shopClose/shopClose',
            })
          } else {
            callback()
          }
        }
      })
    },
    handleViewMoreSocialTeam() {
      this.initSocialTeamBlockPosition()
      this.setData({
        isShowSocialTeamModal: true,
      })
    },
    handleHideMoreSocialTeam() {
      this.setData({
        isShowSocialTeamModal: false,
      })
    },
    initSocialTeamBlockPosition() {
      const query = wx.createSelectorQuery()
      query.select('.team-info-area').boundingClientRect()
      query.selectViewport().scrollOffset()
      query.exec(res => {
        this.setData({
          socialTeamBlockTopHeight:
            Math.max(res[1].scrollTop, res[0].top) + 100,
        })
      })
    },
    togglePintuanRuleModal() {
      this.setData({
        isShowPintuanRule: !this.data.isShowPintuanRule,
      })
    },
  },
})
