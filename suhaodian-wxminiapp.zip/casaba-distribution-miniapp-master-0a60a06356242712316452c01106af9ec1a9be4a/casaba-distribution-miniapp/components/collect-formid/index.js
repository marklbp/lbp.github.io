/*
 * @Author: xiaofei.meng_tic
 * @Date:   2019-03-14 15:57:22
 * @Last Modified by:   mengxiaofei
 * @Last Modified time: 2019-04-12 17:44:23
 */
import { saveFormId } from '../../api/index'
import apiReload from '../../utils/reload'

const app = getApp()
Component({
  externalClasses: ['u-class'],
  methods: {
    collectFormId(e) {
      let detail = e.detail
      let formIds = []
      if (detail.formId && detail.formId !== 'the formId is a mock one') {
        formIds.push(detail.formId)
        console.log('搜集到的formId', formIds)
        if (!app.globalData.unexUserToken) {
          apiReload.getOpenIdAndToken(app).then(() => {
            this.handleSaveFormId(formIds)
          })
        } else {
          this.handleSaveFormId(formIds)
        }
      } else {
        console.log('developTool collect formid')
      }
      this.triggerEvent('callback', detail.formId)
    },
    handleSaveFormId(formIds) {
      saveFormId(
        {
          openId: app.globalData.openid,
          formIds: formIds,
        },
        {
          unexUserToken: app.globalData.unexUserToken,
        }
      )
    },
  },
})
