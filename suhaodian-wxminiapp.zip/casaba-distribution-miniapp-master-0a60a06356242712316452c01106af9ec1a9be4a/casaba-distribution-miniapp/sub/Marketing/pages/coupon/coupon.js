import { queryCoupons } from '../../../../api/index'
import apiReload from '../../../../utils/reload'
const app = getApp()
Page({
  data: {
    couponTab: [
      {
        tabName: '可使用',
        status: '1',
      },
      {
        tabName: '已使用',
        status: '2',
      },
      {
        tabName: '已过期',
        status: '3',
      },
    ],
    couponDatas: [
      {
        lastPage: 1,
        noMore: false,
        coupons: [],
      },
      {
        lastPage: 1,
        noMore: false,
        coupons: [],
      },
      {
        lastPage: 1,
        noMore: false,
        coupons: [],
      },
    ],
    access_token: '',
    scrollHeight: 495,
    offsetLeft: 0,
    moveDistance: 0,
    current: 0,
    tabBarCilcked: false,
    listLoading: true,
    lastPage: 1,
    noMore: false,
    moreLoading: false,
    isShowReloadBtn: false,
    clickPay: false,
    timer: null,
  },

  onLoad: function(options) {
    this.pollingData()
  },
  onShow() {
    wx.getSystemInfo({
      success: res => {
        const wh = res.windowHeight
        const scrollHeight = wh - 50
        this.setData({ scrollHeight: scrollHeight })
      },
    })
    this.getFields()
  },
  pollingData() {
    if (this.data.timer) {
      return
    }
    let pollingCount = 0
    const timer = setInterval(() => {
      if (!app.globalData.openid || !app.globalData.unexUserToken) {
        pollingCount++
        if (pollingCount > 70) {
          clearInterval(timer)
          this.setData({
            timer: null,
          })
          apiReload
            .getOpenIdAndToken(app)
            .then(res => {
              apiReload.getAuthParam(app, app.globalData.openid).then(() => {
                this.initCouponList(1)
              })
            })
            .catch(() => {})
        }
      } else {
        clearInterval(timer)
        this.initCouponList(1)
      }
    }, 100)
    this.setData({
      timer: timer,
    })
  },
  getFields() {
    let current = this.data.current
    wx.createSelectorQuery()
      .select('.tab-text-item')
      .fields(
        {
          size: true,
        },
        res => {
          const offsetLeft = res.width / 2 - 7
          const moveDistance = res.width
          this.setData({
            offsetLeft: offsetLeft + current * moveDistance,
            moveDistance: moveDistance,
            current: current,
            tabBarCilcked: current !== 0,
          })
        }
      )
      .exec()
  },
  handleTabChange(e) {
    const dataset = e.currentTarget.dataset
    const index = dataset.index
    if (index === this.data.current) {
      return
    }
    this.setData({
      current: index,
      offsetLeft:
        (index - this.data.current) * this.data.moveDistance +
        this.data.offsetLeft,
      tabBarCilcked: true,
    })
  },
  bindViewClickTabItem(e) {
    wx.pageScrollTo({
      scrollTop: 0,
      duration: 0,
    })
    const dataset = e.currentTarget.dataset
    let status = dataset.status
    const index = dataset.index
    if (index === this.data.current) {
      return
    }
    this.setData({
      isShowReloadBtn: false,
      current: index,
      offsetLeft:
        (index - this.data.current) * this.data.moveDistance +
        this.data.offsetLeft,
      tabBarCilcked: true,
    })
    this.initCouponList(status)
  },
  loadMore() {
    console.log('加载更多')
    let current = this.data.current
    this.setData({
      moreLoading: true,
    })
    this.initCouponList(current)
  },
  // 初始化请求优惠券接口
  initCouponList(status) {
    wx.showLoading({
      title: '数据加载中',
    })
    let current = this.data.current
    queryCoupons(
      {
        size: 999,
        data: {
          status: status,
        },
      },
      {
        unexUserToken: app.globalData.unexUserToken,
        'invoke-source': app.globalData['invoke-source'],
      }
    )
      .then(res => {
        if (res.code === '0') {
          wx.hideLoading()
          let currentCoupon = 'couponDatas[' + current + '].coupons'
          // let currentTabCoupon = this.data.couponDatas[current].coupons
          this.setData({
            [currentCoupon]: res.data.list,
            listLoading: false,
            moreLoading: false,
          })
        }
      })
      .catch(() => {
        wx.hideLoading()
        this.setData({
          isShowReloadBtn: true,
          listLoading: false,
          moreLoading: false,
        })
      })
  },
  handleReload() {
    this.initCouponList(this.data.current)
  },
  handleCouponDetail(e) {
    let couponCode = e.currentTarget.dataset.couponcode
    let activityCode = e.currentTarget.dataset.activitycode
    let current = this.data.current
    app.router.navigateTo(
      `/sub/Marketing/pages/couponDetail/couponDetail?couponCode=${couponCode}&activityCode=${activityCode}&current=${current}`
    )
  },
  useNow() {
    app.router.navigateTo('/pages/home/home')
  },
})
