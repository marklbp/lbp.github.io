const app = getApp()

Page({
  data: {
    logistics: null,
  },

  onLoad: function(options) {
    this.transformTime(options.orderDate)
    this.stateLogis(options.orderId, options.orderDate)
  },
  // fu复制按钮
  copyClick() {
    let data = this.data.logistics.expressOrder
    wx.setClipboardData({
      data: data,
      success: function(res) {
        wx.getClipboardData({
          success: function(res) {
            console.log(res.data) // data
          },
        })
      },
    })
  },
  transformTime(timestr) {
    let temp = timestr.split(' ')
    let date = temp[0]
    let time = temp[1]
    return {
      date: date.substring(5),
      time: time.substring(0, 5),
    }
    // return date.split('-').splice(0, 1) + time
  },
  // 物流信息查询 this.stateLogis(options.orderId, options.orderDate)
  stateLogis(orderId, orderDate) {
    let $this = this
    let data = {
      orderNumber: orderId,
      tenantCode: app.globalData.tenantCode,
    }
    let list = [
      {
        context: '卖家已发货',
        time: this.transformTime(orderDate),
      },
      {
        context: '您的订单正在处理',
        time: this.transformTime(orderDate),
      },
    ]
    app.http({
      url: '/express/getExpressDetails',
      data: data,
      header: {
        // 'invoke-source': app.globalData['invoke-source']
        // 'content-type': 'application/x-www-form-urlencoded',
        // 'xAuthToken': app.globalData.xAuthToken
      },
      success: function(res) {
        if (res.data.data.data.length === 0) {
          res.data.data.data = [...res.data.data.data, ...list]
        } else {
          res.data.data.data = res.data.data.data.map(item => {
            return {
              context: item.context,
              time: $this.transformTime(item.time),
            }
          })
        }
        $this.setData({
          logistics: res.data.data,
        })
      },
      fail: function(res) {},
    })
    // wx.request({
    //   url: 'http://rap2api.taobao.org/app/mock/data/437958',
    //   data:data,
    //   success:function (res) {
    //     console.log(res)
    //     res.data.data.data = [...res.data.data.data,...list]
    //     $this.setData({
    //       logistics:res.data.data
    //     })
    //     console.log($this.data.logistics)
    //   }
    // })
  },
})
