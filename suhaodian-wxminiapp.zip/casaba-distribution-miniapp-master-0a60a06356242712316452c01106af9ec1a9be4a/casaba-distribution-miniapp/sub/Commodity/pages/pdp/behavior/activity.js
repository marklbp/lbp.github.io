// 活动
import {
  querySkuPrice,
  activitiesByProduct,
  getItemDetailBySku,
} from '../../../../../api/index'

const app = getApp()

export default Behavior({
  data: {
    isShowActivityRule: false, // 活动规则弹出层
    productSingle: false, // 单品促销
    promotionPrice: null, // 单品促销价
    activityList: [],
    catalogueIndex: 0, // 活动目录索引
    saleNums: 0, // 销量
  },
  methods: {
    handleOpenRuleSheet() {
      this.setData({
        isShowActivityRule: true,
      })
      setTimeout(() => {
        this.setData({
          hookLayer: true,
        })
      }, 100)
    },
    onRuleCancel() {
      this.setData({
        isShowActivityRule: false,
      })
    },
    // 获取销量
    getSaleNum(skuCode) {
      getItemDetailBySku({
        tenantCode: app.globalData.tenantCode,
        skuCode: skuCode,
      })
        .then(res => {
          this.setData({
            saleNums: res.saleNums,
          })
        })
        .catch(err => {
          console.error('通过sku找商品详情', err)
        })
    },
    getActivityList(data) {
      let dataObj1 = {
        spuCode: this.data.spuCode,
        categoryCode: data.categoryList
          ? data.categoryList[data.categoryList.length - 1].categoryPath
          : '',
        skuCode: data.skuList[0].code,
        brandCode: data.brand.code,
        memberLevelCode: '18040300000029',
        price: data.salePrice,
        tenantCode: app.globalData.tenantCode,
      }
      let dataObj2 = {
        spuCode: this.data.spuCode,
        categoryCode: data.categoryList
          ? data.categoryList[data.categoryList.length - 1].categoryPath
          : '',
        skuCode: data.skuList[0].code,
        brandCode: data.brand.code,
        memberLevelCode: '18040300000029',
      }
      // 单品促销
      querySkuPrice(dataObj1, {
        'invoke-source': app.globalData['invoke-source'],
      }).then(res => {
        if (res.success && res.data.activity) {
          this.setData({
            productSingle: true,
            promotionPrice: res.data.activity[0].promotionPrice,
          })
        }
      })
      activitiesByProduct(dataObj2, {
        'invoke-source': app.globalData['invoke-source'],
      }).then(res => {
        let _activityList = res.data || []
        _activityList.forEach((item, index) => {
          ;(function(item, index, root) {
            let giftProductList = []
            item.activityGifts.forEach(giftItem => {
              getItemDetailBySku({
                tenantCode: app.globalData.tenantCode,
                skuCode: giftItem.skuCode,
              })
                .then(skuRes => {
                  if (!skuRes.data) {
                    return
                  }
                  giftProductList.push({
                    image: skuRes.data.itemImageList[0].picUrl,
                    title: skuRes.data.title,
                  })
                  _activityList[index].giftProductList = giftProductList
                  root.setData({
                    activityList: _activityList,
                  })
                })
                .catch(err => {
                  console.error('通过sku找商品详情', err)
                })
            })
          })(item, index, this)
        })
        this.setData({
          activityList: _activityList,
          catalogueIndex: _activityList.length > 1 ? -1 : 0,
        })
      })
    },
    // 处理显示目录更改
    handleCatalogueChange({ currentTarget }) {
      const index = currentTarget.dataset.index
      if (index === this.data.catalogueIndex) {
        this.setData({
          catalogueIndex: -1,
        })
      } else {
        this.setData({
          catalogueIndex: index,
        })
      }
    },
  },
})
