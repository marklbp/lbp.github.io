import {
  getOrderCodesAction,
  getPintuanTeamDetailAction,
} from '../../../../honghuStore/action'
import { getAttr, getImgUrl } from '../../../../static/utils/skuHelper'
import { TEAM_STATUS_KEY } from '../../../../honghuStore/constant'
import { hideLoading, showLoading } from '../../../../honghuStore/uiHelper'
import apiReload from '../../../../utils/reload'

const app = getApp()
Page({
  data: {
    defaultAvatar:
      'http://bztic-casaba.oss-cn-shanghai.aliyuncs.com/miniprograme/common/user.png',
    crownUrl:
      'http://bztic-casaba.oss-cn-shanghai.aliyuncs.com/miniprograme/Marketing/pintuan/crown.png',
    timer: null,
    product: {
      id: '',
      code: '',
      title: '',
      attr: '',
      pintuanPrice: 0.0,
      listPrice: 0.0,
    },
    orderId: '',
    teamId: '',
    orderOwnerCode: '',
    team: {
      isStart: false,
      isSuccess: false,
      isFailed: false,
      isMember: false,
      isOrderOwner: false,
      remainingPeopleNumber: 0,
      teamMembers: [],
      limitTime: 1537200000000,
    },
  },
  onLoad(params) {
    this.setData({
      orderId: params.orderId,
      teamId: decodeURIComponent(params.teamId),
    })
  },
  onShow() {
    this.pollingData()
  },
  pollingData() {
    if (this.data.timer) {
      return
    }
    let pollingCount = 0
    const timer = setInterval(() => {
      if (!app.globalData.openid || !app.globalData.accountId) {
        pollingCount++
        if (pollingCount > 70) {
          clearInterval(timer)
          this.setData({
            timer: null,
          })
          apiReload
            .getOpenIdAndAuthParam(app)
            .then(res => {
              this.initReq()
            })
            .catch(() => {
              wx.showToast({
                title: '服务器出现异常，请稍后再试',
                icon: 'none',
              })
            })
        }
      } else {
        clearInterval(timer)
        this.setData({
          timer: null,
        })
        this.initReq()
      }
    }, 100)
    this.setData({ timer: timer })
  },
  initReq() {
    showLoading()
    this.getOrderDetail(this.data.orderId)
      .then(() => this.getPintuanTeamDetail(this.data.teamId))
      .then(() => {
        hideLoading()
      })
      .catch(() => {
        hideLoading()
      })
  },
  getOrderDetail(id) {
    return getOrderCodesAction(id).then(response => {
      let res = response[0]
      this.setData({
        product: {
          id: res.items[0].productSku.product.id,
          code: res.items[0].productSku.product.code,
          imgUrl:
            getImgUrl(res.items[0].productSku.attrSaleList) +
            '?x-oss-process=image/quality,Q_80',
          title: res.items[0].productSku.product.name,
          attr: getAttr(res.items[0].productSku.attrSaleList),
          pintuanPrice: res.items[0].price,
          listPrice: res.items[0].productSku.salePrice,
        },
        orderOwnerCode: res.member && res.member.code,
      })
    })
  },
  getPintuanTeamDetail(teamId) {
    return getPintuanTeamDetailAction(teamId).then(res => {
      this.initTeamData(res)
    })
  },
  initTeamData(team) {
    const teamMembers = this.getTeamMembers(team.members, team.creator)
    this.setData({
      team: {
        id: team.id,
        endedAt: team.endedAt,
        isStart: team.status === TEAM_STATUS_KEY.STARTED,
        isSuccess: team.status === TEAM_STATUS_KEY.ENDED,
        isFailed: team.status === TEAM_STATUS_KEY.FAILED,
        teamMembers,
        isMember: this.some(teamMembers, {
          code: app.globalData.accountId.toString(),
        }),
        isOrderOwner:
          this.data.orderOwnerCode === app.globalData.accountId.toString(),
        remainingPeopleNumber: team.limitNumber - teamMembers.length,
        status: team.status,
      },
    })
  },
  getTeamMembers(members, creator) {
    let currentMembers = []
    if (members.some(member => member.code === creator.code)) {
      currentMembers = members
    } else {
      currentMembers = [creator].concat(members)
    }
    return currentMembers.map(item => {
      return {
        code: item.code,
        avatarUrl: item.avatarUrl,
        isCreator: item.code === creator.code,
      }
    })
  },
  some(arr, value) {
    for (let item of arr) {
      for (let key in value) {
        if (item[key] === value[key]) {
          return item[key] === value[key]
        }
      }
    }
    return false
  },
  createNewGroup() {
    wx.navigateTo({
      url: `/sub/Commodity/pages/pdp/pdp?spuCode=${this.data.product.code}`,
    })
  },
  joinTeam() {
    wx.navigateTo({
      url: `/sub/Commodity/pages/pdp/pdp?spuCode=${
        this.data.product.code
      }&pintuanTeamId=${encodeURIComponent(this.data.teamId)}`,
    })
  },
  refreshCountdown() {
    this.getPintuanTeamDetail(this.data.teamId).then(() => {
      if (this.data.team.isStart) {
        setTimeout(() => this.refreshCountdown(), 1000)
      }
    })
  },
  handleBackHome() {
    app.router.navigateTo('/pages/home/home')
  },
  handleOrderDetail() {
    wx.navigateTo({
      url: '/sub/Order/pages/orderdetail/orderdetail?id=' + this.data.orderId,
    })
  },
  onShareAppMessage() {
    return {
      path: `/sub/Marketing/pages/pintuanDetail/pintuanDetail?orderId=${
        this.data.orderId
      }&teamId=${encodeURIComponent(this.data.teamId)}`,
    }
  },
})
