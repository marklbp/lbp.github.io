const getImgUrl = function(attr) {
  for (let item of attr) {
    if (item.attributeValueList[0].itemAttributeValueImageList.length > 0) {
      return item.attributeValueList[0].itemAttributeValueImageList[0].picUrl
    }
  }
}

const getAttr = function(attr) {
  return attr
    .map(item => item.attributeValueList[0].attributeValueFrontName)
    .join(',')
}

module.exports = {
  getImgUrl,
  getAttr,
}
