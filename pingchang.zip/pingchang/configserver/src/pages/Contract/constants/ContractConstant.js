import { BaseConstant } from 'base';

class ContractConstant extends BaseConstant{
	constructor(){
		super();

		this.key = 'Contract_'
	}
}

export default new ContractConstant();