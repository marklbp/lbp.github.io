import AddFont from './AddFont';

export default AddFont;
