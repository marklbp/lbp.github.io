// sub/Distribution/pages/incomeDetails/incomeDetails.js
import { myClientList } from '../../../../api/index.js'
const app = getApp()
let id = null
Page({

  /**
   * 页面的初始数据
   */
  data: {
    animationData: null,
    orderStatus: -1,
    inviterArray: [
      // {
      //   userId: '',
      //   openId: '',
      //   nickname: '', // 用户名称
      //   portrait: '', // 用户头像
      //   payTotalAmount: '', // 贡献收益
      //   payOrderCount: '' // 订单数
      // }
    ],
    page: null
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    console.log('options', options)
    if (options.id) {
      id = options.id
    }
    this.myClientLists()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    const page = this.page
    if (page.total > page.pageNum * page.pageSize) {
      this.myClientLists(++page.pageNum)
    }
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    this.myClientLists()
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },
  /**
   * 激活标签页
   */
  activeTab(e) {
    const dataset = e.target.dataset
    this.setData({
      orderStatus: dataset.status,
      inviterArray: [],
      page: null
    })
    this.myClientLists()
  },
  /**
   * 邀请朋友
   */
  invitationFriend(e) {
    wx.navigateTo({
      url: '/sub/Distribution/pages/client/client',
    })
  },
  /**
   * 我的客户
   */
  myClientLists(pageNum = 1) {
    const orderStatus = this.data.orderStatus
    const promise = myClientList({
      pageNum,
      pageSize: 5,
      id: Object.is(id, null) ? undefined : id,
      tenantCode: app.globalData.tenantCode,
      openId: app.globalData.openid || wx.getStorageSync('openid'),
    })
    promise.then(res => {
      let { code, data: { distributorCustomerList = [], page = { pageNum: 1, pageSize: 5, total: 0} } } = res
      if (!distributorCustomerList) {
        distributorCustomerList = []
      }
      if (!page) {
        page = { pageNum: 1, pageSize: 5, total: 0 }
      }
      distributorCustomerList = distributorCustomerList.map(item => {
        item.portrait = item.portrait || 'http://bztic-casaba.oss-cn-shanghai.aliyuncs.com/miniprograme/Distribution/myClient/user_pic.png'
        item.nickname = item.nickname || '匿名用户'
        return item
      })
      if (Object.is(code, '0')) {
        const inviterArray = this.data.inviterArray.concat(distributorCustomerList)
        this.setData({
          inviterArray: inviterArray,
          page: page
        })
      }
    })
  }
})
