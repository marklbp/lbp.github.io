import BaseConstant from '../../../base/constants/BaseConstant';


class MaterialSubmitConstant extends BaseConstant{
	constructor(){
		super();

		this.key = 'MATERIALSUBMIT_'
	}
}

export default new MaterialSubmitConstant();
