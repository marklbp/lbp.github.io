import {
  pintuanCampaignFragment,
  limitTimeDiscountsCampaignFragment,
} from './gqlFragments'

const getPintuanProductDetailStr = `query($id: ID!) {
  node(id: $id) {
    ... on PintuanCampaignProduct {
    id
    code
    name
    title
    salePrice
    listPrice
    description
    listTime
    saleStatus
    type
    itemImageList{
      picUrl
      saleAttributeId
      saleAttributeValue
    }
    campaign{
      id
      code
      name
      availablePeriod{
        start
        end
      }
      limitNumber
      productSkus{
          id
          code
          sales
          status
          netqty
          inventory
          listPrice
          salePrice
          price: pintuanPrice
          creatorPrice
          attrSaleList{
            code
            attributeFrontName
            attributeValueList{
              code
              attributeValueName
              attributeValueFrontName
              attributeValuePicURL
              itemAttributeValueImageList{
                picUrl
                saleAttributeId
                saleAttributeValue
              }
            }
          }
      }
    }
    attrSaleList{
      code
      attributeFrontName
      attributeValueList{
        code
        attributeValueName
        attributeValueFrontName
        attributeValuePicURL
        itemAttributeValueImageList{
          picUrl
          saleAttributeId
          saleAttributeValue
        }
      }
    }
    skus{
      id
      code
      sales
      status
      netqty
      inventory
      listPrice
      salePrice
      attrSaleList{
        code
        attributeFrontName
        attributeValueList{
          code
          attributeValueName
          attributeValueFrontName
          attributeValuePicURL
          itemAttributeValueImageList{
            picUrl
            saleAttributeId
            saleAttributeValue
          }
        }
      }
    }
  }
  }
}`

const getProductDetailStr = `query($ids: [String!]!) {
  products(productIds: $ids) {
    id
    code
    name
    title
    salePrice
    listPrice
    description
     skus {
        id code netqty inventory listPrice salePrice
        attrSaleList {
          code
          attributeFrontName
          attributeValueList {
            code
            attributeValueFrontName
            itemAttributeValueImageList {
              picUrl
            }
          }
        }
      }
     ongoingTeams {
      id
      campaign {
        id
      }
      creator {
        id
        nickName
        avatarUrl
      }
      endedAt
      limitNumber
      members{
        id
        nickName
        avatarUrl
      }
    }
    campaign {
      id
      code
      name
      ... on PintuanCampaign {
        ...pintuanCampaignFragment
      }
      ... on LimitTimeDiscountsCampaign {
        ...limitTimeDiscountsCampaignFragment
      }
    }
  }
}
${pintuanCampaignFragment}
${limitTimeDiscountsCampaignFragment}
`
const getJoinPintuanTeamDetailStr = `query($ids: [String!]!, $pintuanTeamId: ID!) {
  products: byCodes(typename: "Product", codes: $ids) {
    id
  }
  pintuanTeam: node(id:$pintuanTeamId){
    ... on PintuanTeam {
      id
      status
      campaign {
        ...pintuanCampaignFragment
      }
    }
  }
}
${pintuanCampaignFragment}
`

const getProductInfoStr = `query($code: String!) {
  byCode(code: $code, typename: "Product") {
    ... on Product {
      title
      campaign {
        code
        name
        __typename
        ... on PintuanCampaign {
          pintuanType: type
        }
      }
    }
  }
}`

module.exports = {
  getPintuanProductDetailStr,
  getProductDetailStr,
  getJoinPintuanTeamDetailStr,
  getProductInfoStr,
}
