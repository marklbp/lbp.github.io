Component({
  properties: {
    content: {
      type: Object,
      value: null,
    },
  },
  detached() {
    this.destroyTimer()
  },
  ready() {
    const { textType, textShowStyle } = this.data.content
    if (textType === 'default' && textShowStyle === 'roll') {
      this.initAnimation()
    }
  },
  data: {
    timer: null,
    speed: 40,
    duration: 0,
    animationData: {},
  },
  methods: {
    pubRefresh() {
      const { textType, textShowStyle } = this.data.content
      if (textType === 'default' && textShowStyle === 'roll') {
        this.destroyTimer()
        this.initAnimation()
      }
    },
    initAnimation() {
      const windowWidth = wx.getSystemInfoSync().windowWidth || 375
      const rpx = windowWidth / 750
      const query = wx.createSelectorQuery().in(this)
      query
        .select('#text_len')
        .fields({ size: true }, res => {
          const textWidth = res.width
          const padding = 40 * rpx // 将其转化成px，两边设有padding
          if (textWidth + padding * 2 >= windowWidth) {
            const duration = (textWidth / this.data.speed) * 1000
            console.log(`${textWidth}米耗时：${duration / 1000}秒`)
            this.animation = wx.createAnimation({
              duration: duration,
            })
            this.setData({ duration }, () => {
              this.startAnimation(textWidth)
            })
          } else {
            if (this.animation) {
              this.animation.option.transition.duration = 0
              const resetAnimation = this.animation.translateX(0).step()
              this.setData({
                animationData: resetAnimation.export(),
              })
            }
          }
        })
        .exec()
    },
    startAnimation(textWidth) {
      // 重置文本位置
      if (this.animation.option.transition.duration !== 0) {
        this.animation.option.transition.duration = 0
        const resetAnimation = this.animation.translateX(textWidth).step()
        this.setData({
          animationData: resetAnimation.export(),
        })
      }
      this.animation.option.transition.duration = this.data.duration
      this.animation.translateX(-textWidth).step()
      setTimeout(() => {
        this.setData({
          animationData: this.animation.export(),
        })
      }, 100)
      const timer = setTimeout(() => {
        this.startAnimation(textWidth)
      }, this.data.duration)
      this.setData({
        timer,
      })
    },
    destroyTimer() {
      if (this.data.timer) {
        clearTimeout(this.data.timer)
      }
    },
  },
})
