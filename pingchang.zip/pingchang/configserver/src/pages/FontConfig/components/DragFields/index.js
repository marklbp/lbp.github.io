import DragFields from './DragFields';

export default DragFields;
