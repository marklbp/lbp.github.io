import React, { Component } from 'react';
// import DashboardDetail from './components/DashboardDetail';

export default class Demo extends Component {

  constructor(props) {
    super(props);

  }

  /**
   * <DashboardDetail {...this.props} />
   * @return {[type]} [description]
   */
  render() {
    return (
      <div className="dashboard-page">
        这是详情
      </div>
    );
  }
}
