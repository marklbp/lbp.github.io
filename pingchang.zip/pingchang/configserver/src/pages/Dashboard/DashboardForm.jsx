import React, { Component } from 'react';
//import DashboardForm from './components/DashboardForm';

export default class Demo extends Component {

  constructor(props) {
    super(props);
    
  }

  /**
   * <DashboardForm {...this.props} />
   * @return {[type]} [description]
   */
  render() {
    return (
      <div className="dashboard-page">
        这是表单
      </div>
    );
  }
}
