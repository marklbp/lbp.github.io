import {
  roundRect,
  circleAvatar,
  textAlignCenter,
} from '../../../../utils/canvas'

const app = getApp()

Page({
  data: {
    showAuthorizedLogin: false,
    openShare: false,
    imgLoading: true,
    QSCodeUrl: '',
    tempFilePath: '',
    avatarUrl: '',
    shareWeChatImage: '',
    shareMomentsImage: '',
  },

  onLoad() {
    // this.getWeChatCode()
  },
  getWeChatCode() {
    return new Promise((resolve, reject) => {
      wx.downloadFile({
        url: `${
          app.globalData.API_HOST
        }/wechat/ma/getwxacode_ext?page=sub/Distribution/pages/setupshop/setupshop&scene=${
          app.globalData.accountId
        }&appCode=${app.globalData.appCode}&width=116`,
        success: res => {
          resolve(res)
          this.setData({ QSCodeUrl: res.tempFilePath })
        },
        fail: err => {
          reject(err)
        },
      })
    })
  },
  bindInvitation() {
    if (!app.globalData.userInfo) {
      this.setData({ showAuthorizedLogin: true })
    } else {
      if (!this.data.avatarUrl) {
        Promise.all([this.getWeChatCode(), this.downloadAvaUrl()]).then(res => {
          const WeChatCode = res[0].tempFilePath
          const avatarUrl = res[1].tempFilePath
          this.drawShareWeChatImage(avatarUrl)
          this.drawShareMomentsImage(avatarUrl, WeChatCode)
        })
      }
      this.bindOpen()
    }
  },
  onSuccess({ detail }) {
    app.globalData.userInfo = detail.userInfo
    this.setData({ showAuthorizedLogin: false })
    Promise.all([this.getWeChatCode(), this.downloadAvaUrl()]).then(res => {
      const WeChatCode = res[0].tempFilePath
      const avatarUrl = res[1].tempFilePath
      this.drawShareWeChatImage(avatarUrl)
      this.drawShareMomentsImage(avatarUrl, WeChatCode)
    })
    this.bindOpen()
  },
  onCancel() {
    this.setData({ showAuthorizedLogin: false, openShare: false })
  },
  downloadAvaUrl() {
    // 只有利用downloadFile得到的图片路径才能在真机上用canvas画出头像
    return new Promise((resolve, reject) => {
      wx.downloadFile({
        url: app.globalData.userInfo.avatarUrl,
        success: res => {
          resolve(res)
          this.setData({
            avatarUrl: res.tempFilePath,
          })
        },
        fail: err => {
          reject(err)
        },
      })
    })
  },
  bindOpen() {
    this.setData({
      openShare: true,
    })
  },

  onShareAppMessage(Object) {
    console.log('分享人的openid======', app.globalData.openid)
    return {
      title: app.globalData.userInfo.nickName + '邀请你加入分销员一起赚钱！',
      path:
        '/sub/Distribution/pages/setupshop/setupshop?sharerOpenId=' +
        app.globalData.openid,
      imageUrl: this.data.shareWeChatImage,
    }
  },

  // 绘画分享好友图片
  drawShareWeChatImage(avatarUrl) {
    console.log('开始绘制好友')
    const ctx = wx.createCanvasContext('shareWeChat')
    roundRect(ctx, 0, 0, 4, 400, 320, {
      tl: false,
      tr: false,
      bl: false,
      br: false,
      stroke: '#000',
    })
    circleAvatar(ctx, avatarUrl, 200, 100, 60)
    textAlignCenter(ctx, 400, '快来和我一起开店吧', 195, '#333', 20)
    textAlignCenter(ctx, 400, '人数越多，分红越多', 225, '#333', 16)

    const grd = ctx.createLinearGradient(110, 275, 165, 275)
    grd.addColorStop(0, '#D6625A')
    grd.addColorStop(1, '#B574C5')
    ctx.font = 'normal bold 42px PingFangSC-Medium'
    ctx.setFillStyle(grd)
    ctx.fillText('马上开店', 110, 275)

    ctx.draw(false, () => {
      wx.canvasToTempFilePath({
        canvasId: 'shareWeChat',
        success: res => {
          this.setData({ shareWeChatImage: res.tempFilePath })
          console.log('好友绘制结束', res.tempFilePath)
        },
      })
    })
  },

  // 绘画分享朋友圈图片
  drawShareMomentsImage(avatarUrl, QSCodeUrl) {
    console.log('开始绘制朋友圈')
    const ctx = wx.createCanvasContext('moments')
    roundRect(ctx, 0, 0, 4, 280, 400)
    roundRect(ctx, 0, 0, 4, 280, 64, { br: false, bl: false, fill: '#F9F9F9' })
    // 绘制头像
    ctx.beginPath()
    ctx.arc(140, 60, 34, 0, 2 * Math.PI)
    ctx.setFillStyle('#FFF')
    ctx.fill()
    circleAvatar(ctx, avatarUrl, 140, 60, 30)
    // 用户名
    textAlignCenter(ctx, 280, app.globalData.userInfo.nickName, 115)
    textAlignCenter(ctx, 280, '邀请您一起来速好店', 150, '#3B9AFF')
    textAlignCenter(ctx, 280, '开店赚钱', 188, '#3B9AFF', 28)

    // 小程序码
    ctx.drawImage(QSCodeUrl, 82, 221, 115, 115)

    textAlignCenter(ctx, 280, '长按识别二维码  即可开店', 370, '#6B6B6B', 12)
    ctx.draw(false, () => {
      wx.canvasToTempFilePath(
        {
          canvasId: 'moments',
          success: res => {
            this.setData({
              shareMomentsImage: res.tempFilePath,
              imgLoading: false,
            })
            console.log('朋友圈', res.tempFilePath)
          },
        },
        this
      )
    })
  },
})
