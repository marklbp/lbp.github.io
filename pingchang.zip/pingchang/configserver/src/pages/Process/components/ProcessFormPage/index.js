import ProcessFormPage from './ProcessFormPage';

export default ProcessFormPage;