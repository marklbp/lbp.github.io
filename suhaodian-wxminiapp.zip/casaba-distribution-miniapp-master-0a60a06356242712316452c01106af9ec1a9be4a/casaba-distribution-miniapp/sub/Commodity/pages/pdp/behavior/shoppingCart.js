// 购物车、立即购买
import queryString from '../../../../../utils/query-string'
import { addToCart, queryCartCount } from '../../../../../utils/cart'

const app = getApp()

export default Behavior({
  data: {
    isAddCard: false,
    isBuyNow: false,
    addCartAnimatin: false,
    allCount: 0, // 加入购物车的商品数量,
  },
  methods: {
    // 立即购买
    handleBuyNow() {
      this.setData({
        isCreatePintuanAction: false,
        isAddCard: false,
        isBuyNow: true,
      })
      if (this.data.isNormal) {
        if (!this.data.skucode) {
          wx.showToast({
            title: '请选择' + this.data.pleaseSelectSku,
            icon: 'none',
          })
          return
        }
        this.setProductList(this.data.salePriceCopy)
        this.onSpecCancel()
      } else {
        this.buyNow()
      }
    },
    buyNow() {
      const data = this.data
      let skuListMap = data.skuListMap
      this.setData({
        skuListMap,
      })
      this.initDisabledSku()
      this.handleShowSelectionSpec()
    },
    getRightDiscount(skucode) {
      let currentSku = this.data.skuList.find(item => {
        return item.code === skucode
      })
      return currentSku
    },
    // 立即购物，将商品添加到app.globalData
    setProductList(price) {
      const data = this.data
      const attrValue = data.skuListMap
        .map(item => item.attributeName)
        .join(',')
      const productList = [
        {
          title: data.title,
          pic: data.picCopy,
          saleprice: data.isNormal ? price : data.salePriceCopy,
          listprice: data.listPriceCopy,
          attrValue: attrValue,
          count: data.countData,
          brandcode: data.brandcode,
          categorycode: data.categorycode,
          categoryname: data.categoryname,
          brandname: data.brandname,
          image: data.picCopy,
          spuCode: data.spuCode,
          skucode: data.skucode,
          extentionCode: data.currentSelectSku.extentionCode
            ? data.currentSelectSku.extentionCode
            : data.skucode,
          skuListMap: data.skuListMap,
          campaignId: data.pintuanCampaign.code,
          pintuanCampaignSkuId: data.currentPintuanCampaignSelectSku
            ? data.currentPintuanCampaignSelectSku.id
            : '',
          pintuanCampaignProduct: data.pintuanCampaignProduct,
          currentType: data.currentType,
        },
      ]
      app.globalData.productlist = productList
      const query = queryString({
        isTrueFase: true,
        fromPage: 'pdp',
        isCreatePintuanAction: data.isCreatePintuanAction,
        pintuanTeamId: data.socialPintuanTeamId || data.pintuanTeamId || '',
        storeId: data.storeId,
        storeCode: data.storeCode,
      })
      console.log('购买的product详情', productList)
      app.router.navigateTo(`/sub/Pay/pages/checkout/checkout?${query}`)
    },
    // 加入购物车
    handleAddBtn(e) {
      this.setData({
        isAddCard: true,
        isBuyNow: false,
      })
      if (this.data.isNormal) {
        if (!this.data.skucode) {
          wx.showToast({
            title: '请选择' + this.data.pleaseSelectSku,
            icon: 'none',
          })
          return
        }
        this.canAddShoppingCart()
        this.onSpecCancel()
      } else {
        this.initDisabledSku()
        this.handleShowSelectionSpec()
      }
    },
    // 判断能否加入购物车
    canAddShoppingCart() {
      this.handleAddCartNetQty()
    },
    // 处理加入购物车， 再次调用查询购物车接口
    handleAddCartNetQty() {
      addToCart([
        {
          quantity: this.data.countData,
          skuCode: this.data.skucode,
        },
      ]).then(() => {
        this.setData({
          isAddCard: false,
          addCartAnimatin: true,
        })
        this.getShopCartProductCount()
      })
    },
    // 处理加入购物车动画
    handleAddCartAnimatinend(e) {
      this.setData({
        addCartAnimatin: false,
      })
    },
    // 查询购物车的商品数量
    getShopCartProductCount() {
      queryCartCount()
        .then(count => {
          this.setData({
            allCount: count,
          })
        })
        .catch(err => {
          console.error('pdp：/queryShoppingCart', err)
        })
    },
    // 跳转购物车
    gotoShopCart() {
      app.router.navigateTo('/sub/Pay/pages/shopcart/shopcart')
    },
  },
})
