import { getPageDetail, getCouponTreasure } from '../../api/index'
import { getExtConfig } from '../../utils/util'
import queryString from '../../utils/query-string'
import * as dnt from '../../template/decoration'
import reload from '../../utils/reload.js'
const app = getApp()

Page({
  data: {
    homeData: [],
    isShowReloadBtn: false,
    listLoading: false,
    barTitle: '首页',
    background: '#FFFFFF',
    luma: true,
    tap: 1,
    tabBarLists: [],
    activityName: '阳光普照包阳光普照包阳光普照包阳光普照包',
    couponTreasure: undefined,
    couponTreasureList: [
      // {
      //   productType: '00', // 00-全部商品 01-指定范围 02-指定商品 03-指定多个商品
      //   validStart: '2018.08.15',     //使用门槛(满多少元才能有优惠)
      //   validEnd: '2018.08.20',
      //   faceValue: '2000.00',
      //   conditionValue: '500',
      //   couponName: '满减优惠券',
      //   faceUnit: '01'
      // },
      // {
      //   productType: '00', // 00-全部商品 01-指定范围 02-指定商品 03-指定多个商品
      //   validStart: '2018.08.15',     //使用门槛(满多少元才能有优惠)
      //   validEnd: '2018.08.20',
      //   faceValue: '2000.00',
      //   conditionValue: '500',
      //   couponName: '满减优惠券',
      //   faceUnit: '01'
      // }
    ],
  },
  store: {
    allVideoComponentNode: [],
    currentVideoNode: '',
  },
  onLoad(options) {
    // 开启转发按钮，并带上shareTicket信息
    if (options.sharerOpenId) {
      wx.setStorageSync('sharerOpenId', options.sharerOpenId)
    }
    wx.showShareMenu({ withShareTicket: true })
    if (!Object.is(options, {})) {
      if (options.page) {
        const query = queryString(options)
        switch (options.page) {
          case 'order':
            app.router.navigateTo(
              `/sub/Order/pages/orderdetail/orderdetail?${query}`
            )
            break
        }
      }
    }
    // 只在第一次加载的时候才显示loading
    this.setData({
      listLoading: true,
    })
  },
  onShow() {
    // wx.showLoading({
    //   title: '处理中...',
    // })
    this.initLoad()
    this.getCouponTreasures()
    // this.setData({
    //   couponTreasure: true
    // })
  },
  /**
   * 关闭优惠券
   */
  closeCouponTresure() {
    this.setData({
      couponTreasure: false,
    })
  },
  /**
   * 获取优惠券
   */
  getCouponTreasures(time = 0) {
    clearTimeout(time)
    const data = app.globalData
    if (!data.accountId) {
      // console.log('定时1', data)
      const time = setTimeout(() => {
        this.getCouponTreasures(time) // 延时0.1触发， 直到登录完成， 执行请求
      }, 100)
    } else {
      if (!app.globalData.account) {
        reload.getAuthParam(app, app.globalData.openid).then(res => {
          // console.log('定时2', res, data)
          const { content } = res
          this.getCouponTreasures1(content)
        })
      } else {
        this.getCouponTreasures1(data)
      }
    }
  },
  /**
   * 获取
   */
  getCouponTreasures1(content) {
    const data = app.globalData
    const promise = getCouponTreasure({
      account: content.account,
      tenantCode: content.tenantCode,
      userCache: {
        accountId: content.accountId,
        account: content.account,
        tenantCode: data.tenantCode,
        userCode: data.userCode,
      },
    })
    promise.then(res => {
      if (res.data) {
        const {
          success,
          data: { activityName, coupons },
        } = res
        const couponTreasureList = coupons.map(item => {
          let faceValue = item.faceValue
          let str = faceValue.substring(2)
          return {
            couponName: item.couponName,
            validStart: this.transformDate(item.validStart),
            validEnd: this.transformDate(item.validEnd),
            productType: item.productType,
            faceValue: Object.is(str, '0')
              ? Number.parseInt(faceValue)
              : faceValue,
            conditionValue: item.conditionValue,
            faceUnit: item.faceUnit,
          }
        })
        if (success) {
          this.setData({
            couponTreasure: true,
            activityName: activityName,
            couponTreasureList: couponTreasureList,
          })
        }
      }
    })
  },
  /**
   * 转换时间
   */
  transformDate(str, replace) {
    if (str) {
      let _str = str.substring(0, 4) + '.'
      _str = _str + str.substring(4, 6) + '.'
      _str = _str + str.substring(6, 8)
      return _str
    } else {
      return null
    }
  },
  onUnload() {
    this.selectAllComponents('#js-marketing').forEach(
      c => c.pubClearTimer && c.pubClearTimer()
    )
    this.initLoad()
  },
  initLoad() {
    this.getHomeData(this.refreshMarketingComponent)
    this.refreshBaseComponents()
    // this.getHomeData()
  },
  handleReload() {
    this.initLoad()
  },
  setNavigationBarTitle(obj) {
    wx.setNavigationBarTitle({
      title: obj.name || '首页',
    })
  },
  setNavigationBarColor(obj) {
    wx.setNavigationBarColor({
      frontColor: obj.nameColor || '#000000',
      backgroundColor: obj.titleBgColor || '#FFFFFF',
      animation: {
        duration: 0,
        timingFunc: 'easeIn',
      },
    })
  },
  getHomeData(cb) {
    getExtConfig().then(c => {
      getPageDetail({
        tenantCode: c.extConfig.tenantCode,
        url: 'pages/home/home',
      })
        .then(res => {
          dnt.getCallBack(this, res, cb)
        })
        .catch(() => this.handleCatchError())
    })
  },
  handleCatchError() {
    dnt.handleCatchError(this)
  },
  onEmitJump({ detail }) {
    app.router.navigateTo(detail.url)
  },
  onVideoPlay({ detail }) {
    if (detail.status === 'play') {
      // 页面中只能播放一个视频，想要播放下一个视频，必须停止上一个
      const allVideoComponentNode = this.store.allVideoComponentNode
      allVideoComponentNode.forEach(node => {
        if (node !== detail.node) {
          node.pubStop()
        }
      })
      this.store.currentVideoNode = detail.node
    }
  },
  onShareAppMessage() {
    return {
      title: this.data.barTitle,
      path: '/pages/home/home',
    }
  },
  onPullDownRefresh() {
    wx.showNavigationBarLoading()
    this.getHomeData(this.refreshMarketingComponent())
    this.refreshBaseComponents()
  },
  refreshBaseComponents() {
    this.selectAllComponents(`#js-base`).forEach(c =>
      setTimeout(() => {
        if (c.pubRefresh) {
          c.pubRefresh()
        }
      }, 16)
    )
  },
  refreshMarketingComponent() {
    this.selectAllComponents('#js-marketing').forEach(c =>
      // 这里使用setTimeout是为了将刷新任务作为异步任务推入到任务队列中
      // 等待getHomeData的Promise.resolve的执行，小程序将组件的初始数据刷新，就不会出现初始数据为空的情况
      setTimeout(() => {
        if (c.pubRefresh) {
          c.pubRefresh()
        }
      }, 16)
    )
  },
  catchtouchmove() {},
})
