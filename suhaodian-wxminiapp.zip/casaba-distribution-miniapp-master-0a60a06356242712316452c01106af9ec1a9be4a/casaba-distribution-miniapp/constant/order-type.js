export default {
  NORMAL: {
    code: '11',
    label: '普通订单',
  },
  CUSTOMER: {
    code: '99',
    label: '自定义订单',
  },
  // 虚拟商品
  VIRTUAL: {
    code: '31',
    label: '虚拟订单',
  },
}
