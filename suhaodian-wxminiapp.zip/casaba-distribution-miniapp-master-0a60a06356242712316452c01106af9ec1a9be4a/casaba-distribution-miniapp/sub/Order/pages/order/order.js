import { transformPrice } from '../../../../utils/util'
import { queryOrder, queryOrderOpenDetail } from '../../../../api/index'
import apiReload from '../../../../utils/reload'
import queryString from '../../../../utils/query-string'
import { getOrderCodesAction } from '../../../../honghuStore/action'
import {
  TEAM_STATUS,
  TEAM_STATUS_KEY,
  HONGHU_PINTUAN,
  HONGHU_ORDER_STATUS_KEY,
} from '../../../../honghuStore/constant'
import { showLoading, hideLoading } from '../../../../honghuStore/uiHelper'
// import { set } from '../../utils/storage.js'
import pay from '../../../../filter/pay'

const app = getApp()
Page({
  data: {
    orderTab: [
      {
        tabName: '全部',
        status: '',
      },
      {
        tabName: '待支付',
        status: '21',
      },
      {
        tabName: '待发货',
        status: '31',
      },
      {
        tabName: '待收货',
        status: '41',
      },
      {
        tabName: '已完成',
        status: '61',
      },
    ],
    idx: '', // 点中当前的状态索引
    orderDatas: [
      {
        lastPage: 1,
        noMore: false,
        orders: [],
      },
      {
        lastPage: 1,
        noMore: false,
        orders: [],
      },
      {
        lastPage: 1,
        noMore: false,
        orders: [],
      },
      {
        lastPage: 1,
        noMore: false,
        orders: [],
      },
      {
        lastPage: 1,
        noMore: false,
        orders: [],
      },
    ],
    shareWX: 'hidden',
    controller: 'friendHidden',
    QSCode: '',
    access_token: '',
    tempFilePath: '',
    productlist: null,
    scrollHeight: 495,
    offsetLeft: 0,
    moveDistance: 0,
    current: 0,
    tabBarCilcked: false,
    listLoading: true,
    lastPage: 1,
    noMore: false,
    moreLoading: false,
    isShowReloadBtn: false,
    clickPay: false,
    shopStyle: {
      color: '#fff',
      selectedColor: '#333333',
      auxiliaryColor: '#F4766E',
    },
  },
  onLoad: function(options) {
    this.setData({
      idx: options.idx,
      shopStyle: {
        color: app.globalData.shopStyle[0],
        selectedColor: app.globalData.shopStyle[1],
        auxiliaryColor: app.globalData.shopStyle[2],
      },
    })
    this.setCurrent(options.idx)
  },
  setCurrent(idx) {
    let current = 0
    switch (idx) {
      case '21':
        current = 1
        break
      case '31':
        current = 2
        break
      case '41':
        current = 3
        break
      case '61':
        current = 4
        break
      default:
        break
    }
    this.setData({
      current: current,
    })
  },
  onShow() {
    wx.getSystemInfo({
      success: res => {
        const wh = res.windowHeight
        const scrollHeight = wh - 50
        this.setData({ scrollHeight: scrollHeight })
      },
    })
    this.setData({
      [`orderDatas[${this.data.current}].noMore`]: false,
    })
    this.getFields()
    this.bindViewOrderList(this.data.idx)
  },
  getFields() {
    let current = 0
    switch (this.data.idx) {
      case '21':
        current = 1
        break
      case '31':
        current = 2
        break
      case '41':
        current = 3
        break
      case '61':
        current = 4
        break
      default:
        break
    }
    wx.createSelectorQuery()
      .select('.tab-text-item')
      .fields(
        {
          size: true,
        },
        res => {
          const offsetLeft = res.width / 2 - 7
          const moveDistance = res.width
          this.setData({
            offsetLeft: offsetLeft + current * moveDistance,
            moveDistance: moveDistance,
            current: current,
            tabBarCilcked: current !== 0,
          })
        }
      )
      .exec()
  },
  handleTabChange(e) {
    const dataset = e.currentTarget.dataset
    const index = dataset.index
    if (index === this.data.current) {
      return
    }
    this.setData({
      current: index,
      offsetLeft:
        (index - this.data.current) * this.data.moveDistance +
        this.data.offsetLeft,
      tabBarCilcked: true,
    })
  },
  bindViewGoOrderDetail(e) {
    // 点击订单进入订单详情
    let orderitem = e.currentTarget.dataset.orderitem
    const query = queryString({
      id: orderitem.orderId,
      type: orderitem.externalOrderId,
    })
    app.router.navigateTo(`/sub/Order/pages/orderdetail/orderdetail?${query}`)
  },
  bindViewClickTabItem(e) {
    // 点击切换tab不同订单   21等待支付，31等待发货， 41等待收货， 51等待评价，61已完成， 71客户已取消，72系统取消
    wx.pageScrollTo({
      scrollTop: 0,
      duration: 0,
    })
    const dataset = e.currentTarget.dataset
    let status = dataset.status
    const index = dataset.index
    if (index === this.data.current) {
      return
    }
    this.setData({
      idx: status,
      isShowReloadBtn: false,
      current: index,
      offsetLeft:
        (index - this.data.current) * this.data.moveDistance +
        this.data.offsetLeft,
      tabBarCilcked: true,
    })
    if (this.data.orderDatas[index]['orders'].length === 0) {
      this.bindViewOrderList(status)
    }
  },
  handleLoadMore() {
    let current = this.data.current
    let noMore = this.data.orderDatas[current].noMore
    if (!noMore) {
      this.loadMore()
    }
  },
  loadMore() {
    let current = this.data.current
    let data = {
      account: app.globalData.openid,
      accountId: app.globalData.accountId,
      tenantCode: app.globalData.tenantCode,
      orderStatus: this.data.idx,
      pageIndex: ++this.data.orderDatas[current].lastPage,
      pageSize: 3,
      months: 3,
    }
    this.setData({
      moreLoading: true,
    })
    if (!app.globalData.xAuthToken) {
      apiReload
        .getOpenIdAndAuthParam(app)
        .then(() => {
          this.queryOrders(data)
        })
        .catch(() => {
          wx.showToast({
            title: '网络超时，请稍后再试',
            icon: 'none',
          })
        })
    } else {
      this.queryOrders(data)
    }
  },
  queryOrders(data) {
    let current = this.data.current
    queryOrder(data, {
      xAuthToken: app.globalData.xAuthToken,
    })
      .then(res => {
        if (res.head.code === '0') {
          let orderData = res.body.orderQueryOutPageInfo.list
          const totalPages = res.body.orderQueryOutPageInfo.pages
          const pageNum = res.body.orderQueryOutPageInfo.pageNum
          let lastPage = this.data.orderDatas[current].lastPage
          if (
            totalPages === 0 ||
            lastPage > totalPages ||
            pageNum > totalPages
          ) {
            wx.hideLoading()
            let currentnoMore = 'orderDatas[' + current + '].noMore'
            this.setData({
              [currentnoMore]: true,
              listLoading: false,
              moreLoading: false,
            })
          } else {
            // TODO 更多数据
            let queryDetailLists = []
            let pintuanIds = []
            orderData.forEach((item, index) => {
              if (item.externalOrderId === HONGHU_PINTUAN) {
                pintuanIds.push(item.orderId)
              }
              let data1 = {
                orderId: item.orderId,
                tenantCode: app.globalData.tenantCode,
              }
              var task = queryOrderOpenDetail(data1, {
                xAuthToken: app.globalData.xAuthToken,
              })
              queryDetailLists.push(task)
            })
            Promise.all(queryDetailLists)
              .then(details => {
                // merge datas
                // var removelist = []
                for (let i = 0, ilen = details.length; i < ilen; i++) {
                  var currentdetail = details[i]
                  if (currentdetail.head.code === '0') {
                    let allCount = 0
                    var productlist = currentdetail.body.orderPorductOutList
                    productlist.forEach(item => {
                      allCount += item.count
                    })
                    orderData[i].clickPay = false
                    orderData[i].orderReceiptInfoOut =
                      currentdetail.body.orderReceiptInfoOut
                    orderData[i].productlist = productlist
                    orderData[i].allCount = allCount
                    orderData[i].amount = transformPrice(orderData[i].amount)
                    orderData[i].distributionType =
                      currentdetail.body.distributionType
                    orderData[i].freight = currentdetail.body.freight
                    orderData[i].status = currentdetail.body.orderStatus
                    // 矫正全部订单中 订单状态为已取消 的待支付订单 (订单自动取消的  时间差导致的bug)
                    if (current === 0) {
                      if (
                        currentdetail.body.orderStatus === '72' ||
                        currentdetail.body.orderStatus === '71'
                      ) {
                        orderData[i].orderStatus = '71'
                        orderData[i].orderStatusName = '已取消'
                      }
                    }
                  } else {
                    this.setData({
                      isShowReloadBtn: true,
                      listLoading: false,
                    })
                    break
                  }
                }
                if (pintuanIds.length > 0) {
                  // TODO 拼团处理后重设  orderdata
                  this.getPintuanOrders(pintuanIds, orderData, data.orderStatus)
                } else {
                  // TODO 拼团 处理完后 关闭loading 渲染数据
                  // 剔除 待支付订单列表中 订单状态不是待支付的订单 (订单自动取消的  时间差导致的bug)
                  if (current === 1) {
                    orderData = orderData.filter(item => {
                      return item.status === '21'
                    })
                  }
                  let currentorder = 'orderDatas[' + current + '].orders'
                  let currentTabOrder = this.data.orderDatas[current].orders
                  this.setData({
                    [currentorder]: currentTabOrder.concat(orderData),
                    listLoading: false,
                    moreLoading: false,
                  })
                  // 数量小于3个自动加载下一页
                  if (currentTabOrder.concat(orderData).length < 3) {
                    this.loadMore()
                  }
                }
                wx.hideLoading()
              })
              .catch(e => {
                wx.hideLoading()
                this.setData({
                  isShowReloadBtn: true,
                  listLoading: false,
                  moreLoading: false,
                })
              })
          }
        } else {
          this.setData({
            isShowReloadBtn: true,
            listLoading: false,
            moreLoading: false,
          })
        }
      })
      .catch(() => {
        wx.hideLoading()
        this.setData({
          isShowReloadBtn: true,
          listLoading: false,
          moreLoading: false,
        })
      })
  },
  bindViewOrderList(status) {
    // 初始化请求订单接口
    wx.showLoading({
      title: '数据加载中',
    })
    let current = this.data.current
    let currenttab = 'orderDatas[' + current + '].lastPage'
    this.setData({
      [currenttab]: 1,
      listLoading: true,
    })
    let data = {
      account: app.globalData.openid,
      accountId: app.globalData.accountId,
      tenantCode: app.globalData.tenantCode,
      orderStatus: status,
      pageIndex: this.data.orderDatas[current].lastPage,
      pageSize: 3,
      months: 3,
    }
    if (this.data.orderDatas[current].lastPage === 1) {
      let currentorder = 'orderDatas[' + current + '].orders'
      this.setData({
        [currentorder]: [],
      })
    }
    if (!app.globalData.xAuthToken) {
      apiReload
        .getOpenIdAndAuthParam(app)
        .then(() => {
          this.queryOrders(data)
        })
        .catch(() => {
          wx.showToast({
            title: '网络超时，请稍后再试',
            icon: 'none',
          })
        })
    } else {
      this.queryOrders(data)
    }
  },
  getPintuanOrders(ids, orderData, orderStatus) {
    function filterPaidPintuanOrderWhenOrderStatusIsWaitPaid(orderList) {
      if (orderStatus !== '21') {
        return orderList
      }

      return orderList.filter(order => {
        return (
          !order.pintuanOrder ||
          order.pintuanOrder.status === HONGHU_ORDER_STATUS_KEY.CREATED
        )
      })
    }
    showLoading()
    getOrderCodesAction(ids)
      .then(res => {
        hideLoading()
        res.forEach(order => {
          for (const item of orderData) {
            // if (
            //   this.data.idx === '21' &&
            //   (order.status === 'PAID' || order.status === 'PENDING_TO_REFUND')
            // ) {
            //   const delIndex = orderData.findIndex(
            //     od => od.orderId === order.code
            //   )
            //   orderData.splice(delIndex, 1)
            //   break
            // }
            // 显示待支付的拼团订单
            if (order.code === item.orderId) {
              item.pintuanOrder = {
                id: order.id,
                code: order.code,
                isCreated:
                  order.team.status === TEAM_STATUS_KEY.CREATED ||
                  order.status === HONGHU_ORDER_STATUS_KEY.CREATED,
                isStarted:
                  order.team.status === TEAM_STATUS_KEY.STARTED &&
                  order.status === HONGHU_ORDER_STATUS_KEY.PAID,
                isFailed: order.team.status === TEAM_STATUS_KEY.FAILED,
                isCancel: order.status === HONGHU_ORDER_STATUS_KEY.CANCELED,
                status: order.status,
                teamEndTime: order.team.endedAt,
                teamId: order.team.id,
                campaignType: order.team.campaign.type,
                teamStatus:
                  order.status === HONGHU_ORDER_STATUS_KEY.CANCELED
                    ? '已取消'
                    : order.status === HONGHU_ORDER_STATUS_KEY.CREATED
                      ? '待支付'
                      : TEAM_STATUS[order.team.status],
                quantity: order.items.length,
              }
            }
          }
          // delIndexList.reverse().forEach(idx => this.data.orderData.splice(idx, 1))
        })
        let current = this.data.current
        let currentorder = 'orderDatas[' + current + '].orders'
        let currentTabOrder = this.data.orderDatas[current].orders
        this.setData({
          [currentorder]: filterPaidPintuanOrderWhenOrderStatusIsWaitPaid(
            currentTabOrder.concat(orderData)
          ),
          listLoading: false,
          moreLoading: false,
        })
      })
      .catch(() => {
        hideLoading()
        let current = this.data.current
        let currentorder = 'orderDatas[' + current + '].orders'
        let currentTabOrder = this.data.orderDatas[current].orders
        this.setData({
          [currentorder]: filterPaidPintuanOrderWhenOrderStatusIsWaitPaid(
            currentTabOrder.concat(orderData)
          ),
          listLoading: false,
          moreLoading: false,
        })
      })
  },
  refreshCountdown() {
    this.handleReload()
  },
  handleClickPayBtn({ currentTarget }) {
    if (this.data.clickPay) {
      return
    }
    const index = currentTarget.dataset.index
    let orderData = this.data.orderData
    orderData[index].clickPay = true
    this.setData(
      {
        orderData: orderData,
      },
      () => {
        if (!app.globalData.unexUserToken) {
          apiReload
            .getUnexUserToken(app, app.globalData.openid)
            .then(res => {
              this.bindPayMent(index)
            })
            .catch(() => {
              wx.showToast({
                title: '网络超时，请稍后再试',
                icon: 'none',
              })
            })
        } else {
          this.bindPayMent(index)
        }
      }
    )
  },
  toPay({ currentTarget: { dataset } }) {
    let index = dataset.index
    let orders = this.data.orderDatas[this.data.current]['orders']
    pay(orders[index])
  },
  bindPayMent(index) {
    let orderData = this.data.orderData
    const orderId = orderData[index].orderId
    const orderTime = orderData[index].orderDate.replace(/-|:| /g, '')
    const iphone = orderData[index].orderReceiptInfoOut.mobile
    let $this = this
    // let data = {
    //   'channelType': 'weixin',
    //   'currency': 'cny',
    //   'extendParams': '{"openid":"' + app.globalData.openid + '",\"spbill_create_ip\":\"127.0.0.1\"}',
    //   'memo': brandName + '-订单号' + orderId,
    //   'orderDesc': brandName + '-订单号' + orderId,
    //   'payAmount': this.data.amount,
    //   'paymentType': 'applet',
    //   'tenantCode': app.globalData.tenantCode,
    //   'tenantOrderNo': orderId,
    //   'tenantOrderTime': orderTime,
    //   'tenantReturnUrl': 'https://casabaplus.baozun.com'
    // }
    let data = {
      channelType: 'weixin',
      currency: 'cny',
      extendParams:
        '{"openid":"' +
        app.globalData.openid +
        '","spbill_create_ip":"127.0.0.1"}',
      memo: orderId,
      orderDesc: orderId,
      payAmount: orderData[index].amount,
      //    "pay_sign": "m3gqvBYcgZmSQs71oAg+KNek6orOqTCZDcN89c7btio97duDjzya6MfKtSs8clsukpp2Ca+5u9yvbqErzvsafylvZ47Tl9hZuRWRkd02Ec7+jty7PNxQWJMarOR7UeRTk6Z3chX5cKBH31dAc0Mgl1JUxJzw0kWWqjflvFJbJow=",
      paymentType: 'applet',
      //    "product_type": "",
      tenantCode: app.globalData.tenantCode,
      //    "tenant_expire_time": "",
      tenantOrderNo: orderId,
      tenantOrderTime: orderTime,
      tenantReturnUrl: 'https://casabaplus.baozun.com',
    }
    console.log('订单页支付金额', data.payAmount, this.data.orderData)
    app.http({
      url: '/casaba/trade/payOrder',
      data: data,
      header: {
        xAuthToken: app.globalData.xAuthToken,
        unexUserToken: app.globalData.unexUserToken,
        'invoke-source': app.globalData['invoke-source'],
      },
      success: function(res) {
        console.log('payOrder', res)
        if (res.data.code !== '0') {
          wx.showModal({
            title: '/payOrder',
            content: res.data.msg || res.data.errMsg || '服务器出错',
            showCancel: false,
          })
          orderData[index].clickPay = false
          $this.setData({
            orderData: orderData,
          })
        } else {
          // 发起支付
          wx.requestPayment({
            timeStamp: res.data.data.weixin_timestamp,
            nonceStr: res.data.data.weixin_nonce_str,
            package: res.data.data.weixin_wx_package,
            signType: 'MD5',
            paySign: res.data.data.weixin_sign,
            fail: function(res) {
              console.log('支付', res)
              if (res.errMsg.split(' ')[1] === 'cancel') {
                wx.showToast({
                  title: '取消支付',
                  icon: 'none',
                  duration: 2000,
                })
              } else {
                wx.showModal({
                  title: '调用支付失败',
                  content: res.err_desc || res,
                })
              }
              // wx.navigateTo({
              //   url: '../againMoney/againMoney?orderId=' + orderId,
              // })
              // 目前没有支付失败页面，暂时注释
              // setTimeout(function () {
              //   options.failToUrl && wx.redirectTo({url: options.failToUrl})
              // }, 2000)
            },
            success: function() {
              wx.showToast({
                title: '支付成功',
                icon: 'success',
                duration: 2000,
              })
              setTimeout(function() {
                wx.redirectTo({
                  url:
                    '/sub/Pay/pages/paysuccess/paysuccess?orderId=' +
                    orderId +
                    '&receivedAmount=' +
                    data.payAmount +
                    '&iphone=' +
                    iphone,
                })
                // resolve(res)
              }, 2000)
            },
            complete() {
              orderData[index].clickPay = false
              $this.setData({
                orderData: orderData,
              })
            },
          })
        }
      },
      fail: function(res) {
        orderData[index].clickPay = false
        $this.setData({
          orderData: orderData,
        })
        console.log('支付失败', res)
      },
    })
  },

  handleReload() {
    this.setData({
      isShowReloadBtn: false,
      lastPage: 1,
    })
    this.onLoad({
      idx: this.data.idx,
    })
  },
  pubRefresh() {
    this.setData({
      isShowReloadBtn: false,
      lastPage: 1,
    })
    this.onLoad({
      idx: this.data.idx,
    })
  },
  gotoPintuanDetail(e) {
    const {
      code: orderCode,
      teamId,
      campaignType,
    } = e.target.dataset.pintuanorder
    let query
    if (campaignType === 'CASH_BACK') {
      query = queryString({
        orderId: orderCode,
        teamId: teamId,
      })
      app.router.navigateTo(
        `/honghu/pages/pintuanCashBack/detail/index?${query}`
      )
    } else {
      query = queryString({
        orderId: orderCode,
        teamId: teamId,
      })
      app.router.navigateTo(
        `/sub/Marketing/pages/pintuanDetail/pintuanDetail?${query}`
      )
    }
  },
})
