import { get } from '../../../../utils/storage.js'

const app = getApp()
Page({
  data: {
    name: '申请退款选择页面',
  },
  onLoad() {
    const ro = get('refundOrder', null)
    this.setData({
      rejectedProduct: ro,
      isMajorCustomer: app.globalData.isMajorCustomer,
    })
    console.log(ro)
  },
  goRefund({ currentTarget: { dataset } }) {
    app.router.redirectTo(
      `/sub/AfterSales/pages/rejectedGoods/rejectedGoods?mode=${dataset.flag}`
    )
  },
})
