export default {
  SECKILL: {
    type: 'SeckillCampaign',
    name: '秒杀',
  },
  BARGAIN: {
    type: 'BargainCampaign',
    name: '砍价',
  },
  LIMITTIMEDISCOUNTS: {
    type: 'LimitTimeDiscountsCampaign',
    name: '限时折扣',
  },
  STEPPEDGROUPBUY: {
    type: 'SteppedGroupBuyCampaign',
    name: '阶梯团购',
  },
  PINTUAN: {
    type: 'PintuanCampaign',
    name: '返现拼团', // 返现拼团 || 多人拼团
  },
  PACKBUY: {
    type: 'PackBuyCampaign',
    name: '打包一口价',
  },
  REDUCEPRICEBUY: {
    type: 'ReducePriceBuyCampaign',
    name: '降价拍',
  },
}
