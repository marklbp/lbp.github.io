// 分销
const app = getApp()
export default Behavior({
  data: {
    distUser: 0, // 用户自己
    sharerName: '', // 分享人的名称
    sharerDistUser: 0, // 分享人distUser
    sharerOpenId: '', // 分享人的openid
    sameUser: false, // 是否是同一个用户
    commission: -1, // 佣金
  },
  methods: {
    // 回到自己的店铺
    handleBackShop() {
      // 改为原生tabbar跳转
      app.router.navigateTo('/pages/home/home')
      wx.removeStorageSync('sharerOpenId')
      this.setData({
        sharerDistUser: 0,
      })
    },
  },
})
