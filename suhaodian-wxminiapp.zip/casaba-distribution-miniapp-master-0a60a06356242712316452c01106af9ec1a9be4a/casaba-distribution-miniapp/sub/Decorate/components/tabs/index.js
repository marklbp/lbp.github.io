import link from '../../utils/link'
Component({
  properties: {
    tabs: {
      type: Array,
      value: [],
      observer: function(newVal, oldVal) {
        if (newVal.length < oldVal.length) {
          if (this.data.activeIndex === oldVal.length - 1) {
            this.setData({
              activeIndex: 0,
              intoView: 'text0',
            })
          }
        }
      },
    },
    content: {
      type: Object,
      value: {},
    },
  },
  detached() {},
  data: {
    activeIndex: 0,
    intoView: '',
  },
  methods: {
    handleTabs({ currentTarget: { dataset } }) {
      const { index } = dataset
      const { tabs, activeIndex, content } = this.data
      const len = tabs.length
      let intoView
      let direction = ''
      if (index === activeIndex) {
        return
      }
      if (index > activeIndex) {
        direction = 'R'
      } else if (index < activeIndex) {
        direction = 'L'
      }
      if (direction === 'R') {
        if (index >= content.screenNum - 1) {
          intoView = 'text' + index
        }
      } else if (direction === 'L') {
        const diffIndex = len - content.screenNum
        if (index <= diffIndex) {
          intoView = 'text' + (index - 1 <= 2 ? 0 : index - 1)
        }
      }
      this.setData({
        activeIndex: index,
        intoView: intoView || '',
      })
    },
    handleJump({ currentTarget: { dataset } }) {
      const { item } = dataset
      link.bind(this, item.content, item.content.navigation2Url)()
    },
  },
})
