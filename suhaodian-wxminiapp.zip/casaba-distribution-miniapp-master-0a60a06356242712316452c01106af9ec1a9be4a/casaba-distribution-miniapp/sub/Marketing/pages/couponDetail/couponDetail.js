import {
  queryRecommendProd,
  sendCoupon,
  queryCouponDetail,
} from '../../../../api/index'
import apiReload from '../../../../utils/reload'

const app = getApp()
Page({
  /**
   * 页面的初始数据
   */
  data: {
    couponCode: '',
    activityCode: '',
    couponDetail: {
      status: '',
      faceUnit: '',
      faceValue: '',
      conditionValue: '',
      conditionUnit: '',
      validStartTime: '',
      validEndTime: '',
    },
    current: '0',
    isShowReloadBtn: false,
    prodList: [],
    identity: '0', // 0 分享者  1 被分享者
    receiveSuccess: false,
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    wx.showLoading({
      title: '数据加载中',
    })
    this.setData(options, () => {
      this.initLoad()
    })
  },
  initLoad() {
    if (!app.globalData.unexUserToken || !app.globalData.xAuthToken) {
      apiReload
        .getxAuthTokenAndunexUserToken(app)
        .then(res => {
          this.queryCouponDetailfn()
          this.queryRecommendProdfn()
        })
        .catch(() => {
          this.setData({
            isShowReloadBtn: true,
          })
        })
    } else {
      this.queryCouponDetailfn()
      this.queryRecommendProdfn()
    }
  },
  onShareAppMessage() {
    let data = {
      activityCode: this.data.activityCode,
      identity: 1,
      couponCode: this.data.couponCode,
    }
    return {
      title: '优惠券分享',
      path: `/sub/Marketing/pages/couponDetail/couponDetail?activityCode=${
        data.activityCode
      }&identity=${data.identity}&couponCode=${data.couponCode}`,
      // imageUrl: '/assets/coupon/coupon-detail1.png'
    }
  },
  // 领取优惠券 token是否存在判断
  getCoupon() {
    if (!app.globalData.unexUserToken || !app.globalData.xAuthToken) {
      apiReload.getxAuthTokenAndunexUserToken(app).then(res => {
        this.handleGetCoupon()
      })
    } else {
      this.handleGetCoupon()
    }
  },
  // 领取优惠券 接口调用
  handleGetCoupon() {
    sendCoupon(
      {
        activityCode: this.data.activityCode,
        takeLabel: '02',
        memberLevelCode: '18040300000029',
      },
      {
        unexUserToken: app.globalData.unexUserToken,
        'invoke-source': app.globalData['invoke-source'],
      }
    )
      .then(res => {
        if (res.code === '0' && res.data) {
          console.log('领取优惠券成功', res)
          wx.showToast({
            title: '领取成功',
            icon: 'none',
            duration: 1500,
          })
          this.setData({
            receiveSuccess: true,
            couponCode: res.data,
          })
        } else {
          wx.showModal({
            title: '领取',
            content: res.msg,
            showCancel: false,
            confirmColor: '#333',
            success: function() {
              app.router.navigateTo('/pages/home/home')
            },
          })
        }
      })
      .catch(err => {
        wx.showModal({
          title: '领取',
          content: err.msg,
          showCancel: false,
          confirmColor: '#333',
          success: function() {
            app.router.navigateTo('/pages/home/home')
          },
        })
        console.log('领取优惠券err', err)
      })
  },
  // 根据优惠券条码  查询优惠券详情 接口调用
  queryCouponDetailfn() {
    console.log('查询参数', {
      activityCode: this.data.activityCode,
      tenantCode: app.globalData.tenantCode,
    })
    queryCouponDetail(
      {
        activityCode: this.data.activityCode,
        tenantCode: app.globalData.tenantCode,
      },
      {
        unexUserToken: app.globalData.unexUserToken,
        'invoke-source': app.globalData['invoke-source'],
        xAuthToken: app.globalData.xAuthToken,
      }
    )
      .then(res => {
        if (res.code === '0') {
          this.setData({
            couponDetail: res.data,
            isShowReloadBtn: false,
          })
        } else {
          wx.showModal({
            title: '提示',
            content: res.message || '',
            showCancel: false,
            confirmColor: '#333',
          })
          this.setData({
            isShowReloadBtn: false,
          })
        }
        wx.hideLoading()
      })
      .catch(e => {
        wx.showModal({
          title: '提示',
          content: e.msg || '',
          showCancel: false,
          confirmColor: '#333',
          success: function() {
            app.router.navigateBack()
          },
        })
        wx.hideLoading()
        this.setData({
          isShowReloadBtn: true,
        })
      })
  },
  // 根据活动 activityCode 查询该活动推荐的商品列表
  queryRecommendProdfn() {
    queryRecommendProd(
      {
        activityCode: this.data.activityCode,
        tenantCode: app.globalData.tenantCode,
      },
      {
        xAuthToken: app.globalData.xAuthToken,
        unexUserToken: app.globalData.unexUserToken,
        'invoke-source': app.globalData['invoke-source'],
      }
    )
      .then(res => {
        if (res.code === '0') {
          this.setData({
            prodList: res.data,
          })
        }
      })
      .catch(e => {
        // this.setData({
        //   isShowReloadBtn: true,
        // })
      })
  },
  handleReload() {
    this.initLoad()
  },
  // 进入该店铺首页
  gotoShop() {
    app.router.navigateTo('/pages/home/home')
  },
  // 查看推荐商品详情
  recoProdDetail(e) {
    let code = e.currentTarget.dataset.code
    let src = e.currentTarget.dataset.src
    app.router.navigateTo(
      `/sub/Commodity/pages/pdp/pdp?spuCode=${code}&src=${src}`
    )
  },
})
