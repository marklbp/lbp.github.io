import {
  getReturnDetail,
  closeRefundment,
  queryOrderOpenDetail,
} from '../../../../api/index.js'
import { get } from '../../../../utils/storage.js'
const app = getApp()

// 退换货状态 11、等待审核；21、待商家收货；31、产品质检；41、换货；51、待退款；61、已完成；71、已取消 81 审核未通过
Page({
  data: {
    isShowReloadBtn: false,
    isShowUndoOrder: false,
    listLoading: false,
    refundConfirmLoading: false,
    returnId: '',
    productlist: [],
    refundment: null,
    refundTotalCount: 0,
  },
  onLoad: function(query) {
    this.setData({ returnId: query.returnId })
    this.initLoad()
  },
  initLoad() {
    this.setData({ listLoading: true })
    getReturnDetail({
      tenantCode: app.globalData.tenantCode,
      orderId: this.data.returnId,
    })
      .then(res => {
        if (res.code === '0') {
          const result = res.data[0]
          const ro = get('refundOrder', [])
          let refundTotalCount = 0
          let _product = []
          var temp = []
          temp.push(ro)
          console.log('temp', temp)
          if (ro && ro.length !== 0) {
            _product = result.lines.map(i => {
              const someItem = temp.find(j => j.skuId === i.skuId)
              if (someItem) {
                return {
                  ...someItem,
                  ...i,
                }
              } else {
                return i
              }
            })
          }

          _product.forEach(i => {
            // i.isGift === undefined 防止getStorageSync出错的判断
            if (i.isGift === '0' || i.isGift === undefined) {
              refundTotalCount += i.count
            }
          })

          this.setData({
            refundment: result,
            refundTotalCount: refundTotalCount,
            productlist: _product,
            listLoading: false,
            isShowReloadBtn: false,
          })
        }
      })
      .catch(e => {
        console.error(e)
        this.setData({
          listLoading: false,
          isShowReloadBtn: true,
        })
      })
  },
  handleReload() {
    this.setData({ isShowReloadBtn: false })
    this.initLoad()
  },
  handleContact() {
    wx.request({
      url:
        'https://api.weixin.qq.com/cgi-bin/message/custom/send?access_token=ACCESS_TOKEN',
    })
  },
  hideUndoOrder() {
    this.setData({ isShowUndoOrder: false })
  },
  handleUndoApplyFor() {
    this.setData({ isShowUndoOrder: true })
  },
  handleHideUndoOrder({ currentTarget: { dataset } }) {
    if (dataset.type === 'confirm') {
      this.setData({ refundConfirmLoading: true })
      closeRefundment({
        returnId: this.data.returnId,
      })
        .then(res => {
          if (res.code === '0') {
            this.setData({
              refundConfirmLoading: false,
              isShowUndoOrder: false,
              'refundment.status': '71',
            })
            const route = getCurrentPages()
            if (route[route.length - 1].pubRefresh) {
              route[route.length - 1].pubRefresh()
            }
            wx.showToast({
              title: '撤销退款申请成功',
              icon: 'none',
            })
            this.queryOrderOpenDetail()
          }
        })
        .catch(() => {
          this.setData({
            refundConfirmLoading: false,
            isShowUndoOrder: false,
          })
        })
    } else {
      this.setData({ isShowUndoOrder: false })
    }
  },
  queryOrderOpenDetail() {
    var refundOrder = wx.getStorageSync('refundOrder')
    refundOrder = JSON.parse(refundOrder)
    queryOrderOpenDetail(
      {
        orderId: refundOrder.orderId,
        tenantCode: app.globalData.tenantCode,
      },
      {
        xAuthToken: app.globalData.xAuthToken,
      }
    )
      .then(res => {
        if (res.head.code === '0') {
          const productlist = res.body.orderPorductOutList
          const currentproduct = productlist.find(
            j => j.skuId === refundOrder.skuId
          )
          wx.setStorageSync(
            'refundOrder',
            JSON.stringify({
              ...currentproduct,
              orderStatus: res.body.orderStatus,
            })
          )
        } else {
          this.setData({
            refundConfirmLoading: false,
            isShowUndoOrder: false,
          })
        }
      })
      .catch(e => {
        this.setData({
          refundConfirmLoading: false,
          isShowUndoOrder: false,
        })
      })
  },
  handleReloadApplyFor() {
    app.router.redirectTo(
      `/sub/AfterSales/pages/rejectedGoods/rejectedGoods?mode=0`
    )
  },
})
