/*
* @Author: mengxiaofei
* @Date:   2019-01-18 14:26:57
* @Last Modified by:   mengxiaofei
* @Last Modified time: 2019-03-18 15:38:43
*/
const app = getApp()
/**
 * 数据说明
 * @Author mengxiaofei
 * @Date   2019-01-18T16:17:49+0800
 * tabs:
 * [{
 *  name: 'xx', String   // 显示的tab名称
 *  canActive: true, Boolean  默认true // 是否显示可激活状态
 *  dividingLine: false, Boolean 默认false // 是否在左侧显示分割线
 * }]
 */
Component({
  externalClasses: ['u-class'],
  properties: {
    tabs: {
      type: Array,
      value: [],
      observer: function(val) {
        let result = val.map(item => {
          if (!item.hasOwnProperty('canActive')) {
            return Object.assign(item, {
              canActive: true,
            })
          } else {
            return item
          }
        })
        this.setData({
          handledTabs: result,
        })
      },
    },
  },
  options: {
    multipleSlots: true,
  },
  data: {
    current: 0,
    offsetLeft: 16,
    moveDistance: 0,
    handledTabs: [],
    shopStyle: {
      color: '#fff',
      selectedColor: '#333333',
      auxiliaryColor: '#F4766E',
    },
  },
  attached() {
    this.setData({
      shopStyle: {
        color: app.globalData.shopStyle[0],
        selectedColor: app.globalData.shopStyle[1],
        auxiliaryColor: app.globalData.shopStyle[2],
      },
    })
  },
  ready() {
    this.calcOffset(0)
  },
  methods: {
    calcOffset(index) {
      const query = wx.createSelectorQuery().in(this)
      query
        .select('.category_item')
        .fields(
          {
            size: true,
          },
          res => {
            const offsetLeft = this.data.offsetLeft + res.width / 2 - 14
            const moveDistance = res.width
            this.setData({
              offsetLeft: offsetLeft + index * moveDistance,
              moveDistance: moveDistance,
              current: index,
            })
          }
        )
        .exec()
    },
    bindEvent({ currentTarget: { dataset } }) {
      let currentTab = dataset.item
      let index = dataset.index
      if (currentTab.canActive) {
        // const query = wx.createSelectorQuery().in(this)
        // query
        //   .select('.category_item > .category__text')
        //   .fields({
        //     rect: true,
        //     size: true
        //   }, res => {
        //     console.log(res)
        //   }).exec()
        let offsetLeft =
          (index - this.data.current) * this.data.moveDistance +
          this.data.offsetLeft
        if (currentTab.showIcon) {
          offsetLeft = offsetLeft - 8
        } else {
          if (
            (offsetLeft - this.data.moveDistance / 2 + 14) %
            this.data.moveDistance !==
            16
          ) {
            offsetLeft += 8
          }
        }
        if (index !== this.data.current) {
          this.setData({
            offsetLeft: offsetLeft,
          })
        }
        this.setData({
          current: index,
        })
      }
      this.triggerEvent(
        'change',
        Object.assign(currentTab, {
          index,
        })
      )
    },
  },
})
