/*
* @Author: mengxiaofei
* @Date:   2019-02-20 11:19:56
* @Last Modified by:   mengxiaofei
* @Last Modified time: 2019-03-25 11:19:44
*/
import { getBrandList, queryProdCategory } from '../../../../../api/index'
const app = getApp()
export default Behavior({
  data: {
    prodTypeAllList: [], // 展开后的分类列表
    brandList: [], // 品牌列表
    labelList: [], // 标签列表
    prodTypeList: [], // 筛选条件列表
    currentType: 0, // 当前商品的商品类型
    condition1: false, // 一级筛选条件不显示
    condition2: false, // 二级筛选条件不显示
    currentChoseType: null, // 当前选择的分类
    currentSelectBrand: [], // 当前选择的品牌
    currentSelectLabel: [], // 当前选择的标签
    minPrice: '', // 筛选最低价
    maxPrice: '', // 筛选最高价
    showBrandMore: false,
    showLabelMore: false,
    prodTypeNotInCondition1: false,
  },
  methods: {
    // tab 筛选
    // 最新
    handleNewProduct(index) {
      wx.pageScrollTo({
        scrollTop: 0,
        duration: 0,
      })
      this.setData({
        itemSortList: 'list_time',
        isActive: index,
        listLoading: true,
        lastPage: 1,
        noMore: false,
        productListData: [],
      })
      this.getProductList()
    },
    // 最热
    handleHotProduct(index) {
      wx.pageScrollTo({
        scrollTop: 0,
        duration: 0,
      })
      this.setData({
        itemSortList: 'sales',
        isActive: index,
        listLoading: true,
        lastPage: 1,
        noMore: false,
        productListData: [],
      })
      this.getProductList()
    },
    // 价格
    handlePriceProduct(index) {
      wx.pageScrollTo({
        scrollTop: 0,
        duration: 0,
      })
      let upSort = true
      if (index === this.data.isActive) {
        upSort = !this.data.upSort
      }
      this.setData({
        itemSortList: 'sale_price',
        upSort: upSort,
        isActive: index,
        listLoading: true,
        lastPage: 1,
        noMore: false,
        productListData: [],
      })
      this.getProductList()
    },
    // 筛选弹窗
    // 商品筛选
    showCondition1() {
      Promise.all([
        getBrandList(
          {},
          {
            unexUserToken: app.globalData.unexUserToken,
          }
        ),
        queryProdCategory({
          tenantCode: app.globalData.tenantCode,
        }),
      ])
        .then(response => {
          let brands = response[0]
          let categorys = response[1]
          if (categorys.code === '0' && brands.code === '0') {
            // 分类
            let result = []
            categorys.data.data.forEach(item => {
              result.push(item)
              if (item.children) {
                result = result.concat(item.children)
              }
            })
            // 品牌
            let currentSelectBrand = this.data.currentSelectBrand
            let sourceBrand = brands.data.data
            let brandList = sourceBrand.map(item => {
              item.selected = currentSelectBrand.includes(item.brandCode)
              return item
            })
            this.setData({
              brandList: brandList,
              prodTypeList: categorys.data.data,
              prodTypeAllList: result,
              condition1: true,
            })
          } else {
            if (brands.code !== '0') {
              wx.showToast({
                title: '请求品牌列表失败',
                icon: 'none',
              })
            }
            if (categorys.code !== '0') {
              wx.showToast({
                title: '请求分类列表失败',
                icon: 'none',
              })
            }
          }
        })
        .catch(e => {
          wx.showToast({
            title: '请求分类/品牌失败',
            icon: 'none',
          })
          console.log('请求分类/品牌err', e)
        })
    },
    hideCondition1() {
      this.setData({
        condition1: false,
      })
    },
    showMoreProdType() {
      this.setData({
        condition2: true,
      })
    },
    hideCondition2() {
      this.setData({
        condition2: false,
      })
    },
    handleShowBrand() {
      let showBrandMore = this.data.showBrandMore
      this.setData({
        showBrandMore: !showBrandMore,
      })
    },
    // handleShowLabel() {
    //   let showLabelMore = this.data.showLabelMore
    //   this.setData({
    //     showLabelMore: !showLabelMore
    //   })
    // },
    // 一级筛选列表中 ， 选择分类
    choseProdType({ currentTarget: { dataset } }) {
      let currentChoseType = this.data.currentChoseType
      this.setData(
        {
          currentChoseType:
            !currentChoseType || dataset.item.id !== currentChoseType.id
              ? dataset.item
              : null,
          prodTypeNotInCondition1: false,
        },
        () => {
          currentChoseType = this.data.currentChoseType
          wx.setNavigationBarTitle({
            title: currentChoseType ? currentChoseType.name : '全部商品',
          })
        }
      )
    },
    // 选择品牌
    handleChoseBrand({ currentTarget: { dataset } }) {
      let currentSelectBrand = this.data.currentSelectBrand
      let brandList = this.data.brandList
      let some = brandList.find(item => {
        return item.brandCode === dataset.item.brandCode
      })
      if (currentSelectBrand.includes(dataset.item.brandCode)) {
        let index = currentSelectBrand.findIndex(brandCode => {
          return brandCode === dataset.item.brandCode
        })
        currentSelectBrand.splice(index, 1)
        some.selected = false
      } else {
        currentSelectBrand.push(dataset.item.brandCode)
        some.selected = true
      }
      this.setData({
        currentSelectBrand: currentSelectBrand,
        brandList: brandList,
      })
    },
    handleChoseLabel({ currentTarget: { dataset } }) {
      let currentSelectLabel = this.data.currentSelectLabel
      let labelList = this.data.labelList
      let some = labelList.find(item => {
        return item.id === dataset.item.id
      })
      if (currentSelectLabel.includes(dataset.item.id)) {
        let index = currentSelectLabel.findIndex(id => {
          return id === dataset.item.id
        })
        currentSelectLabel.splice(index, 1)
        some.selected = false
      } else {
        currentSelectLabel.push(dataset.item.id)
        some.selected = true
      }
      this.setData({
        currentSelectLabel: currentSelectLabel,
        labelList: labelList,
      })
    },
    // 重置搜索条件
    resetChosed() {
      let brandList = this.data.brandList
      let labelList = this.data.labelList
      brandList = brandList.map(item => {
        return Object.assign(item, {
          selected: false,
        })
      })
      labelList = labelList.map(item => {
        return Object.assign(item, {
          selected: false,
        })
      })
      wx.setNavigationBarTitle({
        title: '全部商品',
      })
      this.setData({
        currentChoseType: null,
        currentSelectBrand: [],
        currentSelectLabel: [],
        minPrice: '',
        maxPrice: '',
        brandList: brandList,
        labelList: labelList,
        prodTypeNotInCondition1: false,
      })
    },
    bindblurGetMinPrice({ detail: { value } }) {
      this.setData({
        minPrice: value,
      })
    },
    bindblurGetMaxPrice({ detail: { value } }) {
      this.setData({
        maxPrice: value,
      })
    },
    // 根据搜索条件进行筛选
    searchProd() {
      let currentChoseType = this.data.currentChoseType
      let prodTypeChooseList = currentChoseType ? [currentChoseType.code] : []
      this.setData({
        prodTypeChooseList: prodTypeChooseList,
      })
      // 执行搜索
      this.searchProdType()
      // 关闭弹窗
      this.setData({
        condition1: false,
      })
    },
    // 二级筛选选择分类
    handleChooseType({ currentTarget: { dataset } }) {
      function objInArray(obj, array, length) {
        let handleArr = array.slice(0, length)
        let result = handleArr.findIndex(function(item) {
          return item.id === obj.id
        })
        return Boolean(result === -1)
      }
      let prodTypeNotInCondition1 = objInArray(
        dataset.item,
        this.data.prodTypeAllList,
        3
      )
      this.setData(
        {
          currentChoseType: dataset.item,
          condition2: false,
          prodTypeNotInCondition1: prodTypeNotInCondition1,
        },
        () => {
          wx.setNavigationBarTitle({
            title: dataset.item.name,
          })
        }
      )
    },
    // 全部
    resetProdType() {
      this.setData({
        prodTypeChooseList: [],
        condition2: false,
        prodTypeNotInCondition1: false,
        currentChoseType: null,
      })

      // this.searchProdType()
      wx.setNavigationBarTitle({
        title: '全部商品',
      })
    },
    // 查看分类
    searchProdType() {
      this.setData({
        listLoading: true,
        lastPage: 1,
        showProdType: false,
        noMore: false,
      })
      this.getProductList()
    },
  },
})
