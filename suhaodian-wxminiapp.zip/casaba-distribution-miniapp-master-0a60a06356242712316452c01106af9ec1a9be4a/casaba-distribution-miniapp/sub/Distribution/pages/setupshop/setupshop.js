import apiReload from '../../../../utils/reload'
import {
  registerDistUser,
  // getOpenIdByAccountId,
  updateUserInfo,
  getPhone,
  queryPromotionPlan,
  queryDistributionConfigureName,
} from '../../../../api/index'
const app = getApp()
Page({
  data: {
    sharerOpenId: '',
    accountId: '',
    distributFlag: null, // 分销开关
    recruitFlag: null, // 招募开关
    auditStatus: null,
    showLoading: false,
    timer: null,
    testHtml: '',
    distributionConfigureName: '',
  },
  onPullDownRefresh() {},
  onShow() {
    this.showLoading = true
    queryPromotionPlan({
      tenantCode: app.globalData.tenantCode,
    }).then(
      res => {
        if (
          res.code == '0' &&
          res.data != null &&
          typeof res.data.title !== 'undefined'
        ) {
          wx.setNavigationBarTitle({
            title: res.data.title,
          })
          this.setHtml(res.data.mainBody)
        }
      },
      rej => {
        console.log('rej', rej)
      }
    )
    queryDistributionConfigureName({
      tenantCode: app.globalData.tenantCode,
    }).then(res => {
      const { success, data } = res
      if (success) {
        this.setData({
          distributionConfigureName: data,
        })
      }
      console.log('res', res)
    })

    Promise.all([this.getAuditStatus(), this.getStatus()])
      .then(res => {
        console.log('完成所有请求')
        this.showLoading = false
      })
      .catch(err => {
        console.log('其中的请求失败', err)
      })
  },
  onLoad(query) {
    if (query.sharerOpenId) {
      this.setData({
        sharerOpenId: query.sharerOpenId,
      })
    }
    const distUser = wx.getStorageSync('distUser')
    console.log('setupshop=====', query, distUser)
    if (distUser == 1) {
      console.log('onLoadDistUser1', distUser)
      this.onLoadReady({})
    } else {
      console.log('load.data.distributorStatus', 1)
      setTimeout(() => {
        if (query.sharerOpenId) {
          this.setData({
            sharerOpenId: query.sharerOpenId,
          })
          this.getAuditStatus(load => {})
            .then(load => {
              console.log(
                'load.data.distributorStatus',
                load,
                load.data.data.distributorStatus,
                load.data.data.distributorStatus == 0
              )
              if (load.data.data.distributorStatus == 0) {
                this.onLoadReady(query)
                wx.setStorageSync('sharerOpenId', query.sharerOpenId)
              }
            })
            .catch(err => {
              console.log('捕获异常', err)
            })
        }
      }, 1000)
    }
  },
  setHtml(html) {
    html = html.replace(/"/g, '"')
    html = html.replace(/<mark/g, '<span')
    html = html.replace(/<\/mark/g, '</span')
    html = html.replace(/<figure/g, '<div')
    html = html.replace(/<\/figure/g, '</div')
    html = html.replace(/<img/g, '<img class="image_imgs" ')
    html = html.replace(/<p/g, '<p class="rick_box_p" ')
    this.setData({
      testHtml: '<div class="rick_box">' + html + '</div>',
    })
  },
  onLoadReady(query) {
    const distUser = wx.getStorageSync('distUser')
    if (distUser == 1) {
      const route = getCurrentPages()
      if (route.length === 1) {
        // 改为原生tabbar跳转
        // app.router.navigateTo('/pages/account/account')
      } else {
        wx.showModal({
          title: '',
          content: '你已经开过店铺了，无需再次操作',
          showCancel: false,
          success: () => {
            wx.navigateBack()
          },
        })
      }
    }
  },
  pollingData(detail) {
    if (this.data.timer) {
      return
    }
    let pollingCount = 0
    const timer = setInterval(() => {
      if (!app.globalData.openid || !app.globalData.accountId) {
        pollingCount++
        if (pollingCount > 60) {
          clearInterval(timer)
          this.setData({
            timer: null,
          })
          apiReload
            .getOpenIdAndAuthParam(app)
            .then(res => {
              updateUserInfo(
                {
                  id: app.globalData.accountId,
                  openId: app.globalData.openid,
                  userName: detail.userInfo.nickName,
                  userPhoto: detail.userInfo.avatarUrl,
                },
                {
                  unexUserToken: app.globalData.unexUserToken,
                }
              )
            })
            .catch(() => {
              console.error('获取openid或unexusertoken出错')
            })
        }
      } else {
        clearInterval(timer)
        updateUserInfo(
          {
            id: app.globalData.accountId,
            openId: app.globalData.openid,
            userName: detail.userInfo.nickName,
            userPhoto: detail.userInfo.avatarUrl,
          },
          {
            unexUserToken: app.globalData.unexUserToken,
          }
        )
        this.setData({
          timer: null,
        })
      }
    }, 100)
    this.setData({
      timer: timer,
    })
  },
  /**
   * 微信授权，成功回调
   */
  onSuccess({ detail }) {
    app.globalData.userInfo = detail.userInfo
    this.pollingData(detail)
    this.handleRegisterDistUser()
  },
  /**
   * 获取手机号码
   */
  getPhoneNumber(e) {
    // debugger
    const details = e.detail
    console.log(e.detail.errMsg)
    console.log(e.detail.iv)
    console.log(e.detail.encryptedData)
    const promise = getPhone({
      iv: details.iv,
      encrypted: details.encryptedData,
      sessionKey: wx.getStorageSync('session_key'),
      tenantCode: app.globalData.tenantCode,
      memberId: wx.getStorageSync('accountId'),
    })
    promise.then(res => {
      // wx.showModal({
      //   title: 'ceshi',
      //   content: res.data.data.phoneNumber,
      // })
    })

    if (Object.is(wx.getStorageSync('distUser'), '0')) {
      this.handleRegisterDistUser()
    } else {
      const route = getCurrentPages()
      if (route.length === 1) {
        app.router.navigateTo('/pages/account/account')
      } else {
        wx.navigateBack({
          delta: route.length - 1,
          success: () => {
            if (route[0].pubRefresh) {
              route[0].pubRefresh('account')
            }
          },
        })
      }
    }
  },
  /**
   * 注册成为分销员
   */
  handleRegisterDistUser() {
    console.log('registerDistUser', {
      sharedUserOpenid: this.data.sharerOpenId,
      openid: app.globalData.openid,
      tenantCode: app.globalData.tenantCode,
      userCode: app.globalData.userCode,
    })
    // if (!app.globalData.userId) {
    registerDistUser({
      sharedUserOpenid: this.data.sharerOpenId,
      openid: app.globalData.openid,
      tenantCode: app.globalData.tenantCode,
      userCode: app.globalData.userCode,
    })
      .then(res => {
        if (res.statusCode == 200) {
          wx.setStorageSync('userId', res.data.id)
          wx.setStorageSync('auditStatus', res.data.distributorStatus)
          if (res.data.distributorStatus == 0) {
            wx.setStorageSync('distUser', '1')
          }
          console.log('注册成为分销员', res.data)
          this.handleOpenShop(res.data.id, load => {
            const route = getCurrentPages()
            if (route.length === 1) {
              app.router.navigateTo('/pages/account/account')
            } else {
              wx.navigateBack({
                delta: route.length - 1,
                success: () => {
                  if (route[0].pubRefresh) {
                    route[0].pubRefresh('account')
                  }
                },
              })
            }
          })
        } else if (res.statusCode == 202) {
          const route = getCurrentPages()
          if (route.length === 1) {
            app.router.navigateTo('/pages/account/account')
          } else {
            wx.navigateBack({
              delta: route.length - 1,
              success: () => {
                if (route[0].pubRefresh) {
                  route[0].pubRefresh('account')
                }
              },
            })
          }
        } else {
          wx.showModal({
            title: '提示',
            content: res.msg,
          })
        }
      })
      .catch(() => {
        console.log('registerDistUser', registerDistUser)
      })
  },
  handleOpenShop(userId, callback) {
    let data = {
      tenantCode: app.globalData.tenantCode,
      userId: userId,
    }
    app.https({
      method: 'POST',
      url: '/shop/insert',
      data: data,
      header: {
        xAuthToken: app.globalData.xAuthToken,
      },
      success: res => {
        console.log('开店', res.data)
        if (res.data.code == 0) {
          if (callback) {
            callback(res)
          }
        }
      },
      fail: function(res) {
        console.log('res', res)
      },
    })
  },
  /**
   * 判断IOS系统
   */
  isIos() {
    const platform = wx.getSystemInfoSync().platform.toLowerCase()
    if (platform.indexOf('ios') !== 0) {
      this.onPullDownRefresh()
    }
  },
  getStatus(resolve = () => {}, reject = () => {}) {
    return new Promise((resolve, reject) => {
      let $this = this
      let data = {
        tenantCode: app.globalData.tenantCode,
      }
      app.https({
        method: 'POST',
        url: '/member/account/tenant/flag',
        data: data,
        header: {
          xAuthToken: app.globalData.xAuthToken,
        },
        success: function(res) {
          if (res.data.code == 0) {
            const result = res.data.data
            $this.setData({
              distributFlag: result.distributFlag,
              recruitFlag: result.recruitFlag,
            })
            console.log($this.data.distributFlag, $this.data.recruitFlag)
          }
        },
        fail: function(res) {
          console.log('res', res)
        },
      })
    })
  },
  getAuditStatus(resolve = () => {}, reject = () => {}) {
    return new Promise(() => {
      let $this = this
      let data = {
        tenantCode: app.globalData.tenantCode,
        openId: app.globalData.openid || wx.getStorageSync('openid'),
      }
      app.https({
        method: 'POST',
        url: '/member/account/user/status',
        data: data,
        header: {
          xAuthToken: app.globalData.xAuthToken,
        },
        success: function(res) {
          resolve(res)
          if (res.data.code == 0) {
            const result = res.data.data
            $this.setData({
              auditStatus: result.distributorStatus,
            })
            if ($this.data.auditStatus == 0) {
              wx.setStorageSync('distUser', '1')
              wx.setStorageSync('auditStatus', '0')
            }
            // if (result.distributorStatus) {
            //   const route = getCurrentPages()
            //   if (route.length === 1) {
            //     console.log('因此跳转')
            //     wx.setStorageSync('tabBarIndex', 3)
            //     wx.redirectTo({
            //       url: '/pages/tabbar/tabbar'
            //     })
            //   }
            // }
          }
        },
        fail: function(res) {
          console.log('res', res)
        },
      })
    })
  },
})
