var behaviorShopStyle = require('../../utils/behavior-shop-style.js')
Component({
  externalClasses: ['u-class'],
  behaviors: [behaviorShopStyle],
  properties: {
    // small || default || large
    size: {
      type: String,
      value: 'default',
    },
    fix: {
      type: Boolean,
      value: false,
    },
    mask: {
      type: Boolean,
      value: true,
    },
    custom: {
      type: Boolean,
      value: false,
    },
  },
})
