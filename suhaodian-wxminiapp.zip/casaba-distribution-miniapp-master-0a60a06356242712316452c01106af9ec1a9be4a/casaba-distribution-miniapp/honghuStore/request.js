/* global getApp, wx */
import request from '../utils/http'
import { showToast } from './uiHelper'

let HH_API_HOST = wx.getStorageSync('HH_API_HOST')
// 同步获取extconfig, 先判断缓存中有没有配置，如果没有则重新获取
if (!HH_API_HOST) {
  const config = wx.getExtConfigSync()
  HH_API_HOST = config.host.HH_API_HOST
}

export default function(data) {
  let app = getApp()

  const header = {
    'X-Tenant-Code': app.globalData.tenantCode,
  }
  if (app.globalData.unexUserToken) {
    header['X-Access-Token'] = app.globalData.unexUserToken
  }
  return request
    .post(HH_API_HOST + '/customer/graphql?', data, {
      header,
    })
    .then(response => {
      if (response.errors && response.errors.length > 0) {
        if (response.errors[0].errorType === 'DataFetchingException') {
          const cause = response.errors[0].cause
          const title = cause && cause.length > 0 ? cause : '服务器异常'
          showToast({ title })
        }
        return Promise.reject(response.errors)
      }
      return response
    })
}
