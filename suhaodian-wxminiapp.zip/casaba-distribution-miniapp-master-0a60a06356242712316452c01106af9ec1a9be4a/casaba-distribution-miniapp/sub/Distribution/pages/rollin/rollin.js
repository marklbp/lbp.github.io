import { transformPrice } from '../../../../utils/util'
const app = getApp()
Page({
  data: {
    money: '',
    bgColor: '#BABABA',
    addColor: '#E4E4E4',
    commissionAmount: '8,534,567.00',
    userId: '',
    disabled: false,
  },
  onLoad() {
    this.bindGet()
    this.queryEarnings()
  },
  bindblurGetNum(e) {
    let val = e.detail.value
    val = val.replace(',', '')
    val = Number.parseFloat(val)
    if (Number.isNaN(val)) {
      this.setData({
        bgColor: '#BABABA',
        addColor: '#E4E4E4',
        disabled: true,
      })
    } else {
      if (val > 0 || val !== '') {
        this.setData({
          money: transformPrice(val),
          bgColor: '#3194FF',
          addColor: '#fff',
          disabled: false,
        })
      } else {
        this.setData({
          bgColor: '#BABABA',
          addColor: '#E4E4E4',
          disabled: true,
        })
      }
    }
  },
  bindGet() {
    if (this.data.money) {
      this.setData({
        bgColor: '#3194FF',
        addColor: '#fff',
        disabled: false,
      })
    } else {
      this.setData({
        bgColor: '#BABABA',
        addColor: '#E4E4E4',
        disabled: true,
      })
    }
  },
  bindGetAll() {
    let amout = Number.parseInt(
      (this.data.commissionAmount + '').replace(/,/gi, '')
    )
    if (amout > 0) {
      this.setData({
        money: transformPrice(amout),
        bgColor: '#3194FF',
        addColor: '#fff',
        disabled: false,
      })
    } else {
      wx.showToast({
        title: '暂无可提现金额',
        icon: 'none',
        duration: 1000,
        mask: true,
      })
      this.setData({
        bgColor: '#BABABA',
        addColor: '#E4E4E4',
        disabled: true,
      })
    }
  },
  queryEarnings() {
    let $this = this
    let data = {
      openId: app.globalData.openid,
    }
    app.https({
      method: 'GET',
      url: '/income/getIncomeInfo',
      data: data,
      header: {
        xAuthToken: app.globalData.xAuthToken,
      },
      success: function(res) {
        let result = res.data.data
        result.commissionAmount = transformPrice(result.commissionAmount / 100)
        $this.setData({
          commissionAmount: result.commissionAmount,
          userId: result.userId,
        })
      },
      fail: function(res) {
        console.log('res', res)
      },
    })
  },
  bindconfirm() {
    // 提现
    let amout = this.data.commissionAmount.replace(/,/gi, '')
    amout = Number.parseInt(amout)
    let $this = this
    let num = Number.parseInt($this.data.money.replace(/,/gi, ''))
    if (!$this.data.disabled) {
      // debugger
      if (num > amout) {
        wx.showToast({
          title: '提现金额不可大于账户金额',
          icon: 'none',
          duration: 1000,
          mask: true,
        })
      } else if (num < 10 || num > 50000) {
        wx.showToast({
          title: '提现金额需要在10-50000之间',
          icon: 'none',
          duration: 1000,
          mask: true,
        })
        return false
      } else {
        let data = {
          userId: $this.data.userId,
          cashAmount: num * 100,
        }
        console.log('data', data)
        app.https({
          method: 'POST',
          url: '/income/cash',
          data: data,
          header: {
            xAuthToken: app.globalData.xAuthToken,
          },
          success: function(res) {
            setTimeout(() => {
              if (res.data.success === true) {
                wx.showToast({
                  title: '提现申请成功',
                  icon: 'none',
                  duration: 1000,
                  mask: true,
                })
              } else {
                wx.showToast({
                  title: res.data.message + '',
                  icon: 'none',
                  duration: 1000,
                  mask: true,
                })
              }
            }, 500)
            setTimeout(() => {
              $this.queryEarnings()
            }, 1000)
          },
          fail: function(res) {
            console.log('res', res.data.message)
          },
        })
      }
    }
  },
})
