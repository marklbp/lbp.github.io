const app = getApp()
Page({
  data: {
    friendsData: [],
    pageNum: 1,
    pageSize: 5,
    hasMoreData: false,
    recruitFlag: '',
    distributFlag: '',
  },
  onLoad(opts) {
    this.setData({
      recruitFlag: opts.recruitFlag,
      distributFlag: opts.distributFlag,
    })
    this.getFriendsLists()
  },
  bindClient() {
    wx.navigateTo({
      url: '../client/client',
    })
  },
  getFriendsLists() {
    let $this = this
    let data = {
      openId: app.globalData.openid || wx.getStorageSync('openid'),
      pageNum: this.data.pageNum,
      pageSize: this.data.pageSize,
      tenantCode: app.globalData.tenantCode,
    }
    app.https({
      method: 'POST',
      url: '/member/user/friend/list',
      data: data,
      header: {
        xAuthToken: app.globalData.xAuthToken,
      },
      success: function(res) {
        if (res.data.code == 0) {
          const friendsData = res.data.data.result
          const total = res.data.data.page.total
          if ($this.data.pageNum >= total / $this.data.pageSize) {
            $this.setData({
              friendsData: $this.data.friendsData.concat(friendsData),
              hasMoreData: false,
            })
          } else {
            $this.setData({
              friendsData: $this.data.friendsData.concat(friendsData),
              hasMoreData: true,
              pageNum: $this.data.pageNum + 1,
            })
          }
        }
      },
      fail: function(res) {
        console.log('res', res)
      },
    })
  },
  onReachBottom() {
    if (this.data.hasMoreData) {
      this.getFriendsLists()
    } else {
      wx.showToast({
        title: '没有更多数据',
        icon: 'none',
        duration: 2000,
        mask: true,
      })
    }
  },
})
