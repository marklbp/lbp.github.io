import link from '../../utils/link'
Component({
  properties: {
    content: {
      type: Object,
      value: null,
    },
  },
  methods: {
    handleJump() {
      const { titleMoreUrl } = this.data.content
      link.bind(this, this.data.content, titleMoreUrl)()
    },
  },
})
