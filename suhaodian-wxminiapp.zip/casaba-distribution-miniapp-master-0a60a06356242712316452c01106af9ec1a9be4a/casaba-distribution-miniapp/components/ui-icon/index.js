Component({
  externalClasses: ['u-class'],
  properties: {
    type: {
      type: String,
      value: '',
    },
    size: {
      type: String,
      value: 14,
    },
    color: {
      type: String,
      value: '',
    },
  },
})
