export const PROCESS_VIEW = {
	"EDITFORM": "编辑流程",
	"DETAIL": "查看流程",
	"PREVIEWPAGE": "预览页面",
	"EDITPAGE": "编辑页面",
	"MATERIAL": "材料清单",
	"EDITAUTH": "编辑权限",
	"VIEWAUTH": "查看权限",
	"VIEWFIELD": "查看字段",
};