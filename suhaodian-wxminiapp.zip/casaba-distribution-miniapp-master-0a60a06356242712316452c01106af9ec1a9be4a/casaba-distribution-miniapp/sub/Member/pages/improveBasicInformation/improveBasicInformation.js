// pages/ImproveBasicInformation/ImproveBasicInformation.js
import { activateMemberCard, getAllAddress } from '../../../../api/index.js'
let regions = []
Page({
  /**
   * 页面的初始数据
   */
  data: {
    username: '',
    wechat: '',
    sex: '01',
    birthday: '1990-01-01',
    provinceContent: null,
    provinceList: [],
    province: 0,
    cityContent: null,
    cityList: [],
    city: 0,
    areaContent: null,
    areaList: [],
    area: 0,
    options: null,
    customItem: '全部',
    effectiveType: 1,
    effectiveDay: 0,
    endTime: '',
    // _regions: [[], [], []],
    // multiIndex: [0, 0, 0],
    region: ['全部', '全部', '全部'],
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    // debugger
    this.setData({
      options,
    })
    this.getAllAddress()
  },
  /**
   * 获取全部地址
   */
  getAllAddress() {
    const promise = getAllAddress()
    promise.then(res => {
      regions = res.data.data
      // this.tranformArray()
      // this.tranformArray(1)
    })
  },
  /**
   * 转换数组
   */
  tranformArray(column = 0, multiIndex = null) {
    const _regions = this.data._regions
    if (!multiIndex) {
      multiIndex = this.data.multiIndex
    }
    switch (column) {
      case 0:
        regions.forEach(region => {
          _regions[column].push(region)
        })
        break
      case 1:
        regions[multiIndex[0]].subCitys.forEach(region => {
          _regions[column].push(region)
        })
        break
      case 2:
        regions[multiIndex[0]].subCitys[multiIndex[1]].subDistricts.forEach(
          region => {
            _regions[column].push(region)
          }
        )
        break
    }
    if (Object.is(_regions[1].length, 1) && Object.is(_regions[2].length, 0)) {
      this.tranformArray(2)
    }
    this.setData({
      _regions,
    })
  },
  /**
   * [bindRegionChange 更新省市区]
   * @param  {[type]} e [description]
   * @return {[type]}   [description]
   */
  bindRegionChange(e) {
    console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      region: e.detail.value,
    })
  },
  /**
   * 改变选项
   */
  bindMultiPickerColumnChange(e) {
    console.log('e', e)
    const _regions = this.data._regions
    const detail = e.detail
    const multiIndex = this.data.multiIndex
    multiIndex[detail.column] = detail.value
    // this.setData({
    //   multiIndex
    // })
    if (Object.is(detail.column, 0)) {
      _regions[2] = []
      multiIndex[2] = 0
    }

    if (detail.column < 2) {
      _regions[detail.column + 1] = []
      // this.setData({
      //   _regions
      // })
      this.tranformArray(detail.column + 1, multiIndex)
    }
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {},
  /**
   *
   */
  updateUsername(e) {},
  /**
   * 提交基本信息
   */
  submitBasicInfo(e) {
    const data = this.data
    const sex = data.sex

    const params = Object.assign({}, e.detail.value, { sex: sex })

    params.province = data.provinceList[data.province]
    params.city = data.cityList[data.city]
    params.area = data.areaList[data.area]
    const birthday = data.birthday
    const options = this.data.options
    const username = params.username
    if (Object.is(username, '')) {
      wx.showModal({
        title: '提示',
        content: '请输入姓名',
      })
      return
    }
    const wechat = params.wechat
    if (Object.is(wechat, '')) {
      wx.showModal({
        title: '提示',
        content: '输入微信号',
      })
      return
    }

    let provinceId = 1
    let cityId = 1
    let districtId = 1
    const region = this.data.region
    try {
      const provinceItem = regions.filter(item => {
        let name = item.name.slice(0, 2)
        let name1 = region[0].slice(0, 2)
        console.log(
          'item.name.slice(0, 2)',
          item.name.slice(0, 2),
          region[0].slice(0, 2)
        )
        if (Object.is(name, name1)) {
          provinceId = item.id
          return true
        }
      })
      const cityItem = provinceItem[0].subCitys.filter(item => {
        if (Object.is(item.name, region[1])) {
          cityId = item.id
          return true
        }
      })
      const districtItem = cityItem[0].subDistricts.filter(item => {
        if (Object.is(item.name, region[2])) {
          districtId = item.id
          return true
        }
      })
      console.log(provinceItem, cityItem, districtItem)
    } catch (e) {
      console.log('没有匹配')
    }
    // debugger
    const promise = activateMemberCard({
      relationId: options.id,
      userId: wx.getStorageSync('distUser'),
      activatieType: options.activateType,
      accountId: options.accountId,
      tenantCode: wx.getStorageSync('tenantCode'),
      name: params.username,
      birthdayYear: birthday.substr(0, 4),
      birthdayMonth: birthday.substring(
        birthday.indexOf('-') + 1,
        birthday.lastIndexOf('-')
      ),
      birthday: birthday.substr(birthday.lastIndexOf('-') + 1),
      mobile: options.phone,
      activeCode: options.activeCode,
      gender: data.sex,
      provinceId: provinceId,
      cityId: cityId,
      province: region[0],
      city: region[1],
      districtId: districtId,
      district: region[2],
    })
    promise.then(res => {
      // debugger
      console.log('res', res)
      const { success, message } = res
      if (success) {
        this.handlerSubmit()
      } else {
        if (Object.is(message, '请勿重复提交激活')) {
          wx.showModal({
            title: '提示',
            content: '不能重复领取',
          })
        } else {
          wx.showModal({
            title: '提示',
            content: message,
          })
        }
      }
    })
  },
  birthdayChange(e) {
    this.setData({
      birthday: e.detail.value,
    })
  },
  /**
   * 处理提交
   */
  handlerSubmit() {
    const data = this.data.options
    let url = `../membershipCardDetails/membershipCardDetails`
    wx.navigateTo({
      url: `${url}?id=${data.id}&activate=${data.activate}&cardcode=${
        data.cardcode
      }&createtime=${data.createtime}&cardName=${data.cardName}&logoUrl=${
        data.logoUrl
      }&coverImage=${data.coverImage}&profitFreeShipping=${
        data.profitFreeShipping
      }&profitDiscount=${data.profitDiscount}&profitCoupon=${
        data.profitCoupon
      }&profitPoint=${data.profitPoint}&merName=${data.merName}&cardDefault=${
        data.cardDefault
      }&backgroundColor=${data.backgroundColor}&size=${data.size}&useRemark=${
        data.useRemark
      }&effectiveType=${data.effectiveType}&effectiveDay=${
        data.effectiveDay
      }&endTime=${data.endTime}`,
    })
  },
  /**
   * 改变性别
   */
  changeSex(e) {
    const sex = e.currentTarget.dataset.sex
    // debugger
    this.setData({
      sex: sex,
    })
  },
})
