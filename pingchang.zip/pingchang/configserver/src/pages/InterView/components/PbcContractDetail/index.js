import PbcContractDetail from './PbcContractDetail';

export default PbcContractDetail;
