import ProcessAuthDetails from './ProcessAuthDetails';

export default ProcessAuthDetails;
