import {
  queryProdCategory,
  getBaseInfo,
  getItemListbyConditionsV1,
  queryCategoryTemplate,
} from '../../../../api/index'
import MARKETING_TYPE from '../../../../constant/marketing-type'
import queryString from '../../../../utils/query-string'
const app = getApp()
Page({
  data: {
    isShowReloadBtn: false,
    searchText: '', // 搜索关键字
    categorys: [],
    currentIndex: 0,
    currentCategory: null,
    bgColor: '#333333',
    allNoneImg: true,
    saleInfo: null,
    moreCategoryStatus: false,
    activeCategoryCode: '',
    lastPage: 1,
    listLoading: false,
    maxPage: 1,
    categoryTemplate: 1,
    prodScrollTop: 0,
  },
  onLoad() {
    this.setData({
      bgColor: app.globalData.shopStyle[1],
    })
  },
  onShow() {
    this.handleGetbaseInfo()
    this.queryCategory(false)
  },
  refreshData() {
    wx.showNavigationBarLoading()
    this.handleGetbaseInfo()
    this.queryCategory(true)
  },
  confirmSearch({ detail }) {
    app.router.navigateTo('/sub/Base/pages/searchdetail/searchdetail')
  },
  clearValue() {
    this.setData({
      searchText: '',
    })
  },
  goplp({ currentTarget: { dataset } }) {
    wx.setStorageSync('toPlpOptions', dataset.item)
    app.router.navigateTo('/sub/Base/pages/searchdetail/searchdetail')
  },
  handleallNoneImg(category, callback) {
    let result = false
    if (category.children) {
      result = category.children.every(j => !j.imageUrl)
    }
    this.setData(
      {
        allNoneImg: result,
      },
      () => {
        callback && callback()
      }
    )
  },
  // 左侧分类点击
  handleCategoryChange({ currentTarget: { dataset } }) {
    this.handleallNoneImg(dataset.item, () => {
      this.setData({
        currentCategory: dataset.item,
        currentIndex: dataset.index,
        activeCategoryCode: dataset.item.code,
      })
    })
    this.setData({
      lastPage: 1,
      listLoading: true,
      prodScrollTop: 0,
    })

    this.getProductList(dataset.item.code)
  },
  // 获取店铺信息
  handleGetbaseInfo() {
    // app.globalData.tenantCode
    getBaseInfo({
      merCode: app.globalData.tenantCode,
    }).then(res => {
      if (res.code === '0' && res.data) {
        wx.setNavigationBarTitle({
          title: res.data.merName,
        })
        this.setData({
          saleInfo: res.data,
        })
      }
    })
  },
  // 刷新左侧分类
  refreshCurrentCategory(categorys) {
    let result
    categorys.forEach(j => {
      if (this.data.currentCategory.id === j.id) {
        result = j
      }
    })
    this.handleallNoneImg(result, () => {
      this.setData({
        currentCategory: result,
      })
    })
  },
  handleImg(arr) {
    return arr.map(item => {
      if (item.imageUrl) {
        if (item.imageUrl.indexOf('http') <= -1) {
          item.imageUrl = 'https://product-res.baozun.com/' + item.imageUrl
        }
      }
      if (item.children) {
        item.children.forEach(j => {
          if (j.imageUrl && j.imageUrl.indexOf('http') <= -1) {
            j.imageUrl = 'https://product-res.baozun.com/' + j.imageUrl
          }
        })
      }
      return item
    })
  },
  // 查询分类
  queryCategory(ispullDown) {
    let params = {
      tenantCode: app.globalData.tenantCode,
    }
    // 分类模版
    queryCategoryTemplate(params).then(res => {
      if (res.code === '0') {
        this.setData({
          categoryTemplate: res.data.selectModelCode,
        })
      }
    })
    queryProdCategory(params).then(res => {
      if (res.code === '0') {
        let result = this.handleImg(res.data.data)
        this.setData({
          categorys: result,
        })
        if (this.data.currentCategory) {
          this.refreshCurrentCategory(result)
        } else {
          this.handleallNoneImg(result[0], () => {
            this.setData({
              currentCategory: result[0],
              activeCategoryCode: result[0].code,
            })
            this.getProductList(result[0].code)
          })
        }
        wx.stopPullDownRefresh()
        wx.hideNavigationBarLoading()
      }
    })
  },
  // 展示更多分类
  showMoreCategory() {
    this.setData({
      moreCategoryStatus: !this.data.moreCategoryStatus,
    })
  },
  // 获取商品列表
  getProductList(code, isLoadMore) {
    let data = {
      tenantCode: app.globalData.tenantCode,
      itemSortList: [],
      conditionList: [
        {
          key: 'saleStatus',
          value: ['1'],
          valueType: 'basic',
        },
        {
          key: 'categoryCode',
          value: [code],
          valueType: 'list',
        },
      ],
      page: {
        page: this.data.lastPage,
        size: 6,
      },
    }
    getItemListbyConditionsV1(data).then(res => {
      if (res.content.data) {
        this.getInfoByCode(res.content.data, result => {
          let _productList = []
          if (isLoadMore) {
            _productList = this.data.productListData || []
            _productList = _productList.concat(result)
          } else {
            _productList = result || []
          }
          this.setData({
            productListData: _productList,
            listLoading: false,
            moreLoading: false,
            maxPage: parseInt((res.content.count + 5) / 6),
          })
        })
      } else {
        this.setData({
          listLoading: false,
          moreLoading: false,
          productListData: isLoadMore ? this.data.productListData : [],
        })
      }
    })
  },
  // 获取鸿鹄活动信息
  getInfoByCode(spuArr, cb) {
    let task = []
    spuArr.forEach(item => {
      task.push(app.honghuStore.getProductInfoAction(item.code))
      if (item.activitySorts && item.activitySorts.length > 0) {
        // 去重
        let sourceTags = Array.from(new Set(item.activitySorts))
        item.tags = this.transformTags(sourceTags)
      } else {
        item.tags = []
      }
    })
    Promise.all(task).then(info => {
      info.forEach((item, index) => {
        const { campaign } = item.byCode || {}
        if (campaign) {
          spuArr[index].campaign = {
            ...campaign,
            type: this.formatCampaignType(campaign),
          }
          if (
            campaign['__typename'] === MARKETING_TYPE.PINTUAN.type &&
            campaign.pintuanType === 'NORMAL'
          ) {
            spuArr[index].tags.unshift(this.formatCampaignType(campaign))
          } else {
            spuArr[index].tags = [this.formatCampaignType(campaign)]
          }
        }
      })
      cb && cb(spuArr)
    })
  },
  // 标签名称
  transformTags(sourceTags) {
    const tagMap = new Map([
      ['1', '单品'],
      ['2', '满减'],
      ['3', '满折'],
      ['4', '特价'],
      ['5', '满包邮'],
      ['6', '赠品'],
      ['7', '捆绑'],
      ['8', '满送'],
    ])
    return sourceTags.map(item => tagMap.get(item))
  },
  // 显示活动类型
  formatCampaignType(campaign) {
    let result = ''
    switch (campaign['__typename']) {
      case MARKETING_TYPE.PINTUAN.type:
        if (campaign.pintuanType === 'NORMAL') {
          result = '多人拼团'
        } else if (campaign.pintuanType === 'CASH_BACK') {
          result = '返现拼团'
        }
        break
      case MARKETING_TYPE.SECKILL.type:
        result = '秒杀'
        break
      case MARKETING_TYPE.BARGAIN.type:
        result = '砍价'
        break
      case MARKETING_TYPE.LIMITTIMEDISCOUNTS.type:
        result = '限时折扣'
        break
      case MARKETING_TYPE.STEPPEDGROUPBUY.type:
        result = '阶梯团购'
        break
      case MARKETING_TYPE.PACKBUY.type:
        result = '打包一口价'
        break
      case MARKETING_TYPE.REDUCEPRICEBUY.type:
        result = '降价拍'
        break
    }
    return result
  },
  moreData() {
    if (this.data.maxPage <= this.data.lastPage) {
      return
    }
    this.setData({
      lastPage: ++this.data.lastPage,
      moreLoading: true,
    })
    this.getProductList(this.data.activeCategoryCode, true)
  },
  // 选择子分类
  chooseCategory({ currentTarget: { dataset } }) {
    this.getProductList(dataset.code)
    this.setData({
      activeCategoryCode: dataset.code,
      lastPage: 1,
    })
  },
  hideCategoryModel() {
    this.setData({
      moreCategoryStatus: !this.data.moreCategoryStatus,
    })
  },
  urlFactory(data) {
    let url = ''
    let campaign = data.campaign
    switch (campaign.__typename) {
      case MARKETING_TYPE.SECKILL.type:
        url = `/honghu/pages/seckill/detail/index?scene=${campaign.code}`
        break
      case MARKETING_TYPE.BARGAIN.type:
        url = `/honghu/pages/bargain/detail/index?scene=${campaign.code}`
        break
      case MARKETING_TYPE.LIMITTIMEDISCOUNTS.type:
        url = `/honghu/pages/discount/pdp/index?scene=${data.code}`
        break
      case MARKETING_TYPE.STEPPEDGROUPBUY.type:
        url = `/honghu/pages/steppedGroupBuy/pdp/index?scene=${campaign.code}`
        break
      case MARKETING_TYPE.PINTUAN.type:
        if (campaign.pintuanType === 'NORMAL') {
          url = `/sub/Commodity/pages/pdp/pdp?spuCode=${data.code}`
        } else if (campaign.pintuanType === 'CASH_BACK') {
          url = `/honghu/pages/pintuanCashBack/pdp/index?scene=${data.code}`
        }
        break
      case MARKETING_TYPE.PACKBUY.type:
        url = `/honghu/pages/packBuy/pdp/index?scene=${data.code}`
        break
      case MARKETING_TYPE.REDUCEPRICEBUY.type:
        url = `/honghu/pages/reducePriceAuction/pdp/index?scene=${
          campaign.code
        }`
    }
    return url
  },
  goPdp({ currentTarget: { dataset } }) {
    const { store, item } = dataset
    if (item.campaign) {
      let url = this.urlFactory(item)
      app.router.navigateTo(url)
    } else {
      const query = queryString({
        storeId: store ? store.storeId : '',
        storeCode: store ? store.storeCode : '',
        spuCode: item.spuCode || item.code || '',
        src:
          item.pic ||
          (item.itemImageList && item.itemImageList[0].picUrl) ||
          '',
      })
      app.router.navigateTo(`/sub/Commodity/pages/pdp/pdp?${query}`)
    }
  },
})
