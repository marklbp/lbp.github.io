import CreditInformationDetail from './CreditInformationDetail';

export default CreditInformationDetail;
