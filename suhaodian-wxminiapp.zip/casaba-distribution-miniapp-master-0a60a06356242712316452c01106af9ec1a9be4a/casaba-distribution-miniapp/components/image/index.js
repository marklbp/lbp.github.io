import { getOSSImageInfo } from '../../api/index'
const unitConversion = unit => unit / 1024 / 1024
const getZoomParamsbyFileSize = size => {
  let p = 80 // 倍数百分比。 小于 100，即是缩小，大于 100 即是放大。
  if (size >= 3) {
    p = 20
  } else if (size >= 2) {
    p = 30
  } else if (size >= 1.5) {
    p = 40
  } else if (size >= 1) {
    p = 50
  } else if (size >= 0.5) {
    p = 90
  } else {
    p = 100
  }
  return p
}
const getImageUrl = (url, p) => {
  if (/\.gif/.test(url)) {
    return url
  }
  return `${url}?x-oss-process=image/resize,p_${p},image/quality,Q_80`
}
Component({
  externalClasses: ['u-class'],
  properties: {
    src: {
      type: String,
      value: '',
      observer: function(val) {
        this.imageProcess(val)
      },
    },
    list: {
      type: Array,
      value: [],
    },
    mode: {
      type: String,
      value: 'scaleToFill',
    },
    lazyLoad: {
      type: Boolean,
      value: false,
    },
    preview: {
      type: Boolean,
      value: true,
    },
    autoReload: {
      type: Boolean,
      value: false,
    },
    p: String, // 倍数百分比。 小于 100，即是缩小，大于 100 即是放大。
  },
  data: {
    imgUrl: '',
    loadError: false,
    loading: true,
    autoReloadCount: 0,
  },
  methods: {
    handlePreview({ currentTarget }) {
      const { list, preview, loadError, loading } = this.data
      if (!preview || loadError || loading) return
      const src = currentTarget.dataset.src
      if (list.length > 0) {
        wx.previewImage({
          current: src,
          urls: list,
        })
      } else {
        const _src = src.split('?x')[0]
        wx.previewImage({
          urls: [_src],
        })
      }
    },
    handleLoad() {
      this.setData({
        loading: false,
      })
      this.triggerEvent('load')
    },
    handleError() {
      if (this.data.autoReload) {
        // 自动重载5次，图片还没加载出来则显示重新加载文字
        let autoReloadCount = this.data.autoReloadCount
        autoReloadCount++
        if (autoReloadCount > 6) {
          this.setData({
            autoReloadCount: autoReloadCount,
            loadError: true,
            loading: false,
          })
        } else {
          this.setData({
            loadError: true,
            autoReloadCount: autoReloadCount,
          })
          this.handleReload()
        }
      } else {
        this.setData({
          loading: false,
          loadError: true,
        })
        this.triggerEvent('load')
      }
    },
    handleReload() {
      this.setData({
        loading: true,
        loadError: false,
        imgUrl: this.data.imgUrl,
      })
    },
    imageProcess(src) {
      if (!src) {
        return
      }
      this.setData({ loading: true })
      if (
        /(http:\/\/|https:\/\/|)?.*\.(mp4|m3u8|rmvb|avi|swf|3gp|mkv|flv|ogg)\??/.test(
          src
        )
      ) {
        const poster =
          src.split('?x')[0] + '?x-oss-process=video/snapshot,t_10000,m_fast'
        this.setData({ imgUrl: poster, loading: false })
      } else {
        const _src = src.split('?x')[0]
        getOSSImageInfo(_src)
          .then(res => {
            let url
            if (res && res.FileSize && res.FileSize.value) {
              const calcP = getZoomParamsbyFileSize(
                unitConversion(res.FileSize.value)
              )
              // 可以传入一个最小压缩比例p，小于p时采用p，大于p采用calcP
              const _p = this.data.p
              if (_p) {
                url = getImageUrl(_src, calcP < _p ? _p : calcP)
              } else {
                url = getImageUrl(_src, calcP)
              }
            } else {
              url = getImageUrl(_src, 80)
            }
            this.setData({ imgUrl: url, loading: false })
          })
          .catch(() => {
            this.setData({ imgUrl: _src, loading: false })
          })
      }
    },
  },
})
