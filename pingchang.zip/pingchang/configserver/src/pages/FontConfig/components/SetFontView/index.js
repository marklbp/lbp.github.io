import SetFontView from './SetFontView';

export default SetFontView;
