/*
* @Author: mengxiaofei
* @Date:   2019-01-03 15:39:07
* @Last Modified by:   mengxiaofei
* @Last Modified time: 2019-03-20 17:27:19
*/
import { updateInvoice, addInvoice } from '../../../../api/index'
import { debounce } from '../../../../utils/function'
const app = getApp()
Page({
  data: {
    actionType: 0, // 0 新建 1 修改
    isUpdate: false,
    postData: {
      remark: '0', // 0 公司 1 个人
      company: '', // 个人-抬头  公司-公司名称
      taxCode: '', // 纳税人识别号
    },
    waiting: false,
  },
  onLoad(options) {
    if (options.action) {
      let postData = this.data.postData
      let updateInvoiceStr = wx.getStorageSync('updateInvoice')
      let updateInvoice = JSON.parse(updateInvoiceStr)
      updateInvoice.remark = updateInvoice.remark + ''
      updateInvoice.taxCode =
        updateInvoice.taxCode === '0' ? '' : updateInvoice.taxCode
      wx.setNavigationBarTitle({
        title: '修改发票信息',
      })
      this.setData({
        isUpdate: true,
        postData: Object.assign(postData, updateInvoice),
      })
    }
  },
  // 更新对应的value值
  updateValue({ detail: { value }, currentTarget: { dataset } }) {
    let target = `postData.${dataset.key}`
    this.setData({
      [target]: value,
    })
  },
  // 修改发票类型
  changeType({ currentTarget: { dataset } }) {
    this.setData({
      'postData.remark': dataset.type,
    })
    // 个人 切换到个人类型时 清空可能存在的 税号
    if (dataset.type === '1') {
      this.setData({
        'postData.taxCode': '',
      })
    }
  },
  submitData: debounce(function() {
    if (this.data.isUpdate) {
      this.updateInvoice()
    } else {
      this.addInvoice()
    }
  }, 1500),
  validData() {
    let postData = this.data.postData
    if (postData.remark === '0') {
      if (!postData.taxCode.trim()) {
        wx.showToast({
          title: '纳税人识别号不可为空',
          icon: 'none',
          duration: 2000,
        })
        return false
      }
    }
    if (!postData.company) {
      let title = ''
      if (postData.remark === '0') {
        title = '公司名称不可为空'
      } else {
        title = '抬头不可为空'
      }
      wx.showToast({
        title: title,
        icon: 'none',
        duration: 2000,
      })
      return false
    }
    return true
  },
  // 修改发票信息
  updateInvoice() {
    let postData = this.data.postData
    if (!this.validData()) {
      return
    }
    updateInvoice(postData)
      .then(res => {
        if (res.code === '0' && res.success) {
          wx.showToast({
            title: '修改成功',
            icon: 'none',
            duration: 1500,
          })
          setTimeout(() => {
            app.router.navigateBack()
          }, 1500)
        } else {
          wx.showToast({
            title: res.message,
            icon: 'none',
            duration: 1500,
          })
        }
      })
      .catch(e => {
        console.log('修改发票信息err', e)
      })
  },
  // 添加发票信息
  addInvoice() {
    let postData = this.data.postData
    if (!this.validData()) {
      return
    }
    addInvoice(postData)
      .then(res => {
        if (res.code === '0' && res.success) {
          wx.showToast({
            title: '添加成功',
            icon: 'none',
            duration: 1500,
          })
          setTimeout(() => {
            app.router.navigateBack()
          }, 1500)
        } else {
          wx.showToast({
            title: res.message,
            icon: 'none',
            duration: 1500,
          })
        }
      })
      .catch(e => {
        console.log('添加发票信息err', e)
      })
  },
})
