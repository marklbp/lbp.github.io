import FileListDetail from './FileListDetail';

export default FileListDetail;