// 服务 + 商家信息
import {
  querySettings,
  getBaseInfo,
  getItemListbyConditionsV1,
  getFreightFromAddress,
} from '../../../../../api/index'

const app = getApp()
export default Behavior({
  data: {
    isShowService: false,
    services: {
      speedReturn: true,
      productGuarantee: true,
      speedRefund: true,
      sevenGuarantee: true,
    },
    saleInfo: null,
    products: [],
    freight: '--',
  },
  attached() {
    this.handleGetquerySettings()
    this.handleGetbaseInfo()
  },
  methods: {
    onServiceCancel() {
      this.setData({
        isShowService: false,
      })
    },
    handleOpenServiceSheet() {
      this.setData({
        isShowService: true,
      })
    },
    handleToIndex() {
      app.router.navigateTo('/sub/Commodity/pages/plp/plp')
    },
    // 获取 保障条例
    handleGetquerySettings() {
      querySettings({
        tenantCode: app.globalData.tenantCode,
      })
        .then(res => {
          if (res.code === '0') {
            var services = res.data
            if (
              !res.data.speedReturn &&
              !res.data.productGuarantee &&
              // !res.data.speedRefund &&
              !res.data.sevenGuarantee
            ) {
              services = null
            }
            this.setData({
              services: services,
            })
          }
        })
        .catch(e => {
          console.log(e)
        })
    },
    handleGetbaseInfo() {
      // app.globalData.tenantCode
      getBaseInfo({
        merCode: app.globalData.tenantCode,
      }).then(res => {
        if (res.code === '0' && res.data) {
          this.setData({
            saleInfo: res.data,
          })
        }
      })
    },
    // 获取当前分类下商品
    handleGetItemListbyConditionsV1() {
      const data = {
        tenantCode: app.globalData.tenantCode,
        itemSortList: [
          {
            name: 'sales',
            sort: 1,
          },
        ],
        conditionList: [
          {
            key: 'saleStatus',
            value: ['1'],
            valueType: 'basic',
          },
          {
            key: 'categoryCode',
            value: [this.data.categorycode],
            valueType: 'basic',
          },
        ],
        notIncludeSpuCodeList: [this.data.spuCode],
        saleStatus: 1,
        page: {
          page: 1,
          size: 8,
        },
      }
      // {"conditionList":[{"key":"categoryCode","value":["18110500000155"],"valueType":"basic"},{"key":"keyword","value":[""],"valueType":"basic"}]}

      getItemListbyConditionsV1(data)
        .then(res => {
          if (res.code === '0') {
            this.setData({
              products: res.content.data || [],
            })
          }
        })
        .catch(e => {
          console.log(e)
        })
    },
    getFreight(skuCode, address) {
      // 运费获取 默认5.00 默认地址 上海市
      if (this.data.isCreatePintuanAction) {
        return
      }
      let spuCodes = [
        {
          spuCode: this.data.spuCode,
          count: 1,
          skuCode: skuCode,
        },
      ]
      let defaultAddress
      let city = null
      if (address.ok && address.content.length > 0) {
        if (address.content.length === 1) {
          defaultAddress = address.content[0]
        } else {
          let defaultSave = address.content.find(j => j.isDefault === '1')
          defaultAddress = defaultSave || address.content[0]
        }
      } else {
        defaultAddress = {
          province: '上海市',
          city: '上海市',
        }
      }
      let here = '北京市上海市天津市重庆市'
      let here1 = '河北省河南省湖北省海南省'
      if (here.indexOf(defaultAddress.province) === -1) {
        city = defaultAddress.city
        if (here1.indexOf(defaultAddress.province) !== -1) {
          if (defaultAddress.city === '省直辖县级行政区划') {
            city = defaultAddress.province + defaultAddress.city
          }
        }
      } else {
        city = defaultAddress.district
      }
      let data = {
        province: defaultAddress.province,
        city: city,
        spuCodes: spuCodes,
        tenantCode: app.globalData.tenantCode,
      }
      getFreightFromAddress(data)
        .then(res => {
          console.log('运费', res)
          if (res.data.statusCode === '100011') {
          } else {
            this.setData({
              freight: res.data.freight,
            })
          }
        })
        .catch(e => {
          console.log(e)
        })
    },
    recoProdDetail(e) {
      let code = e.currentTarget.dataset.code
      let src = e.currentTarget.dataset.src
      app.router.navigateTo(
        `/sub/Commodity/pages/pdp/pdp?spuCode=${code}&src=${src}`
      )
    },
  },
})
