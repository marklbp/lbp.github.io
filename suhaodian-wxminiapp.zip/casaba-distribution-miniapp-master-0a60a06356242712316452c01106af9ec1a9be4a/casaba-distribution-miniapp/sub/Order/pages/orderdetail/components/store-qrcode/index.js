import drawQrcode from '../../../../../../utils/qrcode/index'
import { safeGet } from '../../../../../../utils/util'

const app = getApp()

Component({
  data: {
    shopStyle: [],
    qrCodeImg: '',
  },
  properties: {
    order: {
      type: Object,
      value: {},
      observer(newVal, oldVal) {
        if (safeGet(newVal, 'orderId') !== safeGet(oldVal, 'orderId')) {
          this.drawQrcode(newVal)
        }
      },
    },
    invisible: {
      type: Boolean,
      value: false,
    },
  },
  attached() {
    this.drawQrcode(this.order)
    console.log(app.globalData.shopStyle)
    this.setData({
      shopStyle: app.globalData.shopStyle,
    })
  },
  methods: {
    drawQrcode(order) {
      const that = this
      const orderId = safeGet(order, 'orderId')
      const ctx = wx.createCanvasContext('qrCode', this)
      if (orderId) {
        drawQrcode({
          width: 150,
          height: 150,
          ctx,
          text: orderId,
          callback() {
            wx.canvasToTempFilePath(
              {
                width: 150,
                height: 150,
                quality: 1,
                canvasId: 'qrCode',
                success(res) {
                  that.setData({
                    qrCodeImg: res.tempFilePath,
                  })
                },
              },
              that
            )
          },
        })
      }
    },
    copyId({ currentTarget: { dataset } }) {
      // 复制订单 id
      wx.setClipboardData({
        data: dataset.orderid,
        success: function(res) {
          wx.getClipboardData({
            success: function(res) {
              console.log(res.data) // data
            },
          })
        },
      })
    },
    handleConfirm() {
      this.triggerEvent('confirm')
    },
  },
})
