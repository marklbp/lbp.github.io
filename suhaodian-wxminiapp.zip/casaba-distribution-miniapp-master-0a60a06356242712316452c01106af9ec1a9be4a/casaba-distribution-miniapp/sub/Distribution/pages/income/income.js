import { transformPrice } from '../../../../utils/util'

const app = getApp()

Page({
  data: {
    cashAmount: 0,
    commissionAmount: 0,
    enteringAmount: 0,
    settlementAmount: 0,
    showTip: 0,
    userId: '',
  },
  onShow() {
    this.queryEarnings()
  },
  bindShowTip(e) {
    let target = e.currentTarget.dataset.index
    this.setData({ showTip: target })
  },
  bindClose() {
    this.setData({ showTip: 0 })
  },
  bindfinancialdetail() {
    wx.navigateTo({
      url: '../financialdetail/financialdetail?userId=' + this.data.userId,
    })
  },
  bindGetMoney() {
    wx.navigateTo({ url: '../rollin/rollin' })
  },
  queryEarnings() {
    let $this = this
    let data = {
      openId: app.globalData.openid,
    }
    app.https({
      method: 'GET',
      url: '/income/getIncomeInfo',
      data: data,
      header: {
        xAuthToken: app.globalData.xAuthToken,
      },
      success: function(res) {
        let result = res.data.data
        result.commissionAmount = transformPrice(result.commissionAmount / 100)
        result.cashAmount = transformPrice(result.cashAmount / 100)
        result.enteringAmount = transformPrice(result.enteringAmount / 100)
        result.settlementAmount = transformPrice(result.settlementAmount / 100)
        $this.setData({
          commissionAmount: result.commissionAmount,
          cashAmount: result.cashAmount,
          enteringAmount: result.enteringAmount,
          settlementAmount: result.settlementAmount,
          userId: result.userId,
        })
      },
      fail: function(res) {
        console.log('res', res)
      },
    })
  },
})
