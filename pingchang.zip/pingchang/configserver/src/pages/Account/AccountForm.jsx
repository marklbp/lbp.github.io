import React, { Component } from 'react';
//import AccountForm from './components/AccountForm';

export default class Demo extends Component {

  constructor(props) {
    super(props);
    
  }

  /**
   * <AccountForm {...this.props} />
   * @return {[type]} [description]
   */
  render() {
    return (
      <div className="account-page">
        这是表单
      </div>
    );
  }
}
