import {
  createPintuanOrderAction,
  getOrderDetailStatusAction,
  getProductDetailAction,
  joinPintuanTeamAction,
  prepayPintuanOrderAction,
  loginAction,
  updateUserAction,
  getJoinPintuanTeamDetailAction,
  getProductInfoAction,
} from './action'

export const honghuStore = {
  getOrderDetailStatusAction,
  getProductDetailAction,
  prepayPintuanOrderAction,
  createPintuanOrderAction,
  joinPintuanTeamAction,
  loginAction,
  updateUserAction,
  getJoinPintuanTeamDetailAction,
  getProductInfoAction,
  user: {},
  isAuthorized: false,
}
export default honghuStore
