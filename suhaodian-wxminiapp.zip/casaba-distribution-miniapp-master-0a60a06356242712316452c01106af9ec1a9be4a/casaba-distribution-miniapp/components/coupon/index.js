/* global wx, Component */
Component({
  externalClasses: ['u-class'],

  properties: {
    item: {
      type: Object,
      value: null,
      observer: function(val) {
        let type = ''
        switch (val.rewardType) {
          case '01':
            type = '￥' + val.faceValue
            break
          case '02':
            type = '满折'
            break
          case '05':
            type = '包邮'
            break
          case '06':
            type = '赠品'
            break
          default:
            type = '其他'
            break
        }
        var validBegin =
          val.activityBegin || val.validBegin || val.startReceiveTime
        var validEnd = val.activityEnd || val.validEnd || val.endReceiveTime
        this.setData({
          activityCode: val.activityCode,
          type: type,
          desc: val.activityRuleDesc,
          time: `${this.formatTime(validBegin)}-${this.formatTime(validEnd)}`,
        })
      },
    },
    selectItem: {
      type: Object,
      value: null,
      observer: function(val) {
        let type = ''
        switch (val.rewardType) {
          case '01':
            type = '￥' + val.faceValue
            break
          case '02':
            type = '满折'
            break
          case '05':
            type = '包邮'
            break
          case '06':
            type = '赠品'
            break
          default:
            type = '其他'
            break
        }
        this.setData({
          activityCode: val.activityCode,
          couponCode: val.couponCode,
          activityName: val.activityName,
          type: type,
          desc: val.activityRuleDesc,
          time: `${this.formatTime(val.validBegin)}-${this.formatTime(
            val.validEnd
          )}`,
        })
      },
    },
    status: {
      type: String,
      value: '0', // 0-立即领取 1-已领取 1.1-立即使用 2-已使用 3-已过期
      observer: function(val) {
        let state = ''
        switch (val) {
          case '0':
            state = '立即领取'
            break
          case '1':
            state = '已领取'
            break
          case '1.1':
            state = '立即使用'
            break
          case '2':
          case '02':
            state = '已使用'
            break
          case '3':
          case '03':
            state = '已过期'
            break
          case '10143034':
            state = '已领过'
            break
          case '4':
          case '10143009':
            state = '已领完'
            break
          case '':
            state = '不可用'
            break
        }
        this.setData({
          state: state,
        })
      },
    },
    select: {
      type: Boolean,
      value: false,
    },
    code: {
      type: Boolean,
      value: false,
    },
    discountCodeMsg: {
      type: String,
      value: '',
    },
    checked: {
      type: Boolean,
      value: false,
    },
    useable: {
      type: Number,
      value: -1,
    },
    loading: {
      type: Boolean,
      value: false,
    },
  },

  data: {
    state: '立即领取',
    type: '￥20',
    desc: '满50可使用',
    time: '2018.08.20-2018.09.10',
    activityCode: '',
    couponCode: '',
    activityName: '-',
    fontSize: 30,
  },

  ready() {
    // if (!this.data.select && !this.data.code) {
    //   const query = wx.createSelectorQuery().in(this)
    //   query
    //     .select('.u-coupon-type')
    //     .boundingClientRect(res => {
    //       const _size = (60 / res.width) * 30
    //       this.setData({
    //         fontSize: _size > 30 ? 30 : _size,
    //       })
    //     })
    //     .exec()
    // }
    if (this.data.select) {
      const query = wx.createSelectorQuery().in(this)
      query
        .select('.u-coupon-type_select')
        .boundingClientRect(res => {
          const _size = (70 / res.width) * 30
          this.setData({
            fontSize: _size > 22 ? 22 : _size,
          })
        })
        .exec()
    }
  },
  methods: {
    handleTap() {
      if (this.data.status === '0' || this.data.status === '1.1') {
        this.triggerEvent('click', {})
      }
    },

    handleCouponDetail() {
      this.triggerEvent('detail', {})
    },

    handleSelectChange({ detail }) {
      this.triggerEvent('change', {
        ...detail,
      })
    },
    formatTime(t) {
      const y = t.substr(0, 4)
      const m = t.substr(4, 2)
      const d = t.substr(6, 2)
      return `${y}.${m}.${d}`
    },
  },
})
