import { BaseConstant } from 'base';

class ContractFileConstant extends BaseConstant{
	constructor(){
		super();

		this.key = 'ContractFile_'
	}
}

export default new ContractFileConstant();