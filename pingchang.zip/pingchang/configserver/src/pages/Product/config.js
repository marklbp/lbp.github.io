export  const company_process = [{
  "label": "资方1",
  "value": '10'
},
{
  "label": "资方2",
  "value": '20'
},
{
  "label": "资方3",
  "value": '30'
},
{
  "label": "其他",
  "value": '40'
}
];