import ProcessFormProduct from './ProcessFormProduct';

export default ProcessFormProduct;
