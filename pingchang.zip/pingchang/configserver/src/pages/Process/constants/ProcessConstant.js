import { BaseConstant } from 'base';

class ProcessConstant extends BaseConstant{
	constructor(){
		super();

		this.key = 'PROCESS_'
	}
}

export default new ProcessConstant();