export const COMPANY_TYPE = [{
    "label": "贷款业务",
    "value": '1'
  }
];