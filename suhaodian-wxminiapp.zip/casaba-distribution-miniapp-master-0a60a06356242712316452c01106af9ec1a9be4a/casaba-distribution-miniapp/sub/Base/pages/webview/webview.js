Page({
  data: {
    url: '',
    loading: false,
  },
  onLoad(options) {
    if (options.src) {
      this.setData({
        url: decodeURIComponent(options.src),
      })
    }
  },
  wvLoad({ detail }) {
    this.setData({
      loading: true,
    })
  },
  wvError() {
    wx.showToast({
      title: '加载失败',
      icon: 'none',
    })
  },
})
