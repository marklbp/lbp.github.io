// 拼团
import {
  PINTUAN_CAMPAIGN_STATUS,
  TEAM_STATUS_KEY,
} from '../../../../../honghuStore/constant'
import { getRemainingTime } from '../../../../../static/utils/remainingTime'
import { getMinimalPriceSku } from '../../../../../static/utils/getMinimalPriceSku'
import { updateUserInfo } from '../../../../../api/index'
import apiReload from '../../../../../utils/reload'
import queryString from '../../../../../utils/query-string'
import delay from '../../../../../utils/delay'
import feature from '../../../../../feature'
import currentServerTime from '../../../../../utils/currentServerTime'
// import { showToast } from '../../../honghuStore/uiHelper'

const app = getApp()

function formatProductSkus(skus, skuCodeList, pintuanTeamId) {
  return skus
    .map(sku => {
      if (!skuCodeList.includes(sku.code)) {
        return null
      }
      let attrCodes = []
      sku.attrSaleList.forEach(skuAttrItem => {
        attrCodes = attrCodes.concat(
          skuAttrItem.attributeValueList.map(item => item.code)
        )
      })
      return {
        ...sku,
        price: pintuanTeamId ? sku.price : sku.creatorPrice || sku.price,
        attrCodes,
        attrSaleList: sku.attrSaleList,
      }
    })
    .filter(sku => sku !== null)
}

function getRemainingInventory(skus) {
  return skus
    .map(item => {
      return item.netqty
    })
    .reduce((pre, cur) => {
      if (!cur) {
        return pre
      }
      return pre + cur
    }, 0)
}

function formatSkuOptions(attrSaleList) {
  return attrSaleList.map(option => {
    return {
      code: option.code,
      name: option.attributeFrontName,
      value: {
        code: get(option.attributeValueList[0], 'code', ''),
        value: get(option.attributeValueList[0], 'attributeValueFrontName', ''),
        imageURL: get(
          option.attributeValueList[0].itemAttributeValueImageList[0],
          'picUrl',
          ''
        ),
      },
    }
  })
}

function get(obj, path = '', defaultValue) {
  let result = obj

  try {
    path.split('.').forEach(item => {
      result = result[item]
    })
  } catch (e) {
    result = defaultValue
  }
  return result
}

function formatCampaignSkus(productSkus, campaignSkus) {
  return campaignSkus
    .filter(CSku => {
      return (
        productSkus.findIndex(PSku => {
          return PSku.code === CSku.code
        }) !== -1
      )
    })
    .map(item => {
      return {
        ...item,
        options: formatSkuOptions(item.attrSaleList),
      }
    })
}

function getProductAndCampaign(productId) {
  return app.honghuStore
    .getProductDetailAction({ id: productId })
    .then(product => {
      if (product && product.campaign && product.campaign.type === 'NORMAL') {
        if (
          feature.ENABLE_PDP_GOTO_DISCOUNTS_CAMPAIGN &&
          product.campaign.discountsStatus === 'IN_PROGRESS'
        ) {
          const query = queryString({
            code: product.code,
          })
          wx.redirectTo({
            url: `/honghu/pages/discount/pdp/index?${query}`,
          })
          return delay(2000, {})
        } else if (
          product.campaign.status === PINTUAN_CAMPAIGN_STATUS.STARTED
        ) {
          return { product, campaign: product.campaign }
        }
      }

      if (
        product &&
        product.campaign &&
        product.campaign.type === 'CASH_BACK'
      ) {
        const remainingInventory = getRemainingInventory(
          formatCampaignSkus(product.skus, product.campaign.productSkus)
        )
        if (remainingInventory > 0) {
          const query = queryString({
            scene: product.code,
          })
          wx.redirectTo({
            url: `/honghu/pages/pintuanCashBack/pdp/index?${query}`,
          })
          return delay(3000, {})
        }
      }
      return {}
    })
}

const PINTUAN_CAMPAIGN_DEFAULT_DESCRIPTION =
  '1.多人同时支付/参团，支付完成最早的人获得开团/参团资格\n2.在拼团有效期内邀请到足够人数参团即拼团成功，商家发货\n3.拼团有效期内未邀请到足够人数参团即拼团失败，已付款原路退还支付账户\n4.在拼团有效期内，已支付订单不允许申请退款'

export default Behavior({
  data: {
    isShowAuthorized: false,
    isRequestingTeamInfo: false,
    hasPintuanCampaign: false,
    isCreatePintuanAction: false,
    pintuanCampaignProduct: {},
    pintuanCampaign: {},
    minimalPriceSku: {},
    joinTeamMinimalPriceSku: {},
    pintuanRemainingTime: {
      day: '00',
      hours: '00',
      minutes: '00',
      seconds: '00',
    },
    isCampaignEnd: false,
    pintuanAttrSaleList: [],
    currentPintuanCampaignSelectSku: null,
    pintuanTeamId: null,
    pintuanActionButtonText: '发起拼团',
    pintuanRemainingTimer: null,
    pintuanOngoingTeam: null,
    isAuthorized: false,
    pageParams: {},
    socialPintuanTeamId: null,
    pintuanCampaignDescription: PINTUAN_CAMPAIGN_DEFAULT_DESCRIPTION,
    unavailable: [],
    cacheUnavailable: [],
  },
  methods: {
    changeStringToArrByDelimiter(str, delimiter = '\n') {
      return str.split(delimiter)
    },
    getProductDetailFromHonghu(id, pintuanTeamId) {
      return pintuanTeamId
        ? app.honghuStore
          .getJoinPintuanTeamDetailAction(id, pintuanTeamId)
          .then(
            ({ products, pintuanTeam: { status, campaign } }) =>
              status === TEAM_STATUS_KEY.STARTED
                ? { product: products[0], campaign }
                : getProductAndCampaign(id)
          )
        : getProductAndCampaign(id)
    },
    getOngoingPintuanTeam(campaignId, ongoingTeams) {
      const pintuanOngoingTeam = {}
      const currentCampaignTeam = (ongoingTeams || []).filter(team => {
        return (
          team.campaign.id === campaignId &&
          new Date(team.endedAt).getTime() - 100 * 1000 > currentServerTime()
        )
      })
      pintuanOngoingTeam.top10Team = currentCampaignTeam.slice(0, 10)
      pintuanOngoingTeam.top2Team = pintuanOngoingTeam.top10Team.slice(0, 2)
      pintuanOngoingTeam.currentPeopleCount = currentCampaignTeam.reduce(
        (pre, cur) => {
          return pre + (cur.members.length || 1)
        },
        0
      )
      return pintuanOngoingTeam
    },
    updateHonghuCampaignProduct(data, skuList = [], pintuanTeamId) {
      const campaign = data.campaign
      const product = data.product
      if (campaign) {
        const pintuanCampaign = JSON.parse(JSON.stringify(campaign))
        pintuanCampaign.productSkus = formatProductSkus(
          pintuanCampaign.productSkus,
          skuList.map(sku => sku.code),
          pintuanTeamId
        )
        const pintuanOngoingTeam = this.getOngoingPintuanTeam(
          campaign.id,
          product.ongoingTeams
        )
        this.setData({
          pintuanAllNetQty: this.calculationTotalInventory(
            pintuanCampaign.productSkus
          ),
          pintuanCampaign,
          pintuanCampaignDescription: this.changeStringToArrByDelimiter(
            (pintuanCampaign.description &&
              pintuanCampaign.description.replace(/↵/g, '\n')) ||
              PINTUAN_CAMPAIGN_DEFAULT_DESCRIPTION
          ),
          pintuanOngoingTeam,
          pintuanCampaignProduct: { campaign, ...product },
          minimalPriceSku: getMinimalPriceSku(pintuanCampaign.productSkus),
          hasPintuanCampaign: true,
        })
        this.updatePintuanCampaignRemainingTime()
      }
    },
    updatePintuanCampaignRemainingTime() {
      const timeEnd = this.data.pintuanCampaign.availablePeriod.end
      this.setData({
        isCampaignEnd: new Date(timeEnd) <= new Date(),
        pintuanRemainingTime: getRemainingTime(timeEnd, 'BY_DAY', false),
      })
      this.data.pintuanRemainingTimer = setInterval(() => {
        this.setData({
          isCampaignEnd: new Date(timeEnd) <= new Date(),
          pintuanRemainingTime: getRemainingTime(timeEnd, 'BY_DAY', false),
        })
      }, 1000)
    },
    getNewestPintuanCampaign(pintuanTeamId) {
      const data = this.data
      let pintuanCampaign
      try {
        pintuanCampaign = JSON.parse(
          JSON.stringify(data.pintuanCampaignProduct.campaign)
        )
      } catch (e) {
        pintuanCampaign = data.pintuanCampaignProduct
        return pintuanCampaign
      }
      pintuanCampaign.productSkus = formatProductSkus(
        pintuanCampaign.productSkus,
        data.skuList.map(sku => sku.code),
        pintuanTeamId
      )
      return pintuanCampaign
    },
    handleCreatePintuan(_, isJoinSocialTeaAction) {
      if (!isJoinSocialTeaAction) {
        this.setData({
          socialPintuanTeamId: null,
        })
      }
      const data = this.data
      const pintuanCampaign = this.getNewestPintuanCampaign(
        data.socialPintuanTeamId || data.pintuanTeamId
      )
      if (!app.globalData.userInfo) {
        this.setData({
          isShowAuthorized: true,
          clickAuthBtnType: 'pintuan',
          pintuanCampaign,
        })
      } else {
        this.setData({
          pintuanSkuListMap: [],
          isCreatePintuanAction: true,
          isBuyNow: false,
          currentPintuanCampaignSelectSku: null,
          joinTeamMinimalPriceSku: isJoinSocialTeaAction
            ? getMinimalPriceSku(pintuanCampaign.productSkus)
            : {},
          pintuanCampaign,
        })
        if (this.data.isNormal) {
          this.setProductList(this.data.currentPintuanCampaignSelectSku.price)
          this.onSpecCancel()
        } else {
          this.buyNow()
        }
      }
    },
    handleJoinSocialTeam(event) {
      const socialPintuanTeamId = event.detail.teamId

      this.setData(
        {
          socialPintuanTeamId,
          isShowSocialTeamModal: false,
          attrSaleList: JSON.parse(
            JSON.stringify(this.data.pintuanAttrSaleList)
          ),
        },
        () => {
          this.handleCreatePintuan(null, true)
        }
      )
    },
    handleSocialTeamRefresh() {
      this.clearAttributeStatus()
      this.setData({
        pintuanOngoingTeam: {},
        isShowSocialTeamModal: false,
        isRequestingTeamInfo: true,
      })
      this.bindGetProductDetail(this.data.pintuanTeamId)
    },
    onAuthorizationSuccess({ detail }) {
      app.globalData.userInfo = detail.userInfo
      app.honghuStore.isAuthorized = true
      if (!app.globalData.accountId) {
        apiReload.getAuthParam(app, app.globalData.openid).then(() => {
          this.updateUserInfo(detail)
        })
      } else {
        this.updateUserInfo(detail)
      }
      this.setData({ isShowAuthorized: false })
      if (detail.tapType === 'buynow') {
        this.handleBuyNow()
      } else if (detail.tapType === 'addcart') {
        this.handleAddBtn()
      } else if (detail.tapType === 'pintuan') {
        this.handleCreatePintuan()
      } else if (detail.tapType === 'joinPintuan') {
        this.handleJoinSocialTeam({
          detail: {
            teamId: detail.extraData,
          },
        })
      }
    },
    onAuthorizationCancel({ detail }) {
      if (detail.tapType !== 'pintuan' && detail.cancel === 'fail') {
        this.setData({ refusedToAuth: false })
        if (detail.tapType === 'buynow') {
          this.handleBuyNow()
        } else if (detail.tapType === 'addcart') {
          this.handleAddBtn()
        }
      }
      this.setData({ isShowAuthorized: false, clickAuthBtnType: '' })
    },
    updateUserInfo(detail) {
      updateUserInfo(
        {
          id: app.globalData.accountId,
          openId: app.globalData.openid,
          userName: detail.userInfo.nickName,
          userPhoto: detail.userInfo.avatarUrl,
        },
        {
          unexUserToken: app.globalData.unexUserToken,
        }
      )
    },
    initOptionClickableStatus(attrSaleList, skuList) {
      if (attrSaleList.length !== 1) {
        return
      }
      const validAttrCode = []
      skuList.forEach(sku => {
        sku.attrCodes.forEach(ac => {
          if (sku.netqty > 0) {
            validAttrCode.push(ac)
          }
        })
      })

      const attrItem = attrSaleList[0]
      attrItem.attributeValueList.forEach(option => {
        option.isDisabled = !(validAttrCode.indexOf(option.code) > -1)
      })
    },
    handleUpdateStatus(currentSelectArr, attrSaleList) {
      if (attrSaleList.length === 1) {
        this.handleOneAttrSaleStatus(currentSelectArr, attrSaleList)
      } else {
        this.handleTwoAttrSaleStatus(currentSelectArr, attrSaleList)
      }
    },
    handleOneAttrSaleStatus(currentSelectArr, attrSaleList) {
      let { skuList } = this.data
      attrSaleList[0].attributeValueList.forEach(av => {
        const index = skuList.findIndex(s => s.attrCodes[0] === av.code)
        if (~index && skuList[index].netqty > 0) {
          av.isDisabled = false
        } else {
          av.isDisabled = true
        }
      })
      this.setData({
        attrSaleList,
      })
    },
    handleTwoAttrSaleStatus(currentSelectArr, attrSaleList) {
      let { unavailable, cacheUnavailable, skuList } = this.data
      const len = currentSelectArr.length
      if (len === 0) {
        // 清除所有属性的disabled以及清空unavailable
        unavailable = []
        attrSaleList.forEach(item => {
          item.attributeValueList.forEach(k => {
            k.isDisabled = false
          })
        })
        this.setData({
          unavailable,
          attrSaleList,
        })
      } else {
        // 已选择的二级属性codes
        const _currentSelectArr = currentSelectArr[len - 1]
        const levelTwoAttrCode = _currentSelectArr.attrCode
        const cacheIndex = cacheUnavailable.findIndex(
          cu => cu.sourceAttrCode === _currentSelectArr.attrCode
        )
        if (len >= unavailable.length) {
          if (~cacheIndex) {
            const sIndex = unavailable.findIndex(
              u => u.code === cacheUnavailable[cacheIndex].code
            )
            if (~sIndex) {
              // 存在sku，替换
              unavailable[sIndex].attrCodes =
                cacheUnavailable[cacheIndex].attrCodes
            } else {
              // 不存在sku，添加至unavailable
              unavailable.push({
                code: cacheUnavailable[cacheIndex].code,
                attrCodes: cacheUnavailable[cacheIndex].attrCodes,
              })
            }
          } else {
            // 过滤出skuList已选择的属性的sku
            const someCodes = new Set()
            let someSkuList
            skuList.forEach(s => {
              if (s.attrCodes.some(ac => ac === levelTwoAttrCode)) {
                someSkuList = s
                s.attrCodes.forEach(sa => {
                  if (sa !== levelTwoAttrCode) {
                    someCodes.add(sa)
                  }
                })
              }
            })
            // 筛选出未选择的属性
            const nextAttrSale = attrSaleList.filter(
              as => as.code !== _currentSelectArr.code
            )[0]
            const unavailableValues = new Set()
            // 先判断库存
            if (someSkuList.netqty <= 0) {
              let diffCode
              someSkuList.attrCodes.forEach(sa => {
                if (sa !== levelTwoAttrCode) {
                  diffCode = sa
                }
              })
              unavailableValues.add(diffCode)
            }
            const _someCodes = Array.from(someCodes)
            nextAttrSale.attributeValueList.forEach(av => {
              if (!_someCodes.includes(av.code)) {
                unavailableValues.add(av.code)
              }
            })
            const sIndex = unavailable.findIndex(
              u => u.code === nextAttrSale.code
            )
            if (~sIndex) {
              // 存在sku，替换
              unavailable[sIndex].attrCodes = Array.from(unavailableValues)
            } else {
              // 不存在sku，添加至unavailable
              unavailable.push({
                code: nextAttrSale.code,
                attrCodes: Array.from(unavailableValues),
              })
            }
            cacheUnavailable.push({
              sourceAttrCode: _currentSelectArr.attrCode,
              code: nextAttrSale.code,
              attrCodes: Array.from(unavailableValues),
            })
          }
        } else {
          const levelOneCodes = currentSelectArr.map(item => item.code)
          const delAttrCodes = []
          unavailable.forEach((u, i) => {
            if (levelOneCodes.some(lo => lo === u.code)) {
              delAttrCodes.push(i)
            }
          })
          delAttrCodes.reverse().forEach(d => unavailable.splice(d, 1))
        }
        // 先将所有属性disabled置为false
        attrSaleList.forEach(item => {
          item.attributeValueList.forEach(k => {
            k.isDisabled = false
          })
        })
        unavailable.forEach(un => {
          attrSaleList.forEach(as => {
            if (un.code === as.code) {
              as.attributeValueList.forEach(asa => {
                if (un.attrCodes.some(una => una === asa.code)) {
                  asa.isDisabled = true
                } else {
                  asa.isDisabled = false
                }
              })
            }
          })
        })
        console.log('[][][][][][][][', unavailable, cacheUnavailable)
        this.setData({
          cacheUnavailable,
          unavailable,
          attrSaleList,
        })
      }
    },
    handlePinTuanUpdateStatus(
      currentSelectArr,
      attrSaleList,
      skuList,
      combinatorialNumber
    ) {
      this.setData({
        attrSaleList: attrSaleList.map(attr => {
          return {
            ...attr,
            attributeValueList: attr.attributeValueList.map(attrValue => {
              let isDisabled = attrValue.isDisabled
              if (skuList.length > 1) {
                isDisabled = false
                if (currentSelectArr.find(item => item.code !== attr.code)) {
                  const currentSelectCodes = currentSelectArr.map(
                    item => item.attrCode
                  )
                  const skusCodes = skuList
                    .map(item => item.attrCodes)
                    .filter(item => {
                      return currentSelectCodes.every(currCode =>
                        item.includes(currCode)
                      )
                    })
                  isDisabled =
                    skusCodes.every(skusItem => {
                      return (
                        skusItem.findIndex(item =>
                          item.includes(attrValue.code)
                        ) === -1
                      )
                    }) && !attrValue.active
                }
              }
              return {
                ...attrValue,
                isDisabled,
                active:
                  currentSelectArr.findIndex(
                    item => item.attrCode === attrValue.code
                  ) !== -1,
              }
            }),
          }
        }),
      })
    },
    contain(A, B) {
      A = A.slice()
      for (var i = 0, len = B.length; i < len; i++) {
        if (A.indexOf(B[i]) === -1) {
          return false
        } else {
          A.splice(A.indexOf(B[i]), 1)
        }
      }
      return true
    },
    updateOptionClickableStatus(
      code,
      index,
      attrSaleList,
      isSelectCode,
      currentSelectedCode,
      skus
    ) {
      attrSaleList.forEach(attrItem => {
        if (code === attrItem.code) {
          return
        }
        attrItem.attributeValueList.forEach(option => {
          if (!isSelectCode || currentSelectedCode.length === 0) {
            option.isDisabled = false
            return
          }
          const isValidOption = skus.some((sku, index) => {
            const isAllInCurrentAttr = !currentSelectedCode.some(code => {
              return sku.attrCodes.indexOf(code) === -1
            })
            return (
              isAllInCurrentAttr &&
              sku.attrCodes.includes(option.code) &&
              sku.netqty > 0
            )
          })
          option.isDisabled = !isValidOption
        })
      })
    },
    updateCurrentSelectSku(data, skuCode) {
      if (!this.data.hasPintuanCampaign) {
        return
      }
      const currentSku = this.data.pintuanCampaign.productSkus.find(sku => {
        return sku.code === skuCode
      })
      data.currentPintuanCampaignSelectSku = currentSku || null
      data.pintuanCampaignProduct = this.data.pintuanCampaignProduct
      this.setData(data)
    },

    clearAttributeStatus() {
      const attrSaleList = this.data.attrSaleList
      attrSaleList.forEach((attr, index) => {
        attr.attributeValueList.forEach((item, _idx) => {
          attrSaleList[index].attributeValueList[_idx].active = false
        })
      })
      this.setData({
        skucode: '',
        skuListMap: [],
        currentSelectAttrMap: null,
      })
    },
  },
})
