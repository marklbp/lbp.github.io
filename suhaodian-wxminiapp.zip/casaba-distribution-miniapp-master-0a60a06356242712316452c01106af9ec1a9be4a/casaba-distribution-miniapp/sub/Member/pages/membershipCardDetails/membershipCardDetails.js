import {
  deleteMemberShopCard,
  defaultMemberCard,
  showShowMemberCardData,
  getEncoderQRCode,
  getEncoderBarCode,
  getMemberCardList,
} from '../../../../api/index.js'
const app = getApp()
Page({
  /**
   * 页面的初始数据
   */
  data: {
    deleteMemberShop: false, // 显示删除dialog
    showMemberCard: false, // 出示会员卡
    showUserDesc: '',
    showUserPower: '',
    animationData: {},
    deleteAnimationData: {},
    id: 0,
    cardCode: 0,
    createTime: '',
    activate: '',
    cardName: '',
    logoUrl: '',
    encoderQRCode: '', // 二维码
    barCode: '', // 条形码
    merName: null, // 商户名称
    coverImage: '', // 背景图片
    backgroundColor: '', // 背景颜色
    profitFreeShipping: null, // 包邮-不为空就显示
    profitDiscount: null, // 折扣-不为空就显示
    profitCoupon: null, // 优惠券-不为空就显示
    profitPoint: null, // 积分-不为空就显示
    cardDefault: null,
    size: 0, // 总的卡片数
    useRemark: '',
    effectiveType: 1,
    effectiveDay: 0,
    endTime: '',
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    // debugger
    const data = this.data
    data.id = options.id
    // data.activate = options.activate
    // data.createTime = options.createtime
    // data.cardCode = options.cardcode
    // data.cardName = options.cardName
    // data.merName = options.merName
    // data.logoUrl = options.logoUrl
    // data.profitFreeShipping = options.profitFreeShipping
    // if (options.profitDiscount && options.profitDiscount !== 'null' && options.profitDiscount !== 'undefined') {
    //   data.profitDiscount = Number.parseFloat(options.profitDiscount).toFixed(1)
    // } else {
    //   if (options.profitDiscount === 'undefined') {
    //     data.profitDiscount = null
    //   } else {
    //     data.profitDiscount = options.profitDiscount
    //   }
    // }
    // if (options.profitPoint && (options.profitPoint !== 'undefined')) {
    //   data.profitPoint = options.profitPoint
    // }
    // if (options.profitCoupon && (options.profitCoupon !== 'undefined')) {
    //   data.profitCoupon = options.profitCoupon
    // }
    // data.cardDefault = options.cardDefault
    // data.coverImage = options.coverImage
    // data.backgroundColor = options.backgroundColor
    // data.size = options.size
    // data.useRemark = options.useRemark
    // data.effectiveType = Number.parseInt(options.effectiveType)
    // data.effectiveDay = options.effectiveDay
    // data.endTime = options.endTime
    this.setData(data)
    this.getMemberCardLists()
  },
  /**
   * 获取会员卡集合
   */
  getMemberCardLists() {
    wx.showLoading({
      title: '数据加载中',
    })
    const _id = this.data.id
    const promise = getMemberCardList({
      tenantCode: wx.getStorageSync('tenantCode'),
      openId: wx.getStorageSync('openid'),
    })
    promise
      .then(res => {
        const { data } = res
        let card = data.filter(item => Object.is(item.id, Number.parseInt(_id)))
        console.log('card', card)
        let {
          id,
          activate,
          cardCode,
          createTime,
          cardName,
          logoUrl,
          coverImage,
          profitFreeShipping,
          profitDiscount,
          profitCoupon,
          profitPoint,
          merName,
          cardDefault,
          backgroundColor,
          useRemark,
          activateType,
          accountId,
          effectiveType,
          effectiveDay = 0,
          endTime,
        } = card[0]
        if (profitDiscount) {
          profitDiscount = Number.parseFloat(profitDiscount).toFixed(1)
        }
        this.setData({
          id,
          activate,
          cardCode,
          createTime,
          cardName,
          logoUrl,
          coverImage,
          profitFreeShipping,
          profitDiscount,
          profitCoupon,
          profitPoint,
          merName,
          cardDefault,
          backgroundColor,
          useRemark,
          activateType,
          accountId,
          effectiveType,
          effectiveDay,
          endTime,
        })
        wx.hideLoading()
      })
      .catch(() => {
        wx.hideLoading()
      })
  },
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {},
  /**
   * 删除会员卡
   */
  deleteMemberShopMethod() {
    const data = this.data
    data.deleteMemberShop = true

    this.setData(data)

    setTimeout(
      function() {
        let animation = wx.createAnimation({
          duration: 500,
          timingFunction: 'ease',
        })
        this.animation = animation

        const windowHeight = wx.getSystemInfoSync().windowHeight
        animation.translateY(-windowHeight).step({ duration: 500 })
        animation.opacity(1).step()
        this.setData({
          deleteAnimationData: animation.export(),
        })
      }.bind(this),
      100
    )
  },
  /**
   * 确认删除会员卡
   */
  confirmDeleteMemberShop() {
    const promise = deleteMemberShopCard({
      id: this.data.id,
    })
    promise
      .then(res => {
        const { code } = res
        if (Object.is(code, '0')) {
          this.cancelDeleteMemberShop()
          wx.navigateBack({
            delta: 1,
          })
        }
      })
      .catch(err => {
        console.log('err', err)
      })
  },
  /**
   * 取消删除会员卡
   */
  cancelDeleteMemberShop(e) {
    const data = this.data
    let animation = wx.createAnimation({
      duration: 500,
      timingFunction: 'ease',
    })
    this.animation = animation

    const windowHeight = wx.getSystemInfoSync().windowHeight
    animation.translateY(windowHeight).step()
    animation.opacity(1).step()
    this.setData({
      deleteAnimationData: animation.export(),
    })

    setTimeout(
      function() {
        data.deleteAnimationData = false
        this.setData(data)
      }.bind(this),
      2000
    )
  },
  /**
   * 设置默认卡
   */
  setDefaultCard() {
    const promise = defaultMemberCard({
      accountId: app.globalData.accountId,
      userId: app.globalData.accountId,
      relationId: this.data.id,
    })
    promise.then(res => {
      const { success } = res
      if (success) {
        this.setData({
          cardDefault: 1,
        })
      }
    })
  },
  /**
   * 取消出示会员卡
   */
  cancelShowMemberCard(e) {
    const data = this.data
    let animation = wx.createAnimation({
      duration: 500,
      timingFunction: 'ease',
    })

    const windowHeight = wx.getSystemInfoSync().windowHeight
    animation.translateY(windowHeight).step()
    this.setData({
      animationData: animation.export(),
    })

    setTimeout(
      function() {
        data.showMemberCard = false
        this.setData(data)
        wx.setNavigationBarColor({
          frontColor: '#000000',
          backgroundColor: '#ffffff',
          animation: {
            duration: 200,
            timingFunc: 'easeIn',
          },
        })
      }.bind(this),
      200
    )
  },
  /**
   * 出示会员卡
   */
  showShowMemberCard(e) {
    wx.setNavigationBarColor({
      frontColor: '#000000',
      backgroundColor: '#999999',
      animation: {
        duration: 100,
        timingFunc: 'easeIn',
      },
    })
    const _data = this.data
    _data.showMemberCard = true

    this.setData(_data)

    setTimeout(
      function() {
        let animation = wx.createAnimation({
          duration: 500,
          timingFunction: 'ease',
        })

        const windowHeight = wx.getSystemInfoSync().windowHeight
        animation.translateY(-windowHeight).step({ duration: 500 })
        this.setData({
          animationData: animation.export(),
        })
      }.bind(this),
      100
    )
    // 出示会员卡
    const promise = showShowMemberCardData({
      id: this.data.id,
    })
    promise
      .then(res => {
        const { data } = res
        _data.cardCode = data
        this.setData(_data)
      })
      .catch(err => {
        console.log('err', err)
      })
    // 获取二维码
    const promise1 = getEncoderQRCode({
      id: this.data.id,
    })
    promise1
      .then(res => {
        const { data } = res
        _data.encoderQRCode = data
        this.setData(_data)
      })
      .catch(err => {
        console.log('err', err)
      })

    // 获取条形码
    const promise2 = getEncoderBarCode({
      id: this.data.id,
    })
    promise2
      .then(res => {
        const { data } = res
        _data.barCode = data
        this.setData(_data)
      })
      .catch(err => {
        console.log('err', err)
      })
  },
  /**
   * 更新出示会员卡样式
   */
  updateShowUserDesc() {
    const data = this.data
    if (Object.is(data.showUserDesc, 'showUserDesc')) {
      data.showUserDesc = 'closeUserDesc'
    } else {
      data.showUserDesc = 'showUserDesc'
    }
    this.setData(data)
    console.log('data', data)
  },
  /**
   * 更新出会员权益样式
   */
  updateMemberPower() {
    const data = this.data
    if (Object.is(data.showUserPower, 'showUserPower')) {
      data.showUserPower = 'closeUserPower'
    } else {
      data.showUserPower = 'showUserPower'
    }
    this.setData(data)
    console.log('data', data)
  },
  onPageScroll: function(e) {
    if (e.scrollTop < 0) {
      wx.pageScrollTo({
        scrollTop: 0,
      })
    }
  },
  handleGoHome() {
    app.router.navigateTo('/pages/home/home')
  },
})
