// pages/myMembershipCard/myMembershipCard.js
import { getMemberCardList } from '../../../../api/index.js'
Page({
  /**
   * 页面的初始数据
   */
  data: {
    loading: false,
    cards: [
      // {
      //   id: 1,                                   // 关系id
      //   cardCode: '3298 1233 0445 2248 12',      // 会员卡编码
      //   activate: '激活',                        // 是否激活 (true：已领取， false:未领取 )
      //   createTime: '2018-11-29 12:12:12',       // 创建时间
      //   coverImage: '#4985D5',                   // 卡片封面
      //   backgroundColor: '#4985D5',              // 背景颜色
      //   cardName: 'VIP完整资料卡',                // 卡片名称
      //   logoUrl: '/assets/membership/code.png',  // logo地址
      //   avatarUrl: '/assets/logo-test.png',
      //   merName: 'MEMBERSHIP',                   // 商户名称
      //   status: '生效中',
      //   profitFreeShipping: null,                // 包邮-不为空就显示
      //   profitDiscount: null,                    // 折扣-不为空就显示
      //   profitCoupon: null,                      // 优惠券-不为空就显示
      //   profitPoint: null,                       // 积分-不为空就显示
      //   cardDefault: null,                       // 是否默认（1：默认 0：非默认）
      //   useRemark: ''                            // 使用须知
      //  }
    ],
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {},
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {
    this.getMemberCardListData()
  },
  /**
   * 会员卡-会员卡列表；
   */
  getMemberCardListData() {
    wx.showLoading({
      title: '',
      mask: true,
    })
    const promise = getMemberCardList({
      // "tenantCode": "88000731",
      // "openId": "oH_y05HmYTx9TsG-3_0SNBa4fGRc"
      tenantCode: wx.getStorageSync('tenantCode'),
      openId: wx.getStorageSync('openid'),
      // openId: 'oPqS94lYobsr4IaHGmjeORmW7s5U'
    })
    promise
      .then(res => {
        const { data } = res
        const _data = this.data
        _data.cards = data
        _data.loading = true
        this.setData(_data)
        console.log('res', this.data.cards)
        console.log(this.data)
        wx.hideLoading()
      })
      .catch(err => {
        console.log('err', err)
      })
  },
  /**
   * 前往会员卡详细信息
   */
  goMembershipDetails(e) {
    const data = e.currentTarget.dataset
    let url = null
    if (data.activate) {
      url = `../membershipCardDetails/membershipCardDetails`
    } else {
      url = `../receiveMembershipCard/receiveMembershipCard`
    }
    console.log('data', data)
    wx.navigateTo({
      url: `${url}?id=${data.id}&activate=${data.activate}&cardcode=${
        data.cardcode
      }&createtime=${data.createtime}&cardName=${data.cardname}&logoUrl=${
        data.logourl
      }&coverImage=${data.coverimage}&profitFreeShipping=${
        data.profitfreeshipping
      }&profitDiscount=${data.profitdiscount}&profitCoupon=${
        data.profitcoupon
      }&profitPoint=${data.profitpoint}&merName=${data.mername}&cardDefault=${
        data.carddefault
      }&backgroundColor=${data.backgroundcolor}&size=${
        this.data.cards.length
      }&useRemark=${data.useremark}&activateType=${
        data.activatetype
      }&accountId=${data.accountid}&effectiveType=${
        data.effectivetype
      }&effectiveDay=${data.effectiveday}&endTime=${data.endtime}`,
    })
  },
})
