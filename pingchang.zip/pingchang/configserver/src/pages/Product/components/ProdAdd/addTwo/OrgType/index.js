import OrgType from './OrgType';

export default OrgType;
