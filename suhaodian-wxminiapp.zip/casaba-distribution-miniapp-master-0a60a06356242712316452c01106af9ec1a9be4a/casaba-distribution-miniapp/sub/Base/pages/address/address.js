import {
  createAddress,
  queryAddress,
  deleteAddress,
} from '../../../../api/index'
import apiReload from '../../../../utils/reload'
import { set, get } from '../../../../utils/storage.js'

const app = getApp()
Page({
  data: {
    isShowReloadBtn: false,
    isProduct: false, // 是否有地址列表数据
    isDefaultAddressed: false,
    addressData: [],
    startX: 0, // 开始坐标
    startY: 0,
    isSelectAddress: false,
    isActive: '',
    windowHeight: 495,
    iscanceled: false,
    isChosed: false,
    actions: [
      {
        name: '删除',
        color: '#fff',
        size: '20',
        width: 60,
        icon: 'delete',
        background: '#F4766E',
      },
    ],
    authflag: 0, // 是否授权获取通讯地址
  },
  onLoad: function(options) {
    const data = this.data
    let authflag = get('authflag')
    if (options.isSelectAddress && Object.is(options.isSelectAddress, 'true')) {
      data.isSelectAddress = true
      data.isActive = options.id ? options.id : ''
      this.setData(data)
    }
    if (authflag > 0) {
      this.setData({
        authflag: authflag,
      })
    }
    this.getAddresslist()
  },
  onShow(options) {
    wx.getSystemInfo({
      success: res => {
        const wh = res.windowHeight
        const scrollHeight = wh - 137
        this.setData({
          scrollHeight: scrollHeight,
        })
      },
    })
    this.getAddresslist()
    let $this = this
    wx.getSetting({
      success(res) {
        if (res.authSetting['scope.address']) {
          set('authflag', 1)
          $this.setData({
            authflag: 1,
          })
        }
      },
    })
  },
  addAddressTap() {
    // 新建地址按钮进入添加地址页面
    const data = this.data
    console.log('data.isSelectAddress', data.isSelectAddress)
    app.router.navigateTo(
      '/sub/Base/pages/addaddress/addaddress?isSelectAddress=' +
        data.isSelectAddress
    )
  },
  getAddresslist() {
    let $this = this
    if (!app.globalData.unexUserToken) {
      apiReload
        .getOpenIdAndToken(app)
        .then(res => {
          $this.getAddress()
        })
        .catch(() => {
          wx.showToast({
            title: '服务器异常，请稍后再试',
            icon: 'none',
          })
        })
    } else {
      $this.getAddress()
    }
  },
  getAddress() {
    queryAddress(
      {},
      {
        unexUserToken: app.globalData.unexUserToken,
      }
    )
      .then(res => {
        if (res.ok) {
          if (res.content.length > 0) {
            const result = res.content
            let isActive = this.data.isActive
            try {
              let checkoutAddress = wx.getStorageSync('checkoutAddress')
              if (checkoutAddress) {
                checkoutAddress = JSON.parse(checkoutAddress)
                checkoutAddress = result.find(
                  item => item.id === checkoutAddress.id
                )
                isActive = checkoutAddress.id
                wx.setStorageSync(
                  'checkoutAddress',
                  JSON.stringify(checkoutAddress)
                )
              } else {
                // 是否存在默认地址
                const address = result.filter(item => item.isDefault === '1')
                isActive = address[0].id
                wx.setStorageSync('checkoutAddress', JSON.stringify(address[0]))
              }
              this.setData({
                isActive: isActive,
                isProduct: true,
                addressData: res.content.reverse(),
              })
            } catch (e) {
              this.setData({
                isProduct: true,
                addressData: res.content.reverse(),
              })
            }
          } else {
            wx.removeStorageSync('checkoutAddress')
            wx.removeStorageSync('editAddress')
            this.setData({
              isProduct: false,
            })
          }
        }
      })
      .catch(e => {
        console.log(e)
        this.setData({
          isShowReloadBtn: true,
        })
      })
  },
  // 选择微信地址
  importWechatAdd(e) {
    let $this = this
    wx.getSetting({
      success(res) {
        if (!res.authSetting['scope.address']) {
          wx.authorize({
            scope: 'scope.address',
            success: function() {
              set('authflag', 1)
              $this.setData({
                authflag: 1,
              })
              $this.handleSaveWechatAddress()
            },
            fail: function() {
              set('authflag', 2)
              $this.setData({
                authflag: 2,
              })
              wx.openSetting({
                success(res) {
                  console.log('打开设置成功', res)
                },
                fail(e) {
                  console.log('打开设置失败', e)
                },
              })
            },
          })
        } else {
          set('authflag', 2)
          $this.setData({
            authflag: 2,
          })
          $this.handleSaveWechatAddress()
          return false
        }
      },
      fail(e) {
        console.log('获取授权列表失败', e)
      },
    })
  },
  handleSaveWechatAddress() {
    let $this = this
    wx.chooseAddress({
      success(data) {
        console.log('获取到的结果', data)
        let addressInfo = {
          unexUserToken: app.globalData.unexUserToken,
          account: app.globalData.openid,
          isDefault: 0,
          provinceId: 0,
          province: data.provinceName,
          cityId: 1,
          city: data.cityName,
          districtId: 2,
          district: data.countyName,
          address: data.detailInfo,
          receiverName: data.userName,
          receiverMobile: data.telNumber,
          receiverZipcode: data.postalCode || '',
        }
        if (!app.globalData.unexUserToken) {
          apiReload
            .getOpenIdAndToken(app)
            .then(res => {
              console.log('res', res)
              $this.createAddress(addressInfo)
            })
            .catch(() => {
              wx.showToast({
                title: '服务器异常，请稍后再试',
                icon: 'none',
              })
            })
        } else {
          $this.createAddress(addressInfo)
        }
      },
      fail(e) {
        $this.setData({
          iscanceled: true,
        })
        console.log('获取失败', e)
      },
    })
  },
  createAddress(data) {
    createAddress(data, {
      unexUserToken: app.globalData.unexUserToken,
    }).then(res => {
      if (res.ok) {
        wx.showToast({
          title: '导入成功',
          icon: 'none',
          duration: 2000,
        })
      } else {
        wx.showModal({
          title: '提示',
          content: res.msg,
        })
      }
    })
  },
  bindEditAddress(e) {
    // 点击编辑编辑地址
    const data = this.data
    let item = e.currentTarget.dataset.item
    wx.setStorageSync('editAddress', JSON.stringify(item))
    app.router.navigateTo(
      '/sub/Base/pages/editaddress/editaddress?isSelectAddress=' +
        data.isSelectAddress
    )
  },
  bindClickAddress(e) {
    const dataset = e.currentTarget.dataset
    if (this.data.isActive === dataset.item.id) {
      // 取消
      if (app.globalCallbacks.chooseAddress) {
        app.globalCallbacks.chooseAddress('')
      }
      wx.setStorageSync('checkoutAddress', '')
      this.setData({
        isActive: '',
      })
    } else {
      // 确认
      if (app.globalCallbacks.chooseAddress) {
        app.globalCallbacks.chooseAddress(dataset.item)
      }
      wx.setStorageSync('checkoutAddress', JSON.stringify(dataset.item))
      this.setData({
        isActive: dataset.item.id,
      })
      const pages = getCurrentPages()
      let checkoutPages = [
        'sub/Pay/pages/checkout/checkout',
        'honghu/pages/orderConfirm/index',
      ]
      if (
        pages[pages.length - 2] &&
        checkoutPages.includes(pages[pages.length - 2].route)
      ) {
        app.router.navigateBack()
      }
    }
  },
  bindDeleteAddress(e) {
    const id = e.currentTarget.dataset.item.id
    wx.showModal({
      title: '提示',
      content: '确认删除该地址?',
      success: c => {
        if (c.confirm) {
          deleteAddress(
            {
              id: id,
            },
            {
              unexUserToken: app.globalData.unexUserToken,
            }
          )
            .then(res => {
              if (res.ok) {
                if (id === Number(this.data.isActive)) {
                  this.setData({
                    isActive: '',
                  })
                }
                // 将缓存中对应的  地址删除
                const checkoutAddress = wx.getStorageSync('checkoutAddress')
                if (checkoutAddress) {
                  let storeAddressObj = JSON.parse(checkoutAddress)
                  if (storeAddressObj.id === id) {
                    wx.removeStorageSync('checkoutAddress')
                  }
                }
                this.getAddresslist()
              } else {
                wx.showToast({
                  title: res.errMsg,
                })
              }
            })
            .catch(e => {
              console.log(e)
            })
        }
      },
    })
  },
  handleReload() {
    this.setData({
      isShowReloadBtn: false,
    })
    this.onShow()
  },
})
