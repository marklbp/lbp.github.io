export  const company_type = [{
    "label": "身份证",
    "value": '1'
  },
  {
    "label": "港澳通行证",
    "value": '2'
  },
  {
    "label": "军官证",
    "value": '3'
  },
  {
    "label": "护照",
    "value": '4'
  },
  {
    "label": "台湾通行证",
    "value": '5'
  },
  {
    "label": "其他",
    "value": '6'
  }
];
