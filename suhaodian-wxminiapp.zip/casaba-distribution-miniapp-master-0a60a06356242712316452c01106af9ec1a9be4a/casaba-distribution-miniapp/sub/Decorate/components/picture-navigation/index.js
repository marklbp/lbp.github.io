import link from '../../utils/link'
Component({
  properties: {
    picsList: {
      type: Array,
      value: [],
    },
    content: {
      type: Object,
      value: null,
    },
  },
  methods: {
    handleJump({ currentTarget }) {
      console.log('][][][][][', currentTarget.dataset.item)
      const { navigation2Url, swiper2Url } = currentTarget.dataset.item.content
      link.bind(
        this,
        currentTarget.dataset.item.content,
        navigation2Url || swiper2Url
      )()
    },
  },
})
