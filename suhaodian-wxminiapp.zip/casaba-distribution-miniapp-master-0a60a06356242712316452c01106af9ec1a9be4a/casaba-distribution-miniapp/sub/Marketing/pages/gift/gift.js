const app = getApp()
Page({
  data: {
    gifts: [],
    giftGroup: [],
    scrollHeight: 0,
    selectCount: 0,
    scrollTop: 0,
  },
  onLoad(options) {
    wx.getStorage({
      key: 'giftGroup',
      success: res => {
        const giftGroup = JSON.parse(res.data)
        const gifts = JSON.parse(wx.getStorageSync('gift'))
        giftGroup.forEach((item, index) => {
          let _gifts = []
          item.top = 0
          item.nextTop = 12000 // 下个top的值
          item.isSticky = index === 0 // 是否设置成sticky
          gifts.forEach(child => {
            if (child.activityId === item.activityId) {
              // 设置初始的checked和disabed
              child.checked = false
              child.disabled = false
              _gifts.push(child)
            }
          })
          item.gifts = _gifts
        })
        this.setData(
          {
            giftGroup: giftGroup,
          },
          () => {
            const className = '.giftGroup-header'
            const query = wx.createSelectorQuery()
            query
              .selectAll(className)
              .boundingClientRect(res => {
                res.forEach((item, index) => {
                  giftGroup[index].top = item.top
                  // 获取下一个兄弟的top值，如果没有则用自身的bottom+12000(设置大点，防止赠品过多)
                  giftGroup[index].nextTop = res[index + 1]
                    ? res[index + 1].top
                    : item.bottom + 12000
                })
              })
              .exec()
          }
        )
      },
    })
  },
  onShow() {
    wx.getSystemInfo({
      success: res => {
        const wh = res.windowHeight
        const scrollHeight = wh - 84
        this.setData({
          scrollHeight: scrollHeight,
        })
      },
    })
  },
  onChangeCheck({ currentTarget, detail }) {
    const dataset = currentTarget.dataset
    const groupIndex = dataset.groupindex
    const index = dataset.index
    const checked = detail.checked
    // 深拷贝对象，防止浅拷贝或直接复制造成对原有对象的污染
    let giftGroup = JSON.parse(JSON.stringify(this.data.giftGroup))
    let currentGroup = giftGroup[groupIndex]
    let giftLimitMax =
      currentGroup.giftLimitMax === '0'
        ? '0'
        : currentGroup.giftLimitMax === ''
          ? '1'
          : currentGroup.giftLimitMax
    let selectCount = this.data.selectCount
    currentGroup.gifts[index].checked = checked

    if (giftLimitMax === '0') {
      if (checked) {
        selectCount++
      } else {
        selectCount--
      }
      this.setData({
        giftGroup: giftGroup,
        selectCount: selectCount,
      })
    } else {
      this._commonHanding(
        giftGroup,
        currentGroup,
        giftLimitMax,
        checked,
        selectCount
      )
    }
  },
  onChangeInputNumber({ currentTarget, detail }) {
    const dataset = currentTarget.dataset
    const groupIndex = dataset.groupindex
    const index = dataset.index
    const value = detail.value
    // 深拷贝对象，防止浅拷贝或直接复制造成原有对象的污染
    let giftGroup = JSON.parse(JSON.stringify(this.data.giftGroup))
    let currentGroup = giftGroup[groupIndex]
    let giftLimitMax =
      currentGroup.giftLimitMax === '0'
        ? '0'
        : currentGroup.giftLimitMax === ''
          ? '0'
          : currentGroup.giftLimitMax
    currentGroup.gifts[index].count = value
    if (giftLimitMax !== '0') {
      this._commonHanding(giftGroup, currentGroup, giftLimitMax)
    } else {
      this.setData({
        giftGroup: giftGroup,
      })
    }
  },
  // 处理选择赠品数量是否超出限制
  _commonHanding(giftGroup, currentGroup, giftLimitMax, check, selectCount) {
    // 过滤出勾选的商品
    let selectProducts = currentGroup.gifts.filter(item => item.checked)
    let count = 0
    // 遍历过滤后的商品，将count相加，得到最终的数量
    selectProducts.forEach(item => {
      count += item.count
    })
    // 判断选择的数量是否大于限制的数量
    if (count > giftLimitMax) {
      wx.showToast({
        title: '超出限领件数',
        icon: 'none',
      })
      return
    } else {
      // 如果是checkbox，则更改勾选的数量
      if (check !== undefined) {
        if (check) {
          selectCount++
        } else {
          selectCount--
        }
      }
      // 如果count大于限制，则将未勾选的商品禁止勾选
      if (count >= giftLimitMax) {
        currentGroup.gifts.forEach(item => {
          if (!item.checked) {
            item.disabled = true
          }
        })
      } else {
        currentGroup.gifts.forEach(item => {
          if (!item.checked) {
            item.disabled = false
          }
        })
      }
    }
    this.setData({
      giftGroup: giftGroup,
      selectCount: check !== undefined ? selectCount : this.data.selectCount,
    })
  },
  handleConfirmSelect() {
    const route = getCurrentPages()
    const giftGroup = this.data.giftGroup
    let selectGifts = []
    // 获取所有group的勾选商品
    giftGroup.forEach(item => {
      item.gifts.forEach(child => {
        if (child.checked) {
          selectGifts.push(child)
        }
      })
    })
    if (selectGifts.length > 0) {
      // 调用checkout.js暴露的方法pubSelectGift
      route[route.length - 2].pubSelectGift(selectGifts)
    }
    app.router.navigateBack()
  },
  // 监听页面滚动，获取scrollTop，更新group-header的sticky
  onPageScroll({ detail }) {
    const scrollTop = detail.scrollTop
    let giftGroup = this.data.giftGroup
    giftGroup.forEach(item => {
      if (item.nextTop) {
        const top = item.top
        const nextTop = item.nextTop
        if (scrollTop >= top && scrollTop < nextTop - 32) {
          item.isSticky = true
        } else if (scrollTop >= nextTop - 32 && scrollTop < nextTop) {
          item.isSticky = false
        }
      }
    })
    this.setData({
      giftGroup: giftGroup,
    })
  },
})
