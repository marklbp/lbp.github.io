import InterView from './InterView';

export default InterView;
