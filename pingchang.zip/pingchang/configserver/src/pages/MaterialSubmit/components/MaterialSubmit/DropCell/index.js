import DropCell from './DropCell';

export default DropCell;