// sub/Distribution/pages/incomeDetails/incomeDetails.js
import { getFriendList } from '../../../../api/index.js'
const app = getApp()
Page({
  /**
   * 页面的初始数据
   */
  data: {
    index: 1,
    animationData: null,
    orderStatus: -1,
    inviterArray: [
      // {
      //   userId: '',
      //   openId: '',
      //   userName: '', // 用户名称
      //   userPhoto: '', // 用户头像
      //   secondCommision: '', // 贡献收益
      //   totalOrderCount: '' // 订单数
      // }
    ],
    page: null
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    this.getFriendLists()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function() {},

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function() {},

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function() {},

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function() {},

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function() {
    const page = this.page
    if (page.total > page.pageNum * page.pageSize) {
      this.getFriendLists(++page.pageNum)
    }
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function() {
    this.getFriendLists()
  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function() {},
  /**
   * 激活标签页
   */
  activeTab(e) {
    const animation = wx.createAnimation({
      duration: 400,
      timingFunction: 'linear',
    })
    const width1 = '198rpx'
    const width2 = '519rpx'
    const dataset = e.target.dataset
    if (dataset.index == 1) {
      animation.left(width1).step()
    } else {
      animation.left(width2).step()
    }
    this.setData({
      index: dataset.index,
      orderStatus: dataset.status,
      animationData: animation.export(),
      inviterArray: [],
      page: null
    })
    this.getFriendLists()
  },
  /**
   * 邀请朋友
   */
  invitationFriend(e) {
    wx.navigateTo({
      url: '/sub/Distribution/pages/client/client',
    })
  },
  /**
   * 获取邀请人明细
   */
  getFriendLists(pageNum = 1) {
    const orderStatus = this.data.orderStatus
    const promise = getFriendList({
      pageNum,
      pageSize: 5,
      orderStatus: Object.is(orderStatus, -1) ? undefined : orderStatus,
      tenantCode: app.globalData.tenantCode,
      openId: app.globalData.openid || wx.getStorageSync('openid'),
    })
    promise.then(res => {
      const { code, data: { result, page } } = res
      if (Object.is(code, '0')) {
        const inviterArray = this.data.inviterArray.concat(result)
        this.setData({
          inviterArray: inviterArray,
          page: page
        })
      }
    })
  },
})
