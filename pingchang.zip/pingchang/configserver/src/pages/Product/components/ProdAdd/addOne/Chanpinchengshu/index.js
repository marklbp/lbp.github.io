import Chanpinchengshu from './Chanpinchengshu';

export default Chanpinchengshu;
