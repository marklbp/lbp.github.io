/* global Component */
Component({
  externalClasses: [
    'u-class',
    'u-class-icon',
    'u-class-hd',
    'u-class-text',
    'u-class-bd',
    'u-class-ft',
  ],

  options: {
    multipleSlots: true,
  },

  properties: {
    // 左侧标题
    title: {
      type: String,
    },
    // 标题下方的描述信息
    desc: {
      type: String,
    },
    // 右侧内容
    value: {
      type: String,
    },
    // 是否显示border-bottom
    isBorder: {
      type: Boolean,
      value: true,
    },
    // 是否展示右侧箭头
    isLink: {
      type: Boolean,
      value: true,
    },
    useThinArrow: {
      type: Boolean,
      value: false,
    },
  },

  methods: {
    handleTapFooter() {
      this.triggerEvent('click', {})
    },
  },
})
