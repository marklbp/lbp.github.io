import hh from '../../../../honghuStore/request'
import { STATUS } from './status'
import { getSeckillDetail } from './gql'
import { detectionTime, getRemainingTime, fixIOSDate } from '../../utils/util'

Component({
  properties: {
    cid: Number,
    ctype: String,
    commodityList: {
      type: Array,
      value: [],
    },
    mode: {
      type: String,
      value: 'listLineTwo',
    },
    content: {
      type: Object,
      value: null,
      observer: function(newVal) {
        this.setData({
          content: newVal,
        })
      },
    },
  },
  data: {
    _commodityList: [],
    loading: false,
    done: false,
    timer: null,
  },
  attached() {
    this.setData({ loading: true, done: false })
    this.initLoad(this.data.commodityList)
  },
  methods: {
    initLoad(cacheProductList) {
      if (this.data.timer) {
        clearInterval(this.data.timer)
      }
      hh(getSeckillDetail()).then(res => {
        const {
          spellGoodsType,
          autoSelectsort,
          autoSelectNum,
          autohideFailAct,
        } = this.data.content
        const seckillList = res.data.shop.campaigns.edges
        if (spellGoodsType === '2') {
          let matchSeckill = []
          // 后台配置的自动选择
          // step1. 过滤出【预热中】和【进行中】的活动
          matchSeckill = seckillList.filter(
            s =>
              s.node.status === STATUS.WARMING_UP ||
              s.node.status === STATUS.STARTED
          )
          // step2. 排序出spu下最低秒杀价格的sku
          let finalProductList = this.spuGroup(matchSeckill)
          // step3. 然后根据后台排序规则进行商品排序
          this.sortProduct(finalProductList, autoSelectsort)
          // step4. 根据是否显示已售罄规则过滤商品；根据数量规则显示相应的数量
          this.showProduct(
            this.filterSoldOut(finalProductList, autohideFailAct),
            autoSelectNum
          )
        } else {
          // 后台配置的手动选择
          const finalProductList = this.spuGroup(
            cacheProductList
              .map(cp => {
                for (const sk of seckillList) {
                  if (cp.goodsInfo.actCode === sk.node.code) {
                    return {
                      ...sk,
                    }
                  }
                }
              })
              .filter(f => !!f)
          )
          this.showProduct(
            this.filterSoldOut(finalProductList, autohideFailAct)
          )
        }
      })
    },
    pubRefresh() {
      this.setData({ done: false })
      let _commodityList = this.data._commodityList
      if (this.data.commodityList.length) {
        _commodityList = this.data.commodityList
      }
      this.initLoad(_commodityList)
    },
    pubClearTimer() {
      // 当页面被卸载的时候清除掉计时器
      clearInterval(this.data.timer)
    },
    spuGroup(productList) {
      return productList.map(p => {
        p.node.productSkus.sort((a, b) => a.seckillPrice - b.seckillPrice)
        return {
          ...p.node,
        }
      })
    },
    sortProduct(productList, type) {
      if (type === 'newShelve') {
        productList.sort((a, b) => {
          const at = a.createdAt
          const bt = b.createdAt
          return new Date(fixIOSDate(bt)) - new Date(fixIOSDate(at))
        })
      } else if (type === 'priHighToLow') {
        productList.sort(
          (a, b) =>
            b.productSkus[0].seckillPrice - a.productSkus[0].seckillPrice
        )
      } else if (type === 'priLowToHigh') {
        productList.sort(
          (a, b) =>
            a.productSkus[0].seckillPrice - b.productSkus[0].seckillPrice
        )
      }
    },
    filterSoldOut(productList, isHide) {
      let filteredProduct = []
      filteredProduct = productList
        .map(p => {
          if (p.status === STATUS.WARMING_UP || p.status === STATUS.STARTED) {
            const { remaining, netqty } = this.remainingQuantity(p.productSkus)
            if (isHide && !netqty) {
              return false
            } else {
              // 判断sku是否启用了，商品SKU可用状态：0-启用, 1-失效
              if (p.productSkus[0].status === 1) {
                return false
              }
              return this.reducer({}, p, { remaining, netqty })
            }
          }
        })
        .filter(f => !!f)
      return filteredProduct
    },
    showProduct(filteredProduct, limitShowNum) {
      this.setData({
        loading: false,
        done: true,
        _commodityList: limitShowNum
          ? filteredProduct.splice(0, limitShowNum)
          : filteredProduct,
      })
      this.countDown()
    },
    remainingQuantity(productSkus) {
      // 计算出剩余的件数和skus总库存
      const remaining = productSkus.reduce((s, c) => {
        const finalInventory = Math.min(c.netqty, c.seckillInventory)
        let diff = finalInventory - c.seckillSoldNum
        diff = diff < 0 ? 0 : diff
        return (s += diff)
      }, 0)
      const netqty = productSkus.reduce((s, c) => {
        const finalInventory = Math.min(c.netqty, c.seckillInventory)
        return (s += finalInventory)
      }, 0)
      return { remaining, netqty }
    },
    countDown() {
      // 为每个活动即每个商品设置倒计时
      const timer = setInterval(() => {
        const arr = this.data._commodityList
        arr.forEach(a => {
          const now = new Date()
          if (a.goodsInfo.status === STATUS.WARMING_UP) {
            const r = getRemainingTime(now, a.goodsInfo.startTime, true)
            if (detectionTime(r)) {
              clearInterval(timer)
              return this.initLoad(this.data.commodityList)
            }
            a.goodsInfo.remainingTime = r
          } else if (a.goodsInfo.status === STATUS.STARTED) {
            const r = getRemainingTime(now, a.goodsInfo.endTime, true)
            if (detectionTime(r)) {
              clearInterval(timer)
              return this.initLoad(this.data.commodityList)
            }
            a.goodsInfo.remainingTime = r
          }
        })
        this.setData({ _commodityList: arr })
      }, 1000)
      this.setData({ timer })
    },
    reducer(source, target, other) {
      // 将数据进行转换
      const now = new Date()
      let remainingTime = {
        hours: '00',
        minutes: '00',
        seconds: '00',
      }
      if (target.status === STATUS.WARMING_UP) {
        remainingTime = getRemainingTime(
          now,
          target.availablePeriod.start,
          true
        )
      } else if (target.status === STATUS.STARTED) {
        remainingTime = getRemainingTime(now, target.availablePeriod.end, true)
      }
      return {
        goodsInfo: {
          ...source,
          id: target.id,
          code: target.code,
          title: target.name,
          status: target.status,
          salePrice: target.productSkus[0].seckillPrice,
          listPrice: target.productSkus[0].salePrice,
          picUrl: target.product.pics[0].picUrl,
          listTime: target.product.listTime,
          seckillInventory: target.productSkus[0].seckillInventory,
          seckillSoldNum: target.productSkus[0].seckillSoldNum,
          warmUpAt: target.warmUpAt,
          startTime: target.availablePeriod.start,
          endTime: target.availablePeriod.end,
          remainingQuantity: other.remaining < 0 ? 0 : other.remaining,
          remainingTime: remainingTime,
          netqty: other.netqty,
        },
      }
    },
    handleViewMore() {
      const { path } = this.content
      if (path) {
        this.triggerEvent('jump', { url: path })
      }
    },
    handleJump({ currentTarget }) {
      const { code } = currentTarget.dataset.item
      if (code) {
        this.triggerEvent('jump', {
          url: `/honghu/pages/seckill/detail/index?scene=${code}`,
        })
      }
    },
  },
})
