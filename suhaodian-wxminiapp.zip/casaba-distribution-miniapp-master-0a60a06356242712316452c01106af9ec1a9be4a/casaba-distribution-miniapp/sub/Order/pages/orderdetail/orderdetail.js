import {
  getStoreDetail,
  orderConfirmGoods,
  queryOrderOpenDetail,
  returnOrderByOrderId,
} from '../../../../api/index'
import { transformPrice } from '../../../../utils/util'
import apiReload from '../../../../utils/reload'
import { throttle } from '../../../../utils/function'
import {
  getOrderCodesAction,
  prepayPintuanOrderAction,
} from '../../../../honghuStore/action'
import {
  HONGHU_ORDER_STATUS_KEY,
  TEAM_STATUS,
  TEAM_STATUS_KEY,
} from '../../../../honghuStore/constant'
import queryString from '../../../../utils/query-string'
import { getRemainingTime } from '../../../../static/utils/remainingTime'
import { prepayOrderAction } from '../../../../honghu/index'
import { showToast } from '../../../../honghuStore/uiHelper'

const app = getApp()

Page({
  data: {
    isShowReloadBtn: false,
    listLoading: true,
    query: null,
    orderItem: null,
    orderDetail: null,
    productlist: null,
    orderRefund: null,
    skuOProductList: [],
    freight: '',
    orderNum: 0, // 商品数量
    skuList: [],
    clickPay: false,
    logistics: null,
    team: {},
    timer: null,
    isShowConfirmGoods: false,
    remainingTime: {
      day: '00',
      hours: '00',
      minutes: '00',
      seconds: '00',
    },
    isShowPreengage: false,
    isShowCancelOrder: false,
    remainingTimer: null,
    storeDetails: false,
    enableReceipt: false, // 是否显示确认收货
    autoCancelRule: true,
    isNotComple: true,
    reloadTimeHandler: null,
    orderInvoice: null,
    isInvoice: false,
    isPersonInVoice: false,
    qrimg: '',
    changedAmount: 0,
    changedAmountStr: '',
    memberDis: 0,
    showLogistic: false, // 是否有物流
    isMajorCustomer: false, // PACS 大客户
  },
  onLoad: function(query) {
    // autoCancelRule: app.globalData.autoCancelRule,
    this.setData({
      query: query,
      isMajorCustomer: app.globalData.isMajorCustomer,
    })
    this.initLoad()
  },
  transformText(status) {
    let result = ''
    switch (status) {
      case '11':
        result = '待审核'
        break
      case '21':
        result = '待商家收货'
        break
      case '31':
        result = '待产品质检'
        break
      case '41':
        result = '待换货'
        break
      case '51':
        result = '待退款'
        break
      case '61':
        result = '退款成功'
        break
      case '81':
        result = '审核不通过'
        break
      case '91':
        result = '处理中'
        break
      default:
        result = '申请退款'
        break
    }
    return result
  },
  transformInvoiceType(invoiceType) {
    let result = ''
    switch (invoiceType) {
      case '11':
        result = '普通发票'
        break
      case '21':
        result = '增值税发票'
        break
      case '31':
        result = '电子发票'
        break
    }
    return result
  },
  onUnload() {
    if (this.data.reloadTimeHandler) {
      clearTimeout(this.data.reloadTimeHandler)
      this.data.reloadTimeHandler = null
    }
    clearInterval(this.data.remainingTimer)
  },
  initLoad() {
    this.setData({
      team: {},
    })
    this.handleGetDetail(this.data.query.id)
  },
  handleReload() {
    wx.redirectTo({
      url: `./orderdetail?id=${this.data.query.id}&type=${
        this.data.query.type
      }`,
    })
  },
  pubRefresh() {
    this.handleGetDetail(this.data.query.id)
  },
  handleGetDetail(orderId) {
    if (!app.globalData.xAuthToken) {
      apiReload.getxAuthTokenAndunexUserToken(app).then(() => {
        this.bindViewOrderDetailTap(orderId)
      })
    } else {
      this.bindViewOrderDetailTap(orderId)
    }
  },
  bindViewOrderDetailTap(orderId) {
    queryOrderOpenDetail(
      {
        orderId: orderId,
        tenantCode: app.globalData.tenantCode,
      },
      {
        xAuthToken: app.globalData.xAuthToken,
      }
    )
      .then(res => {
        if (res.head.code === '0') {
          const result = res.body
          const productlist = result.orderPorductOutList
          const freight = transformPrice(result.freight)
          // 订单状态
          returnOrderByOrderId(
            {
              orderId: result.orderId,
            },
            {
              unexUserToken: app.globalData.unexUserToken,
              'invoke-source': app.globalData['invoke-source'],
            }
          )
            .then(
              returnOrder =>
                result['externalOrderId']
                  ? this.getOrderDetail(this.data.query.id)
                    .then(() => returnOrder)
                    .catch(() => returnOrder)
                  : returnOrder
            )
            .then(returnOrder => {
              if (returnOrder.code === '0') {
                const _product = productlist.map(i => {
                  const someItem = returnOrder.data.find(
                    j => j['products'][0]['skuId'] === i.skuId
                  )
                  returnOrder.data = returnOrder.data.map(item => {
                    return {
                      ...item,
                      statusNameBak: this.transformText(item.status),
                    }
                  })
                  if (someItem) {
                    return {
                      ...someItem,
                      ...i,
                      btnText: this.transformText(someItem.status),
                    }
                  } else {
                    return i
                  }
                })
                // all 商品都已经是完成状态, 隐藏确认收货按钮
                var completeOrder = _product.filter(item => {
                  return item.status === '61'
                })
                if (
                  completeOrder.length === 0 ||
                  completeOrder.length !== _product.length
                ) {
                  this.setData({
                    enableReceipt: true,
                  })
                }
                // PACS 大客户处理  待收货|非自提|PACS
                if (
                  result.orderStatus !== '41' ||
                  result.distributionType === '21' ||
                  !this.data.isMajorCustomer
                ) {
                  this.setData({
                    enableReceipt: true,
                  })
                }
                // PACS 大客户处理  待收货|非自提|PACS
                if (
                  result.orderStatus === '41' &&
                  result.distributionType !== '21' &&
                  this.data.isMajorCustomer
                ) {
                  this.setData({
                    enableReceipt: false,
                  })
                }
                // 自动取消规则
                if (res.body.scheduleCancelTime === '9999-12-31 23:59:59') {
                  this.setData({
                    autoCancelRule: false,
                  })
                }
                // 是否减价
                let differenceValue = this.calcUpdateAmount(
                  result.orderPriceChangeMsgs
                )
                if (differenceValue !== 0) {
                  this.setData({
                    changedAmount: differenceValue,
                    changedAmountStr: transformPrice(Math.abs(differenceValue)),
                  })
                }
                this.setData({
                  orderRefund: returnOrder.data[0] || null,
                  freight: freight,
                  orderDetail: result,
                  productlist: _product,
                  isShowReloadBtn: false,
                  listLoading: false,
                  memberDis: Math.abs(
                    result.productAmount - result.amount
                  ).toFixed(2),
                })
                if (this.data.orderDetail.distributionType === '21') {
                  this.getStoreDetails()
                }
                this.stateLogis(orderId)
              }
            })
          if (result.orderStatus !== '21') {
            this.data.team.orderStatusText = result.orderStatusName
            this.setData({ team: this.data.team })
          }
          if (
            result.orderStatus === '41' &&
            result.distributionType === '21' &&
            result.shopCode
          ) {
            const reloadTimeHandler = setTimeout(() => {
              this.handleGetDetail(orderId)
            }, 10 * 1000)
            this.setData({
              reloadTimeHandler,
            })
          }

          let orderInvoice = Object.assign(result.orderOpenInvoiceOut, {
            type:
              result.orderOpenInvoiceOut.taxCode &&
              result.orderOpenInvoiceOut.taxCode !== '0'
                ? '公司'
                : '个人',
          })
          // isPersonInVoice  '0' 公司  '1' 个人
          if (
            orderInvoice &&
            ['0', '1'].includes(orderInvoice.isPersonInVoice)
          ) {
            this.setData({
              isInvoice: true,
              isPersonInVoice: orderInvoice.isPersonInVoice === '1',
            })
          }
          this.setData({
            freight: freight,
            orderDetail: result,
            orderInvoice: orderInvoice,
            productlist: productlist,
            isShowReloadBtn: false,
            listLoading: false,
          })
          console.log('订单信息', result)
          // this.getStoreDetails()
          this.stateLogis(orderId)
          let orderNum = null
          result.orderPorductOutList.map(item => {
            orderNum += item.count
          })
          this.setData({
            orderNum: orderNum,
          })
          let scheduleCancelTime = result.scheduleCancelTime

          // 营销订单特殊处理。 所有营销订单 scheduleCancelTime 固定为 'scheduleCancelTime'， 支付结束倒计时固定为五分钟
          if (
            scheduleCancelTime === '2999-10-10 00:00:00' &&
            result.orderDate
          ) {
            const orderDate = new Date(result.orderDate.replace(/-/g, '/'))
            scheduleCancelTime = new Date(
              orderDate.getTime() + 5 * 60 * 1000
            ).toUTCString()
          }

          this.updateRemainingTime(scheduleCancelTime)
        } else {
          this.setData({
            isShowReloadBtn: true,
            listLoading: false,
          })
        }
      })
      .catch(() => {
        this.setData({
          isShowReloadBtn: true,
          listLoading: false,
        })
      })
  },
  copyId() {
    // 复制订单 id
    let orderId = this.data.orderDetail.orderId
    wx.setClipboardData({
      data: orderId,
      success: function(res) {
        wx.getClipboardData({
          success: function(res) {
            console.log(res.data) // data
          },
        })
      },
    })
  },
  // 计算 涨/减 价金额
  calcUpdateAmount(logList) {
    let result = 0
    let productlist = this.data.productlist
    for (let i = 0; i < logList.length; i++) {
      for (let j = 0; j < productlist.length; j++) {
        if (logList[i].skuId === productlist[j].skuId) {
          result =
            (result * 100 +
              logList[i].changedAmount * productlist[j].count * 100) /
            100
        }
      }
    }
    return result
  },
  updateRemainingTime(scheduleCancelTime) {
    scheduleCancelTime = scheduleCancelTime.replace(/-/g, '/')
    console.log(getRemainingTime(scheduleCancelTime, 'BY_DAY'))
    this.setData({
      remainingTime: getRemainingTime(scheduleCancelTime, 'BY_DAY'),
    })
    this.data.remainingTimer = setInterval(() => {
      this.setData(
        {
          remainingTime: getRemainingTime(scheduleCancelTime, 'BY_DAY'),
        },
        () => {
          // 倒计时结束
          let remainingTime = this.data.remainingTime
          if (
            this.data.orderDetail.orderStatus === '21' &&
            remainingTime.day === '00' &&
            remainingTime.hours === '00' &&
            remainingTime.minutes === '00' &&
            remainingTime.seconds === '00'
          ) {
            clearInterval(this.data.remainingTimer)
            this.handleGetDetail(this.data.query.id)
          }
        }
      )
    }, 1000)
  },
  handleGoPdp({ currentTarget: { dataset } }) {
    const spuCode = dataset.spucode
    const src = dataset.src
    const query = queryString({
      spuCode: spuCode,
      src: src,
    })
    app.router.navigateTo(`/sub/Commodity/pages/pdp/pdp?${query}`)
  },
  handleShowConfirmGoods() {
    this.setData({ isShowConfirmGoods: true })
  },
  handleHideConfirmGoods({ currentTarget: { dataset } }) {
    if (dataset.type === 'confirm') {
      orderConfirmGoods(
        {
          tenantCode: app.globalData.tenantCode,
          orderId: this.data.orderDetail.orderId,
          account: app.globalData.account,
        },
        {
          xAuthToken: app.globalData.xAuthToken,
        }
      )
        .then(res => {
          if (res.code === '0') {
            const route = getCurrentPages()
            if (route[route.length - 2].pubRefresh) {
              route[route.length - 2].pubRefresh()
            }
            this.pubRefresh()
            app.router.navigateTo(
              '/sub/Order/pages/confirmGoods/confirmGoods?orderId=' +
                this.data.query.id
            )
          }
          this.setData({ isShowConfirmGoods: false })
        })
        .catch(() => {
          this.setData({ isShowConfirmGoods: false })
        })
    } else {
      this.setData({ isShowConfirmGoods: false })
    }
  },
  handleClickPayBtn() {
    if (this.data.clickPay) {
      return
    }
    this.setData(
      {
        clickPay: true,
      },
      () => {
        if (!app.globalData.unexUserToken) {
          apiReload
            .getUnexUserToken(app, app.globalData.openid)
            .then(res => {
              this.bindPayMent()
            })
            .catch(() => {
              wx.showToast({
                title: '网络超时，请稍后再试',
                icon: 'none',
              })
            })
        } else {
          this.bindPayMent()
        }
      }
    )
  },
  bindPayMent() {
    if (
      this.data.orderDetail.isHonghu !== false &&
      this.data.orderDetail['externalOrderId']
    ) {
      return prepayOrderAction(this.data.orderDetail.orderId)
        .then(({ data: { orderPrepay } }) => this.requestPayment(orderPrepay))
        .catch(() => {
          this.data.orderDetail.isHonghu = false
          this.bindPayMent()
        })
    }
    const orderId = this.data.orderDetail.orderId
    const orderTime = this.data.orderDetail.orderDate.replace(/-|:| /g, '')
    let $this = this
    // let data = {
    //   'channelType': 'weixin',
    //   'currency': 'cny',
    //   'extendParams': '{"openid":"' + app.globalData.openid + '",\"spbill_create_ip\":\"127.0.0.1\"}',
    //   'memo': brandName + '-订单号' + orderId,
    //   'orderDesc': brandName + '-订单号' + orderId,
    //   'payAmount': this.data.amount,
    //   'paymentType': 'applet',
    //   'tenantCode': app.globalData.tenantCode,
    //   'tenantOrderNo': orderId,
    //   'tenantOrderTime': orderTime,
    //   'tenantReturnUrl': 'https://casabaplus.baozun.com'
    // }
    let data = {
      channelType: 'weixin',
      currency: 'cny',
      extendParams:
        '{"openid":"' +
        app.globalData.openid +
        '","spbill_create_ip":"127.0.0.1"}',
      memo: orderId,
      orderDesc: orderId,
      payAmount: $this.data.orderDetail.amount,
      //    "pay_sign": "m3gqvBYcgZmSQs71oAg+KNek6orOqTCZDcN89c7btio97duDjzya6MfKtSs8clsukpp2Ca+5u9yvbqErzvsafylvZ47Tl9hZuRWRkd02Ec7+jty7PNxQWJMarOR7UeRTk6Z3chX5cKBH31dAc0Mgl1JUxJzw0kWWqjflvFJbJow=",
      paymentType: 'applet',
      //    "product_type": "",
      tenantCode: app.globalData.tenantCode,
      //    "tenant_expire_time": "",
      tenantOrderNo: orderId,
      tenantOrderTime: orderTime,
      tenantReturnUrl: 'https://casabaplus.baozun.com',
    }
    console.log('订单页支付金额', data.payAmount, $this.data.orderDetail)
    app.http({
      url: '/casaba/trade/payOrder',
      data: data,
      header: {
        xAuthToken: app.globalData.xAuthToken,
        unexUserToken: app.globalData.unexUserToken,
        'invoke-source': app.globalData['invoke-source'],
      },
      success: function(res) {
        console.log('payOrder', res)
        if (res.data.code !== '0') {
          if (res.data.code === '511202112') {
            wx.showModal({
              title: '微信支付',
              content: '卖家还没开通微信支付，请联系卖家',
              showCancel: false,
              success: () => {
                wx.redirectTo({
                  url:
                    '/sub/Pay/pages/againMoney/againMoney?orderId=' + orderId,
                })
                $this.setData({
                  clickPay: false,
                })
              },
            })
          } else {
            wx.showModal({
              title: '微信支付',
              content: res.data.msg || res.data.errMsg || '服务器出错',
              showCancel: false,
              success: () => {
                wx.redirectTo({
                  url:
                    '/sub/Pay/pages/againMoney/againMoney?orderId=' + orderId,
                })
                $this.setData({
                  clickPay: false,
                })
              },
            })
          }
          $this.setData({ clickPay: false })
        } else {
          // 发起支付
          $this.requestPayment({
            timeStamp: res.data.data.weixin_timestamp,
            nonceStr: res.data.data.weixin_nonce_str,
            package: res.data.data.weixin_wx_package,
            signType: 'MD5',
            paySign: res.data.data.weixin_sign,
          })
        }
      },
      fail: function(res) {
        $this.setData({ clickPay: false })
        console.log('支付失败', res)
      },
    })
  },
  requestPayment(payment) {
    wx.requestPayment({
      ...payment,
      fail: res => {
        console.log('支付', res)
        if (res.errMsg.split(' ')[1] === 'cancel') {
          wx.showToast({
            title: '取消支付',
            icon: 'none',
            duration: 2000,
          })
        } else {
          wx.showModal({
            title: '调用支付失败',
            content: res.err_desc || res,
          })
        }
        wx.redirectTo({
          url:
            '/sub/Pay/pages/againMoney/againMoney?orderId=' +
            this.data.orderDetail.orderId,
        })
      },
      success: () => {
        wx.showToast({
          title: '支付成功',
          icon: 'success',
          duration: 2000,
        })
        setTimeout(() => {
          wx.redirectTo({
            url:
              '/sub/Pay/pages/paysuccess/paysuccess?orderId=' +
              this.data.orderDetail.orderId +
              '&receivedAmount=' +
              this.data.orderDetail.amount +
              '&iphone=' +
              this.data.orderDetail.orderReceiptInfoOut.mobile,
          })
          // resolve(res)
        }, 2000)
      },
      complete: () => {
        this.setData({ clickPay: false })
      },
    })
  },
  bindCancelOrder() {
    this.setData({ isShowCancelOrder: true })
  },
  bindQueryproduct(product) {
    const skuOProductList = this.data.skuOProductList
    let datas = {
      tenantCode: app.globalData.tenantCode,
      spuCode: product.spuCode,
    }
    app.http({
      url: '/pim/solr/item/getItemDetailV1',
      data: datas,
      success: res => {
        console.log('product', product)
        let result = res.data.data
        const skuList = result.skuList.filter(item => {
          return product.skuId === item.code
        })
        skuOProductList.push(result)
        const data = this.data
        data.skuList.unshift(skuList[0])
        data.skuOProductList = skuOProductList
        this.setData(data)
      },
      fail: function(res) {
        console.log('res', res)
      },
    })
  },
  logisticsJump() {
    if (
      this.data.orderDetail.orderStatus === '31' ||
      this.data.orderDetail.ordertype === '31' ||
      !this.data.showLogistic
    ) {
      return false
    }
    let orderId = this.data.orderDetail.orderId
    let orderDate = this.data.orderDetail.orderDate
    app.router.navigateTo(
      `/sub/Order/pages/stateLogistics/stateLogistics?orderId=${orderId}&orderDate=${orderDate}`
    )
  },
  // 物流信息查询
  stateLogis(orderNumber) {
    let $this = this
    let data = {
      orderNumber: orderNumber,
      tenantCode: app.globalData.tenantCode,
    }
    app.http(
      {
        url: '/express/getExpressDetails',
        data: data,
        header: {
          // 'invoke-source': app.globalData['invoke-source']
          // 'content-type': 'application/x-www-form-urlencoded',
          // 'xAuthToken': app.globalData.xAuthToken
        },
        success: function(res) {
          let list = []
          let logistics = []
          let showLogistic = false
          if ($this.data.orderDetail.orderStatus) {
            // 虚拟商品 无待发货状态
            list.push({
              context:
                $this.data.orderDetail.orderStatusName || '您的订单正在处理',
              time: $this.data.orderDetail.orderDate,
            })
          }

          if (Object.keys(res.data.data).length > 0) {
            logistics = [...res.data.data.data, ...list]
            showLogistic = !!res.data.data.companyName
          } else {
            logistics = list
          }
          $this.setData({
            logistics: logistics,
            showLogistic: showLogistic,
          })
        },
        fail: function(res) {},
      },
      false
    )
  },
  handleServiceBtns({ currentTarget: { dataset } }) {
    // 待发货 || 非虚拟商品
    if (
      this.data.orderDetail.orderStatus === '31' ||
      this.data.orderDetail.ordertype === '31'
    ) {
      this.handleRefund(dataset, '31')
    } else if (
      this.data.orderDetail.orderStatus === '41' ||
      this.data.orderDetail.orderStatus === '51' ||
      this.data.orderDetail.orderStatus === '61' ||
      this.data.orderDetail.orderStatus === '71'
    ) {
      this.handleRejectedProduct(dataset, this.data.orderDetail.orderStatus)
    }
  },
  noop() {
    console.log(1)
  },
  handleRefund(dataset, orderStatus) {
    let targetObj = {
      orderStatus: orderStatus,
      orderId: this.data.orderDetail.orderId,
    }
    if (this.data.isMajorCustomer) {
      targetObj.prods = this.data.productlist.map(item => {
        return {
          id: item.id,
          count: item.count,
        }
      })
      targetObj.amount = this.data.orderDetail.amount
    }
    wx.setStorageSync(
      'refundOrder',
      JSON.stringify(Object.assign({}, dataset.item, targetObj))
    )
    if (this.data.isMajorCustomer) {
      if (
        !this.data.orderRefund ||
        this.data.orderRefund.statusNameBak === '申请退款'
      ) {
        wx.redirectTo({
          url: `/sub/AfterSales/pages/rejectedGoods/rejectedGoods?mode=0`,
        })
      } else {
        wx.redirectTo({
          url: `/sub/AfterSales/pages/refundsDetails/refundsDetails?returnId=${
            this.data.orderRefund.returnId
          }&orderId=${this.data.orderRefund.orderId}`,
        })
      }
    } else {
      if (!dataset.item.btnText || dataset.item.btnText === '申请退款') {
        wx.redirectTo({
          url: `/sub/AfterSales/pages/rejectedGoods/rejectedGoods?mode=0`,
        })
      } else {
        wx.redirectTo({
          url: `/sub/AfterSales/pages/refundsDetails/refundsDetails?returnId=${
            dataset.item.returnId
          }&orderId=${this.data.orderRefund.orderId}`,
        })
      }
    }
  },
  // 申请退货
  handleRejectedProduct(dataset, orderStatus) {
    // 申请退货的商品
    let targetObj = {
      orderStatus: orderStatus,
      orderId: this.data.orderDetail.orderId,
    }
    if (this.data.isMajorCustomer) {
      targetObj.prods = this.data.productlist.map(item => {
        return {
          id: item.id,
          count: item.count,
        }
      })
      targetObj.amount = this.data.orderDetail.amount
    }
    wx.setStorageSync(
      'refundOrder',
      JSON.stringify(Object.assign({}, dataset.item, targetObj))
    )
    let url = ''
    if (this.data.isMajorCustomer) {
      if (!this.data.orderRefund || this.data.orderRefund.status === '71') {
        url = '/sub/AfterSales/pages/applyService/applyService'
      } else {
        url = `/sub/AfterSales/pages/rejectedGoodsDetail/rejectedGoodsDetail?returnId=${
          this.data.orderRefund.returnId
        }&orderId=${this.data.orderRefund.orderId}`
      }
    } else {
      if (!dataset.item.status || dataset.item.status === '71') {
        url = '/sub/AfterSales/pages/applyService/applyService'
      } else {
        url = `/sub/AfterSales/pages/rejectedGoodsDetail/rejectedGoodsDetail?returnId=${
          dataset.item.returnId
        }&orderId=${this.data.orderRefund.orderId}`
      }
    }
    app.router.navigateTo(url)
  },
  gotoPintuanDetail() {
    const {
      team: { orderCode, id: teamId, campaignType },
    } = this.data
    let query
    if (campaignType === 'CASH_BACK') {
      query = queryString({
        orderId: orderCode,
        teamId: teamId,
      })
      app.router.navigateTo(
        `/honghu/pages/pintuanCashBack/detail/index?${query}`
      )
    } else {
      query = queryString({
        orderId: orderCode,
        teamId: teamId,
      })
      app.router.navigateTo(
        `/sub/Marketing/pages/pintuanDetail/pintuanDetail?${query}`
      )
    }
  },
  getTeamMembers(members, creator) {
    let currentMembers = []
    if (members.some(member => member.code === creator.code)) {
      currentMembers = members
    } else {
      currentMembers = [creator].concat(members)
    }
    return currentMembers.map(item => {
      return {
        code: item.code,
        avatarUrl: item.avatarUrl,
        isCreator: item.code === creator.code,
      }
    })
  },
  getOrderDetail(id) {
    return getOrderCodesAction(id).then(response => {
      let order = response[0]
      const teamMember = this.getTeamMembers(
        order.team.members,
        order.team.creator
      )
      this.setData({
        team: {
          orderCode: order.code,
          orderId: order.id,
          orderStatus: order.status,
          id: order.team.id,
          campaignType: order.team.campaign.type,
          endedAt: order.team.endedAt,
          isCreated: order.team.status === TEAM_STATUS_KEY.CREATED,
          isStart:
            order.team.status === TEAM_STATUS_KEY.STARTED &&
            order.status === HONGHU_ORDER_STATUS_KEY.PAID,
          isSuccess: order.team.status === TEAM_STATUS_KEY.ENDED,
          isFailed: order.team.status === TEAM_STATUS_KEY.FAILED,
          totalPeopleNumber: order.team.limitNumber,
          remainingPeopleNumber: order.team.limitNumber - teamMember.length,
          orderStatusText:
            order.status === HONGHU_ORDER_STATUS_KEY.CANCELED
              ? '已取消'
              : order.status === HONGHU_ORDER_STATUS_KEY.CREATED
                ? '待支付'
                : TEAM_STATUS[order.team.status],
          status: order.team.status,
        },
      })
    })
  },
  refreshCountdown() {
    this.setData(
      {
        team: {
          isStart: false,
        },
      },
      () => this.handleReload()
    )
  },
  onShareAppMessage() {
    return {
      title: this.data.skuOProductList[0].title,
      imageUrl: this.data.productlist[0].image,
      path: `/sub/Marketing/pages/pintuanDetail/main?orderId=${
        this.data.orderDetail.orderId
      }&teamId=${this.data.team.id}`,
    }
  },
  payPintuanOrder() {
    const { minutes, seconds } = this.data.remainingTime
    if (
      this.data.team.orderStatus === 'CREATED' &&
      minutes === '00' &&
      seconds === '00'
    ) {
      return this.handleReload()
    }
    this.setData({ clickPay: true }, () =>
      new Promise((resolve, reject) =>
        prepayPintuanOrderAction(this.data.team.orderId).then(prepay =>
          wx.requestPayment({
            ...prepay,
            success: () => showToast({ title: '支付成功', complete: resolve }),
            fail: () => showToast({ title: '支付失败', complete: reject }),
          })
        )
      )
        .then(() =>
          this.setData({ clickPay: false }, () => this.handleReload())
        )
        .catch(() => this.setData({ clickPay: false }))
    )
  },
  getStoreDetails() {
    if (this.data.orderDetail.storeCode) {
      getStoreDetail(app.globalData.tenantCode, this.data.orderDetail.storeCode)
        .then(res => {
          if (res.data) {
            this.setData({
              storeDetails: res.data,
            })
          }
        })
        .catch(() => {})
    }
  },
  handleShowPreengage: function() {
    this.setData({
      isShowPreengage: true,
    })
  },
  handleHidePreengage({ currentTarget: { dataset } }) {
    if (dataset.type === 'confirm') {
      this.setData({ isShowPreengage: false })
      this.handleMakePhoneCall()
    } else {
      this.setData({ isShowPreengage: false })
    }
  },
  handleHideCancelOrder({ currentTarget: { dataset } }) {
    if (dataset.type === 'confirm') {
      this.setData({ isShowCancelOrder: false })
      let $this = this
      app.http({
        url: '/businesslayer/orderIntegration/cancelOrder',
        data: {
          tenantCode: app.globalData.tenantCode,
          orderId: $this.data.orderDetail.orderId,
        },
        header: {
          xAuthToken: app.globalData.xAuthToken,
        },
        success: res => {
          if (Object.is(res.data.head.code, '0')) {
            const route = getCurrentPages()
            if (route[route.length - 2].pubRefresh) {
              route[route.length - 2].pubRefresh()
            }
            // this.initLoad()
            this.setData({
              isNotComple: false,
            })
          }
        },
        fail: function(res) {
          console.log('res', res)
        },
      })
    } else {
      this.setData({ isShowCancelOrder: false })
    }
  },
  handleMakePhoneCall: throttle(function() {
    wx.makePhoneCall({
      phoneNumber: this.data.storeDetails.phone,
    })
  }, 100),
})
