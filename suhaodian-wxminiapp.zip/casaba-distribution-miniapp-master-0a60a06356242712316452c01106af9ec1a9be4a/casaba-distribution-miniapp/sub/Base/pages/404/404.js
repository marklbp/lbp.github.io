const app = getApp()
Page({
  onShow() {},
  handleGoHome() {
    app.router.navigateTo('/pages/home/home')
  },
})
