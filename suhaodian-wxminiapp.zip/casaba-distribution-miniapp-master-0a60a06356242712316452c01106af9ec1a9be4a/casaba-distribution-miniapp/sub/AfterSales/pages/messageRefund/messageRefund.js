// 未使用
import { createRefundment } from '../../../../api/index.js'
import queryString from '../../../../utils/query-string'

const app = getApp()

Page({
  data: {
    orderId: '',
    orderDetail: null,
    productlist: [],
    count: 1, // 申请件数
    money: '', // 申请金额
    limitMaxCount: 1, // 申请最大数量限制
    limitMaxMoney: 0, // 申请最大金额限制
    refundDesc: '', // 退款说明
    parcelMask: false,
    parcelStatus: ['未收到货', '已经收到货'],
    currentParcelStatus: [],
    _currentParcelStatus: '',
    reasonsMask: false,
    reasonList: [
      '不喜欢/不想要',
      '空包裹',
      '快递/物流一直未送到',
      '快递/物流无跟踪记录',
      '货物破损已拒签',
    ],
    currentReason: [],
    _currentReason: '',
    postLoading: false,
  },

  onLoad: function(query) {
    this.setData({ orderId: query.orderId })
    wx.getStorage({
      key: 'refundOrder',
      success: res => {
        const _data = JSON.parse(res.data)
        console.log(_data)
        this.setData({
          money: (_data.amount - _data.freight).toFixed(2),
          orderDetail: _data,
          productlist: _data.orderPorductOutList,
        })
      },
    })
  },
  onChangeCount({ detail }) {
    this.setData({
      count: detail.value,
    })
  },

  // 货物状态
  handleOpenParcelSheet() {
    this.setData({
      parcelMask: true,
    })
  },
  onParcelCancel() {
    this.setData({
      parcelMask: false,
    })
  },
  onParcelChange({ detail }) {
    if (detail.checked) {
      this.setData({
        currentParcelStatus: [detail.value],
        _currentParcelStatus: detail.value,
      })
    } else {
      this.setData({
        currentParcelStatus: [],
        _currentParcelStatus: '',
      })
    }
  },

  // 退款原因
  handleOpenReasonSheet() {
    this.setData({
      reasonsMask: true,
    })
  },
  onReasonCancel() {
    this.setData({
      reasonsMask: false,
    })
  },
  onReasonChange({ detail }) {
    if (detail.checked) {
      this.setData({
        currentReason: [detail.value],
        _currentReason: detail.value,
      })
    } else {
      this.setData({
        currentReason: [],
        _currentReason: '',
      })
    }
  },

  // 申请金额
  handleInputMoney({ detail }) {
    this.setData({
      money: detail.value,
    })
  },
  handleInputBlur({ detail }) {
    let value = detail.value
    if (value > this.data.limitMaxMoney) {
      value = this.data.limitMaxMoney
    }
    this.setData({
      money: value,
    })
  },
  // 退款说明 选填
  handleRefundDesc({ detail }) {
    this.setData({
      refundDesc: detail.value,
    })
  },

  handlePost() {
    const returnProduct = this.data.productlist.map(prod => {
      return {
        count: prod.count,
        description: this.data._currentReason,
        orderProdureId: prod.id,
      }
    })
    let data = {
      isInvoice: '0',
      orderId: this.data.orderDetail.orderId,
      orderReturnLineCreateInfoIns: returnProduct,
      pickupMode: '21',
      returnMode: '41', // 仅退款
      tenantCode: app.globalData.tenantCode,
    }
    if (this.data.refundDesc) {
      data.description = this.data.refundDesc
    }
    this.setData({
      postLoading: true,
    })
    createRefundment(data, {
      xAuthToken: app.globalData.xAuthToken,
    })
      .then(res => {
        if (res.code === '0') {
          const route = getCurrentPages()
          if (route[route.length - 2].pubRefresh) {
            route[route.length - 2].pubRefresh()
          }
          const query = queryString({
            returnId: res.data,
            orderId: this.data.orderId,
          })
          app.router.redirectTo(
            `/sub/AfterSales/pages/refundsDetails/refundsDetails?${query}`
          )
        } else {
          wx.showToast({
            title: res.message,
            icon: 'none',
            duration: 3000,
          })
        }
        this.setData({ postLoading: false })
      })
      .catch(err => {
        this.setData({ postLoading: false })
        console.error(err)
      })
  },
})
