import link from '../../utils/link'
Component({
  properties: {
    carouselList: {
      type: Array,
      value: [],
      observer: function(list, oldList) {
        if (oldList.length) return
        this.observerList(list)
      },
    },
    content: Object,
    type: {
      type: String,
      value: 'broadcast',
    },
    padding: {
      type: Boolean,
      value: false,
    },
  },
  data: {
    _carouselList: [],
    maxHeight: 0,
    nextMarin: {
      broadcast: 0,
      broadcastTwoShow: 140,
      broadcastThreeShow: 144,
    },
    previousMarin: {
      broadcast: 0,
      broadcastTwoShow: 0,
      broadcastThreeShow: 144,
    },
    swiperCurrent: 0, // 用于自定义的指示点，此处为激活的指示点位置
  },

  methods: {
    observerList(list) {
      const { type } = this.data
      const _list = JSON.parse(JSON.stringify(list))
      let item
      // 2裁剪：最小高度，1留白：最大高度
      if (this.data.content.fileWay === '2') {
        item = _list.sort(
          (a, b) =>
            a.content.width / a.content.height -
            b.content.width / b.content.height
        )[0].content
      } else {
        item = _list.sort(
          (a, b) =>
            b.content.height / b.content.width -
            a.content.height / a.content.width
        )[0].content
      }
      try {
        const systemInfo = wx.getSystemInfoSync()
        this.calculationMaxHeight(
          this.data.type,
          this.data.padding,
          systemInfo,
          item
        )
      } catch (error) {
        this.calculationMaxHeight(
          this.data.type,
          this.data.padding,
          {
            windowWidth: 375,
          },
          item
        )
      }
      if (
        (type === 'broadcastThreeShow' || type === 'broadcastTwoShow') &&
        list.length === 2
      ) {
        list = list.concat(list)
      }
      this.setData({
        _carouselList: list,
      })
    },
    pubRefresh() {
      this.observerList(this.data.carouselList)
    },
    handleJump({ currentTarget }) {
      console.log('轮播图======', currentTarget.dataset.item.content)
      const { swiper2Url } = currentTarget.dataset.item.content
      link.bind(this, currentTarget.dataset.item.content, swiper2Url)()
    },
    swiperChange({ detail }) {
      this.setData({
        swiperCurrent: detail.current,
      })
    },
    rpxToPx(windowWidth) {
      return windowWidth / 750
    },
    calculationMaxHeight(type, hasPadding, systemInfo, imageInfo) {
      let padding = 0
      let margin = 0
      let w = systemInfo.windowWidth
      const PX = this.rpxToPx(w)
      if (type === 'broadcast') {
        if (hasPadding) {
          padding = 40 * PX
          w = w - padding
        }
      }
      if (type === 'broadcastTwoShow') {
        if (hasPadding) {
          padding = 40 * PX
          margin = 150 * PX
          w = w - padding - margin
        } else {
          margin = 140 * PX
          w = w - margin
        }
      }
      if (type === 'broadcastThreeShow') {
        if (hasPadding) {
          padding = 20 * PX
          margin = 134 * 2 * PX
          w = w - padding - margin
        } else {
          margin = 144 * 2 * PX
          w = w - margin
        }
      }
      this.setData({
        maxHeight: (Math.round(w) / imageInfo.width) * imageInfo.height,
      })
    },
  },
})
