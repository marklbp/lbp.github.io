/* global Component */
Component({
  externalClasses: [
    'u-class',
    'u-class-mask',
    'u-class-header',
    'u-class-custom',
  ],
  options: {
    multipleSlots: true,
  },
  properties: {
    visible: {
      type: Boolean,
      value: false,
    },
    maskClosable: {
      type: Boolean,
      value: true,
    },
    actions: {
      type: Array,
      value: [],
    },
    showClose: {
      type: Boolean,
      value: false,
    },
    closeInside: {
      type: Boolean,
      value: false,
    },
    showCancel: {
      type: Boolean,
      value: true,
    },
    cancelText: {
      type: String,
      value: '取消',
    },
    header: {
      // 是否传了slot-header
      type: Boolean,
      value: false,
    },
    custom: {
      // 是否传了slot-custom
      type: Boolean,
      value: false,
    },
    customContent: {
      // 是否传了slot-custom-content
      type: Boolean,
      value: false,
    },
    topHeight: {
      type: Number,
      value: 0,
    },
  },

  methods: {
    doNonthing() {},
    handleActionItem({ currentTarget }) {
      const dataset = currentTarget.dataset || {}
      const { index } = dataset
      this.triggerEvent('click', { index })
    },
    handleMask() {
      if (!this.data.maskClosable) return
      this.handleCancel()
    },
    handleCancel() {
      this.triggerEvent('cancel')
    },
  },
})
