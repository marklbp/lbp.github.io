import hh from '../../../../honghuStore/request'
import { getDiscountDetail } from './gql'
import {
  detectionTime,
  getRemainingTime,
  fixIOSDate,
  periodTime,
} from '../../utils/util'

const STATUS = {
  CREATED: 'CREATED',
  IN_PROGRESS: 'IN_PROGRESS',
  ENDED: 'ENDED',
  STOPPED: 'STOPPED',
}

const TIMETYPE = {
  FIXED: 'FIXED', // 固定时间
  PERIOD_DAILY: 'PERIOD_DAILY', // 每天重复
  PERIOD_MONTHLY: 'PERIOD_MONTHLY', // 每月重复
  PERIOD_WEEKLY: 'PERIOD_WEEKLY', // 每周重复
}

Component({
  properties: {
    cid: Number,
    ctype: String,
    commodityList: {
      type: Array,
      value: [],
    },
    mode: {
      type: String,
      value: 'listLineTwo',
    },
    content: {
      type: Object,
      value: null,
      observer: function(newVal) {
        this.setData({
          content: newVal,
        })
      },
    },
  },
  data: {
    _commodityList: [],
    loading: false,
    done: false,
    timer: null,
  },
  attached() {
    this.setData({ loading: true, done: false })
    this.initLoad(this.data.commodityList)
  },
  methods: {
    initLoad(cacheProductList) {
      if (this.data.timer) {
        clearInterval(this.data.timer)
      }
      const {
        spellGoodsType,
        autoSelectsort,
        autoSelectNum,
        autohideFailAct,
        spellActityType,
      } = this.data.content
      hh(getDiscountDetail({ code: spellActityType.id })).then(res => {
        const discountInfo = res.data.byCode
        const discountProductList = discountInfo.spus
        if (spellGoodsType === '2') {
          const finalProductList = this.spuGroup(
            discountInfo,
            discountProductList
          )
          this.sortProduct(finalProductList, autoSelectsort)
          this.showProduct(
            this.filterSoldOut(finalProductList, autohideFailAct),
            autoSelectNum
          )
        } else {
          // 手动选择
          const selectProductList = cacheProductList
            .map(cp => {
              return discountProductList.find(
                dp => cp.goodsInfo.code === dp.product.spuCode
              )
            })
            .filter(f => !!f)
          const finalProductList = this.spuGroup(
            discountInfo,
            selectProductList
          )
          this.showProduct(
            this.filterSoldOut(finalProductList, autohideFailAct),
            -1
          )
        }
      })
    },
    pubRefresh() {
      this.setData({ done: false })
      let _commodityList = this.data._commodityList
      if (this.data.commodityList.length) {
        _commodityList = this.data.commodityList
      }
      this.initLoad(_commodityList)
    },
    pubClearTimer() {
      // 当页面被卸载的时候清除掉计时器
      clearInterval(this.data.timer)
    },
    pricePrecision(price, precision) {
      let _price = String(price)
      if (_price[0] === '0') {
        price =
          precision === 2
            ? price.toFixed(2)
            : precision === 1
              ? _price[2] === '0'
                ? price.toFixed(2)
                : price.toFixed(1) + '0'
              : price.toFixed(1) + '0'
      } else {
        price =
          price.toFixed(precision) +
          `${precision === 0 ? '.00' : precision === 1 ? '0' : ''}`
      }
      return price
    },
    spuGroup(info, productList) {
      return productList.map(p => {
        const netqty = p.product.skus.reduce((s, c) => (s += c.netqty), 0)
        let limitPrice = (Number(p.product.salePrice) * Number(p.discount)) / 10
        // 抹角、分，补零
        limitPrice = this.pricePrecision(
          limitPrice,
          info.discountPricePrecision
        )
        return {
          code: info.code,
          limitCount: info.limitCount,
          availablePeriod: info.availablePeriod,
          status: info.status,
          timeType: info.timeType,
          periodPoints: info.periodPoints,
          spuCode: p.product.spuCode,
          name: p.product.name,
          picUrl: p.product.pics[0].picUrl,
          salePrice: limitPrice,
          listPrice: p.product.salePrice.toFixed(2),
          listTime: p.product.listTime,
          netqty,
        }
      })
    },
    sortProduct(productList, type) {
      if (type === 'newShelve') {
        productList.sort(
          (a, b) =>
            new Date(fixIOSDate(b.listTime)) - new Date(fixIOSDate(a.listTime))
        )
      } else if (type === 'priHighToLow') {
        productList.sort((a, b) => b.salePrice - a.salePrice)
      } else if (type === 'priLowToHigh') {
        productList.sort((a, b) => a.salePrice - b.salePrice)
      }
    },
    filterSoldOut(productList, isHide) {
      let filteredProduct = []
      if (isHide) {
        filteredProduct = productList.filter(
          p =>
            p.netqty &&
            (p.status === STATUS.CREATED || p.status === STATUS.IN_PROGRESS)
        )
      } else {
        filteredProduct = productList.filter(
          p =>
            p.status === STATUS.CREATED ||
            p.status === STATUS.IN_PROGRESS ||
            p.status === STATUS.ENDED
        )
      }
      return filteredProduct.map(p => this.reducer(p))
    },
    showProduct(filteredProduct, limitShowNum) {
      this.setData({
        loading: false,
        done: true,
        _commodityList: ~limitShowNum
          ? filteredProduct.splice(0, limitShowNum)
          : filteredProduct,
      })
      this.countDown()
    },
    countDown() {
      // 为每个活动即每个商品设置倒计时
      const timer = setInterval(() => {
        const arr = this.data._commodityList
        arr.forEach(a => {
          const now = new Date()
          let _start = a.goodsInfo.availablePeriod.start
          let _end = a.goodsInfo.availablePeriod.end
          if (a.goodsInfo.status === STATUS.CREATED) {
            if (a.goodsInfo.timeType === TIMETYPE.PERIOD_DAILY) {
              _start = periodTime(now, new Date(_start))
            } else if (a.goodsInfo.timeType === TIMETYPE.PERIOD_WEEKLY) {
              _start = periodTime(
                now,
                new Date(_start),
                'weekly',
                a.goodsInfo.periodPoints
              )
            } else if (a.goodsInfo.timeType === TIMETYPE.PERIOD_MONTHLY) {
              _start = periodTime(
                now,
                new Date(_start),
                'monthly',
                a.goodsInfo.periodPoints
              )
            }
            const r = getRemainingTime(now, _start, true)
            if (detectionTime(r)) {
              clearInterval(timer)
              // 延迟100ms，防止服务端状态未更新
              setTimeout(() => {
                this.initLoad(this.data.commodityList)
              }, 100)
              return
            }
            a.goodsInfo.remainingTime = r
          } else if (a.goodsInfo.status === STATUS.IN_PROGRESS) {
            if (a.goodsInfo.timeType === TIMETYPE.PERIOD_DAILY) {
              _end = periodTime(now, new Date(_end))
            } else if (a.goodsInfo.timeType === TIMETYPE.PERIOD_WEEKLY) {
              _end = periodTime(
                now,
                new Date(_end),
                'weekly',
                a.goodsInfo.periodPoints
              )
            } else if (a.goodsInfo.timeType === TIMETYPE.PERIOD_MONTHLY) {
              _end = periodTime(
                now,
                new Date(_end),
                'monthly',
                a.goodsInfo.periodPoints
              )
            }
            const r = getRemainingTime(now, _end, true)
            if (detectionTime(r)) {
              clearInterval(timer)
              // 延迟100ms，防止服务端状态未更新
              setTimeout(() => {
                this.initLoad(this.data.commodityList)
              }, 100)
              return
            }
            a.goodsInfo.remainingTime = r
          }
        })
        this.setData({ _commodityList: arr })
      }, 1000)
      this.setData({ timer })
    },
    reducer(source) {
      // 将数据进行转换
      const now = new Date()
      let remainingTime = {
        day: '00',
        hours: '00',
        minutes: '00',
        seconds: '00',
      }
      if (source.status === STATUS.CREATED) {
        let _start = source.availablePeriod.start
        if (source.timeType === TIMETYPE.PERIOD_DAILY) {
          _start = periodTime(now, new Date(_start))
        } else if (source.timeType === TIMETYPE.PERIOD_WEEKLY) {
          _start = periodTime(
            now,
            new Date(_start),
            'weekly',
            source.periodPoints
          )
        } else if (source.timeType === TIMETYPE.PERIOD_MONTHLY) {
          _start = periodTime(
            now,
            new Date(_start),
            'monthly',
            source.periodPoints
          )
        }
        remainingTime = getRemainingTime(now, _start, true)
      } else if (source.status === STATUS.IN_PROGRESS) {
        let _end = source.availablePeriod.end
        if (source.timeType === TIMETYPE.PERIOD_DAILY) {
          _end = periodTime(now, new Date(_end))
        } else if (source.timeType === TIMETYPE.PERIOD_WEEKLY) {
          _end = periodTime(now, new Date(_end), 'weekly', source.periodPoints)
        } else if (source.timeType === TIMETYPE.PERIOD_MONTHLY) {
          _end = periodTime(now, new Date(_end), 'monthly', source.periodPoints)
        }
        remainingTime = getRemainingTime(now, _end, true)
      }
      return {
        goodsInfo: {
          ...source,
          remainingTime,
        },
      }
    },
    handleViewMore() {
      const { path } = this.content
      if (path) {
        this.triggerEvent('jump', { url: path })
      }
    },
    handleJump({ currentTarget }) {
      const { spuCode } = currentTarget.dataset.item
      if (spuCode) {
        this.triggerEvent('jump', {
          url: `/honghu/pages/discount/pdp/index?scene=${spuCode}`,
        })
      }
    },
  },
})
