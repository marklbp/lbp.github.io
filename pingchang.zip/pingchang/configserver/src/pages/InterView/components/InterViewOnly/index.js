import InterViewOnly from './InterViewOnly';

export default InterViewOnly;
