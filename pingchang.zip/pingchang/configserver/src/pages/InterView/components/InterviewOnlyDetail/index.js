import InterviewOnlyDetail from './InterviewOnlyDetail';

export default InterviewOnlyDetail;
