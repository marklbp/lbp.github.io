/*
* @Author: mengxiaofei
* @Date:   2019-01-23 11:33:01
* @Last Modified by:   xiaofei.meng_tic
* @Last Modified time: 2019-03-14 16:05:12
*/
const app = getApp()
Component({
  externalClasses: ['u-class'],
  properties: {
    customStyle: {
      type: Object,
      value: {},
    },
  },
  data: {
    url: '',
  },
  attached() {
    let customSeting = app.globalData.customSeting
    if (customSeting) {
      if (customSeting.defaultLogo === '1' && customSeting.logoUrl) {
        if (customSeting.logoUrl.indexOf('http') > -1) {
          this.setData({
            url: app.globalData.customSeting.logoUrl,
          })
        } else {
          this.setData({
            url:
              'https://product-res.baozun.com/' +
              app.globalData.customSeting.logoUrl,
          })
        }
      }
    } else {
      app.customCallback = data => {
        app.globalData.customSeting = data
        if (data.defaultLogo === '1' && data.logoUrl) {
          if (data.logoUrl.indexOf('http') > -1) {
            this.setData({
              url: data.logoUrl,
            })
          } else {
            this.setData({
              url: 'https://product-res.baozun.com/' + data.logoUrl,
            })
          }
        }
      }
    }
  },
})
